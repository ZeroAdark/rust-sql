"""Freeze the completed build, pressure and performance screen without retaining the candidate."""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile

if not __debug__:
    raise RuntimeError('Assertions must remain enabled')
base = Path('/home/rustsql')
workspace = Path('/mnt/c/Users/DarkMoon/Desktop/Rust SQL')
target = workspace / 'pgrust/artifacts/validation/known-budget-reclaim-2026-10-31'
review = json.loads((base / 'known-budget-performance-review-20261031.json').read_text())
assert review['evidence_valid'] and set(review['phases']) == {'medium', 'capacity', 'medium-1g'}
assert review['timed_statements'] == 1_812_600
target.mkdir(exist_ok=False)
files = {}

def add(path, name=None):
    assert path.is_file(), path
    key = name or path.relative_to(base).as_posix()
    assert key not in files
    files[key] = path

for pattern in ('known-budget-build-20261031', 'known-budget-pressure-20261031*',
                'known-budget-medium-20261031*', 'known-budget-capacity-20261031*',
                'known-budget-medium-1g-20261031*', 'known-budget-screen-20261031.json',
                'known-budget-*-review-independent-20261031.json', 'known-budget-performance-review-20261031.json'):
    for path in sorted(base.glob(pattern)):
        if path.is_dir():
            for member in sorted(path.rglob('*')):
                if member.is_file() and '__pycache__' not in member.parts:
                    add(member)
        else:
            add(path)
pressure = json.loads((base / 'known-budget-pressure-20261031-summary.json').read_text())
for entry in pressure['trials']:
    trial = json.loads((base / (entry['name'] + '.json')).read_text())
    for filename in ('initdb.log', 'server.log'):
        add(Path(trial['cluster']) / filename, entry['name'] + '-cluster/' + filename)
for key in review['phases']:
    label = 'known-budget-' + key + '-20261031'
    phase = review['phases'][key]['phase']
    summary = json.loads((base / label / 'summary.json').read_text())
    for item in summary['trials']:
        name = f"{phase}-{item['engine']}-{item['repetition']}"
        d = json.loads((base / label / (name + '.json')).read_text())
        for filename in ('initdb.log', 'server.log'):
            add(Path(d['cluster']) / filename, label + '-cluster/' + name + '/' + filename)
for filename in ('build_known_budget_candidate.py', 'prepare_known_budget_checks.py', 'run_known_budget_pressure.py',
                 'run_known_budget_performance.py', 'screen_known_budget.py', 'after_known_budget_build.py',
                 'audit_known_budget_pressure.py', 'review_known_budget_performance.py', 'known_budget_design.json',
                 'freeze_known_budget_evidence.py', 'replay_known_budget_reclaim.py'):
    add(workspace / filename, 'controllers/' + filename)
archive = target / 'evidence.tar.xz'
with tarfile.open(archive, 'w:xz') as handle:
    for name, path in files.items():
        handle.add(path, arcname=name)
manifest = {'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'members': {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}}
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(target / 'results.json').write_text(json.dumps(review, indent=2) + '\n')
assessment = {'decision': 'advance-to-runtime-validation' if review['all_requested_preservation_guards_pass'] else 'rejected',
              'promoted': False, 'production_qualified': False,
              'candidate_sha256': 'f7f033774c2c37157eb633045ff6bbc6f1956a96b370bcbae6e03e211abca220',
              'accepted_sha256': '0be60915b40c9f70f39dcb3a0fd1f8918608a20095f767ec081a5b5320caa277',
              'pressure_candidate_passes': 6, 'performance_preservation_passed': review['all_requested_preservation_guards_pass'],
              'remaining': ['SQL/isolation/protocol and recovery checks on this exact binary', 'positive-budget sort checks',
                            'PostgreSQL memory/read/update parity', 'broader production operational gates']}
(target / 'retention-assessment.json').write_text(json.dumps(assessment, indent=2) + '\n')
shutil.copyfile(workspace / 'review_known_budget_performance.py', target / 'performance_checks.py')
shutil.copyfile(workspace / 'replay_known_budget_reclaim.py', target / 'replay.py')
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size, 'members': len(files)}))
