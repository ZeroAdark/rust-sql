"""Review the completed known-budget pressure campaign without rerunning SQL."""
from pathlib import Path
import hashlib
import json

base = Path('/home/rustsql')
campaign = 'known-budget-pressure-20261031'
summary = json.loads((base / (campaign + '-summary.json')).read_text())
assert summary['complete'] and len(summary['trials']) == 12
build = json.loads((base / 'known-budget-build-20261031/report.json').read_text())
assert build['passed']
candidate = build['binaries']['postgres']['sha256']
sort = '1617e17e9ee2e6e0a614c994459558f80ed98ada447da0a83dd521398abd057f'
counts = dict(trials=0, passes=0, candidate_passes=0, successful_sorts=0, watchdog_cancellations=0, oom_trials=0)
for item in summary['trials']:
    d = json.loads((base / (item['name'] + '.json')).read_text())
    is_candidate = item['variant'].startswith('candidate')
    executable = candidate if is_candidate else '07b16e1aa4f0e2206c37b339b6e4cc813aa8ab9e3c5516334f753b3d90d0c536' if item['variant'] == 'postgresql' else '0be60915b40c9f70f39dcb3a0fd1f8918608a20095f767ec081a5b5320caa277'
    assert d['binary_sha256'] == executable
    assert d['durability'] == ['on', 'on'] and d['memory_mib'] == 1024 and d['cycles'] == 12
    assert d['parent_memory_max'] == str(4 * 2**30)
    assert d['limits']['memory.max'] == str(2**30) and d['limits']['memory.swap.max'] == '0'
    assert d['cpu_escape_proof'] == {'allowed': [0, 2, 4, 6], 'escape_rejected': True}
    assert d['shutdown_exit_codes'] == [0, 0] and not d['remaining_server_pids']
    assert not d.get('error') and not d.get('monitor_error')
    events = d['resources_after_shutdown']['events']
    assert all(events[k] == 0 for k in ('oom', 'oom_kill', 'oom_group_kill'))
    assert d['connection_recovery'] == 1 and d['transaction_status'] == 'IDLE'
    assert d['restart_count'] == 1_000_000
    assert (d['restart_full_sort']['rows'], d['restart_full_sort']['sha256']) == (1_000_000, sort)
    for name, sha in d['source_lf_sha256'].items():
        assert hashlib.sha256((base / (item['name'] + '-source') / name).read_bytes().replace(b'\r\n', b'\n')).hexdigest() == sha
    for q in d['queries']:
        assert q['cpu_delta']['nr_throttled'] == q['cpu_delta']['throttled_usec'] == 0
        if q['passed']:
            assert (q['result']['rows'], q['result']['sha256']) == (1_000_000, sort)
            assert not q['remaining_temp_files']
            if q['work_mem'] == '64kB':
                assert sum(f['bytes'] for f in q['spill_files']) > 0
            counts['successful_sorts'] += 1
        else:
            assert not is_candidate and item['variant'] == 'baseline-observed'
            assert q['sqlstate'] == '53200' and 'memory_cancel_threshold' in q['error']
            counts['watchdog_cancellations'] += 1
    complete = len(d['queries']) == 12 and all(q['passed'] for q in d['queries'])
    assert complete == d['passed'] == item['passed']
    if is_candidate:
        assert complete
        counts['candidate_passes'] += 1
        if d['allocator_sql_observer']:
            rows = [r for r in d['ownership'][-1]['rows'] if r[1:3] == ['pool', 'grow_guard']]
            assert len(rows) == 1 and 0 < rows[0][4] <= rows[0][3] * 16 * 2**20
    counts['trials'] += 1
    counts['passes'] += complete
assert counts['candidate_passes'] == 6 and counts['watchdog_cancellations'] == 3
report = {'passed': True, 'recorded_evidence_only': True, 'candidate_sha256': candidate, **counts}
(base / (campaign + '-review.json')).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
