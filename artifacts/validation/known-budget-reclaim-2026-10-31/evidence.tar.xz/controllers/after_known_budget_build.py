"""Wait for the confirmed builder; run serial comparisons only after its successful completion."""
from pathlib import Path
import json
import subprocess
import time

base = Path('/home/rustsql')
builder = Path('/proc/303/cmdline')
report = base / 'known-budget-build-20261031/report.json'
assert builder.exists() and b'build_known_budget_candidate.py' in builder.read_bytes()
deadline = time.monotonic() + 1800
while builder.exists() and b'build_known_budget_candidate.py' in builder.read_bytes():
    assert time.monotonic() < deadline, 'builder still running; do not restart automatically'
    time.sleep(5)
data = json.loads(report.read_text())
assert data['passed'] and all(c['exit'] == 0 for c in data['commands'] if not c['label'].startswith('negative-'))
raise SystemExit(subprocess.run(['/usr/bin/python3', '-u', '/mnt/c/Users/DarkMoon/Desktop/Rust SQL/screen_known_budget.py']).returncode)
