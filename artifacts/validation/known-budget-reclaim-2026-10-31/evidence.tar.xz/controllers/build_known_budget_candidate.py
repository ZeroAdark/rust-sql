"""Build an isolated, unpromoted bounded budget-reclaim experiment."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import time

base = Path('/home/rustsql')
repo = base / 'pgrust'
root = base / 'known-budget-build-20261031'
root.mkdir(exist_ok=False)
source_repo = Path('/mnt/c/Users/DarkMoon/Desktop/Rust SQL/pgrust')
files = ['crates/_support/pagepool/src/purger.rs', 'crates/_support/pagepool/src/superpage.rs',
         'crates/_support/pagepool/src/claimer.rs', 'crates/_support/pagepool/src/lib.rs',
         'crates/backend/postmaster/memruntime/src/lib.rs', 'crates/_support/pagepool/tests/reclaim_budget.rs']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip() == ''
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head == 'b3d1a667e200da873aa72fda7530cce5c2c9279f'
report = {'passed': False, 'promoted': False, 'base_commit': head, 'source_sha256': {}, 'commands': []}
for name in files:
    content = (source_repo / name).read_bytes().replace(b'\r\n', b'\n')
    (repo / name).write_bytes(content)
    target = root / 'sources' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    report['source_sha256'][name] = hashlib.sha256(content).hexdigest()
(root / 'candidate.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', *files[:-1]], cwd=repo))
cargo = str(base / '.cargo/bin/cargo')

def run(label, command, success=True):
    start = time.monotonic()
    with (root / (label + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    item = {'label': label, 'command': command, 'exit': result.returncode, 'seconds': time.monotonic() - start}
    report['commands'].append(item)
    (root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(item), flush=True)
    if success:
        result.check_returncode()
    return result

test = [cargo, 'test', '--locked', '--release', '-j', '2', '-p', 'pagepool', '--features', 'global']
run('focused', test + ['--test', 'reclaim_budget', '--test', 'grow_guard', '--test', 'global_cap'])
for label, name, needle, replacement, message in [
    ('negative-zero', files[0], b'bytes.unwrap_or(usize::MAX)', b'bytes.filter(|&n| n != 0).unwrap_or(usize::MAX)',
     'known or finite budget must release free pages before growth'),
    ('negative-prefault', 'crates/_support/pagepool/src/claimer.rs', b' || crate::purger::prefault_held()', b'',
     'known-zero budget must hold cold prefaults'),
]:
    path = repo / name
    original = path.read_bytes()
    assert original.count(needle) == 1
    try:
        path.write_bytes(original.replace(needle, replacement))
        result = run(label, test + ['--test', 'reclaim_budget'], False)
        assert result.returncode != 0 and message in (root / (label + '.log')).read_text()
    finally:
        path.write_bytes(original)
run('pagepool', test + ['--lib', '--tests'])
run('memruntime', [cargo, 'test', '--locked', '--release', '-j', '2', '-p', 'memruntime', '--lib'])
run('release-build', [cargo, 'build', '--locked', '--release', '-j', '2', '-p', 'main_main', '-p', 'initdb'])
candidate = base / 'known-budget-candidate/bin'
candidate.mkdir(parents=True, exist_ok=False)
report['binaries'] = {}
for name in ['postgres', 'initdb']:
    shutil.copy2(repo / 'target/release' / name, candidate / name)
    report['binaries'][name] = {'path': str(candidate / name), 'sha256': hashlib.sha256((candidate / name).read_bytes()).hexdigest()}
shutil.copytree(repo / 'target/release/share', candidate / 'share')
assert (candidate / 'share/postgres.bki').exists()
assert all(hashlib.sha256((repo / name).read_bytes()).hexdigest() == sha for name, sha in report['source_sha256'].items())
report['passed'] = True
(root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report['binaries']), flush=True)
