"""Predeclared medium and longer-capacity checks for the bounded budget-reclaim candidate."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

if not __debug__:
    raise RuntimeError('Assertions must remain enabled')
base = Path('/home/rustsql')
phase = sys.argv[1]
assert phase in ('medium', 'capacity')
memory_mib = int(sys.argv[2]) if len(sys.argv) > 2 else 2048
assert memory_mib in (1024, 2048)
label = 'known-budget-' + phase + ('-1g' if memory_mib == 1024 else '') + '-20261031'
assert not subprocess.check_output(['systemctl', 'list-units', 'rustsql-qualification-*', '--state=running', '--plain', '--no-legend'], text=True).strip()
build = json.loads((base / 'known-budget-build-20261031/report.json').read_text())
assert build['passed']
expected = {'guc-registry-reserve-candidate': '0be60915b40c9f70f39dcb3a0fd1f8918608a20095f767ec081a5b5320caa277',
            'known-budget-candidate': build['binaries']['postgres']['sha256'],
            'postgres18': '07b16e1aa4f0e2206c37b339b6e4cc813aa8ab9e3c5516334f753b3d90d0c536'}
def verify():
    for name, sha in expected.items():
        assert hashlib.sha256((base / name / 'bin/postgres').read_bytes()).hexdigest() == sha
verify()
source = base / (label + '-source')
source.mkdir(exist_ok=False)
frozen = base / ('guc-registry-reserve-medium-20261031-source' if phase == 'medium' else 'guc-registry-reserve-long-capacity-20261031-source')
for filename in ('postgres_comparison.py', 'fixed_workload.py', 'cluster.py', 'connection_churn_probe.py', 'connection_queue_probe.py', 'resource_scope.py', 'cpuset_preflight.py'):
    shutil.copyfile(frozen / filename, source / filename)
shutil.copyfile(Path(__file__), source / Path(__file__).name)
probe = source / 'postgres_comparison.py'
text = probe.read_text()
assert text.count('/home/rustsql/guc-name-index-candidate/bin') == 2
text = text.replace('/home/rustsql/guc-name-index-candidate/bin', '/home/rustsql/guc-registry-reserve-candidate/bin')
if phase == 'capacity':
    original = "Predeclared longer-duration check after the short capacity screen failed range p99 by 5.27%; retains the failed screen and makes no new PostgreSQL comparison claim."
    assert original in text
    text = text.replace(original, 'Predeclared five-pair 1500-bundle capacity check of the bounded budget-triggered reclaim; CPU, throughput and every query p99 must meet the unchanged 5 percent guards. Rust-only capacity comparison.')
probe.write_text(text)
compile(text, str(probe), 'exec')
(source / 'design.json').write_text(json.dumps({'binaries': expected, 'phase': phase, 'repeats': 5,
                                               'bundles_per_client': 30 if phase == 'medium' else 1500,
                                               'memory_mib': memory_mib, 'guard_percent': 5,
                                               'candidate_promoted': False}, indent=2) + '\n')
properties = ['--uid=rustsql', '--gid=rustsql', '--wait', '--collect', '--property=Delegate=cpu memory pids cpuset',
              '--property=AllowedCPUs=0,2,4,6,8,10', '--property=MemorySwapMax=0']
command = ['systemd-run', '--unit=rustsql-qualification-' + label + '-cpuset-check', *properties, '--pipe',
           '--property=MemoryMax=512M', '--property=RuntimeMaxSec=30', '/usr/bin/python3', str(source / 'cpuset_preflight.py')]
result = subprocess.run(command, capture_output=True, text=True, timeout=40)
(base / (label + '-cpuset-preflight.json')).write_text(json.dumps({'command': command, 'exit': result.returncode,
                                                               'stdout': result.stdout, 'stderr': result.stderr}, indent=2) + '\n')
result.check_returncode()
assert json.loads(result.stdout)['passed']
unit = 'rustsql-qualification-' + label
command = ['systemd-run', '--unit=' + unit, *properties, '--property=MemoryMax=8G', '--property=LimitSTACK=67108864',
           '--property=RuntimeMaxSec=2400', '--property=StandardOutput=append:' + str(base / (label + '.log')),
           '--property=StandardError=append:' + str(base / (label + '.log')), '/usr/bin/python3', '-u', str(probe),
           '--candidate', str(base / 'known-budget-candidate/bin'), '--reference', str(base / 'postgres18/bin'),
           '--work-dir', str(base / 'conformance'), '--output-dir', str(base / label), '--phase', phase,
           '--bundles', '30' if phase == 'medium' else '1500', '--warmup', '10', '--repeats', '5']
if phase == 'medium':
    command += ['--bundle-rate', '9.4']
command += ['--memory-mib', str(memory_mib)]
result = subprocess.run(command, capture_output=True, text=True, timeout=2430)
(base / (label + '-command.json')).write_text(json.dumps({'command': command, 'exit': result.returncode,
                                                       'stdout': result.stdout, 'stderr': result.stderr}, indent=2) + '\n')
(base / (label + '-journal.log')).write_bytes(subprocess.check_output(['journalctl', '-u', unit + '.service', '--no-pager', '-o', 'short-iso']))
print(label, result.returncode, flush=True)
print((base / (label + '.log')).read_text()[-2000:], flush=True)
result.check_returncode()
verify()
