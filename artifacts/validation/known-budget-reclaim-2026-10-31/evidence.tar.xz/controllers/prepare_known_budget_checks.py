"""Freeze the revised candidate's tests and serial comparison plan."""
from pathlib import Path

root = Path(__file__).resolve().parent
builder = (root / 'build_budget_guard_candidate.py').read_text().replace('budget-guard', 'known-budget')
builder = builder.replace("'crates/_support/pagepool/tests/budget_guard.rs'", "'crates/_support/pagepool/src/claimer.rs', 'crates/_support/pagepool/src/lib.rs',\n         'crates/backend/postmaster/memruntime/src/lib.rs', 'crates/_support/pagepool/tests/reclaim_budget.rs'")
builder = builder.replace("'budget_guard'", "'reclaim_budget'")
start = builder.index('path = repo / files[0]')
end = builder.index("run('pagepool'", start)
builder = builder[:start] + '''for label, name, needle, replacement, message in [
    ('negative-zero', files[0], b'bytes.unwrap_or(usize::MAX)', b'bytes.filter(|&n| n != 0).unwrap_or(usize::MAX)',
     'known or finite budget must release free pages before growth'),
    ('negative-prefault', 'crates/_support/pagepool/src/claimer.rs', b' || crate::purger::prefault_held()', b'',
     'known-zero budget must hold cold prefaults'),
]:
    path = repo / name
    original = path.read_bytes()
    assert original.count(needle) == 1
    try:
        path.write_bytes(original.replace(needle, replacement))
        result = run(label, test + ['--test', 'reclaim_budget'], False)
        assert result.returncode != 0 and message in (root / (label + '.log')).read_text()
    finally:
        path.write_bytes(original)
''' + builder[end:]
builder = builder.replace("run('release-build',", "run('memruntime', [cargo, 'test', '--locked', '--release', '-j', '2', '-p', 'memruntime', '--lib'])\nrun('release-build',")
for filename, content in [('build_known_budget_candidate.py', builder),
                          ('run_known_budget_pressure.py', (root / 'run_budget_guard_pressure.py').read_text().replace('budget-guard', 'known-budget')),
                          ('run_known_budget_performance.py', (root / 'run_budget_guard_performance.py').read_text().replace('budget-guard', 'known-budget')),
                          ('screen_known_budget.py', (root / 'screen_budget_guard.py').read_text().replace('budget-guard', 'known-budget').replace('run_budget_guard_', 'run_known_budget_'))]:
    target = root / filename
    assert not target.exists()
    compile(content, filename, 'exec')
    target.write_text(content)
    print(filename)
