from pathlib import Path
import json,os,subprocess
from resource_scope import DelegatedScope,snapshot
if not __debug__:raise RuntimeError('Assertions must remain enabled')
scope=DelegatedScope([0,2,4,6],[8,10])
os.sched_setaffinity(0,set(range(os.cpu_count())))
assert os.sched_getaffinity(0)=={8,10}
group,launcher=scope.server(512)
child="""import json,os
os.sched_setaffinity(0,set(range(os.cpu_count())))
assert os.sched_getaffinity(0)=={0,2,4,6}
try:os.sched_setaffinity(0,{8})
except OSError as error:assert error.errno==22
else:raise AssertionError('server escaped its CPU set')
print(json.dumps({'allowed':sorted(os.sched_getaffinity(0)),'escape_rejected':True}))
"""
proof=json.loads(subprocess.check_output(launcher+['/usr/bin/python3','-c',child],text=True))
result={'passed':True,'driver_allowed':sorted(os.sched_getaffinity(0)),'server':proof,
        'server_cpu_max':(group/'cpu.max').read_text().strip(),
        'parent_cpu_max':(scope.root/'cpu.max').read_text().strip(),
        'server_resources':snapshot(group)}
assert not (group/'cgroup.procs').read_text().split()
group.rmdir();print(json.dumps(result))
