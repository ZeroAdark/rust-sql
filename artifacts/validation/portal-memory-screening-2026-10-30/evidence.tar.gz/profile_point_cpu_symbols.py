from pathlib import Path
import sys,subprocess,json,signal,time,resource,hashlib
sys.path.insert(0,'/home/rustsql/pgrust/scripts/validation')
import psycopg
from psycopg.conninfo import make_conninfo
from connection_churn_probe import CheckedCluster
from resource_scope import DelegatedScope,snapshot
from fixed_workload import setup,SQL
base=Path('/home/rustsql');out=base/'point-cpu-symbols-20261030';out.mkdir(exist_ok=False)
resource.setrlimit(resource.RLIMIT_STACK,(65520*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
scope=DelegatedScope([0,2,4,6],[8,10]);report={'purpose':'CPU sampling diagnosis, not latency or throughput evidence','engines':{}}
for engine,folder in [('rustsql','point-profile-symbols-candidate')]:
 group,launcher=scope.server(2048);reference=engine=='postgresql';perf=None
 cluster=CheckedCluster(base/folder/'bin',base/'conformance',reference=reference,launcher=launcher,allocator=None if reference else 'hearth',settings=['autovacuum=off','work_mem=16MB','shared_buffers=128MB','max_parallel_workers_per_gather=2'])
 with cluster:
  with psycopg.connect(cluster.dsn,autocommit=True) as c:setup(c,1000000,6,reference=reference)
  with psycopg.connect(make_conninfo(cluster.dsn,user='bench_user'),autocommit=True) as c:
   for i in range(1000):assert c.execute(SQL['read'],(i%120000+1,),prepare=True).fetchall()==[(i%120000+1,0)]
   pids=(group/'cgroup.procs').read_text().split();cmd=['/usr/lib/linux-tools-6.8.0-147/perf','record','-e','cpu-clock:u','-F','997','--call-graph','dwarf,8192','-p',','.join(pids),'-o',str(out/(engine+'.data'))]
   with (out/(engine+'-record.log')).open('w') as log:
    perf=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
    try:
     time.sleep(.2);assert perf.poll() is None
     for i in range(100000):
      key=(i*67)%120000+1;assert c.execute(SQL['read'],(key,),prepare=True).fetchall()==[(key,0)]
    finally:
     if perf.poll() is None:perf.send_signal(signal.SIGINT)
     rc=perf.wait(timeout=20)
     assert rc in (0,-signal.SIGINT,128+signal.SIGINT), rc
   r=subprocess.run(['/usr/lib/linux-tools-6.8.0-147/perf','report','--stdio','--no-children','--percent-limit','0.7','--call-graph','none','--sort','dso,symbol','-i',str(out/(engine+'.data'))],capture_output=True,text=True,timeout=90);r.check_returncode();(out/(engine+'-report.txt')).write_text(r.stdout+r.stderr)
 report['engines'][engine]={'cluster':str(cluster.root),'command':cmd,'intentional_perf_stop_exit_code':rc,'binary_sha256':hashlib.sha256((base/folder/'bin/postgres').read_bytes()).hexdigest(),'shutdown_exit_codes':cluster.shutdown_exit_codes,'remaining_pids':(group/'cgroup.procs').read_text().split(),'resources':snapshot(group)}
 assert not report['engines'][engine]['remaining_pids'];group.rmdir()
 (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
 print(engine,'profile complete',flush=True)
