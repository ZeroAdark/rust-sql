from pathlib import Path
import sys,json,re,time,collections,hashlib
sys.path.insert(0,'/home/rustsql/pgrust/scripts/validation')
import psycopg
from connection_churn_probe import CheckedCluster
from resource_scope import DelegatedScope,snapshot
from fixed_workload import setup
scope=DelegatedScope([0,2,4,6],[8,10]);report={'purpose':'startup and idle memory attribution only; not performance evidence','binary_sha256':hashlib.sha256(Path('/home/rustsql/pool-config-fixed-candidate/bin/postgres').read_bytes()).hexdigest(),'trials':[]}
def maps():
 rows=collections.defaultdict(lambda:collections.Counter());pids=(group/'cgroup.procs').read_text().split()
 for pid in pids:
  try:
   name=''
   for line in Path('/proc',pid,'smaps').read_text().splitlines():
    if re.match(r'^[0-9a-f]+-[0-9a-f]+ ',line):name=(line.split(None,5)[5] if len(line.split(None,5))>5 else '[anonymous]')+' '+line.split()[1]
    elif ':' in line:
     key,val=line.split(':',1)
     if key in ['Rss','Pss','Anonymous','AnonHugePages','Size','Private_Dirty']:
      rows[name][key]+=int(val.split()[0])*1024
  except (FileNotFoundError,ProcessLookupError):pass
 return dict(rows)

for label,flag in [('baseline',None),('no-worker-pool','PGRUST_NO_WORKER_POOL'),('idle-tail','PGRUST_POOL_IDLE_TAIL')]:
 group,launcher=scope.server(2048)
 cluster=CheckedCluster('/home/rustsql/pool-config-fixed-candidate/bin','/home/rustsql/conformance',launcher=launcher,allocator='hearth',settings=['autovacuum=off','max_active_queries=6','work_mem=16MB','shared_buffers=128MB','max_parallel_workers_per_gather=2','log_min_messages=debug1'])
 if flag:cluster.env[flag]='1'
 trial={'label':label,'cluster':str(cluster.root),'stages':[]};report['trials'].append(trial)
 def capture(stage):
  names=collections.Counter();flags={}
  for pid in (group/'cgroup.procs').read_text().split():
   for f in Path('/proc',pid,'task').glob('*/comm'):
    try:names[f.read_text().strip()]+=1
    except FileNotFoundError:pass
   try:
    env=Path('/proc',pid,'environ').read_bytes().split(b'\0')
    flags[pid]=[x.decode() for x in env if x.startswith((b'PGRUST_POOL_IDLE_TAIL=',b'PGRUST_NO_WORKER_POOL='))]
   except (FileNotFoundError,PermissionError):pass
  trial['stages'].append({'label':stage,'resources':snapshot(group),'mapping_totals':maps(),'threads':dict(names),'experimental_flags':flags})
 with cluster:
  with psycopg.connect(cluster.dsn,autocommit=True) as c:
   trial['settings']=c.execute("SELECT name,setting FROM pg_settings WHERE name IN ('pgrust.memory_release_idle','idle_passivate_timeout','max_parallel_workers','max_worker_processes') ORDER BY name").fetchall()
   capture('startup');time.sleep(1.3);capture('startup-idle');setup(c,1000000,6);capture('after-setup');time.sleep(1.3);capture('setup-idle')
 trial['shutdown_exit_codes']=cluster.shutdown_exit_codes;trial['remaining_pids']=(group/'cgroup.procs').read_text().split();assert cluster.shutdown_exit_codes==[0] and not trial['remaining_pids'];group.rmdir()
Path('/home/rustsql/worker-memory-attribution.json').write_text(json.dumps(report,indent=2)+'\n');print('worker memory attribution complete',flush=True)
