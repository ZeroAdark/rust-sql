from pathlib import Path
import subprocess,json,sys,shutil
base=Path('/home/rustsql');label=sys.argv[1];phase=sys.argv[2];bundles=sys.argv[3];repeats=sys.argv[4];warmup=sys.argv[5];rate=None if len(sys.argv)<7 or sys.argv[6]=='none' else sys.argv[6];binary=Path(sys.argv[7]);policy='';variant=sys.argv[8];envname={'idle-tail':'PGRUST_POOL_IDLE_TAIL','no-worker-pool':'PGRUST_NO_WORKER_POOL'}[variant]
source=base/(label+'-source');source.mkdir(exist_ok=False)
for n in ['postgres_comparison.py','fixed_workload.py','cluster.py','connection_churn_probe.py','connection_queue_probe.py','resource_scope.py']:shutil.copyfile(base/'pgrust/scripts/validation'/n,source/n)
probe=source/'postgres_comparison.py'
s=probe.read_text()
s=s.replace("binaries = args.reference if reference else args.candidate", "binaries = args.reference if reference else args.baseline if label == 'rustsql-baseline' else args.candidate")
s=s.replace("('candidate','reference','work-dir','output-dir')", "('candidate','baseline','reference','work-dir','output-dir')")
s=s.replace("[('postgresql',args.reference),('rustsql',args.candidate)]", "[('postgresql',args.reference),('rustsql-baseline',args.baseline),('rustsql',args.candidate)]")
s=s.replace("(('postgresql','rustsql') if repetition%2 else ('rustsql','postgresql'))", "(('postgresql','rustsql-baseline','rustsql') if repetition%2 else ('rustsql','rustsql-baseline','postgresql'))")
s=s.replace("    report = {'passed':False", "    if label == 'rustsql':\n        cluster.env[args.candidate_env] = '1'\n    report = {'passed':False")
s=s.replace("    try:\n        with cluster:", "    report['experimental_environment'] = {args.candidate_env:'1'} if label == 'rustsql' else {}\n    try:\n        with cluster:")
s=s.replace("    parser.add_argument('--candidate-policy',default='')", "    parser.add_argument('--candidate-policy',default='')\n    parser.add_argument('--candidate-env',required=True,choices=['PGRUST_POOL_IDLE_TAIL','PGRUST_NO_WORKER_POOL'])")
s=s.replace("'candidate_policy':args.candidate_policy", "'candidate_env':{args.candidate_env:'1'},'candidate_policy':args.candidate_policy")
probe.write_text(s)
cmd=['systemd-run','--unit=rustsql-qualification-'+label,'--uid=rustsql','--gid=rustsql','--wait','--collect','--property=Delegate=cpu memory pids','--property=MemoryMax=8G','--property=MemorySwapMax=0','--property=CPUQuota=600%','--property=LimitSTACK=67108864','--property=RuntimeMaxSec=2400','--property=StandardOutput=append:'+str(base/(label+'.log')),'--property=StandardError=append:'+str(base/(label+'.log')),'/usr/bin/python3','-u',str(source/'postgres_comparison.py'),'--candidate',str(binary),'--reference',str(base/'postgres18/bin'),'--work-dir',str(base/'conformance'),'--output-dir',str(base/label),'--phase',phase,'--bundles',bundles,'--repeats',repeats,'--warmup',warmup]
cmd+=['--baseline','/home/rustsql/pool-config-fixed-candidate/bin']
cmd+=['--candidate-env',envname]
if rate:cmd+=['--bundle-rate',rate]
if policy:cmd+=['--candidate-policy',policy]
r=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=2430)
(base/(label+'-command.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode,'output':r.stdout},indent=2)+'\n');(base/(label+'-journal.log')).write_bytes(subprocess.check_output(['journalctl','-u','rustsql-qualification-'+label+'.service','--no-pager','-o','short-iso']))
print(label,r.returncode,flush=True);print((base/(label+'.log')).read_text()[-3000:],flush=True);r.check_returncode()
