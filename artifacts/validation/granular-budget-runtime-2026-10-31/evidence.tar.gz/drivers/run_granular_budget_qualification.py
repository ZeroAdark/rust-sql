"""Run the established runtime checks only after every performance gate passes."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

if not __debug__:
    raise RuntimeError('Assertions must remain enabled')
base = Path('/home/rustsql')
repo = base / 'pgrust'
sha = json.loads((base / 'granular-budget-build-20261031/report.json').read_text())['binaries']['postgres']['sha256']
binary = base / 'granular-budget-candidate/bin/postgres'
review = json.loads((base / 'granular-budget-performance-review-20261031.json').read_text())
assert review['evidence_valid'] and review['preservation_passed']
assert set(review['phases']) == {'medium', 'capacity', 'medium-1g'}
assert review['timed_statements'] == 1_812_600
assert json.loads((base / 'granular-budget-pressure-20261031-review.json').read_text())['candidate_passes'] == 6
build = json.loads((base / 'granular-budget-build-20261031/report.json').read_text())
assert build['passed'] and build['binaries']['postgres']['sha256'] == sha
assert hashlib.sha256(binary.read_bytes()).hexdigest() == sha
assert not subprocess.check_output(['systemctl', 'list-units', 'rustsql-qualification-*', '--state=running', '--plain', '--no-legend'], text=True).strip()
for name, digest in build['source_sha256'].items():
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == digest

output = base / 'granular-budget-qualification-20261031.json'
assert not output.exists()
source = base / 'guc-registry-reserve-connections-20261031/source'
validation = base / 'granular_budget_validation.py'
assert not validation.exists()
template = (base / 'residency_retained_validation.py').read_text()
assert 'vma-residency-candidate' in template and 'residency-retained' in template
validation.write_text(template.replace('vma-residency-candidate', 'granular-budget-candidate').replace('residency-retained', 'granular-budget'))
sources = [validation, Path(__file__), *sorted((repo / 'scripts/validation').glob('*.py'))]
source_hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
report = {'passed': False, 'promoted': False, 'candidate_sha256': sha, 'commands': [], 'source_sha256': source_hashes}
tasks = []
for i in range(1, 4):
    label = f'granular-budget-2g-pilot-{i}-20261031'
    tasks.append((label, [str(source / 'guc_queue_probe.py'), '--candidate', str(binary.parent),
                          '--work-dir', str(base / 'conformance'), '--output', str(base / (label + '.json')),
                          '--burst', '--memory-mib', '2048'], True))
tasks += [('granular-budget-' + mode + '-20261031', [str(validation), mode], False) for mode in ('full', 'probes')]
for label, args, cpuset in tasks:
    log = base / (label + '.log')
    assert not log.exists()
    command = ['systemd-run', '--unit=rustsql-qualification-' + label, '--uid=rustsql', '--gid=rustsql', '--wait', '--collect',
               '--property=MemoryMax=12G', '--property=MemorySwapMax=0', '--property=LimitSTACK=67108864',
               '--property=RuntimeMaxSec=3600', '--property=StandardOutput=append:' + str(log),
               '--property=StandardError=append:' + str(log)]
    if cpuset:
        command += ['--property=Delegate=cpu memory pids cpuset', '--property=AllowedCPUs=0,2,4,6,8,10']
    else:
        # Functional qualification only; timings from these quota-limited checks are not performance evidence.
        command += ['--property=CPUQuota=600%']
    command += ['/usr/bin/python3', '-u', *args]
    started = time.monotonic()
    result = subprocess.run(command, capture_output=True, text=True, timeout=3630)
    entry = {'label': label, 'command': command, 'exit': result.returncode, 'seconds': time.monotonic() - started,
             'stdout': result.stdout, 'stderr': result.stderr}
    report['commands'].append(entry)
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'label': label, 'exit': result.returncode, 'seconds': entry['seconds']}), flush=True)
    print(log.read_text()[-1200:], flush=True)
    result.check_returncode()
assert hashlib.sha256(binary.read_bytes()).hexdigest() == sha
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == digest for p, digest in source_hashes.items())
report['passed'] = True
output.write_text(json.dumps(report, indent=2) + '\n')
