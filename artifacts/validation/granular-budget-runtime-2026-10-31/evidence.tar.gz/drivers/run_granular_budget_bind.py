"""Check prepared statements, malformed Bind cleanup and cursor lifetimes after allocator qualification."""
from pathlib import Path
import hashlib
import json
import subprocess

base = Path('/home/rustsql')
repo = base / 'pgrust'
assert json.loads((base / 'granular-budget-runtime-checks-20261031.json').read_text())['passed']
assert not subprocess.check_output(['systemctl', 'list-units', 'rustsql-qualification-*', '--state=running', '--plain', '--no-legend'], text=True).strip()
output = base / 'granular-budget-bind-lifecycle-20261031.json'
log = base / 'granular-budget-bind-lifecycle-20261031.log'
assert not output.exists() and not log.exists()
hashes = {'granular-budget-candidate': '635ec740b3cd85c4318eadc87843705032494a49d92d1deeb79b09a8c5ab9e57',
          'postgres18': '07b16e1aa4f0e2206c37b339b6e4cc813aa8ab9e3c5516334f753b3d90d0c536'}
for directory, digest in hashes.items():
    assert hashlib.sha256((base / directory / 'bin/postgres').read_bytes()).hexdigest() == digest
unit = 'rustsql-qualification-granular-budget-bind-20261031'
command = ['systemd-run', '--unit=' + unit, '--uid=rustsql', '--gid=rustsql', '--wait', '--collect',
           '--property=MemoryMax=4G', '--property=MemorySwapMax=0', '--property=CPUQuota=400%',
           '--property=LimitSTACK=67108864', '--property=RuntimeMaxSec=180',
           '--property=StandardOutput=append:' + str(log), '--property=StandardError=append:' + str(log),
           '/usr/bin/python3', str(repo / 'scripts/validation/bind_lifecycle_probe.py'),
           '--candidate', str(base / 'granular-budget-candidate/bin'), '--reference', str(base / 'postgres18/bin'),
           '--work-dir', str(base / 'conformance'), '--output', str(output)]
sources = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in
           [Path(__file__), repo / 'scripts/validation/bind_lifecycle_probe.py']}
result = subprocess.run(command, capture_output=True, text=True, timeout=210)
(base / 'granular-budget-bind-command-20261031.json').write_text(json.dumps({'command': command, 'exit': result.returncode,
    'stdout': result.stdout, 'stderr': result.stderr, 'source_sha256': sources, 'performance_qualified': False}, indent=2) + '\n')
result.check_returncode()
report = json.loads(output.read_text())
assert report['passed'] and not report.get('failure')
assert report['engines']['rustsql']['result'] == report['engines']['postgresql']['result']
for engine in report['engines'].values():
    assert engine['shutdown_exit_codes'] == [0] and len(engine['result']['checks']) == 8
for directory, digest in hashes.items():
    assert hashlib.sha256((base / directory / 'bin/postgres').read_bytes()).hexdigest() == digest
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == digest for p, digest in sources.items())
print(json.dumps({'passed': True, 'groups_per_engine': 8, 'committed_updates_per_engine': 192}))
