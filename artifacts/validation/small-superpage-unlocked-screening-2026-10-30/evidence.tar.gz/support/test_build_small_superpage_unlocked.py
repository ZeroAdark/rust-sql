from pathlib import Path
import subprocess,os,resource,json,hashlib
b=Path('/home/rustsql');r=b/'pgrust';env=os.environ.copy();env['PATH']=str(b/'.cargo/bin')+':'+env['PATH'];resource.setrlimit(resource.RLIMIT_STACK,(65520*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
p=r/'crates/_support/pagepool/src/state.rs';positive=p.read_bytes();code=positive.decode()
old="""        drop(r);
        drop(g);
        #[cfg(test)]
        crate::tests::small_prepare_hook(i);
"""
new="""        #[cfg(test)]
        crate::tests::small_prepare_hook(i);
        drop(r);
        drop(g);
"""
assert code.count(old)==1
negative=code.replace(old,new).encode();cmd=['cargo','test','--locked','--release','-j','2','-p','pagepool','--features','global','--lib','tests::pool_kernels','--','--exact','--test-threads=1'];log=b/'small-superpage-unlocked-negative-control.log'
try:
 p.write_bytes(negative)
 with log.open('w') as f:run=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
finally:p.write_bytes(positive)
t=log.read_text();report={'command':cmd,'exit':run.returncode,'expected_failure':'another allocation must complete while fresh-page OS preparation is paused','positive_source_sha256':hashlib.sha256(positive).hexdigest(),'negative_source_sha256':hashlib.sha256(negative).hexdigest(),'positive_restored':p.read_bytes()==positive,'passed':run.returncode==101 and 'another allocation must complete while fresh-page OS preparation is paused' in t}
(b/'small-superpage-unlocked-negative-control.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
if not report['passed']:print(t[-5000:],flush=True);raise RuntimeError('negative control did not fail as expected')
subprocess.run(['/usr/bin/python3',str(b/'build_small_superpage_unlocked.py')],check=True)
