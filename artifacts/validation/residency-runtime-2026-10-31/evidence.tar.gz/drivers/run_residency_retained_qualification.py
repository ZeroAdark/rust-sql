from pathlib import Path
import hashlib,json,subprocess,time

base=Path('/home/rustsql')
binary=base/'vma-residency-candidate/bin/postgres'
sha=hashlib.sha256(binary.read_bytes()).hexdigest()
assert sha=='02cfbca6869bb352c8081b1fb275cdd4317b33a72b8feb05c563408e4c48d454'
report={'passed':False,'candidate_sha256':sha,'commands':[]}
output=base/'residency-retained-qualification-20261031.json'
assert not output.exists()
for mode in ['full','probes']:
    name='residency-retained-'+mode+'-20261031';log=base/(name+'.log')
    assert not log.exists()
    command=['systemd-run','--unit=rustsql-qualification-'+name,'--uid=rustsql','--gid=rustsql','--collect','--wait',
        '--property=MemoryMax=12G','--property=MemorySwapMax=0','--property=CPUQuota=600%',
        '--property=LimitSTACK=67108864','--property=RuntimeMaxSec=3600',
        '--property=StandardOutput=append:'+str(log),'--property=StandardError=append:'+str(log),
        '/usr/bin/python3','-u',str(base/'residency_retained_validation.py'),mode]
    started=time.monotonic()
    result=subprocess.run(command,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=3630)
    entry={'command':command,'exit':result.returncode,'seconds':time.monotonic()-started,'output':result.stdout}
    report['commands'].append(entry);output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(entry),flush=True);print(log.read_text()[-2000:],flush=True)
    result.check_returncode()
report['passed']=True;output.write_text(json.dumps(report,indent=2)+'\n')
