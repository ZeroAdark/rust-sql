from pathlib import Path
import sys,json,re,time,threading,collections
sys.path.insert(0,'/home/rustsql/pgrust/scripts/validation')
import psycopg
from cluster import Cluster
from resource_scope import DelegatedScope,snapshot
from fixed_workload import setup,exercise,SQL
scope=DelegatedScope([0,2,4,6],[8,10]);group,launcher=scope.server(2048);report={'purpose':'memory attribution only; isolated run with smaps and owner sampling; not performance evidence','stages':[],'maps':[]}
def maps():
 rows=collections.defaultdict(lambda:collections.Counter());pids=(group/'cgroup.procs').read_text().split()
 for pid in pids:
  try:
   name=''
   for line in Path('/proc',pid,'smaps').read_text().splitlines():
    if re.match(r'^[0-9a-f]+-[0-9a-f]+ ',line):name=line
    elif ':' in line:
     key,val=line.split(':',1)
     if key in ['Rss','Pss','Anonymous','AnonHugePages','Size','Private_Dirty']:
      rows[name][key]+=int(val.split()[0])*1024
  except (FileNotFoundError,ProcessLookupError):pass
 return dict(rows)
done=threading.Event()
def monitor():
 while not done.is_set():
  report['maps'].append({'time':time.monotonic(),'resources':snapshot(group),'mapping_totals':maps()});done.wait(1)
with Cluster('/home/rustsql/pool-config-fixed-candidate/bin','/home/rustsql/conformance',launcher=launcher,allocator='hearth',settings=['autovacuum=off','max_active_queries=6','work_mem=16MB','shared_buffers=128MB','max_parallel_workers_per_gather=2']) as cluster:
 report['cluster']=str(cluster.root)
 with psycopg.connect(cluster.dsn,autocommit=True) as c:
  c.execute("CREATE FUNCTION pressure_owner_end(OUT kind text, OUT source text, OUT class text, OUT events bigint, OUT committed_bytes bigint, OUT reserved_bytes bigint, OUT uses bigint, OUT account text, OUT pid int, OUT seq bigint) RETURNS SETOF record LANGUAGE internal VOLATILE AS 'pgrust_memory_owner_end'")
  def capture(label):report['stages'].append({'label':label,'resources':snapshot(group),'owners':c.execute('SELECT * FROM pressure_owner_end()').fetchall(),'mapping_totals':maps()})
  time.sleep(2);capture('startup');setup(c,1000000,6);capture('setup')
  time.sleep(5);capture('idle-setup')
 report['thread_names']={}
 for pid in (group/'cgroup.threads').read_text().split():
  try:report['thread_names'][pid]=Path('/proc',pid,'comm').read_text().strip()
  except (FileNotFoundError,ProcessLookupError):pass
report['final']=snapshot(group);report['remaining_pids']=(group/'cgroup.procs').read_text().split();Path('/home/rustsql/vma2-memory-profile.json').write_text(json.dumps(report,indent=2)+'\n');assert not report['remaining_pids'];group.rmdir();print('profile complete',flush=True)
