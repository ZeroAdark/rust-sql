from pathlib import Path
import sys,json,re,time,threading,collections
sys.path.insert(0,'/home/rustsql/pgrust/scripts/validation')
import psycopg
from cluster import Cluster
from resource_scope import DelegatedScope,snapshot
from fixed_workload import setup,exercise,SQL
scope=DelegatedScope([0,2,4,6],[8,10]);group,launcher=scope.server(2048);report={'purpose':'memory attribution only; isolated run with smaps and owner sampling; not performance evidence','stages':[],'maps':[]}
def maps():
 rows=collections.defaultdict(lambda:collections.Counter());pids=(group/'cgroup.procs').read_text().split()
 for pid in pids:
  try:
   name=''
   for line in Path('/proc',pid,'smaps').read_text().splitlines():
    if re.match(r'^[0-9a-f]+-[0-9a-f]+ ',line):name=(line.split(None,5)[5] if len(line.split(None,5))>5 else '[anonymous]')+' '+line.split()[1]
    elif ':' in line:
     key,val=line.split(':',1)
     if key in ['Rss','Pss','Anonymous','AnonHugePages','Size','Private_Dirty']:
      rows[name][key]+=int(val.split()[0])*1024
  except (FileNotFoundError,ProcessLookupError):pass
 return dict(rows)
done=threading.Event()
def monitor():
 while not done.is_set():
  report['maps'].append({'time':time.monotonic(),'resources':snapshot(group),'mapping_totals':maps()});done.wait(1)
with Cluster('/home/rustsql/pool-config-fixed-candidate/bin','/home/rustsql/conformance',launcher=launcher,allocator='hearth',settings=['autovacuum=off','max_active_queries=6','work_mem=16MB','shared_buffers=128MB','max_parallel_workers_per_gather=2']) as cluster:
 report['cluster']=str(cluster.root)
 with psycopg.connect(cluster.dsn,autocommit=True) as c:
  c.execute("CREATE FUNCTION pressure_owner_end(OUT kind text, OUT source text, OUT class text, OUT events bigint, OUT committed_bytes bigint, OUT reserved_bytes bigint, OUT uses bigint, OUT account text, OUT pid int, OUT seq bigint) RETURNS SETOF record LANGUAGE internal VOLATILE AS 'pgrust_memory_owner_end'")
  def capture(label):report['stages'].append({'label':label,'resources':snapshot(group),'owners':c.execute('SELECT * FROM pressure_owner_end()').fetchall(),'mapping_totals':maps()})
  capture('startup');setup(c,1000000,6);capture('setup')
  t=threading.Thread(target=monitor);t.start()
  try:report['diagnostic_workload']=exercise(cluster.dsn,group,1000000,6,30,10,bundle_rate=9.4)
  finally:done.set();t.join()
  capture('after-workload');time.sleep(5);capture('idle-5s')
  for kind in ['read','aggregate','range','join']:
   time.sleep(5)
   capture('before-'+kind)
   c.execute(SQL[kind],(1,) if kind=='read' else (1,4096) if kind=='range' else None).fetchall()
   capture('after-'+kind)
 report['remaining_pids_after_stop_expected']=[]
report['final']=snapshot(group);report['remaining_pids']=(group/'cgroup.procs').read_text().split();Path('/home/rustsql/isolated-memory-profile.json').write_text(json.dumps(report,indent=2)+'\n');assert not report['remaining_pids'];group.rmdir();print('profile complete',flush=True)
