"""Freeze, test and build the memory-derived prefault ceiling without touching the accepted executable."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import time

base = Path('/home/rustsql')
repo = base / 'pgrust'
root = base / 'warm-limit-build-20261031'
root.mkdir(exist_ok=False)
source_repo = Path('/mnt/c/Users/DarkMoon/Desktop/Rust SQL/pgrust')
files = ['crates/_support/pagepool/src/claimer.rs', 'crates/_support/pagepool/src/lib.rs',
         'crates/_support/pagepool/src/warmres.rs', 'crates/backend/postmaster/memruntime/src/lib.rs',
         'crates/_support/pagepool/tests/warm_memory_limit.rs']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip() == ''
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == 'b3d1a667e200da873aa72fda7530cce5c2c9279f'
report = {'passed': False, 'base_commit': 'b3d1a667e200da873aa72fda7530cce5c2c9279f', 'source_sha256': {}, 'commands': []}
for name in files:
    content = (source_repo / name).read_bytes().replace(b'\r\n', b'\n')
    (repo / name).write_bytes(content)
    target = root / 'sources' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    report['source_sha256'][name] = hashlib.sha256(content).hexdigest()
(root / 'candidate.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', *files[:-1]], cwd=repo))
cargo = str(base / '.cargo/bin/cargo')

def run(label, command, success=True):
    start = time.monotonic()
    with (root / (label + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    item = {'label': label, 'command': command, 'exit': result.returncode, 'seconds': time.monotonic() - start}
    report['commands'].append(item)
    (root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(item), flush=True)
    if success:
        result.check_returncode()
    return result

test = [cargo, 'test', '--locked', '--release', '-j', '2', '-p', 'pagepool', '--features', 'global']
integration = ['warm_memory_limit', 'warm_target', 'warmres_on', 'warmres_off', 'age_claimer', 'claimer_hold', 'global_cap', 'helper_affinity']
run('pagepool', test + ['--lib'] + [word for name in integration for word in ['--test', name]])
path = repo / files[0]
original = path.read_bytes()
needle = b'    if limit == 0 { usize::MAX } else { (limit / 16 / SUPER * SUPER).max(floor) }'
assert original.count(needle) == 1
try:
    path.write_bytes(original.replace(needle, b'    let _ = (floor, limit);\n    usize::MAX'))
    result = run('negative-control', test + ['--test', 'warm_memory_limit'], False)
    assert result.returncode != 0 and 'the reserve must fit the published memory limit' in (root / 'negative-control.log').read_text()
finally:
    path.write_bytes(original)
run('restored-limit', test + ['--test', 'warm_memory_limit'])
run('memruntime', [cargo, 'test', '--locked', '--release', '-j', '2', '-p', 'memruntime', '--lib'])
run('release-build', [cargo, 'build', '--locked', '--release', '-j', '2', '-p', 'main_main', '-p', 'initdb'])
candidate = base / 'warm-limit-candidate/bin'
candidate.mkdir(parents=True, exist_ok=False)
report['binaries'] = {}
for name in ['postgres', 'initdb']:
    shutil.copy2(repo / 'target/release' / name, candidate / name)
    report['binaries'][name] = {'path': str(candidate / name), 'sha256': hashlib.sha256((candidate / name).read_bytes()).hexdigest()}
shutil.copytree(repo / 'target/release/share', candidate / 'share')
assert (candidate / 'share/postgres.bki').exists()
assert all(hashlib.sha256((repo / name).read_bytes()).hexdigest() == sha for name, sha in report['source_sha256'].items())
report['passed'] = True
(root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report['binaries']), flush=True)
