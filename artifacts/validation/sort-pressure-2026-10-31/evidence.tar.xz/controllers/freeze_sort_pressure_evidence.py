"""Archive completed local pressure experiments, preserving failures and exact sources."""
from pathlib import Path
import hashlib
import importlib.util
import io
import json
import statistics
import tarfile

base = Path('/home/rustsql')
workspace = Path('/mnt/c/Users/DarkMoon/Desktop/Rust SQL')
destination = workspace / 'pgrust/artifacts/validation/sort-pressure-2026-10-31'
destination.mkdir(exist_ok=False)
campaigns = ['sustained-sort-20261031', 'sort-observer-controls2-20261031', 'warm-limit-pressure-20261031']
files = {}
catalog = []

def include(path, name=None):
    name = name or path.relative_to(base).as_posix()
    content = path.read_bytes()
    assert name not in files or files[name] == content
    files[name] = content

for campaign in campaigns:
    summary_path = base / (campaign + '-summary.json')
    summary = json.loads(summary_path.read_text())
    assert summary['complete']
    include(summary_path)
    for trial in summary['trials']:
        name = trial['name']
        data = json.loads((base / (name + '.json')).read_text())
        catalog.append({'campaign': campaign, **trial})
        for suffix in ('.json', '.log', '-command.json', '-journal.log'):
            include(base / (name + suffix))
        for path in sorted((base / (name + '-source')).glob('*.py')):
            include(path)
        for filename in ('server.log', 'initdb.log'):
            include(Path(data['cluster']) / filename, name + '-cluster/' + filename)
# The first controller stopped at a socket-path-length setup failure. Keep it separate from server trials.
bad_name = 'sort-observer-controls-20261031-1-rust-observed'
bad_data = json.loads((base / (bad_name + '.json')).read_text())
for suffix in ('.json', '.log', '-command.json', '-journal.log'):
    include(base / (bad_name + suffix))
for path in sorted((base / (bad_name + '-source')).glob('*.py')):
    include(path)
for filename in ('server.log', 'initdb.log'):
    include(Path(bad_data['cluster']) / filename, bad_name + '-cluster/' + filename)
for path in sorted((base / 'warm-limit-build-20261031').rglob('*')):
    if path.is_file():
        include(path)
include(base / 'warm-limit-screen-20261031.json')
for phase in ('medium', 'capacity'):
    label = 'warm-limit-' + phase + '-20261031'
    for path in sorted((base / label).glob('*.json')):
        include(path)
        if path.name.startswith(phase + '-'):
            trial = json.loads(path.read_text())
            for filename in ('server.log', 'initdb.log'):
                include(Path(trial['cluster']) / filename, label + '-clusters/' + path.stem + '/' + filename)
    for path in sorted((base / (label + '-source')).iterdir()):
        if path.is_file():
            include(path)
    for suffix in ('.log', '-command.json', '-journal.log', '-cpuset-preflight.json'):
        include(base / (label + suffix))
    verifier_path = base / ('review_guc_registry.py' if phase == 'medium' else 'review_guc_registry_long.py')
    verifier_text = verifier_path.read_text()
    if phase == 'capacity':
        verifier_text = verifier_text.replace('Predeclared longer-duration check after the short capacity screen failed range p99 by 5.27%',
                                              'Predeclared five-pair 1500-bundle capacity check of the memory-derived prefault ceiling')
    verifier_out = destination / (phase + '_checks.py')
    verifier_out.write_text(verifier_text)
    specification = importlib.util.spec_from_file_location(phase + '_checks', verifier_out)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    reports = [json.loads(p.read_text()) for p in sorted((base / label).glob(phase + '-*.json'))]
    calculated = module.summarize(reports, phase)
    files[label + '/three-engine-review.json'] = (json.dumps(calculated, indent=2) + '\n').encode()
assessment = {'decision': 'rejected', 'promoted': False, 'pressure_passed': True,
              'cpu_and_latency_guards_passed': True,
              'reason': 'Both medium and longer capacity trials use more charged memory and process PSS than the accepted build.',
              'accepted_binary': '0be60915b40c9f70f39dcb3a0fd1f8918608a20095f767ec081a5b5320caa277',
              'rejected_binary': '4d0518fe5c82fead8641d71df6b16a7aba27664d13b6b2d125c657fe2b508482'}
files['retention-assessment.json'] = (json.dumps(assessment, indent=2) + '\n').encode()
(destination / 'retention-assessment.json').write_bytes(files['retention-assessment.json'])
for filename in ('run_sustained_sort_comparison.py', 'run_sort_observer_controls.py', 'run_warm_limit_pressure.py',
                 'prepare_warm_limit_pressure.py', 'build_warm_limit_candidate.py', 'screen_warm_limit.py',
                 'run_warm_limit_performance.py', 'freeze_sort_pressure_evidence.py'):
    include(workspace / filename, 'controllers/' + filename)
files['catalog.json'] = (json.dumps({'trials': catalog, 'setup_failure': bad_name}, indent=2) + '\n').encode()
archive = destination / 'evidence.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as handle:
    for name, content in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(content), 0o644, 0
        handle.addfile(info, io.BytesIO(content))
manifest = {'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'members': {name: hashlib.sha256(data).hexdigest() for name, data in sorted(files.items())}}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
rows = []
for campaign in campaigns:
    group = [t for t in catalog if t['campaign'] == campaign]
    for variant in sorted({t['variant'] for t in group}):
        arm = [t for t in group if t['variant'] == variant]
        rows.append({'campaign': campaign, 'variant': variant, 'runs': len(arm), 'passes': sum(t['passed'] for t in arm),
                     'successful_sorts': sum(t['successful_queries'] for t in arm),
                     'attempted_sorts': sum(t['queries'] for t in arm),
                     'oom_kills': sum(t['events']['oom_kill'] for t in arm),
                     'median_lifetime_peak_mib': statistics.median(t['peak_mib'] for t in arm)})
(destination / 'summary.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size, 'members': len(files), 'trials': len(catalog), 'summary': rows}), flush=True)
