from pathlib import Path

root = Path('/mnt/c/Users/DarkMoon/Desktop/Rust SQL')
text = (root / 'run_sort_observer_controls.py').read_text()
text = text.replace("campaign = 'sort-observer-controls2-20261031'", "campaign = 'warm-limit-pressure-20261031'")
old = "    'rust-unobserved': ('rustsql', base / 'guc-registry-reserve-candidate/bin', []),"
assert text.count(old) == 1
text = text.replace(old, "    'rust-unobserved': ('rustsql', base / 'warm-limit-candidate/bin', []),")
old = "    'rust-observed64': ('rustsql', base / 'guc-registry-reserve-candidate/bin', ['--allocator-observer', '--warm-reserve-mib', '64']),"
assert text.count(old) == 1
text = text.replace(old, "    'rust-observed64': ('rustsql', base / 'warm-limit-candidate/bin', ['--allocator-observer']),")
text = text.replace('rust-observed64', 'candidate-observed').replace('rust-unobserved', 'candidate-unobserved').replace('rust-observed', 'baseline-observed')
needle = "        assert hashlib.sha256((binary / 'postgres').read_bytes()).hexdigest() == expected_hash"
assert text.count(needle) == 1
text = text.replace(needle, """        if variant.startswith('candidate'):
            build = json.loads((base / 'warm-limit-build-20261031/report.json').read_text())
            assert build['passed']
            expected_hash = build['binaries']['postgres']['sha256']
""" + needle)
needle = "            assert not data['remaining_server_pids']"
assert text.count(needle) == 1
text = text.replace(needle, needle + """
            if variant == 'candidate-observed' and data['passed']:
                bounds = [row[4] for sample in data['ownership'] for row in sample['rows'] if row[1:3] == ['pool_reserve', 'bound']]
                targets = [row[4] for sample in data['ownership'] for row in sample['rows'] if row[1:3] == ['pool_reserve', 'target']]
                assert len(bounds) == len(targets) == 15
                assert set(bounds) == {64 * 2**20}, bounds
                assert max(targets) <= 64 * 2**20, targets
                record['memory_derived_ceiling_verified'] = True
""")
target = root / 'run_warm_limit_pressure.py'
assert not target.exists()
target.write_text(text)
compile(text, str(target), 'exec')
print(target)
