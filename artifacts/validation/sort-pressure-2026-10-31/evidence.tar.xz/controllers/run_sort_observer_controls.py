"""Repeat the historical load-session reproducer with and without SQL observers."""
import hashlib
import json
from pathlib import Path
import subprocess

base = Path('/home/rustsql')
campaign = 'sort-observer-controls2-20261031'
output = base / (campaign + '-summary.json')
assert not output.exists(), output
source_repo = Path('/mnt/c/Users/DarkMoon/Desktop/Rust SQL/pgrust/scripts/validation')
frozen = base / 'guc-registry-reserve-medium-20261031-source'
records = []
variants = {
    'postgresql': ('postgresql', base / 'postgres18/bin', []),
    'rust-unobserved': ('rustsql', base / 'guc-registry-reserve-candidate/bin', []),
    'rust-observed': ('rustsql', base / 'guc-registry-reserve-candidate/bin', ['--allocator-observer']),
    'rust-observed64': ('rustsql', base / 'guc-registry-reserve-candidate/bin', ['--allocator-observer', '--warm-reserve-mib', '64']),
}
for repetition, order in enumerate((['rust-observed', 'rust-unobserved', 'postgresql', 'rust-observed64'],
                                    ['rust-observed64', 'postgresql', 'rust-unobserved', 'rust-observed'],
                                    ['rust-unobserved', 'rust-observed', 'rust-observed64', 'postgresql']), 1):
    for variant in order:
        engine, binary, extra = variants[variant]
        expected_hash = '07b16e1aa4f0e2206c37b339b6e4cc813aa8ab9e3c5516334f753b3d90d0c536' if engine == 'postgresql' else '0be60915b40c9f70f39dcb3a0fd1f8918608a20095f767ec081a5b5320caa277'
        assert hashlib.sha256((binary / 'postgres').read_bytes()).hexdigest() == expected_hash
        name = f'{campaign}-{repetition}-{variant}'
        source = base / (name + '-source')
        source.mkdir(exist_ok=False)
        for filename in ('sustained_sort_probe.py', 'spill_probe.py', 'cluster.py', 'connection_churn_probe.py', 'connection_queue_probe.py', 'resource_scope.py'):
            root = frozen if filename == 'resource_scope.py' else source_repo
            (source / filename).write_bytes((root / filename).read_bytes().replace(b'\r\n', b'\n'))
        report_path = base / (name + '.json')
        command = ['systemd-run', '--unit=rustsql-qualification-' + name,
                   '--uid=rustsql', '--gid=rustsql', '--wait', '--collect',
                   '--property=Delegate=cpu memory pids cpuset', '--property=MemoryMax=4G',
                   '--property=MemorySwapMax=0', '--property=LimitSTACK=67108864',
                   '--property=RuntimeMaxSec=600', '--property=LimitNOFILE=65536',
                   '--property=StandardOutput=append:' + str(base / (name + '.log')),
                   '--property=StandardError=append:' + str(base / (name + '.log')),
                   '/usr/bin/python3', '-u', str(source / 'sustained_sort_probe.py'),
                   '--engine', engine, '--bin-dir', str(binary), '--work-dir', str(base / 'conformance' / 'sort-observer'),
                   '--output', str(report_path), '--reuse-loader-session', *extra]
        print(json.dumps({'starting': name}), flush=True)
        result = subprocess.run(command, capture_output=True, text=True, timeout=630)
        (base / (name + '-command.json')).write_text(json.dumps({'command': command, 'exit': result.returncode,
                                                               'stdout': result.stdout, 'stderr': result.stderr}, indent=2) + '\n')
        journal = subprocess.run(['journalctl', '-u', 'rustsql-qualification-' + name + '.service', '--no-pager', '-o', 'short-iso'], capture_output=True)
        (base / (name + '-journal.log')).write_bytes(journal.stdout + journal.stderr)
        record = {'name': name, 'repetition': repetition, 'variant': variant, 'exit': result.returncode}
        if report_path.exists():
            data = json.loads(report_path.read_text())
            record.update(passed=data['passed'], error=data.get('error'),
                          queries=len(data['queries']), successful_queries=sum(q['passed'] for q in data['queries']),
                          failed_queries=[{k: q.get(k) for k in ('index', 'sqlstate', 'error')} for q in data['queries'] if not q['passed']],
                          events=data['resources_after_shutdown']['events'], shutdown=data['shutdown_exit_codes'],
                          restart_count=data.get('restart_count'), peak_mib=data['resources_after_shutdown']['memory_peak'] / 2**20)
            assert not data['remaining_server_pids']
        else:
            record.update(passed=False, error='missing trial report')
        records.append(record)
        output.write_text(json.dumps({'complete': False, 'trials': records}, indent=2) + '\n')
        print(json.dumps(record), flush=True)
        if record.get('error') and not record.get('queries'):
            raise RuntimeError('harness/setup failure; subsequent trials have not been started')
output.write_text(json.dumps({'complete': True, 'trials': records}, indent=2) + '\n')
