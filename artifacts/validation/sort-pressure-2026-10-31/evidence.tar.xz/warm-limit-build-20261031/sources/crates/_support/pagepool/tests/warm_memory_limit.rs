//! A small server must not grow an optional prefault reserve to a large fraction of its hard memory limit.
#![cfg(target_os = "linux")]

mod common;
use common::*;
use pagepool::*;
use std::time::{Duration, Instant};

fn met() {
    let start = Instant::now();
    while !hooks::claimer_met() || stats().warm_zero < stats().warm_target {
        assert!(start.elapsed() < Duration::from_secs(5), "claimer did not refill: {:?}", stats());
        std::thread::sleep(Duration::from_millis(2));
    }
}

#[test]
fn the_memory_limit_bounds_growth_and_shrinks_without_revoking_live_spans() {
    init_with(|c| {
        c.warm_zero = 4 * MIB;
        c.warm_zero_max = 256 * MIB;
        c.idle_drain_ms = 600_000;
    });
    for (limit, bound) in [(0, 256), (1024, 64), (2048, 128), (4096, 256), (8192, 256), (128, 8), (1, 4)] {
        set_memory_limit(limit * MIB);
        assert_eq!(reserve_bound(), bound * MIB as u64, "the reserve must fit the published memory limit");
    }
    set_memory_limit(128 * MIB);
    assert!(start());
    let mut held = Vec::new();
    for _ in 0..4 {
        met();
        hooks::claimer_hold(true);
        let count = stats().warm_zero / SUPER + 2;
        for _ in 0..count {
            let block = span(SUPER, Hint::new(Class::Task, Tag::OTHER)).expect("span");
            // SAFETY: both locations belong to this committed span, held exclusively by the test.
            unsafe {
                block.as_ptr().write(37);
                block.as_ptr().add(block.len() - 1).write(91);
            }
            held.push(block);
        }
        assert_eq!(stats().warm_target, 8 * MIB, "repeated misses cannot exceed the memory-derived ceiling");
        hooks::claimer_hold(false);
    }
    met();
    set_memory_limit(64 * MIB);
    assert_eq!(stats().warm_target, 4 * MIB, "a smaller live limit must lower the target at once");
    for block in &held {
        // SAFETY: the span remains owned and committed across the limit update.
        unsafe {
            assert_eq!(block.as_ptr().read(), 37);
            assert_eq!(block.as_ptr().add(block.len() - 1).read(), 91);
        }
    }
    set_memory_limit(0);
    assert_eq!(reserve_bound(), 256 * MIB as u64, "an unknown limit restores the configured ceiling");
    assert_eq!(stats().warm_target, 4 * MIB, "raising a ceiling does not eagerly allocate its maximum");
    for block in held {
        // SAFETY: each span is owned by this test and is not used after it is returned.
        unsafe { give_span(block) };
    }
    stop();
    balanced();
}
