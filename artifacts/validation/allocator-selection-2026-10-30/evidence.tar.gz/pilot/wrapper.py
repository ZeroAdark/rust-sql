import sys
sys.path.insert(0,"/home/rustsql/pgrust/scripts/validation")
import connection_queue_probe as probe
class AllocatorCluster(probe.Cluster):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.env["PGRUST_ALLOCATOR"]="mimalloc"
probe.Cluster=AllocatorCluster
probe.main()
