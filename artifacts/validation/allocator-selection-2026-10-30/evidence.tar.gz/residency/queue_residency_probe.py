import sys,json,gzip,re
from pathlib import Path
sys.path.insert(0,"/home/rustsql/pgrust/scripts/validation")
import resource_scope
original=resource_scope.snapshot
count=0
def snapshot(group):
    global count
    result=original(group)
    if int((group/"pids.current").read_text()) >= 800 and count < 2:
        count+=1
        groups={};mappings=[]
        for pid in (group/"cgroup.procs").read_text().split():
            raw=Path("/proc",pid,"smaps").read_text()
            with gzip.open(f"/home/rustsql/queue-residency-{count}-{pid}-20261030.smaps.gz","wt") as out:out.write(raw)
            current=None
            for line in raw.splitlines():
                if re.match(r"^[0-9a-f]+-[0-9a-f]+ ",line):
                    parts=line.split(maxsplit=5);name=parts[5] if len(parts)==6 else "(anonymous)"
                    current={"pid":int(pid),"address":parts[0],"name":name};mappings.append(current)
                elif current is not None and line.split(":",1)[0] in ("Size","Rss","Pss","Anonymous","AnonHugePages"):
                    k,v=line.split(":",1);current[k]=int(v.split()[0])
        for m in mappings:
            g=groups.setdefault(m["name"],{k:0 for k in ("Size","Rss","Pss","Anonymous","AnonHugePages","mappings")});g["mappings"]+=1
            for k in ("Size","Rss","Pss","Anonymous","AnonHugePages"):g[k]+=m.get(k,0)
        Path(f"/home/rustsql/queue-residency-{count}-20261030.json").write_text(json.dumps({"units":"KiB","groups":dict(sorted(groups.items(),key=lambda x:-x[1]["Pss"])),"largest_mappings":sorted(mappings,key=lambda x:-x.get("Pss",0))[:30]},indent=2)+"\n")
    return result
resource_scope.snapshot=snapshot
import connection_queue_probe as probe
raise SystemExit(probe.main())
