"""Analyze saved scaling trials without running or changing either database."""
from pathlib import Path
import argparse,json,math,statistics,sys

parser=argparse.ArgumentParser();parser.add_argument('--input',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(Path(__file__).parent/'.scaling-plot-deps'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

MIB=2**20
names={'postgresql':'PostgreSQL 18.6','rustsql':'Rust SQL (retained binary)'}
colors={'postgresql':'#245DAD','rustsql':'#C35B10'}
records=[];campaigns={}
def pss(stage):
    sample=stage.get('process_sample',{})
    return sample.get('pss_bytes',0) if sample.get('complete') else 0
for dimension in ['data','connections']:
    root=args.input/f'memory-scaling-v2-{dimension}-20261031'
    if not (root/'summary.json').exists():continue
    summary=json.loads((root/'summary.json').read_text());metadata=json.loads((root/'metadata.json').read_text())
    campaigns[dimension]={'complete':summary['complete'],'boundary':summary.get('boundary'),'metadata':metadata}
    for item in summary['trials']:
        report=json.loads((root/item['report']).read_text())
        record={**item,'dimension':dimension,'source_report':(root/item['report']).relative_to(args.input).as_posix(),'error':report.get('error')}
        if not item['passed']:
            record['server_failure_resources']=report.get('resources_after_shutdown')
            record['driver_failure_resources']=report.get('driver_resources_after_shutdown')
            server_events=report.get('resources_after_shutdown',{}).get('events',{})
            driver_events=report.get('driver_resources_after_shutdown',{}).get('events',{})
            record['failure_class']='server_memory_limit' if server_events.get('oom',0) or server_events.get('oom_kill',0) else 'load_generator_memory_limit' if driver_events.get('oom',0) or driver_events.get('oom_kill',0) else 'connection_timeout' if 'ConnectionTimeout' in str(report.get('error')) else 'query_timeout' if 'QueryCanceled' in str(report.get('error')) else 'requires_investigation'
            records.append(record);continue
        m=report['measurement'];sample=m['sampled_resources']
        warm=m['connected_after_warmup'];end=m['connected_after_workload']
        pre=report['resources_before_workload'];post=report['resources_after_workload']
        record.update({
            'charged_mib':max(sample['sampled_memory_current_peak_bytes'],*[x['memory_current'] for x in [pre,warm,end]])/MIB,
            'pss_mib':max(sample['sampled_summed_pss_peak_bytes'],*[pss(x) for x in [pre,warm,end]])/MIB,
            'connected_end_pss_mib':pss(end)/MIB,
            'after_disconnect_pss_mib':pss(post)/MIB,
            'whole_lifetime_charged_mib':report['resources_after_shutdown']['memory_peak']/MIB,
            'setup_charged_mib':report['setup_sampling']['sampled_memory_current_peak_bytes']/MIB,
            'setup_pss_mib':report['setup_sampling']['sampled_summed_pss_peak_bytes']/MIB,
            'connected_anon_shmem_mib':(end['memory'].get('anon',0)+end['memory'].get('shmem',0))/MIB,
            'connected_filesystem_cache_mib':max(0,end['memory'].get('file',0)-end['memory'].get('shmem',0))/MIB,
            'connected_kernel_mib':end['memory'].get('kernel',0)/MIB,
            'driver_charged_mib':m['driver_resources_after_workload']['memory_current']/MIB,
            'driver_campaign_running_peak_mib':m['driver_resources_after_workload']['memory_peak']/MIB,
            'cpu_ms_per_bundle':m['server_cpu_us_per_bundle']/1000,
            'logical_cores_used':m['server_cpu_seconds']/m['elapsed_seconds'],
            'bundles_per_second':m['bundles_per_second'],
            'read_p99_ms':m['latency']['read']['p99_ms'],
            'update_p99_ms':m['latency']['update']['p99_ms'],
            'bundle_p99_ms':m['latency']['bundle']['p99_ms'],
            'server_throttled_us':m['cpu_delta']['throttled_usec'],
            'driver_throttled_us':m['client_cpu_delta']['throttled_usec'],
            'performance_timing_eligible':not(m['cpu_delta']['throttled_usec'] or m['client_cpu_delta']['throttled_usec']),
            'memory_events':report['resources_after_shutdown']['events'],
            'sampler_incomplete_pss_samples':sample['incomplete_process_samples'],
            'complete_endpoint_pss':all(x['process_sample']['complete'] for x in [pre,warm,end]),
            'facts_relation_mib':next(r[3] for r in report['relation_sizes'] if r[0]=='bench_facts')/MIB,
            'data_directory_mib':report['data_directory_allocated_bytes']/MIB,
        })
        records.append(record)

metrics=['charged_mib','pss_mib','connected_end_pss_mib','after_disconnect_pss_mib','whole_lifetime_charged_mib',
         'setup_charged_mib','setup_pss_mib','connected_anon_shmem_mib','connected_filesystem_cache_mib','connected_kernel_mib',
         'driver_charged_mib','driver_campaign_running_peak_mib','cpu_ms_per_bundle','logical_cores_used','bundles_per_second',
         'read_p99_ms','update_p99_ms','bundle_p99_ms','facts_relation_mib','data_directory_mib']
points=[]
for dimension in campaigns:
    for value in sorted({r['value'] for r in records if r['dimension']==dimension}):
        for engine in names:
            group=[r for r in records if r['dimension']==dimension and r['value']==value and r['engine']==engine and r['passed']]
            if not group:continue
            point={'dimension':dimension,'value':value,'engine':engine,'repeats':len(group),
                   'uncensored':all(not any(r['memory_events'].get(k,0) for k in ['max','oom','oom_kill']) for r in group),
                   'guard_or_limit_boundary':any(r['pressure_boundary'] for r in group),
                   'complete_endpoint_pss':all(r['complete_endpoint_pss'] for r in group),
                   'throttled_trials':sum(bool(r['server_throttled_us'] or r['driver_throttled_us']) for r in group)}
            point['metrics']={k:{'median':statistics.median(r[k] for r in group),'min':min(r[k] for r in group),'max':max(r[k] for r in group)} for k in metrics}
            points.append(point)

def fit_two(z,y):
    # Nonnegative intercept and slope: compare the interior and both boundaries.
    X=np.column_stack([np.ones(len(z)),z]);coef=np.linalg.lstsq(X,y,rcond=None)[0]
    candidates=[np.array([np.mean(y),0.]),np.array([0.,max(0.,np.dot(z,y)/np.dot(z,z))])]
    if np.all(coef>=0):candidates.append(coef)
    coef=min(candidates,key=lambda c:np.sum((X@c-y)**2))
    return coef,X@coef

def fit_model(x,y,kind,xscale):
    if kind=='constant':
        a=float(np.mean(y));return {'intercept_mib':a,'scale_mib':0.,'power':None},np.full_like(y,a)
    powers=np.linspace(.05,1.5,146) if kind=='power' else [None]
    candidates=[]
    for power in powers:
        z=np.log1p(x/xscale) if kind=='logarithmic' else x/xscale if kind=='linear' else (x/xscale)**power
        coef,pred=fit_two(z,y)
        candidates.append((float(np.sum((pred-y)**2)),coef,pred,power))
    _,coef,pred,power=min(candidates,key=lambda c:c[0])
    return {'intercept_mib':float(coef[0]),'scale_mib':float(coef[1]),'power':None if power is None else float(power)},pred

def predict(x,model,kind,xscale):
    if kind=='constant':return np.full_like(x,model['intercept_mib'])
    z=np.log1p(x/xscale) if kind=='logarithmic' else x/xscale if kind=='linear' else (x/xscale)**model['power']
    return model['intercept_mib']+model['scale_mib']*z

fits=[]
for dimension in campaigns:
    for engine in names:
        group=[p for p in points if p['dimension']==dimension and p['engine']==engine and p['repeats']>=3 and p['uncensored']]
        if len(group)<5:continue
        x=np.array([p['value'] for p in group],dtype=float);xscale=float(min(x))
        for metric in ['charged_mib','pss_mib','connected_end_pss_mib','whole_lifetime_charged_mib']:
            y=np.array([p['metrics'][metric]['median'] for p in group],dtype=float)
            for kind in ['constant','logarithmic','linear','power']:
                model,pred=fit_model(x,y,kind,xscale);errors=[]
                for i in range(len(x)):
                    keep=np.arange(len(x))!=i
                    folded,_=fit_model(x[keep],y[keep],kind,xscale)
                    errors.append(float(predict(x[i:i+1],folded,kind,xscale)[0]-y[i]))
                fits.append({'dimension':dimension,'engine':engine,'metric':metric,'kind':kind,'n':len(x),'x_scale':xscale,**model,
                             'rmse_mib':float(np.sqrt(np.mean((pred-y)**2))),
                             'loo_rmse_mib':float(np.sqrt(np.mean(np.array(errors)**2))),
                             'loo_relative_rmse_percent':float(100*np.sqrt(np.mean((np.array(errors)/y)**2)))})

slopes=[];large_range_fits=[]
for dimension in campaigns:
    for engine in names:
        group=[p for p in points if p['dimension']==dimension and p['engine']==engine and p['repeats']>=3 and p['uncensored']]
        for metric in ['charged_mib','pss_mib','whole_lifetime_charged_mib']:
            for left,right in zip(group,group[1:]):
                lm,rm=left['metrics'][metric],right['metrics'][metric]
                scale=MIB/(right['value']-left['value'])
                slopes.append({'dimension':dimension,'engine':engine,'metric':metric,'from':left['value'],'to':right['value'],
                               'marginal_bytes_per_unit':(rm['median']-lm['median'])*scale,
                               'observed_range_low':(rm['min']-lm['max'])*scale,'observed_range_high':(rm['max']-lm['min'])*scale})
            high=[p for p in group if dimension=='data' and p['value']>=3000000]
            if len(high)>=3:
                x=np.array([p['value'] for p in high],dtype=float)/1e6
                y=np.array([p['metrics'][metric]['median'] for p in high],dtype=float)
                coef,pred=fit_two(x,y)
                large_range_fits.append({'dimension':dimension,'engine':engine,'metric':metric,'from':int(x[0]*1e6),'to':int(x[-1]*1e6),
                                        'intercept_mib':float(coef[0]),'bytes_per_row':float(coef[1]*MIB/1e6),
                                        'rmse_mib':float(np.sqrt(np.mean((pred-y)**2)))})

crossovers=[]
for dimension in campaigns:
    for metric in ['charged_mib','pss_mib','whole_lifetime_charged_mib']:
        comparison=[]
        for value in sorted({p['value'] for p in points if p['dimension']==dimension}):
            pair={p['engine']:p for p in points if p['dimension']==dimension and p['value']==value and p['repeats']>=3 and p['uncensored']}
            if len(pair)!=2:continue
            pg=pair['postgresql']['metrics'][metric];rust=pair['rustsql']['metrics'][metric]
            direction='rust_lower' if rust['max']<pg['min'] else 'postgresql_lower' if pg['max']<rust['min'] else 'overlapping_ranges'
            comparison.append({'value':value,'direction':direction,'median_rust_over_pg':rust['median']/pg['median']})
        crossovers.append({'dimension':dimension,'metric':metric,'comparisons':comparison})

restart_records=[]
restart_root=args.input/'memory-scaling-restart-20261031'
restart_summary=None
if (restart_root/'summary.json').exists():
    restart_summary=json.loads((restart_root/'summary.json').read_text())
    for item in restart_summary['trials']:
        report=json.loads((restart_root/item['report']).read_text())
        row={**item,'source_report':(restart_root/item['report']).relative_to(args.input).as_posix(),'error':report.get('error')}
        if item['passed']:
            for phase,key,prekey in [('before','measurement','resources_before_workload'),('after','measurement_after_restart','resources_before_restarted_workload')]:
                m=report[key];sample=m['sampled_resources'];stages=[report[prekey],m['connected_after_warmup'],m['connected_after_workload']]
                row[phase+'_pss_mib']=max(sample['sampled_summed_pss_peak_bytes'],*[pss(x) for x in stages])/MIB
                row[phase+'_charged_mib']=max(sample['sampled_memory_current_peak_bytes'],*[x['memory_current'] for x in stages])/MIB
                row[phase+'_cpu_ms_per_bundle']=m['server_cpu_us_per_bundle']/1000
            row['setup_cache_trace']=report.get('setup_cache_trace')
            for key in ['cache_after_plans','cache_after_workload','cache_immediately_after_restart','cache_after_restart_aggregate','cache_after_restarted_workload']:
                row[key]=report.get(key)
        restart_records.append(row)

result={'campaigns':campaigns,'records':records,'points':points,'fits':fits,'large_range_linear_fits':large_range_fits,'marginal_slopes':slopes,'crossovers':crossovers,
        'restart_control':{'complete':restart_summary['complete'] if restart_summary else False,'records':restart_records},
        'interpretation_limits':['Finite measurements cannot prove an asymptotic complexity class.',
            'Fixed buffers, retained allocator pages, filesystem cache and per-session allocations are different contributors.',
            'Filesystem cache can be reclaimed under pressure. A linear fit of unconstrained charged memory is not proof of unavoidable engine allocation growth or of behavior at a tighter memory limit.',
            'Three-run min/max ranges are observed variation, not confidence intervals.',
            'PSS is sampled plus synchronized connected endpoints; transient peaks can still be missed.',
            'CPU and latency are diagnostic; short unpaced runs and a different CPU/memory envelope do not qualify an optimization.',
            'The schema is synthetic, narrow and highly compressible; compression and query working sets determine crossover locations.',
            'Connections start in a synchronized burst with a three-second connect timeout. A connection timeout is not evidence of a RAM limit or a maximum sustainable connection count.',
            'The driver cgroup is reused within a campaign: its memory.peak is a campaign running peak, not a per-trial peak.',
            'At six clients, each trial measures 864 reads, 288 updates and 72 instances of each analytical query; analytical p99 is therefore the observed maximum under the nearest-rank convention.',
            'The statement mix is 12 reads, 4 updates and 3 analytical queries per bundle. At large row counts, analytical work dominates CPU; these savings do not establish pure-OLTP performance.'],
        'analysis_dependencies':{'python':sys.version,'numpy':np.__version__,'matplotlib':matplotlib.__version__}}
(args.output/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')

plt.rcParams.update({'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'font.size':10})
available=[d for d in ['data','connections'] if any(p['dimension']==d for p in points)]
if available:
    fig,axes=plt.subplots(len(available),2,figsize=(12,4.5*len(available)),squeeze=False,layout='constrained')
    for row,dimension in enumerate(available):
        for col,metric in enumerate(['charged_mib','pss_mib']):
            ax=axes[row,col]
            for engine in names:
                group=[p for p in points if p['dimension']==dimension and p['engine']==engine]
                x=[p['value'] for p in group];m=[p['metrics'][metric]['median'] for p in group]
                low=[p['metrics'][metric]['min'] for p in group];high=[p['metrics'][metric]['max'] for p in group]
                ax.plot(x,m,'o-',color=colors[engine],label=names[engine],linewidth=2,markersize=4)
                ax.fill_between(x,low,high,color=colors[engine],alpha=.15)
                for p in group:
                    if p['guard_or_limit_boundary']:ax.scatter([p['value']],[p['metrics'][metric]['median']],marker='x',s=90,color='black',zorder=5)
                    if p['repeats']<3:ax.annotate(f"n={p['repeats']}",(p['value'],p['metrics'][metric]['median']),xytext=(-16,9),textcoords='offset points',fontsize=8)
            deadline_values=sorted({r['value'] for r in records if r['dimension']==dimension and not r['passed'] and r['failure_class']=='connection_timeout'})
            for value in deadline_values:
                ax.axvline(value,color='#777777',linestyle=':',linewidth=1)
                ax.annotate('Connection deadline\n'+f'{value:,} clients',xy=(value,.03),xycoords=('data','axes fraction'),xytext=(-7,0),textcoords='offset points',ha='right',va='bottom',fontsize=8,color='#555555')
            ax.set_xscale('log');ax.set_yscale('log');ax.grid(True,alpha=.18,which='both')
            ax.set_ylabel('MiB (log scale)');ax.set_xlabel('Fact rows; six active clients' if dimension=='data' else 'Active clients; one million fact rows')
            ax.set_title('Charged server memory, including cache' if metric=='charged_mib' else 'Observed process memory (PSS)')
            ax.legend(fontsize=8,loc='best')
    fig.suptitle('Memory scaling on this PC\nSame completed work per client; 24 GiB server limit',fontsize=15)
    fig.supxlabel('Shading: observed run range, not a confidence interval. n=1: one completed trial. Dotted line: connection deadline.',fontsize=8)
    fig.savefig(args.output/'memory-scaling.png',dpi=180)
    fig.savefig(args.output/'memory-scaling.svg')
    plt.close(fig)

lines=['# Memory scaling experiment','',
       'Local experiment using the retained Rust SQL binary and PostgreSQL 18.6. This report is descriptive, not a production qualification.','',
       'Each point runs 6 warmup and 12 measured mixed-workload bundles per client. A bundle has 12 point reads, 4 committed updates, and 3 analytical queries. Facts use PostgreSQL heap storage or Rust columnar storage; accounts remain 120,000 rows. Loading uses batches of at most one million rows. Results, protocol type IDs, committed balances and restart persistence are checked.','',
       'The server gets 24 GiB and 12 logical CPUs spanning six cores in the WSL topology; clients use two other cores. The PC has 64 GiB installed RAM and WSL currently exposes about 30 GiB. Swap is disabled for both test groups. PostgreSQL shared_buffers stays at 128 MiB; work_mem is 16 MiB for both engines. Active-query admission follows the tested client count, so this explores active concurrency, including overload.','',
       'Charged memory includes filesystem cache. PSS apportions shared mappings and is not summed RSS. The main query-window peaks combine periodic samples with synchronized readings after warmup and after completed work while connections remain open. The exact cgroup lifetime peak, including setup and restart, is retained separately.','']
if all(c['complete'] for c in campaigns.values()) and restart_summary and restart_summary['complete']:
    def median_at(dimension,value,engine,metric):
        return next(p for p in points if (p['dimension'],p['value'],p['engine'])==(dimension,value,engine))['metrics'][metric]['median']
    rust_fit=next(f for f in large_range_fits if f['engine']=='rustsql' and f['metric']=='pss_mib')
    pg_fit=next(f for f in large_range_fits if f['engine']=='postgresql' and f['metric']=='pss_mib')
    small_cpu=median_at('data',10000,'rustsql','cpu_ms_per_bundle')/median_at('data',10000,'postgresql','cpu_ms_per_bundle')
    large_cpu=median_at('data',300000000,'rustsql','cpu_ms_per_bundle')/median_at('data',300000000,'postgresql','cpu_ms_per_bundle')
    large_speed=median_at('data',300000000,'rustsql','bundles_per_second')/median_at('data',300000000,'postgresql','bundles_per_second')
    steady=[p for p in points if p['dimension']=='connections' and p['engine']=='rustsql' and p['repeats']==3 and not p['throttled_trials']]
    best_speed=max(p['metrics']['bundles_per_second']['median'] for p in steady)
    at24=median_at('connections',24,'rustsql','bundles_per_second')
    lines+=['## Conclusions','',
        f"The large-data CPU advantage persists: at 300 million rows, Rust uses {100*(1-large_cpu):.1f}% less server CPU per completed bundle and delivers {large_speed:.1f} times PostgreSQL throughput. At 10,000 rows it uses {100*(small_cpu-1):.1f}% more CPU. The savings belong to this analytical-heavy resource mix, not to every SQL workload.",'',
        'Charged-memory ranges cross between 3 million and 10 million rows in all three repeats. Rust process PSS remains higher at every tested size. PostgreSQL uses substantially more filesystem cache; that cache is reclaimable, so the charged-memory crossover does not close the process-memory gap.','',
        f"Over 3 million to 300 million rows, Rust PSS is well described by a fixed intercept of {rust_fit['intercept_mib']:.0f} MiB plus {rust_fit['bytes_per_row']:.2f} bytes per row (fit RMSE {rust_fit['rmse_mib']:.1f} MiB). PostgreSQL PSS is nearly flat in this range, around {pg_fit['intercept_mib']:.0f} MiB with fixed buffers. These are empirical fits within the measured configuration, not Big-O proofs or extrapolations past memory pressure.",'',
        f"Concurrency adds memory much faster than useful throughput. At one million rows, 24 active clients deliver {100*at24/best_speed:.1f}% of Rust's best repeated median throughput. At 384 clients, Rust uses {median_at('connections',384,'rustsql','charged_mib'):.0f} MiB charged memory versus PostgreSQL's {median_at('connections',384,'postgresql','charged_mib'):.0f} MiB. This suggests testing admission and per-session overhead before allowing hundreds of simultaneously active queries; it is not a universal connection-pool recommendation.",'',
        'The 768-client boundary is a PostgreSQL three-second connection timeout during synchronized startup, with no server or driver memory-limit/OOM event. Rust completes that one trial, but throughput declines. It does not establish PostgreSQL\'s maximum sustainable connections or a RAM limit.','',
        'Restarting and rerunning the workload does not remove most Rust process memory. Shared decoded-data counters reset at restart and grow again when the aggregate runs. At 300 million rows this class reaches about 866 MiB despite a 256 MiB decoded-cache cap; cached and held remain zero. The source explicitly excludes this shared (sticky) class from that cap. The counters explain part of the row-dependent growth, not all process memory.','',
        'Memory optimization is still justified: profile fixed/session overhead first, then evaluate bounded decoded-data retention with CPU and latency guards. Lowering the existing cache-size setting alone does not bound the shared class. No runtime/default is promoted by this experiment, and the original fixed-rate medium-load memory/read/update targets remain open.','',
        f"The main size and concurrency campaigns retain {sum(r['passed'] for r in records)} successful trials and {sum(not r['passed'] for r in records)} failed trial; all {len(restart_records)} restart controls pass. The archive also retains the pilot and the rejected small-integer generate_series harness, which failed on both engines before explicit integer casts were added.",'',
        '![Memory scaling](memory-scaling.png)','']
throttled=[r for r in records if r['passed'] and not r['performance_timing_eligible']]
if throttled:
    lines+=['## Timing validity','',
            'The concurrency campaign is not eligible for performance qualification. Its raw CPU/throughput/latency values remain descriptive, and the affected table row is marked with a dagger. Memory observations remain in the memory fits. No dataset-size trial has timed server or driver throttling.','']
    for row in throttled:
        lines.append(f"- {row['dimension']}, {row['value']:,}, {names[row['engine']]}, repeat {row['repeat']}: server throttled {row['server_throttled_us']/1000:.3f} ms; driver throttled {row['driver_throttled_us']/1000:.3f} ms.")
    lines+=['']
for dimension in available:
    lines+=['## '+('Rows at six clients' if dimension=='data' else 'Clients at one million rows'),'','| Size | Engine | Runs | Charged MiB | PSS MiB | CPU ms/bundle | Bundles/s | Read p99 ms | Update p99 ms |','|---:|---|---:|---:|---:|---:|---:|---:|---:|']
    for point in [p for p in points if p['dimension']==dimension]:
        m=point['metrics'];values=[m[k]['median'] for k in ['charged_mib','pss_mib','cpu_ms_per_bundle','bundles_per_second','read_p99_ms','update_p99_ms']]
        label=names[point['engine']]+(' †' if point['throttled_trials'] else '')
        lines.append(f"| {point['value']:,} | {label} | {point['repeats']} | "+' | '.join(f'{v:,.3f}' for v in values)+' |')
    lines+=['']
if large_range_fits:
    lines+=['## Large-row linear fits','','These nonnegative intercept-and-slope fits use completed, uncapped points with at least three repeats and at least three million rows. The slopes describe this observed range, not an asymptotic proof.','',
            '| Engine | Metric | Row range | Intercept MiB | Bytes per additional row | RMSE MiB |','|---|---|---|---:|---:|---:|']
    for fit in large_range_fits:
        lines.append(f"| {names[fit['engine']]} | {fit['metric']} | {fit['from']:,}–{fit['to']:,} | {fit['intercept_mib']:,.3f} | {fit['bytes_per_row']:.3f} | {fit['rmse_mib']:.3f} |")
    lines+=['']
if restart_records:
    lines+=['## Rust restart control','','The same stored facts are queried with six clients after restarting the process. Account balances are reset so the workload has the same oracle. This distinguishes memory retained across loading from memory reconstructed by subsequent queries.','',
            '| Rows | Run | Before restart PSS MiB | After restart PSS MiB |','|---:|---:|---:|---:|']
    for row in restart_records:
        if row['passed']:lines.append(f"| {row['rows']:,} | {row['repeat']} | {row['before_pss_mib']:,.3f} | {row['after_pss_mib']:,.3f} |")
    lines+=['']
    lines+=['The shared decoded-data class is reported separately from the cap. The following medians include only available diagnostic counters; no unavailable value is replaced with zero.','',
            '| Rows | Runs | PSS before restart MiB | PSS after restart/work MiB | Shared decoded data after work MiB | Cache cap MiB |','|---:|---:|---:|---:|---:|---:|']
    for size in sorted({r['rows'] for r in restart_records if r['passed']}):
        group=[r for r in restart_records if r['rows']==size and r['passed']]
        counters=[r['cache_after_restarted_workload']['counters'] for r in group if r.get('cache_after_restarted_workload',{}).get('available')]
        sticky=f"{statistics.median(c['sticky'] for c in counters)/MIB:,.3f}" if counters else 'unavailable'
        cap=f"{statistics.median(c['cap'] for c in counters)/MIB:,.3f}" if counters else 'unavailable'
        lines.append(f"| {size:,} | {len(group)} | {statistics.median(r['before_pss_mib'] for r in group):,.3f} | {statistics.median(r['after_pss_mib'] for r in group):,.3f} | {sticky} | {cap} |")
    lines+=['']
failed=[r for r in records if not r['passed']]
if failed:
    lines+=['## Observed failures','']
    for row in failed:lines.append(f"- {row['dimension']}, value {row['value']:,}, {names[row['engine']]}: {row['failure_class']}. Raw error: {row['error']}")
    lines+=['']
lines+=['## Interpretation limits','']+['- '+x for x in result['interpretation_limits']]
lines+=['','The JSON contains per-trial results, observed ranges, constant/log/linear/power fits with leave-one-point-out prediction error, resource breakdowns, throttling, and failures. Model fit is an empirical description only. Fits require at least three successful repeats without memory-limit events. Failures remain in the records; successful boundary runs remain in the plots.','']
(args.output/'report.md').write_text('\n'.join(lines),encoding='utf-8')
print(json.dumps({'points':len(points),'trials':len(records),'complete':{d:c['complete'] for d,c in campaigns.items()},'output':str(args.output)}))
