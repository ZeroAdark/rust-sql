from pathlib import Path
import json,subprocess,sys
base=Path('/home/rustsql');dimension=sys.argv[1];assert dimension in ('pilot','data','connections')
label='memory-scaling-v2-'+dimension+'-20261031';unit='rustsql-qualification-'+label
cmd=['systemd-run','--unit='+unit,'--uid=rustsql','--gid=rustsql','--wait','--collect',
     '--property=Delegate=cpu memory pids','--property=MemoryMax=28G','--property=MemorySwapMax=0',
     '--property=CPUQuota=1400%','--property=TasksMax=8192','--property=LimitNOFILE=65536',
     '--property=LimitSTACK=67108864','--property=RuntimeMaxSec=14400',
     '--property=StandardOutput=append:'+str(base/(label+'.log')),
     '--property=StandardError=append:'+str(base/(label+'.log')),
     '/usr/bin/python3','-u',str(base/'memory-scaling-connections-source-20261031/memory_scaling_driver.py'),
     '--dimension',dimension,'--output',str(base/label)]
(base/(label+'-command.json')).write_text(json.dumps({'command':cmd,'state':'running'},indent=2)+'\n')
r=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=14430)
(base/(label+'-command.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode,'output':r.stdout},indent=2)+'\n')
(base/(label+'-journal.log')).write_bytes(subprocess.check_output(['journalctl','-u',unit+'.service','--no-pager','-o','short-iso']))
print(label,r.returncode,flush=True)
print((base/(label+'.log')).read_text()[-2200:],flush=True)
r.check_returncode()
