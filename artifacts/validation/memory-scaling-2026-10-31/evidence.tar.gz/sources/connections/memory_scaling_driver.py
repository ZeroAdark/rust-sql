from pathlib import Path
from types import SimpleNamespace
import argparse,hashlib,json,os,platform,re,resource,shutil,time
import fixed_workload as workload
from postgres_comparison import trial
from resource_scope import DelegatedScope

if not __debug__:raise RuntimeError("Assertions must remain enabled")
parser=argparse.ArgumentParser()
parser.add_argument('--dimension',choices=['pilot','data','connections'],required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();base=Path('/home/rustsql');root=args.output
root.mkdir(exist_ok=False)
work=root/'clusters';work.mkdir()
resource.setrlimit(resource.RLIMIT_STACK,(65520*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
server_cpus=[0,1,2,3,4,5,6,7,12,13,14,15];client_cpus=[8,10]
scope=DelegatedScope(server_cpus,client_cpus)
identities={'postgresql':'07b16e1aa4f0e2206c37b339b6e4cc813aa8ab9e3c5516334f753b3d90d0c536',
            'rustsql':'02cfbca6869bb352c8081b1fb275cdd4317b33a72b8feb05c563408e4c48d454'}
binaries={'postgresql':base/'postgres18/bin','rustsql':base/'vma-residency-candidate/bin'}
for name,path in binaries.items():assert hashlib.sha256((path/'postgres').read_bytes()).hexdigest()==identities[name]
values={'pilot':[1000000],'data':[10000,30000,100000,300000,1000000,3000000,10000000,30000000,100000000,300000000],
        'connections':[1,3,6,12,24,48,96,192,384,768]}[args.dimension]
repeats=1 if args.dimension=='pilot' else 3
metadata={"assertions_enabled":__debug__,"python_version":platform.python_version(),'dimension':args.dimension,'values':values,'repeats':repeats,'bundles_per_client':12,'warmup_per_client':6,
          'phase':'unpaced fixed completed work','account_rows':120000,'memory_mib':24576,
          'rust_active_query_cap':'clients (same simultaneously active clients as PostgreSQL)', 'ingest_batch_rows':1000000,'server_cpus':server_cpus,'client_cpus':client_cpus,
          'binary_sha256':identities,'platform':platform.platform(),'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(__file__).parent.glob('*.py')},
          'sampling':'50 ms cgroup, 500 ms process PSS; setup and warmup+execution sampled separately; memory.peak is whole-server lifetime',
          'stop_rules':'Stop increasing a dimension after an engine failure or 85% of the server cap / any memory.max event. Keep every trial. Repeat successful uncensored points twice, in reverse and then original order.',
          'host_meminfo_start':Path('/proc/meminfo').read_text(),'started_unix':time.time()}
(root/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
summary={'complete':False,'production_qualified':False,'trials':[],'boundary':None}
def save():
    temporary=root/'summary.tmp';temporary.write_text(json.dumps(summary,indent=2)+'\n');temporary.replace(root/'summary.json')
save();successful=[]
def point(value,repeat):
    rows=value if args.dimension=='data' else 1000000
    clients=value if args.dimension=='connections' else 6
    workload.SHARD_ROWS=120000//clients
    assert workload.SHARD_ROWS>0
    expected=workload.expected_updates(clients,18)
    assert sum(v for _,v in expected)==clients*18*4 and all(1<=i<=120000 for i,_ in expected)
    folder=root/str(value);folder.mkdir(exist_ok=True)
    config=SimpleNamespace(candidate=binaries['rustsql'],reference=binaries['postgresql'],work_dir=work,
        rows=rows,clients=clients,memory_mib=24576,bundles=12,warmup=6,candidate_policy='',output_dir=folder)
    point_ok=True;point_boundary=[]
    for engine in (('postgresql','rustsql') if (repeat+values.index(value))%2 else ('rustsql','postgresql')):
        available=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
        if available < 5*2**30:raise RuntimeError('host memory headroom fell below 5 GiB before a new trial')
        started=time.monotonic()
        try:result=trial(config,scope,engine,repeat,None,'scaling')
        except Exception:
            report=folder/f'scaling-{engine}-{repeat}.json'
            if not report.exists():raise
            result=json.loads(report.read_text());point_ok=False
        final=result['resources_after_shutdown'];pressure=any(final['events'].get(k,0) for k in ['oom','oom_kill','max']) or final['memory_peak']>=.85*24576*2**20
        item={'value':value,'rows':rows,'clients':clients,'repeat':repeat,'engine':engine,'passed':result['passed'],
              'seconds':time.monotonic()-started,'pressure_boundary':pressure,'report':str((folder/f'scaling-{engine}-{repeat}.json').relative_to(root))}
        summary['trials'].append(item);save()
        if pressure or not result['passed']:point_boundary.append(item)
        cluster=Path(result['cluster']).resolve()
        if result['passed'] and result['shutdown_exit_codes']==[0,0] and not result['remaining_server_pids']:
            assert cluster.parent==work.resolve() and cluster.name.startswith('compat-')
            logdir=folder/(engine+'-'+str(repeat)+'-logs');logdir.mkdir()
            for p in cluster.glob('*.log'):shutil.copyfile(p,logdir/p.name)
            shutil.rmtree(cluster)
    return point_ok,point_boundary
for value in values:
    okay,boundary=point(value,1)
    if boundary:
        summary['boundary']={'dimension':args.dimension,'value':value,'trials':boundary};save();break
    if okay:successful.append(value)
for repeat in range(2,repeats+1):
    for value in reversed(successful) if repeat==2 else successful:
        okay,boundary=point(value,repeat)
        if not okay:raise RuntimeError('repeat failed; preserve campaign for investigation')
        if boundary:summary.setdefault('repeat_boundaries',[]).append({'value':value,'repeat':repeat,'trials':boundary});save()
for name,path in binaries.items():assert hashlib.sha256((path/'postgres').read_bytes()).hexdigest()==identities[name]
summary['complete']=True;summary['successful_values']=successful;summary['finished_unix']=time.time();save()
print(json.dumps({'complete':True,'dimension':args.dimension,'trials':len(summary['trials']),'boundary':summary['boundary']}),flush=True)
