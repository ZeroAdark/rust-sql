from pathlib import Path
import subprocess,json,sys,shutil
base=Path('/home/rustsql');label=sys.argv[1];phase=sys.argv[2];bundles=sys.argv[3];repeats=sys.argv[4];warmup=sys.argv[5];rate=None if len(sys.argv)<7 or sys.argv[6]=='none' else sys.argv[6];binary=Path(sys.argv[7]);policy=sys.argv[8] if len(sys.argv)>8 else ''
source=base/(label+'-source');source.mkdir(exist_ok=False)
for n in ['postgres_comparison.py','fixed_workload.py','cluster.py','connection_churn_probe.py','connection_queue_probe.py','resource_scope.py']:shutil.copyfile(base/'pgrust/scripts/validation'/n,source/n)
cmd=['systemd-run','--unit=rustsql-qualification-'+label,'--uid=rustsql','--gid=rustsql','--wait','--collect','--property=Delegate=cpu memory pids','--property=MemoryMax=8G','--property=MemorySwapMax=0','--property=CPUQuota=600%','--property=LimitSTACK=67108864','--property=RuntimeMaxSec=2400','--property=StandardOutput=append:'+str(base/(label+'.log')),'--property=StandardError=append:'+str(base/(label+'.log')),'/usr/bin/python3','-u',str(source/'postgres_comparison.py'),'--candidate',str(binary),'--reference',str(base/'postgres18/bin'),'--work-dir',str(base/'conformance'),'--output-dir',str(base/label),'--phase',phase,'--bundles',bundles,'--repeats',repeats,'--warmup',warmup]
if rate:cmd+=['--bundle-rate',rate]
if policy:cmd+=['--candidate-policy',policy]
r=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=2430)
(base/(label+'-command.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode,'output':r.stdout},indent=2)+'\n');(base/(label+'-journal.log')).write_bytes(subprocess.check_output(['journalctl','-u','rustsql-qualification-'+label+'.service','--no-pager','-o','short-iso']))
print(label,r.returncode,flush=True);print((base/(label+'.log')).read_text()[-3000:],flush=True);r.check_returncode()
