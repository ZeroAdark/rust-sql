from pathlib import Path
import hashlib,json,statistics,tarfile,io,shutil
base=Path('/home/rustsql');repo=base/'pgrust';destination=repo/'artifacts/validation/bounded-small-refill-2026-10-30'
phases=['capacity','medium'];rollup={};members={}
for phase in phases:
 root=base/f'bounded-small-{phase}-20261030';source=base/(root.name+'-source')
 summary=json.loads((root/'summary.json').read_text());assert summary['complete'] and summary['passed'] and len(summary['trials'])==15
 meta=json.loads((root/'metadata.json').read_text());assert meta['binary_sha256']['rustsql']=='ce85a3a3a2726ff57bc1a1d3594f5ee7a5a6d3fc1d3250bf9b7590a01c66cc83'
 assert meta['binary_sha256']['postgresql']=='07b16e1aa4f0e2206c37b339b6e4cc813aa8ab9e3c5516334f753b3d90d0c536'
 for name,sha in meta['source_lf_sha256'].items():assert hashlib.sha256((source/name).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==sha
 for p in [*root.glob('*.json'),*source.glob('*.py'),base/(root.name+'.log'),base/(root.name+'-command.json'),base/(root.name+'-journal.log')]:members[str(p.relative_to(base))]=p.read_bytes()
 rollup[phase]={}
 for engine in ['postgresql','rustsql-baseline','rustsql']:
  reports=[json.loads((root/f'{phase}-{engine}-{i}.json').read_text()) for i in range(1,6)];assert len(reports)==5
  for d in reports:
   m=d['measurement'];assert d['passed'] and m['passed'] and d['shutdown_exit_codes']==[0,0] and not d['remaining_server_pids']
   assert d['state_after_restart']==d['state_before_restart']
   settings={n:s for n,s,_ in d['settings']};assert settings['fsync']=='on' and settings['synchronous_commit']=='on'
   assert d['limits']['cpu.max']=='400000 100000' and d['limits']['memory.max']==str(2048*2**20) and d['limits']['memory.swap.max']=='0'
   assert not any(d['resources_after_shutdown']['events'][n] for n in ['oom','oom_kill','oom_group_kill','max'])
   assert m['cpu_delta']['nr_throttled']==0 and m['client_cpu_delta']['nr_throttled']==0 and not d['resources_after_shutdown']['memory_swap_current']
   assert d['state_after_restart']['committed_updates']==meta['clients']*(meta['bundles']+meta['warmup'])*4
   for kind,n in (meta['statements_per_bundle']|{'bundle':1}).items():
    l=m['latency'][kind];assert l['count']==meta['clients']*meta['bundles']*n and 0<=l['p50_ms']<=l['p95_ms']<=l['p99_ms']<=l['max_ms']
   assert abs(m['server_cpu_us_per_bundle']-m['cpu_delta']['usage_usec']/(meta['clients']*meta['bundles']))<1e-6
   assert abs(m['bundles_per_second']-meta['clients']*meta['bundles']/m['elapsed_seconds'])<1e-6
   if phase=='medium':
    assert m['offered_bundles_per_second']==9.4 and m['schedule_lag']['count']==meta['clients']*meta['bundles']
    assert m['schedule_lag']['max_ms'] < 1000*meta['clients']/9.4
   cluster=Path(d['cluster'])
   for name in ['server.log','initdb.log','data/postgresql.conf','data/pg_hba.conf']:
    path=cluster/name;members[f'clusters/{phase}-{engine}-{d["repetition"]}/{name}']=path.read_bytes()
  ms=[d['measurement'] for d in reports]
  metrics={'cpu_ms_per_bundle':lambda m:m['server_cpu_us_per_bundle']/1000,'statements_per_second':lambda m:m['bundles_per_second']*19,
   'server_cpu_percent_of_four_cores':lambda m:m['server_cpu_seconds']/m['elapsed_seconds']/4*100,
   'client_cpu_percent_of_two_cores':lambda m:m['client_cpu_delta']['usage_usec']/1e6/m['elapsed_seconds']/2*100,
   'peak_cgroup_mib':lambda m:m['sampled_resources']['sampled_memory_current_peak_bytes']/2**20,
   'peak_process_pss_mib':lambda m:m['sampled_resources']['sampled_summed_pss_peak_bytes']/2**20}
  if phase=='medium':metrics['schedule_lag_p99_ms']=lambda m:m['schedule_lag']['p99_ms']
  for kind in ['read','update','aggregate','range','join','bundle']:
   for pct in ['p50','p95','p99']:metrics[kind+'_'+pct+'_ms']=lambda m,k=kind,p=pct:m['latency'][k][p+'_ms']
  rollup[phase][engine]={k:{'median':statistics.median(f(m) for m in ms),'minimum':min(f(m) for m in ms),'maximum':max(f(m) for m in ms)} for k,f in metrics.items()}
for name in ['pg-compare-medium-rate.json','run_bounded_small_comparison.py','pg-comparison-existing-harness-tests.log','package_bounded_small_comparison.py']:members[name]=(base/name).read_bytes()
for p in (base/'bounded-small-pilot-20261030').glob('*.json'):members[str(p.relative_to(base))]=p.read_bytes()
for p in (base/'bounded-small-pilot-20261030-source').glob('*.py'):members[str(p.relative_to(base))]=p.read_bytes()
for name in ['bounded-small-pilot-20261030.log','bounded-small-pilot-20261030-command.json','bounded-small-pilot-20261030-journal.log']:members[name]=(base/name).read_bytes()
for p in (base/'bounded-small-refill-candidate').rglob('*'):
 if p.is_file() and 'bin' not in p.relative_to(base/'bounded-small-refill-candidate').parts:members[str(p.relative_to(base))]=p.read_bytes()
destination.mkdir(parents=True,exist_ok=False)
with tarfile.open(destination/'evidence.tar.gz','w:gz') as archive:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(data))
manifest={'members':{n:hashlib.sha256(b).hexdigest() for n,b in sorted(members.items())},'archive_sha256':hashlib.sha256((destination/'evidence.tar.gz').read_bytes()).hexdigest()}
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(destination/'results.json').write_text(json.dumps(rollup,indent=2)+'\n')
print(json.dumps(rollup,indent=2))
