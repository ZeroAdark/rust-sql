from pathlib import Path
import json
base=Path('/home/rustsql')
def check(name,expected):
 d=json.loads((base/(name+'.json')).read_text())
 targets=[r[4] for s in d['snapshots'] for r in s['owners'] if r[:3]==['counter','pool_reserve','target']]
 assert targets and max(targets)<=expected,(name,'warm target exceeded requested cap',max(targets),expected)
 assert d['passed'] and len(d['queries'])==12 and all(q['passed'] for q in d['queries'])
 assert d['shutdown_exit_codes']==[0] and not d['remaining_pids']
 assert not any(d['final']['events'][k] for k in ['oom','oom_kill','oom_group_kill']) and not d['final']['memory_swap_current']
 return {'name':name,'queries':len(d['queries']),'max_target_bytes':max(targets),'expected_cap':expected,'max_events':d['final']['events']['max']}
result={'passed':False,'positive':[],'negative':[]}
for mode,cap in [('warm64',64<<20),('no-prefault',16<<20)]:
 for repeat in range(1,4):
  result['positive'].append(check(f'pool-config-fixed-{mode}-{repeat}',cap))
  name=f'pool-warm-cap-{mode}-{repeat}'
  try:check(name,cap)
  except AssertionError as error:
   assert 'warm target exceeded requested cap' in str(error)
   result['negative'].append({'name':name,'rejected':True,'reason':str(error)})
  else:raise AssertionError('unfixed constructor accepted')
result['passed']=True;(base/'pool-config-fixed-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
