"""Preserve the terminal setup failure, repair ownership of our new test, and restore the builder's exact input."""
from pathlib import Path
import hashlib
import json
import os
import pwd

base = Path('/home/rustsql')
repo = base / 'pgrust'
workspace = Path('/mnt/c/Users/DarkMoon/Desktop/Rust SQL/pgrust')
failed = base / 'granular-budget-build-20261031'
saved = base / 'granular-budget-build-setup-failure-20261031'
assert failed.resolve().parent == saved.resolve().parent == base
assert failed.is_dir() and not saved.exists()
prior = json.loads((base / 'known-budget-build-20261031/report.json').read_text())
for name, digest in prior['source_sha256'].items():
    expected = (workspace / name).read_bytes().replace(b'\r\n', b'\n')
    assert (repo / name).read_bytes() == expected
    assert (failed / 'sources' / name).read_bytes() == expected
name = 'crates/_support/pagepool/tests/reclaim_granularity.rs'
test = repo / name
diagnostic = json.loads((base / 'known-budget-granularity-diagnostic-20261031/report.json').read_text())
assert hashlib.sha256(test.read_bytes()).hexdigest() == diagnostic['test_sha256']
account = pwd.getpwnam('rustsql')
before = {'uid': test.stat().st_uid, 'gid': test.stat().st_gid, 'mode': oct(test.stat().st_mode & 0o777)}
assert before['uid'] != account.pw_uid
failed.joinpath('setup-failure.json').write_text(json.dumps({
    'terminal_exit': 1, 'error': 'PermissionError writing the newly copied reclaim_granularity.rs',
    'before': before, 'repair': 'Set only this task-created test file owner to rustsql; restore purger.rs to the exact prior candidate input before retry.',
    'tests_or_build_started': False}, indent=2) + '\n')
failed.rename(saved)
run = base / 'granular-budget-experiment-20261031.json'
run_saved = base / 'granular-budget-experiment-setup-failure-20261031.json'
assert not run_saved.exists()
assert json.loads(run.read_text())['stages'][0]['exit'] == 1
run.rename(run_saved)
os.chown(test, account.pw_uid, account.pw_gid)
purger = 'crates/_support/pagepool/src/purger.rs'
original = (base / 'known-budget-build-20261031/sources' / purger).read_bytes()
assert hashlib.sha256(original).hexdigest() == prior['source_sha256'][purger]
(repo / purger).write_bytes(original)
assert (repo / purger).stat().st_uid == account.pw_uid
print(json.dumps({'preserved_failure': str(saved), 'repaired_file': str(test), 'original_owner': before,
                  'new_owner_uid': test.stat().st_uid, 'ready_for_retry': True}))
