"""Prepare a distinct candidate without modifying the rejected candidate's frozen records."""
from pathlib import Path
import hashlib
import json

workspace = Path(__file__).resolve().parent
base = Path(r'\\wsl.localhost\Ubuntu-24.04\home\rustsql')
diagnostic = base / 'known-budget-granularity-diagnostic-20261031'
diagnostic.mkdir(exist_ok=False)
test_path = base / 'pgrust/crates/_support/pagepool/tests/reclaim_granularity.rs'
diagnostic.joinpath('reclaim_granularity.rs').write_bytes(test_path.read_bytes())
diagnostic.joinpath('negative.log').write_bytes((base / 'known-budget-granularity-negative-20261031.log').read_bytes())
assert b'committed=4096 released=2097152' in diagnostic.joinpath('negative.log').read_bytes()
original = json.loads((base / 'known-budget-build-20261031/report.json').read_text())
for name, sha in original['source_sha256'].items():
    assert hashlib.sha256((base / 'pgrust' / name).read_bytes()).hexdigest() == sha
diagnostic.joinpath('report.json').write_text(json.dumps({
    'observed_wrapper_exit': 1, 'test_failed_as_expected': True,
    'message': 'committed=4096 released=2097152',
    'source_sha256': original['source_sha256'],
    'test_sha256': hashlib.sha256(test_path.read_bytes()).hexdigest(),
    'range_latency_causality_proven': False}, indent=2) + '\n')

builder = (workspace / 'build_known_budget_candidate.py').read_text().replace('known-budget', 'granular-budget')
builder = builder.replace("'crates/_support/pagepool/tests/reclaim_budget.rs']", "'crates/_support/pagepool/tests/reclaim_budget.rs', 'crates/_support/pagepool/tests/reclaim_granularity.rs']")
old_check = "assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip() == ''"
new_check = """assert not subprocess.check_output(['systemctl', 'list-units', 'rustsql-qualification-*', '--state=running', '--plain', '--no-legend'], text=True).strip()
prior = json.loads((base / 'known-budget-build-20261031/report.json').read_text())
for name, digest in prior['source_sha256'].items():
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == digest
diagnostic = json.loads((base / 'known-budget-granularity-diagnostic-20261031/report.json').read_text())
assert hashlib.sha256((repo / files[-1]).read_bytes()).hexdigest() == diagnostic['test_sha256']
assert set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=repo, text=True).splitlines()) == set(files[:5])
assert set(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=repo, text=True).splitlines()) == set(files[5:])"""
assert old_check in builder
builder = builder.replace(old_check, new_check).replace('*files[:-1]', '*files[:5]')
builder = builder.replace("'--test', 'reclaim_budget', '--test', 'grow_guard'", "'--test', 'reclaim_budget', '--test', 'reclaim_granularity', '--test', 'grow_guard'")
marker = "run('pagepool', test + ['--lib', '--tests'])"
negative = """path = repo / files[0]
current = path.read_bytes()
try:
    path.write_bytes((base / 'known-budget-build-20261031/sources' / files[0]).read_bytes())
    result = run('negative-granularity', test + ['--test', 'reclaim_granularity'], False)
    assert result.returncode == 101
    assert 'committed=4096 released=2097152' in (root / 'negative-granularity.log').read_text()
finally:
    path.write_bytes(current)
"""
assert marker in builder
builder = builder.replace(marker, negative + marker)
(workspace / 'build_granular_budget_candidate.py').write_text(builder)

for name in ('run_known_budget_pressure.py', 'run_known_budget_performance.py'):
    target = name.replace('known_budget', 'granular_budget')
    text = (workspace / name).read_text().replace('known-budget', 'granular-budget')
    # __file__ automatically freezes the actual new controller under its correct filename.
    (workspace / target).write_text(text)
screen = (workspace / 'screen_known_budget.py').read_text().replace('known-budget', 'granular-budget').replace('run_known_budget_', 'run_granular_budget_')
screen = screen.replace("key = phase + ('-1g' if memory_mib == 1024 else '')", "phase_key = phase + ('-1g' if memory_mib == 1024 else '')")
screen = screen.replace("'granular-budget-' + key + '-20261031'", "'granular-budget-' + phase_key + '-20261031'")
screen = screen.replace('report[key] = result', 'report[phase_key] = result')
start = screen.index("for phase in ('medium', 'capacity'):")
screen = screen[:start] + """run('run_granular_budget_performance.py', ['medium', '1024'])
if not performance('medium', 1024):
    report['rejected_at'] = 'medium-1g'
    save()
    raise SystemExit(2)
for phase in ('medium', 'capacity'):
    run('run_granular_budget_performance.py', [phase])
    if not performance(phase):
        report['rejected_at'] = phase
        save()
        raise SystemExit(2)
report['passed'] = True
save()
"""
(workspace / 'screen_granular_budget.py').write_text(screen)
design = json.loads((workspace / 'known_budget_design.json').read_text())
design['candidate'] = 'granular-budget'
design['performance'] = [design['performance'][2], *design['performance'][:2]]
design['reason'] = 'Accumulate sub-superpage growth; do not return 2 MiB for each 4 KiB commit. Preserve the failed previous candidate; test the failing 1 GiB regime first.'
(workspace / 'granular_budget_design.json').write_text(json.dumps(design, indent=2) + '\n')

doc = workspace / 'pgrust/docs/production-readiness.md'
content = doc.read_bytes()
marker = b'## Deployment work still needed'
paragraph = (b'The [known-zero reclaim-budget candidate](../artifacts/validation/known-budget-reclaim-2026-10-31/README.md) '
    b'passes all six pressure trials and the 2 GiB medium/capacity preservation checks. At 1 GiB it reduces charged memory '
    b'21.28% with CPU +0.60%, but range p99 rises 10.39%, failing the unchanged 5% guard. It is not retained; all 40 '
    b'performance trials and 180 reported unit tests remain in a portable evidence archive. A focused follow-up reproduces '
    b'a 4 KiB lazy commit returning a 2 MiB warm page. Accumulating small commits is under investigation; its effect on '
    b'the latency failure is not yet established. The retained executable remains `0be60915`.\n\n')
assert content.count(marker) == 1 and b'known-zero reclaim-budget candidate' not in content
doc.write_bytes(content.replace(marker, paragraph + marker))
for filename in ('build_granular_budget_candidate.py', 'run_granular_budget_pressure.py', 'run_granular_budget_performance.py', 'screen_granular_budget.py'):
    compile((workspace / filename).read_text(), filename, 'exec')
print('Prepared separate granular-budget build and screen; no benchmark or build has started.')
