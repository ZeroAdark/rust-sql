"""Run pressure and performance gates serially; do not promote the candidate."""
from pathlib import Path
import hashlib
import json
import statistics
import subprocess

base = Path('/home/rustsql')
scripts = Path('/mnt/c/Users/DarkMoon/Desktop/Rust SQL')
output = base / 'granular-budget-screen-20261031.json'
assert not output.exists()
report = {'passed': False, 'promoted': False, 'stages': []}

def save():
    output.write_text(json.dumps(report, indent=2) + '\n')

def run(name, arguments):
    print(json.dumps({'stage': name, 'starting': True}), flush=True)
    result = subprocess.run(['/usr/bin/python3', '-u', str(scripts / name), *arguments])
    report['stages'].append({'script': name, 'arguments': arguments, 'exit': result.returncode})
    save()
    result.check_returncode()

def performance(phase, memory_mib=2048):
    phase_key = phase + ('-1g' if memory_mib == 1024 else '')
    folder = base / ('granular-budget-' + phase_key + '-20261031')
    metadata = json.loads((folder / 'metadata.json').read_text())
    assert metadata['memory_mib'] == memory_mib
    summary = json.loads((folder / 'summary.json').read_text())
    assert summary['complete'] and summary['passed']
    assert len(summary['trials']) == (15 if phase == 'medium' else 10)
    trials = []
    for item in summary['trials']:
        path = folder / f"{phase}-{item['engine']}-{item['repetition']}.json"
        trial = json.loads(path.read_text())
        measured = trial['measurement']
        assert trial['passed'] and measured['passed']
        assert trial['shutdown_exit_codes'] == [0, 0] and not trial['remaining_server_pids']
        assert trial['state_before_restart'] == trial['state_after_restart']
        assert trial['cpu_binding'] == {'cpuset.cpus': '0,2,4,6', 'cpuset.cpus.effective': '0,2,4,6',
                                        'cpu.max': 'max 100000', 'parent_cpu_max': 'max 100000'}
        assert not any(measured['memory_event_delta'].values())
        for side in ('cpu_delta', 'client_cpu_delta'):
            assert measured[side]['nr_throttled'] == measured[side]['throttled_usec'] == 0
        for key in ('resources_before_setup', 'resources_before_workload', 'resources_after_workload', 'resources_after_shutdown'):
            assert trial[key]['memory_swap_current'] == 0
            assert all(trial[key]['events'][kind] == 0 for kind in ('max', 'oom', 'oom_kill', 'oom_group_kill'))
        assert measured['elapsed_seconds'] >= (15 if phase == 'medium' else 20)
        assert trial['state_after_restart']['committed_updates'] == 6 * (metadata['bundles'] + 10) * 4
        for kind, count in (metadata['statements_per_bundle'] | {'bundle': 1}).items():
            assert measured['latency'][kind]['count'] == 6 * metadata['bundles'] * count
        trials.append(trial)
    getters = {
        'cpu_ms_per_bundle': lambda m: m['server_cpu_us_per_bundle'] / 1000,
        'sql_per_second': lambda m: m['bundles_per_second'] * 19,
        'charged_peak_mib': lambda m: m['sampled_resources']['sampled_memory_current_peak_bytes'] / 2**20,
        'pss_peak_mib': lambda m: m['sampled_resources']['sampled_summed_pss_peak_bytes'] / 2**20,
    }
    for kind in ('read', 'update', 'aggregate', 'range', 'join', 'bundle'):
        getters[kind + '_p99_ms'] = lambda m, k=kind: m['latency'][k]['p99_ms']
    values = {}
    for engine in sorted({t['engine'] for t in trials}):
        arm = [t for t in trials if t['engine'] == engine]
        assert len(arm) == 5
        values[engine] = {key: statistics.median(fn(t['measurement']) for t in arm) for key, fn in getters.items()}
    changes = {key: 100 * (values['rustsql'][key] / val - 1) for key, val in values['rustsql-baseline'].items()}
    failures = [key for key, val in changes.items()
                if (key == 'sql_per_second' and phase == 'capacity' and val < -5)
                or ((key == 'cpu_ms_per_bundle' or key.endswith('_p99_ms')) and val > 5)]
    result = {'phase': phase, 'engines': values, 'candidate_change_percent': changes, 'preservation_failures': failures,
              'evidence_valid': True, 'passed': not failures}
    (folder / 'candidate-review.json').write_text(json.dumps(result, indent=2) + '\n')
    report[phase_key] = result
    save()
    print(json.dumps(result), flush=True)
    return not failures

run('run_granular_budget_pressure.py', [])
pressure = json.loads((base / 'granular-budget-pressure-20261031-summary.json').read_text())
assert pressure['complete'] and len(pressure['trials']) == 12
candidate = [t for t in pressure['trials'] if t['variant'].startswith('candidate')]
assert len(candidate) == 6
report['pressure_passed'] = all(t['passed'] for t in candidate)
save()
if not report['pressure_passed']:
    report['rejected_at'] = 'pressure'
    save()
    raise SystemExit(2)
assert all(t['budget_guard_verified'] for t in candidate if t['variant'] == 'candidate-observed')
run('run_granular_budget_performance.py', ['medium', '1024'])
if not performance('medium', 1024):
    report['rejected_at'] = 'medium-1g'
    save()
    raise SystemExit(2)
for phase in ('medium', 'capacity'):
    run('run_granular_budget_performance.py', [phase])
    if not performance(phase):
        report['rejected_at'] = phase
        save()
        raise SystemExit(2)
report['passed'] = True
save()
