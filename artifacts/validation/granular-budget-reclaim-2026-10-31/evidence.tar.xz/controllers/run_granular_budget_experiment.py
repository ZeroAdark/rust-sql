"""Serial build then pressure/performance screening; never promote a candidate."""
from pathlib import Path
import json
import subprocess

if not __debug__:
    raise RuntimeError('Assertions must remain enabled')
scripts = Path('/mnt/c/Users/DarkMoon/Desktop/Rust SQL')
base = Path('/home/rustsql')
output = base / 'granular-budget-experiment-20261031.json'
assert not output.exists()
report = {'passed': False, 'promoted': False, 'stages': []}
for name, command in [
    ('build', ['/usr/sbin/runuser', '-u', 'rustsql', '--', '/usr/bin/python3', '-u', str(scripts / 'build_granular_budget_candidate.py')]),
    ('screen', ['/usr/bin/python3', '-u', str(scripts / 'screen_granular_budget.py')])]:
    result = subprocess.run(command)
    report['stages'].append({'name': name, 'command': command, 'exit': result.returncode})
    output.write_text(json.dumps(report, indent=2) + '\n')
    result.check_returncode()
report['passed'] = True
output.write_text(json.dumps(report, indent=2) + '\n')
