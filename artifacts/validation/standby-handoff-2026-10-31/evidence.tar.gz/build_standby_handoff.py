from pathlib import Path
import hashlib, json, shutil, subprocess, time

base = Path('/home/rustsql')
repo = base/'pgrust'
root = base/'standby-handoff-build-20261030'
root.mkdir(exist_ok=False)
source = repo/'crates/backend/postmaster/launch_backend/src/lib.rs'
report = {'passed': False, 'commands': [], 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()}
(root/'candidate.patch').write_bytes(subprocess.check_output(['git','diff','--','crates/backend/postmaster/launch_backend/src/lib.rs'],cwd=repo))
cargo = str(base/'.cargo/bin/cargo')
commands = [
    ('allocator-handoff', [cargo,'test','--locked','--release','-j','2','-p','pagepool','--features','global','--test','idle_handoff','--test','idle_fallback']),
    ('worker-retirement', [cargo,'test','--locked','--release','-j','2','-p','launch_backend','--lib','wpool::retirement_tests']),
    ('release-build', [cargo,'build','--locked','--release','-j','2','-p','main_main','-p','initdb']),
]
for label, command in commands:
    start = time.monotonic()
    with (root/(label+'.log')).open('w') as log:
        result = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    item = {'label':label,'command':command,'exit':result.returncode,'seconds':time.monotonic()-start}
    report['commands'].append(item)
    (root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(item),flush=True)
    result.check_returncode()
candidate = base/'standby-handoff-candidate/bin'
candidate.mkdir(parents=True,exist_ok=False)
report['binaries'] = {}
for name in ('postgres','initdb'):
    origin = repo/'target/release'/name
    target = candidate/name
    shutil.copy2(origin,target)
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    assert digest == hashlib.sha256(origin.read_bytes()).hexdigest()
    report['binaries'][name] = {'path':str(target),'sha256':digest}
shutil.copytree(repo/'target/release/share',candidate/'share')
report['share'] = {p.relative_to(candidate/'share').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (candidate/'share').rglob('*') if p.is_file()}
assert report['share'] and (candidate/'share/postgres.bki').exists()
report['passed'] = True
(root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['binaries']),flush=True)
