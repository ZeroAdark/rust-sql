from pathlib import Path
import collections, hashlib, json, os, re, resource, sys, time
sys.path.insert(0, '/home/rustsql/pgrust/scripts/validation')
import psycopg
from connection_churn_probe import CheckedCluster, save
from resource_scope import DelegatedScope, snapshot
from fixed_workload import setup
from spill_probe import copy_digest

base = Path('/home/rustsql')
label = sys.argv[1] if len(sys.argv)>1 else 'standby-handoff-correctness-20261030'
assert label.startswith('standby-handoff-correctness-') and '/' not in label
root = base/label
root.mkdir(exist_ok=False)
resource.setrlimit(resource.RLIMIT_STACK,(65520*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
scope = DelegatedScope([0,2,4,6],[8,10])
report = {'passed':False,'purpose':'standby attribution and parallel-worker correctness; not performance acceptance','cases':[],
          'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
views = (base/'pgrust/scripts/memory-broker-views.sql').read_text()
definitions = [re.search(r'CREATE OR REPLACE FUNCTION '+name+r'\(.*?;',views,re.S).group()
               for name in ['pgrust_memory_accounts','pgrust_memory_owner_end']]
digest = hashlib.sha256()
for value in range(1000):
    first = value*353%1000 or 1000
    for i in range(first,500001,1000):
        digest.update(f'{i}\t{value}\n'.encode())
expected = {'rows':500000,'sha256':digest.hexdigest()}
report['oracle'] = expected

for label, binary in [('baseline',base/'vma-residency-candidate/bin'),('candidate',base/'standby-handoff-candidate/bin')]:
    group, launcher = scope.server(2048)
    cluster = CheckedCluster(binary,base/'conformance',launcher=launcher,allocator='hearth',
        settings=['autovacuum=off','max_active_queries=6','work_mem=16MB','shared_buffers=128MB',
                  'max_parallel_workers_per_gather=2','max_parallel_maintenance_workers=2',
                  'maintenance_work_mem=128MB','min_parallel_table_scan_size=0'])
    for key in list(cluster.env):
        if key.startswith('MIMALLOC_'):del cluster.env[key]
    cluster.env['PGRUST_GATHER_TRACE']='1'
    case = {'label':label,'passed':False,'cluster':str(cluster.root),'stages':[], 'index_builds':[],
            'binary_sha256':hashlib.sha256((binary/'postgres').read_bytes()).hexdigest()}
    report['cases'].append(case)
    try:
        with cluster, psycopg.connect(cluster.dsn,autocommit=True) as connection:
            for definition in definitions:connection.execute(definition)
            case['settings']=connection.execute("SELECT name,setting FROM pg_settings WHERE name IN ('max_parallel_workers','max_worker_processes','max_parallel_maintenance_workers','maintenance_work_mem','min_parallel_table_scan_size') ORDER BY name").fetchall()
            case['live_environment']=sorted(v.decode() for v in Path('/proc',str(cluster.process.pid),'environ').read_bytes().split(b'\0') if v.startswith((b'PGRUST_',b'MIMALLOC_')))
            assert case['live_environment']==['PGRUST_ALLOCATOR=hearth','PGRUST_GATHER_TRACE=1']
            def capture(stage):
                threads=collections.Counter();maps=collections.Counter()
                for pid in (group/'cgroup.procs').read_text().split():
                    for p in Path('/proc',pid,'task').glob('*/comm'):
                        try:threads[p.read_text().strip()]+=1
                        except FileNotFoundError:pass
                    try:
                        for line in Path('/proc',pid,'smaps_rollup').read_text().splitlines():
                            if ':' in line:
                                key,val=line.split(':',1)
                                if key in ['Rss','Pss','Anonymous','AnonHugePages','Private_Dirty']:maps[key]+=int(val.split()[0])*1024
                    except (FileNotFoundError,ProcessLookupError):pass
                case['stages'].append({'stage':stage,'resources':snapshot(group),'mapping_totals':dict(maps),'threads':dict(threads),
                    'accounts':connection.execute('SELECT account,account_bytes,class FROM pgrust_memory_accounts() ORDER BY account').fetchall(),
                    'pool':connection.execute("SELECT class,committed_bytes,reserved_bytes FROM pgrust_memory_owner_end() WHERE source='pool' ORDER BY class").fetchall()})
            time.sleep(1.3);capture('startup_idle')
            setup(connection,1000000,6);capture('after_setup')
            time.sleep(1.3);capture('setup_idle')
            connection.execute('CREATE ROLE maintenance_owner')
            connection.execute('GRANT CREATE ON SCHEMA public TO maintenance_owner')
            connection.execute('SET ROLE maintenance_owner')
            connection.execute('CREATE TABLE worker_probe(id integer,v integer) USING heap')
            connection.execute('INSERT INTO worker_probe SELECT i,i*17%1000 FROM generate_series(1,500000) i')
            connection.execute('ANALYZE worker_probe')
            for repeat in range(3):
                log = cluster.root/'server.log';offset=log.stat().st_size
                connection.execute(f'CREATE INDEX worker_idx_{repeat} ON worker_probe(v,id)')
                connection.execute('SET enable_seqscan=off')
                result=copy_digest(connection,'SELECT id,v FROM worker_probe ORDER BY v,id')
                assert {k:result[k] for k in expected}==expected
                assert connection.execute('SELECT current_user').fetchone()[0]=='maintenance_owner'
                trace=log.read_text()[offset:]
                case['index_builds'].append({'repeat':repeat,'result':result,'pooled_tasks':trace.count('GTRACE w.pool.task '),'warm_claims':trace.count('GTRACE w.retain.claim_warm ')})
                connection.execute(f'DROP INDEX worker_idx_{repeat}')
            connection.execute('RESET ROLE')
            capture('after_parallel_builds')
        assert sum(x['pooled_tasks'] for x in case['index_builds'])>0, 'no pooled worker exercised'
        assert sum(x['warm_claims'] for x in case['index_builds'])>0, 'no retained worker exercised'
        case['passed']=True
    except Exception as error:
        case['error']=repr(error)
        raise
    finally:
        case['shutdown_exit_codes']=cluster.shutdown_exit_codes
        case['remaining_pids']=(group/'cgroup.procs').read_text().split()
        case['after_shutdown']=snapshot(group)
        save(root/'report.json',report)
        assert not case['remaining_pids'];group.rmdir()
    assert case['shutdown_exit_codes']==[0]
    assert not any(case['after_shutdown']['events'][k] for k in ['oom','oom_kill','max'])
    assert case['after_shutdown']['memory_swap_current']==0
    print(json.dumps({'label':label,'passed':True,'index_builds':case['index_builds']}),flush=True)
report['passed']=True
save(root/'report.json',report)
