from pathlib import Path
import hashlib, json, subprocess, time

base=Path('/home/rustsql')
build=json.loads((base/'standby-handoff-build-20261030/report.json').read_text())
assert build['passed']
candidate=base/'standby-handoff-candidate/bin'
assert hashlib.sha256((candidate/'postgres').read_bytes()).hexdigest()==build['binaries']['postgres']['sha256']
cases=[
 ('standby-handoff-correctness-20261030',[str(base/'check_standby_handoff.py')]),
 ('standby-handoff-protocol-20261030',[str(base/'pgrust/scripts/validation/bind_lifecycle_probe.py'),
  '--candidate',str(candidate),'--reference',str(base/'postgres18/bin'),'--work-dir',str(base/'conformance'),
  '--output',str(base/'standby-handoff-protocol-20261030.json')]),
]
report={'passed':False,'build_binaries':build['binaries'],'commands':[]}
for label,args in cases:
 log=base/(label+'.log');assert not log.exists()
 command=['systemd-run','--unit=rustsql-qualification-'+label,'--uid=rustsql','--gid=rustsql','--collect','--wait',
  '--property=Delegate=cpu memory pids','--property=MemoryMax=8G','--property=MemorySwapMax=0',
  '--property=CPUQuota=600%','--property=LimitSTACK=67108864','--property=RuntimeMaxSec=1200',
  '--property=StandardOutput=append:'+str(log),'--property=StandardError=append:'+str(log),
  '/usr/bin/python3','-u',*args]
 start=time.monotonic()
 result=subprocess.run(command,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=1230)
 entry={'label':label,'command':command,'exit':result.returncode,'seconds':time.monotonic()-start,'output':result.stdout}
 report['commands'].append(entry)
 (base/'standby-handoff-checks-20261030.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(entry),flush=True);print(log.read_text()[-2000:],flush=True)
 result.check_returncode()
report['passed']=True
(base/'standby-handoff-checks-20261030.json').write_text(json.dumps(report,indent=2)+'\n')
