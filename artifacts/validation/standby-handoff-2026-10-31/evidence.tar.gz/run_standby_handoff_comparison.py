from pathlib import Path
import json, shutil, subprocess, sys

base = Path('/home/rustsql')
label, phase = sys.argv[1:3]
assert phase in ('medium', 'capacity')
bundles, rate = (30, '9.4') if phase == 'medium' else (50, None)
source = base/(label+'-source')
source.mkdir(exist_ok=False)
for name in ('postgres_comparison.py', 'fixed_workload.py', 'cluster.py', 'connection_churn_probe.py', 'connection_queue_probe.py', 'resource_scope.py'):
    shutil.copyfile(base/'pgrust/scripts/validation'/name, source/name)
probe = source/'postgres_comparison.py'
s = probe.read_text()
def replace(old, new):
    global s
    assert s.count(old) == 1, (old, s.count(old))
    s = s.replace(old, new)
replace("binaries = args.reference if reference else args.candidate",
        "binaries = args.reference if reference else Path('/home/rustsql/vma-residency-candidate/bin') if label == 'rustsql-baseline' else args.candidate")
replace("    if not reference and args.candidate_policy:\n        cluster.env['PGRUST_MEMPOLICY'] = args.candidate_policy", """    assert args.candidate_policy == ''
    for key in list(cluster.env):
        if key.startswith('MIMALLOC_'): del cluster.env[key]
    expected_env = [] if reference else ['PGRUST_ALLOCATOR=hearth']""")
replace("            report['version'] = cluster.version", """            report['version'] = cluster.version
            report['live_environment'] = sorted(v.decode() for v in Path('/proc',str(cluster.process.pid),'environ').read_bytes().split(b'\\0') if v.startswith((b'PGRUST_',b'MIMALLOC_')))
            assert report['live_environment'] == expected_env
            report['resources_before_setup'] = snapshot(group)""")
replace("                setup(connection,args.rows,args.clients,reference=reference)", """                if not reference:
                    report['allocator_before'] = connection.execute('SHOW pgrust.allocator').fetchone()[0]
                    assert report['allocator_before'] == 'hearth'
                setup(connection,args.rows,args.clients,reference=reference)""")
replace("            report['measurement']=exercise(", "            report['resources_before_workload']=snapshot(group)\n            report['measurement']=exercise(")
replace("            with psycopg.connect(cluster.dsn,autocommit=True) as connection:\n                report['state_before_restart']", "            report['resources_after_workload']=snapshot(group)\n            with psycopg.connect(cluster.dsn,autocommit=True) as connection:\n                report['state_before_restart']")
replace("                report['state_after_restart']=verify_state", """                if not reference:
                    report['allocator_after'] = connection.execute('SHOW pgrust.allocator').fetchone()[0]
                    assert report['allocator_after'] == 'hearth'
                report['state_after_restart']=verify_state""")
replace("[('postgresql',args.reference),('rustsql',args.candidate)]", "[('postgresql',args.reference),('rustsql-baseline',Path('/home/rustsql/vma-residency-candidate/bin')),('rustsql',args.candidate)]")
replace("(('postgresql','rustsql') if repetition%2 else ('rustsql','postgresql'))", "(('postgresql','rustsql-baseline','rustsql') if repetition%2 else ('rustsql','rustsql-baseline','postgresql'))")
probe.write_text(s)
compile(s, str(probe), 'exec')
unit = 'rustsql-qualification-'+label
cmd = ['systemd-run', '--unit='+unit, '--uid=rustsql', '--gid=rustsql', '--wait', '--collect',
       '--property=Delegate=cpu memory pids', '--property=MemoryMax=8G', '--property=MemorySwapMax=0',
       '--property=CPUQuota=600%', '--property=LimitSTACK=67108864', '--property=RuntimeMaxSec=2400',
       '--property=StandardOutput=append:'+str(base/(label+'.log')),
       '--property=StandardError=append:'+str(base/(label+'.log')),
       '/usr/bin/python3', '-u', str(probe), '--candidate', str(base/'standby-handoff-candidate/bin'),
       '--reference', str(base/'postgres18/bin'), '--work-dir', str(base/'conformance'),
       '--output-dir', str(base/label), '--phase', phase, '--bundles', str(bundles), '--repeats', '5', '--warmup', '10']
if rate:
    cmd += ['--bundle-rate', rate]
r = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=2430)
(base/(label+'-command.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode,'output':r.stdout},indent=2)+'\n')
(base/(label+'-journal.log')).write_bytes(subprocess.check_output(['journalctl','-u',unit+'.service','--no-pager','-o','short-iso']))
print(label, r.returncode, flush=True)
print((base/(label+'.log')).read_text()[-1800:], flush=True)
r.check_returncode()
