from pathlib import Path
import hashlib, json, shutil, subprocess, sys

if not __debug__:
    raise RuntimeError('Benchmark assertions must remain enabled.')

base = Path('/home/rustsql')
expected_binaries = {
    'guc-name-index-candidate': '57baa2ef25bdfebccd3bf851fb84692828a72e2b8541faddfe1ace0a281cabe6',
    'guc-registry-reserve-candidate': '0be60915b40c9f70f39dcb3a0fd1f8918608a20095f767ec081a5b5320caa277',
    'postgres18': '07b16e1aa4f0e2206c37b339b6e4cc813aa8ab9e3c5516334f753b3d90d0c536',
}
def verify_binaries():
    for name, expected in expected_binaries.items():
        with (base/name/'bin/postgres').open('rb') as f:
            assert hashlib.file_digest(f, 'sha256').hexdigest() == expected, name
verify_binaries()
label, phase = sys.argv[1:3]
assert phase in ('medium', 'capacity')
active = subprocess.check_output(['systemctl','list-units','rustsql-qualification-*','--state=running','--plain','--no-legend'],text=True)
assert not active.strip(), active
bundles, rate = (30, '9.4') if phase == 'medium' else (50, None)
source = base/(label+'-source')
source.mkdir(exist_ok=False)
shutil.copyfile(Path(__file__), source/Path(__file__).name)
for name in ('postgres_comparison.py', 'fixed_workload.py', 'cluster.py', 'connection_churn_probe.py', 'connection_queue_probe.py', 'resource_scope.py'):
    shutil.copyfile(base/'pgrust/scripts/validation'/name, source/name)
scope_path=source/'resource_scope.py'
scope_text=scope_path.read_text()
def scope_replace(old,new):
    global scope_text
    assert scope_text.count(old)==1,(old,scope_text.count(old))
    scope_text=scope_text.replace(old,new)
scope_replace("'+cpu +memory +pids'","'+cpu +memory +pids +cpuset'")
scope_replace("{'cpu.max': f'{100000 * len(self.client_cpus)} 100000',", "{'cpu.max': 'max 100000', 'cpuset.mems': (self.root/'cpuset.mems.effective').read_text().strip(), 'cpuset.cpus': ','.join(map(str,sorted(self.client_cpus))),")
scope_replace("{'cpu.max': f'{100000 * len(self.server_cpus)} 100000',", "{'cpu.max': 'max 100000', 'cpuset.mems': (self.root/'cpuset.mems.effective').read_text().strip(), 'cpuset.cpus': ','.join(map(str,sorted(self.server_cpus))),")
scope_replace('        self.sequence = 0', """        assert (self.driver/'cpuset.cpus.effective').read_text().strip()==','.join(map(str,sorted(self.client_cpus)))
        for parent in [self.root,self.root.parent,CGROUP]:
            if (parent/'cpu.max').exists():assert (parent/'cpu.max').read_text().split()[0]=='max'
        self.sequence = 0""")
scope_replace('        return group, launcher', """        assert (group/'cpuset.cpus.effective').read_text().strip()==','.join(map(str,sorted(self.server_cpus)))
        return group, launcher""")
scope_path.write_text(scope_text)
compile(scope_text,str(scope_path),'exec')
preflight=source/'cpuset_preflight.py'
preflight.write_text('''from pathlib import Path
import json,os,subprocess
from resource_scope import DelegatedScope,snapshot
if not __debug__:raise RuntimeError('Assertions must remain enabled')
scope=DelegatedScope([0,2,4,6],[8,10])
os.sched_setaffinity(0,set(range(os.cpu_count())))
assert os.sched_getaffinity(0)=={8,10}
group,launcher=scope.server(512)
child="""import json,os
os.sched_setaffinity(0,set(range(os.cpu_count())))
assert os.sched_getaffinity(0)=={0,2,4,6}
try:os.sched_setaffinity(0,{8})
except OSError as error:assert error.errno==22
else:raise AssertionError('server escaped its CPU set')
print(json.dumps({'allowed':sorted(os.sched_getaffinity(0)),'escape_rejected':True}))
"""
proof=json.loads(subprocess.check_output(launcher+['/usr/bin/python3','-c',child],text=True))
result={'passed':True,'driver_allowed':sorted(os.sched_getaffinity(0)),'server':proof,
        'server_cpu_max':(group/'cpu.max').read_text().strip(),
        'parent_cpu_max':(scope.root/'cpu.max').read_text().strip(),
        'server_resources':snapshot(group)}
assert not (group/'cgroup.procs').read_text().split()
group.rmdir();print(json.dumps(result))
''')
preflight_unit='rustsql-qualification-'+label+'-cpuset-check'
preflight_command=['systemd-run','--unit='+preflight_unit,'--uid=rustsql','--gid=rustsql','--wait','--pipe','--collect',
    '--property=Delegate=cpu memory pids cpuset','--property=AllowedCPUs=0,2,4,6,8,10',
    '--property=MemoryMax=512M','--property=MemorySwapMax=0','--property=RuntimeMaxSec=30',
    '/usr/bin/python3',str(preflight)]
checked=subprocess.run(preflight_command,capture_output=True,text=True,timeout=40)
(base/(label+'-cpuset-preflight.json')).write_text(json.dumps({'command':preflight_command,'exit':checked.returncode,'stdout':checked.stdout,'stderr':checked.stderr},indent=2)+'\n')
checked.check_returncode()
assert json.loads(checked.stdout)['passed']
probe = source/'postgres_comparison.py'
s = probe.read_text()
def replace(old, new):
    global s
    assert s.count(old) == 1, (old, s.count(old))
    s = s.replace(old, new)
replace("binaries = args.reference if reference else args.candidate",
        "binaries = args.reference if reference else Path('/home/rustsql/guc-name-index-candidate/bin') if label == 'rustsql-baseline' else args.candidate")
replace("    if not reference and args.candidate_policy:\n        cluster.env['PGRUST_MEMPOLICY'] = args.candidate_policy", """    assert args.candidate_policy == ''
    for key in list(cluster.env):
        if key.startswith('MIMALLOC_'): del cluster.env[key]
    expected_env = [] if reference else ['PGRUST_ALLOCATOR=hearth']""")
replace("            report['version'] = cluster.version", """            report['version'] = cluster.version
            report['cpu_binding'] = {n:(group/n).read_text().strip() for n in ('cpuset.cpus','cpuset.cpus.effective','cpu.max')}
            report['cpu_binding']['parent_cpu_max'] = (scope.root/'cpu.max').read_text().strip()
            assert report['cpu_binding'] == {'cpuset.cpus':'0,2,4,6','cpuset.cpus.effective':'0,2,4,6','cpu.max':'max 100000','parent_cpu_max':'max 100000'}
            report['live_environment'] = sorted(v.decode() for v in Path('/proc',str(cluster.process.pid),'environ').read_bytes().split(b'\\0') if v.startswith((b'PGRUST_',b'MIMALLOC_')))
            assert report['live_environment'] == expected_env
            report['resources_before_setup'] = snapshot(group)""")
replace("                setup(connection,args.rows,args.clients,reference=reference)", """                if not reference:
                    report['allocator_before'] = connection.execute('SHOW pgrust.allocator').fetchone()[0]
                    assert report['allocator_before'] == 'hearth'
                setup(connection,args.rows,args.clients,reference=reference)""")
replace("            report['measurement']=exercise(", "            report['resources_before_workload']=snapshot(group)\n            report['measurement']=exercise(")
replace("            with psycopg.connect(cluster.dsn,autocommit=True) as connection:\n                report['state_before_restart']", "            report['resources_after_workload']=snapshot(group)\n            with psycopg.connect(cluster.dsn,autocommit=True) as connection:\n                report['state_before_restart']")
replace("                report['state_after_restart']=verify_state", """                if not reference:
                    report['allocator_after'] = connection.execute('SHOW pgrust.allocator').fetchone()[0]
                    assert report['allocator_after'] == 'hearth'
                report['state_after_restart']=verify_state""")
replace("[('postgresql',args.reference),('rustsql',args.candidate)]", "[('postgresql',args.reference),('rustsql-baseline',Path('/home/rustsql/guc-name-index-candidate/bin')),('rustsql',args.candidate)]")
replace("(('postgresql','rustsql') if repetition%2 else ('rustsql','postgresql'))", "(('postgresql','rustsql-baseline','rustsql') if repetition%2 else ('rustsql','rustsql-baseline','postgresql'))")
replace("    (args.output_dir/'metadata.json').write_text", "    metadata['cpu_binding']='private kernel CPU sets: four server CPUs and two driver CPUs; no CFS quota'\n    (args.output_dir/'metadata.json').write_text")
probe.write_text(s)
compile(s, str(probe), 'exec')
unit = 'rustsql-qualification-'+label
cmd = ['systemd-run', '--unit='+unit, '--uid=rustsql', '--gid=rustsql', '--wait', '--collect',
       '--property=Delegate=cpu memory pids cpuset', '--property=MemoryMax=8G', '--property=MemorySwapMax=0',
       '--property=AllowedCPUs=0,2,4,6,8,10', '--property=LimitSTACK=67108864', '--property=RuntimeMaxSec=2400',
       '--property=StandardOutput=append:'+str(base/(label+'.log')),
       '--property=StandardError=append:'+str(base/(label+'.log')),
       '/usr/bin/python3', '-u', str(probe), '--candidate', str(base/'guc-registry-reserve-candidate/bin'),
       '--reference', str(base/'postgres18/bin'), '--work-dir', str(base/'conformance'),
       '--output-dir', str(base/label), '--phase', phase, '--bundles', str(bundles), '--repeats', '5', '--warmup', '10']
if rate:
    cmd += ['--bundle-rate', rate]
r = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=2430)
(base/(label+'-command.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode,'output':r.stdout},indent=2)+'\n')
(base/(label+'-journal.log')).write_bytes(subprocess.check_output(['journalctl','-u',unit+'.service','--no-pager','-o','short-iso']))
print(label, r.returncode, flush=True)
print((base/(label+'.log')).read_text()[-1800:], flush=True)
r.check_returncode()
verify_binaries()
