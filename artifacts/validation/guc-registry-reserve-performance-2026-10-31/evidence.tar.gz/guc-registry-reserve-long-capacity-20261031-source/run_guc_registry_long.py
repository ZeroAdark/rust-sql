from pathlib import Path
import hashlib,json,shutil,subprocess
if not __debug__:raise RuntimeError('Assertions must remain enabled')
base=Path('/home/rustsql');label='guc-registry-reserve-long-capacity-20261031'
assert not subprocess.check_output(['systemctl','list-units','rustsql-qualification-*','--state=running','--plain','--no-legend'],text=True).strip()
source=base/(label+'-source');source.mkdir(exist_ok=False)
for p in (base/'guc-registry-reserve-capacity-20261031-source').iterdir():
    if p.is_file():shutil.copyfile(p,source/p.name)
shutil.copyfile(Path(__file__),source/Path(__file__).name)
p=source/'postgres_comparison.py';s=p.read_text()
def replace(old,new):
    global s
    assert s.count(old)==1,(old,s.count(old));s=s.replace(old,new)
replace("[('postgresql',args.reference),('rustsql-baseline',Path('/home/rustsql/guc-name-index-candidate/bin')),('rustsql',args.candidate)]", "[('rustsql-baseline',Path('/home/rustsql/guc-name-index-candidate/bin')),('rustsql',args.candidate)]")
replace("(('postgresql','rustsql-baseline','rustsql') if repetition%2 else ('rustsql','rustsql-baseline','postgresql'))", "(('rustsql-baseline','rustsql') if repetition%2 else ('rustsql','rustsql-baseline'))")
replace('not 1<=args.bundles<=400','not 1<=args.bundles<=1500')
replace("    metadata['cpu_binding']", "    metadata['purpose']='Predeclared longer-duration check after the short capacity screen failed range p99 by 5.27%; retains the failed screen and makes no new PostgreSQL comparison claim.'\n    metadata['acceptance_guard_percent']=5\n    metadata['cpu_binding']")
p.write_text(s);compile(s,str(p),'exec')
binaries={'rustsql-baseline':base/'guc-name-index-candidate/bin/postgres','rustsql':base/'guc-registry-reserve-candidate/bin/postgres'}
expected={'rustsql-baseline':'57baa2ef25bdfebccd3bf851fb84692828a72e2b8541faddfe1ace0a281cabe6','rustsql':'0be60915b40c9f70f39dcb3a0fd1f8918608a20095f767ec081a5b5320caa277'}
for name,path in binaries.items():assert hashlib.sha256(path.read_bytes()).hexdigest()==expected[name]
properties=['--uid=rustsql','--gid=rustsql','--wait','--collect','--property=Delegate=cpu memory pids cpuset','--property=AllowedCPUs=0,2,4,6,8,10','--property=MemorySwapMax=0']
cmd=['systemd-run','--unit=rustsql-qualification-'+label+'-cpuset-check',*properties,'--pipe','--property=MemoryMax=512M','--property=RuntimeMaxSec=30','/usr/bin/python3',str(source/'cpuset_preflight.py')]
r=subprocess.run(cmd,capture_output=True,text=True,timeout=40)
(base/(label+'-cpuset-preflight.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr},indent=2)+'\n');r.check_returncode();assert json.loads(r.stdout)['passed']
unit='rustsql-qualification-'+label
cmd=['systemd-run','--unit='+unit,*properties,'--property=MemoryMax=8G','--property=LimitSTACK=67108864','--property=RuntimeMaxSec=1800','--property=StandardOutput=append:'+str(base/(label+'.log')),'--property=StandardError=append:'+str(base/(label+'.log')),'/usr/bin/python3','-u',str(p),'--candidate',str(binaries['rustsql'].parent),'--reference',str(base/'postgres18/bin'),'--work-dir',str(base/'conformance'),'--output-dir',str(base/label),'--phase','capacity','--bundles','1500','--repeats','5','--warmup','10']
r=subprocess.run(cmd,capture_output=True,text=True,timeout=1830)
(base/(label+'-command.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr},indent=2)+'\n')
(base/(label+'-journal.log')).write_bytes(subprocess.check_output(['journalctl','-u',unit+'.service','--no-pager','-o','short-iso']))
print(label,r.returncode,flush=True);print((base/(label+'.log')).read_text()[-2500:],flush=True);r.check_returncode()
for name,path in binaries.items():assert hashlib.sha256(path.read_bytes()).hexdigest()==expected[name]
