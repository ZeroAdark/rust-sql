from pathlib import Path
import hashlib, json, shutil, subprocess

if not __debug__:
    raise RuntimeError('Assertions must remain enabled')

base = Path('/home/rustsql')
root = base/'guc-registry-reserve-connections-20261031'
assert not subprocess.check_output(['systemctl','list-units','rustsql-qualification-*','--state=running','--plain','--no-legend'], text=True).strip()
root.mkdir(exist_ok=False)
shutil.chown(root, user='rustsql', group='rustsql')
source = root/'source'
source.mkdir()
frozen = base/'guc-registry-reserve-medium-20261031-source'
for name in ('cluster.py', 'connection_queue_probe.py', 'resource_scope.py'):
    shutil.copyfile(frozen/name, source/name)
shutil.copyfile(base/'guc_queue_probe.py', source/'guc_queue_probe.py')
shutil.copyfile(Path(__file__), source/Path(__file__).name)
shutil.copyfile(base/'guc-registry-reserve-medium-20261031-cpuset-preflight.json', root/'cpuset-preflight.json')
binaries = {'baseline': base/'guc-name-index-candidate/bin', 'candidate': base/'guc-registry-reserve-candidate/bin'}
hashes = {'baseline':'57baa2ef25bdfebccd3bf851fb84692828a72e2b8541faddfe1ace0a281cabe6', 'candidate':'0be60915b40c9f70f39dcb3a0fd1f8918608a20095f767ec081a5b5320caa277'}
def identities():
    for label, binary in binaries.items():
        with (binary/'postgres').open('rb') as handle:
            assert hashlib.file_digest(handle, 'sha256').hexdigest() == hashes[label]
identities()
metadata = {'repeats':5, 'memory_mib':4096, 'allocator':'hearth', 'server_cpus':[0,2,4,6], 'client_cpus':[8,10],
            'waves':2, 'accepted_per_wave':800, 'cpu_binding':'private kernel CPU sets; no CFS quota',
            'binaries':{label:{'path':str(path), 'sha256':hashes[label]} for label,path in binaries.items()},
            'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir()}}
(root/'metadata.json').write_text(json.dumps(metadata, indent=2)+'\n')
records = []
for repeat in range(1,6):
    for label in (('baseline','candidate') if repeat%2 else ('candidate','baseline')):
        unit = f'rustsql-qualification-guc-registry-connections-{label}-{repeat}-20261031'
        report, log = root/f'{label}-{repeat}.json', root/f'{label}-{repeat}.log'
        command = ['systemd-run', '--unit='+unit, '--uid=rustsql', '--gid=rustsql', '--wait', '--collect',
                   '--property=Delegate=cpu memory pids cpuset', '--property=AllowedCPUs=0,2,4,6,8,10',
                   '--property=MemoryMax=8G', '--property=MemorySwapMax=0', '--property=LimitSTACK=67108864',
                   '--property=RuntimeMaxSec=180', '--property=StandardOutput=append:'+str(log),
                   '--property=StandardError=append:'+str(log), '/usr/bin/python3', '-u', str(source/'guc_queue_probe.py'),
                   '--candidate', str(binaries[label]), '--work-dir', str(base/'conformance'), '--output', str(report),
                   '--burst', '--memory-mib', '4096']
        result = subprocess.run(command, capture_output=True, text=True, timeout=210)
        (root/f'{label}-{repeat}-journal.log').write_bytes(subprocess.check_output(['journalctl','-u',unit+'.service','--no-pager','-o','short-iso']))
        data = json.loads(report.read_text()) if report.exists() else {'passed':False}
        records.append({'label':label, 'repeat':repeat, 'command':command, 'exit':result.returncode,
                        'stdout':result.stdout, 'stderr':result.stderr, 'report':report.name, 'passed':data['passed']})
        (root/'commands.json').write_text(json.dumps(records, indent=2)+'\n')
        print(json.dumps({'label':label, 'repeat':repeat, 'passed':data['passed'], 'cpu_us':data.get('cpu_delta',{}).get('usage_usec'),
                          'peak_mib':data.get('resources_after_shutdown',{}).get('memory_peak',0)/2**20}), flush=True)
        assert result.returncode == 0 and data['passed'], 'Retained failed trial; no retry'
identities()
