from pathlib import Path
import json,subprocess,time
if not __debug__:raise RuntimeError('Assertions must remain enabled')
base=Path('/home/rustsql');output=base/'guc-registry-reserve-followup-20261031.json';assert not output.exists()
short=json.loads((base/'guc-registry-reserve-screen-20261031.json').read_text());assert short['rejected_at']=='capacity' and short['preservation_failures']==['range_p99_ms']
label='guc-registry-reserve-long-capacity-20261031';long=json.loads((base/label/'supplementary-review.json').read_text())[label]
assert long['timed_performance_valid'] and not long['timed']['preservation_failures']
report={'passed':False,'short_capacity_guard_passed':False,'long_capacity_guard_passed':True,'promoted':False,'commands':[]}
def save():output.write_text(json.dumps(report,indent=2)+'\n')
def run(label,command):
    t=time.monotonic();r=subprocess.run(command,capture_output=True,text=True)
    report['commands'].append({'label':label,'command':command,'exit':r.returncode,'seconds':time.monotonic()-t,'stdout':r.stdout,'stderr':r.stderr});save()
    print(label,r.returncode,r.stdout[-2500:],r.stderr[-500:],flush=True);r.check_returncode()
run('connections',['python3',str(base/'run_guc_registry_connections.py')])
root=base/'guc-registry-reserve-connections-20261031'
run('connections-review',['python3',str(base/'compare_guc_registry_connections.py'),'--input-dir',str(root),'--output',str(root/'review.json')])
r=json.loads((root/'review.json').read_text());report['connection_changes']={k:r[k]['median_change_pct'] for k in ['cpu_us_per_accepted_startup','cpu_us_per_accepted_startup_including_shutdown','peak_cgroup_mib']};save()
failures=[k for k,v in report['connection_changes'].items() if v>(0 if k=='peak_cgroup_mib' else 5)]
if failures:report['rejected_at']='connections';report['preservation_failures']=failures;save();raise SystemExit(0)
run('qualification',['python3',str(base/'run_guc_registry_qualification.py')])
report['passed']=True;save()
