from pathlib import Path
import json,subprocess,time
if not __debug__:raise RuntimeError('Assertions must remain enabled')
base=Path('/home/rustsql');output=base/'guc-registry-reserve-screen-20261031.json'
assert not output.exists()
report={'passed':False,'promoted':False,'commands':[]}
def save():output.write_text(json.dumps(report,indent=2)+'\n')
def run(label,command):
    start=time.monotonic()
    r=subprocess.run(command,capture_output=True,text=True)
    report['commands'].append({'label':label,'command':command,'exit':r.returncode,'seconds':time.monotonic()-start,'stdout':r.stdout,'stderr':r.stderr})
    save();print(label,r.returncode,r.stdout[-3000:],r.stderr[-500:],flush=True);r.check_returncode()
run('prepare',['python3',str(base/'prepare_guc_registry_comparisons.py')])
for phase in ('medium','capacity'):
    label='guc-registry-reserve-'+phase+'-20261031'
    run(phase,['python3',str(base/'run_guc_registry_comparison.py'),label,phase])
    run(phase+'-review',['python3',str(base/'review_guc_registry.py'),label,phase])
    review=json.loads((base/label/'supplementary-review.json').read_text())[label]
    failures=review['timed']['preservation_failures'][:]
    for window in ('warmup_and_measurement_cpu','setup_warmup_and_measurement_cpu'):
        if not review[window]['rust_comparison_valid'] or review[window]['median_change_pct']>5:failures.append(window)
    report[phase]=review;save()
    if failures:
        report['rejected_at']=phase;report['preservation_failures']=failures;save()
        print('candidate rejected:',failures,flush=True);raise SystemExit(0)
run('connections',['python3',str(base/'run_guc_registry_connections.py')])
connections=base/'guc-registry-reserve-connections-20261031'
run('connections-review',['python3',str(base/'compare_guc_registry_connections.py'),'--input-dir',str(connections),'--output',str(connections/'review.json')])
review=json.loads((connections/'review.json').read_text());report['connections']=review
failures=[key for key in ('cpu_us_per_accepted_startup','cpu_us_per_accepted_startup_including_shutdown') if review[key]['median_change_pct']>5]
if failures:report['rejected_at']='connections';report['preservation_failures']=failures
else:report['passed']=True
save();print(json.dumps({'screen_passed':report['passed'],'production_qualified':False}),flush=True)
