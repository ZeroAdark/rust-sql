"""Attribute retained memory to isolated SQL categories; not a performance gate."""
from collections import Counter
from pathlib import Path
import argparse,hashlib,json,multiprocessing,os,platform,queue,re,shutil,time
import psycopg
from psycopg.conninfo import make_conninfo
from connection_churn_probe import CheckedCluster
from fixed_workload import SQL,setup,grouped,progression_sum,column_cache_stats
from resource_scope import DelegatedScope,observe,snapshot,delta

if not __debug__:raise RuntimeError('Assertions must remain enabled')
BASE=Path('/home/rustsql')
parser=argparse.ArgumentParser();parser.add_argument('--smoke',action='store_true');args=parser.parse_args()
ROOT=BASE/'memory-ownership-20261031'
SIZES=[1000000]
REPEATS=2
BINARIES={'rustsql':BASE/'vma-residency-candidate/bin'}
HASHES={'postgresql':'07b16e1aa4f0e2206c37b339b6e4cc813aa8ab9e3c5516334f753b3d90d0c536','rustsql':'02cfbca6869bb352c8081b1fb275cdd4317b33a72b8feb05c563408e4c48d454'}
CLIENTS=6
KINDS=['idle','aggregate','join']
DIAGNOSTIC_CONNECTION=None
definition_source=Path(__file__).with_name('memory-broker-views.sql').read_text()
DEFINITIONS=[re.search(r'CREATE OR REPLACE FUNCTION '+name+r'\(.*?;',definition_source,re.S).group()
             for name in ('pgrust_memory_accounts','pgrust_memory_owner_end','pgrust_memory_owners')]

def identities():
    for name,binary in BINARIES.items():
        with (binary/'postgres').open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==HASHES[name]

def save(path,value):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(path)

def mappings(group):
    """PSS by broad mapping category; no allocator-owner attribution is inferred."""
    totals=Counter();largest=[];complete=True
    for pid in sorted(map(int,(group/'cgroup.procs').read_text().split())):
        try:lines=Path('/proc',str(pid),'smaps').read_text().splitlines()
        except (FileNotFoundError,ProcessLookupError):complete=False;continue
        regions=[];item=None
        for line in lines:
            if re.match(r'^[0-9a-f]+-[0-9a-f]+ ',line):
                if item is not None:regions.append(item)
                parts=line.split(maxsplit=5);name=parts[5] if len(parts)>5 else ''
                category='anonymous' if not name or name.startswith(('[heap]','[stack]','[anon:')) else 'shared_memory' if name.startswith(('/dev/shm/','/SYSV','/memfd:')) else 'file_or_other'
                item={'category':category,'pid':pid}
            elif item is not None and ':' in line:
                key,value=line.split(':',1)
                if key in ('Size','Rss','Pss','Private_Dirty','Private_Clean','AnonHugePages'):
                    item[key]=int(value.split()[0])*1024
        if item is not None:regions.append(item)
        for item in regions:
            totals[item['category']]+=item.get('Pss',0)
            if item['category']=='anonymous':largest.append(item)
    return {'complete':complete,'pss_bytes_by_category':dict(totals),'largest_anonymous_regions':sorted(largest,key=lambda x:x.get('Pss',0),reverse=True)[:24]}

def observation(group):
    result=observe(group);result['mapping_summary']=mappings(group)
    assert DIAGNOSTIC_CONNECTION is not None
    result['diagnostics']={}
    for name in ('pgrust_memory_accounts','pgrust_memory_owner_end','pgrust_memory_owners'):
        cursor=DIAGNOSTIC_CONNECTION.execute('SELECT * FROM '+name+'()')
        result['diagnostics'][name]={'columns':[c.name for c in cursor.description],'rows':cursor.fetchall()}
    result['diagnostics']['decoded_data']=column_cache_stats(DIAGNOSTIC_CONNECTION)
    result['after_diagnostics']=observe(group)
    result['after_diagnostics']['mapping_summary']=mappings(group)
    return result

def exercise(dsn,group,rows,kind):
    count=0 if kind=='idle' else 32 if kind in ('read','update') else 12
    ctx=multiprocessing.get_context('fork');messages=ctx.Queue()
    first,rest,release=ctx.Event(),ctx.Event(),ctx.Event()
    def worker(client):
        try:
            with psycopg.connect(make_conninfo(dsn,user='bench_user'),autocommit=True) as con:
                con.execute("SET statement_timeout='60s'; SET lock_timeout='10s'")
                assert con.execute('SELECT rolsuper FROM pg_roles WHERE rolname=current_user').fetchone()==(False,)
                messages.put({'client':client,'stage':'connected','passed':True})
                if not first.wait(180):raise TimeoutError('first-query signal')
                balances=Counter();observed_types=None
                def query(number):
                    nonlocal observed_types
                    key=client*20000+(number*67)%20000+1
                    if kind=='read':args=(key,);expected=[(key,0)];types=[23,20]
                    elif kind=='update':
                        args=(key,);balances[key]+=1;expected=[(key,balances[key])];types=[23,20]
                    elif kind=='range':
                        lo=1+(number*7919)%(rows-4096+1);args=(lo,lo+4095);expected=[(4096,progression_sum(lo,4096,1))];types=[20,20]
                    else:args=None;expected=grouped(1,rows,128 if kind=='aggregate' else 8);types=[23,20,20]
                    cursor=con.execute(SQL[kind],args,prepare=True)
                    actual=cursor.fetchall();assert actual==expected,(kind,actual[:2],expected[:2])
                    observed_types=[c.type_code for c in cursor.description];assert observed_types==types
                if count:query(0)
                messages.put({'client':client,'stage':'first','passed':True,'types':observed_types})
                if not rest.wait(180):raise TimeoutError('repeat signal')
                for number in range(1,count):query(number)
                messages.put({'client':client,'stage':'repeated','passed':True,'queries':count,'types':observed_types})
                if not release.wait(180):raise TimeoutError('release signal')
        except Exception as error:messages.put({'client':client,'passed':False,'error':repr(error)})
    workers=[ctx.Process(target=worker,args=(i,)) for i in range(CLIENTS)]
    def collect(stage):
        result=[];deadline=time.monotonic()+180
        while len(result)<CLIENTS:
            if time.monotonic()>deadline:raise TimeoutError((stage,len(result)))
            try:item=messages.get(timeout=.2)
            except queue.Empty:
                assert not [(p.pid,p.exitcode) for p in workers if p.exitcode not in (None,0)],'client died'
                continue
            assert item['passed'] and item['stage']==stage,item
            result.append(item)
        assert {v['client'] for v in result}==set(range(CLIENTS))
        return result
    report={};okay=False
    try:
        for p in workers:p.start()
        report['connections']=collect('connected');report['connected']=observation(group)
        first.set();report['first_results']=collect('first');report['after_first']=observation(group)
        rest.set();report['repeated_results']=collect('repeated');report['after_repeated']=observation(group)
        report['server_cpu_delta']=delta(report['connected']['cpu'],report['after_repeated']['cpu'])
        report['queries']=CLIENTS*count;okay=True
    finally:
        release.set()
        if not okay:
            for p in workers:
                if p.pid and p.is_alive():p.terminate()
        for p in workers:
            if p.pid:
                p.join(5)
                if p.is_alive():p.terminate();p.join(5)
    assert all(p.exitcode==0 for p in workers)
    report['after_disconnect']=observation(group)
    time.sleep(1)
    report['after_idle_one_second']=observation(group)
    return report

def trial(scope,engine,rows,kind,repeat):
    global DIAGNOSTIC_CONNECTION
    reference=engine=='postgresql';name=f'{rows}-{kind}-{engine}-{repeat}'
    group,launcher=scope.server(2048)
    settings=['autovacuum=off','work_mem=16MB','shared_buffers=128MB','max_parallel_workers_per_gather=2','max_connections=100']
    if not reference:settings.append('max_active_queries=6')
    cluster=CheckedCluster(BINARIES[engine],ROOT/'clusters',reference=reference,launcher=launcher,allocator=None if reference else 'hearth',settings=settings)
    for key in list(cluster.env):
        if key.startswith('MIMALLOC_'):del cluster.env[key]
    result={'passed':False,'engine':engine,'rows':rows,'kind':kind,'repeat':repeat,'cluster':str(cluster.root),'limits':{n:(group/n).read_text().strip() for n in ('memory.max','memory.swap.max','cpu.max')}}
    try:
        with cluster:
            result['version']=cluster.version
            assert os.sched_getaffinity(cluster.process.pid)==scope.server_cpus
            result['live_environment']=sorted(x.decode() for x in Path('/proc',str(cluster.process.pid),'environ').read_bytes().split(b'\0') if x.startswith((b'PGRUST_',b'MIMALLOC_')))
            assert result['live_environment']==([] if reference else ['PGRUST_ALLOCATOR=hearth'])
            with psycopg.connect(cluster.dsn,autocommit=True) as con:
                result['setup_cache_trace']=setup(con,rows,CLIENTS,reference=reference)
                for definition in DEFINITIONS:con.execute(definition)
            cluster.stop();cluster.start()
            DIAGNOSTIC_CONNECTION=psycopg.connect(cluster.dsn,autocommit=True,application_name='ownership-observer')
            result['before_connections']=observation(group)
            result['measurement']=exercise(cluster.dsn,group,rows,kind)
            DIAGNOSTIC_CONNECTION.close();DIAGNOSTIC_CONNECTION=None
            with psycopg.connect(cluster.dsn,autocommit=True) as con:
                expected=sorted((client*20000+(n*67)%20000+1,1) for client in range(CLIENTS) for n in range(32)) if kind=='update' else []
                actual=con.execute('SELECT id,balance FROM bench_accounts WHERE balance<>0 ORDER BY id').fetchall();assert actual==expected
                result['committed_updates']=sum(v for _,v in actual)
                result['state_sha256']=hashlib.sha256(json.dumps(actual).encode()).hexdigest()
                if not reference:result['cache_after_measured_work']=column_cache_stats(con)
                assert con.execute(SQL['aggregate']).fetchall()==grouped(1,rows,128)
            cluster.stop();cluster.start()
            with psycopg.connect(cluster.dsn,autocommit=True) as con:
                assert con.execute('SELECT id,balance FROM bench_accounts WHERE balance<>0 ORDER BY id').fetchall()==expected
                assert con.execute(SQL['aggregate']).fetchall()==grouped(1,rows,128)
            result['passed']=True
    except Exception as error:result['error']=repr(error)
    finally:
        if DIAGNOSTIC_CONNECTION is not None:
            DIAGNOSTIC_CONNECTION.close();DIAGNOSTIC_CONNECTION=None
        result['shutdown_exit_codes']=cluster.shutdown_exit_codes
        result['final_resources']=snapshot(group);result['remaining_pids']=(group/'cgroup.procs').read_text().split()
        if result['shutdown_exit_codes']!=[0,0,0] or result['remaining_pids'] or result['final_resources']['memory_swap_current'] or any(result['final_resources']['events'].get(k,0) for k in ('max','oom','oom_kill')):result['passed']=False
        save(ROOT/(name+'.json'),result)
        if not result['remaining_pids']:group.rmdir()
    if result['passed']:
        logs=ROOT/(name+'-logs');logs.mkdir()
        for p in cluster.root.glob('*.log'):shutil.copyfile(p,logs/p.name)
        target=cluster.root.resolve();assert target.parent==(ROOT/'clusters').resolve() and target.name.startswith('compat-')
        shutil.rmtree(target)
    return {'report':name+'.json','passed':result['passed'],'error':result.get('error')}

identities();ROOT.mkdir(exist_ok=False)
source=Path(__file__).parent
save(ROOT/'metadata.json',{'binary_sha256':HASHES,'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.is_file()},'assertions_enabled':__debug__,'platform':platform.platform(),'clients':CLIENTS,'rows':SIZES,'kinds':KINDS,'repeats':REPEATS,'server_cpus':[0,2,4,6],'client_cpus':[8,10],'purpose':'Diagnostic attribution only, not performance qualification. Six workload clients plus one persistent administrative observer. Physical memory sampled immediately before and after diagnostic SQL to expose observer cost. Account and pool capacity counters are not assumed to be physical residency. Fresh cluster and restart for each category; independent query oracles, type checks and restart persistence retained.'})
scope=DelegatedScope([0,2,4,6],[8,10]);summary={'complete':False,'production_qualified':False,'trials':[]};save(ROOT/'summary.json',summary)
for repeat in range(1,REPEATS+1):
    sizes=SIZES if repeat==1 else list(reversed(SIZES))
    for rows in sizes:
        for kind in KINDS if repeat==1 else list(reversed(KINDS)):
            for engine in BINARIES if repeat==1 else list(reversed(BINARIES)):
                item=trial(scope,engine,rows,kind,repeat);summary['trials'].append(item);save(ROOT/'summary.json',summary);print(json.dumps(item),flush=True)
                if not item['passed']:raise RuntimeError(item)
identities();summary['complete']=True;save(ROOT/'summary.json',summary)
