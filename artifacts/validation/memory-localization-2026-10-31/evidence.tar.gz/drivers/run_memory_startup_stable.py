from pathlib import Path
import json, subprocess

if not __debug__:raise RuntimeError('Assertions must remain enabled')
base=Path('/home/rustsql');label='memory-startup-stable-20261031'
assert not (base/label).exists()
assert not subprocess.check_output(['systemctl','list-units','rustsql-qualification-*','--state=running','--plain','--no-legend'],text=True).strip()
unit='rustsql-qualification-'+label
command=['systemd-run','--unit='+unit,'--uid=rustsql','--gid=rustsql','--wait','--collect',
         '--property=Delegate=cpu memory pids','--property=CPUQuota=600%',
         '--property=MemoryMax=8G','--property=MemorySwapMax=0','--property=LimitSTACK=67108864','--property=RuntimeMaxSec=900',
         '--property=StandardOutput=append:'+str(base/(label+'.log')),'--property=StandardError=append:'+str(base/(label+'.log')),
         '/usr/bin/python3','-u',str(base/'memory-startup-stable-source-20261031/memory_startup_stable.py')]
result=subprocess.run(command,capture_output=True,text=True,timeout=930)
(base/(label+'-command.json')).write_text(json.dumps({'command':command,'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr},indent=2)+'\n')
(base/(label+'-journal.log')).write_bytes(subprocess.check_output(['journalctl','-u',unit+'.service','--no-pager','-o','short-iso']))
print(label,result.returncode,flush=True)
print((base/(label+'.log')).read_text()[-1800:],flush=True)
result.check_returncode()
