"""Prepare, but do not run, a diagnostic attribution experiment."""
from pathlib import Path
import ast, shutil

base = Path('/home/rustsql')
source = base/'memory-ownership-source-20261031'
source.mkdir(exist_ok=False)
previous = base/'memory-localization-source-20261031'
for name in ('cluster.py','connection_churn_probe.py','connection_queue_probe.py','fixed_workload.py'):
    shutil.copyfile(previous/name, source/name)
scope = (base/'guc-name-index-cpuset-capacity-20261031-source/resource_scope.py').read_text()
oldscope = (previous/'resource_scope.py').read_text()
observe = ast.get_source_segment(oldscope, next(n for n in ast.parse(oldscope).body if isinstance(n, ast.FunctionDef) and n.name=='observe'))
assert scope.count('class DelegatedScope:') == 1
(source/'resource_scope.py').write_text(scope.replace('class DelegatedScope:', observe+'\n\nclass DelegatedScope:'))
shutil.copyfile(base/'pgrust/scripts/memory-broker-views.sql', source/'memory-broker-views.sql')
text = (previous/'memory_localization.py').read_text()
def replace(old, new):
    global text
    assert text.count(old)==1, (old,text.count(old))
    text = text.replace(old,new)
replace("ROOT=BASE/('memory-localization-pilot-20261031' if args.smoke else 'memory-localization-20261031')", "ROOT=BASE/'memory-ownership-20261031'")
replace('SIZES=[10000] if args.smoke else [10000,1000000]', 'SIZES=[1000000]')
replace('REPEATS=1 if args.smoke else 2', 'REPEATS=2')
replace("BINARIES={'postgresql':BASE/'postgres18/bin','rustsql':BASE/'vma-residency-candidate/bin'}", "BINARIES={'rustsql':BASE/'vma-residency-candidate/bin'}")
replace("KINDS=['idle','read','update','range','aggregate','join']", """KINDS=['idle','aggregate','join']
DIAGNOSTIC_CONNECTION=None
definition_source=Path(__file__).with_name('memory-broker-views.sql').read_text()
DEFINITIONS=[re.search(r'CREATE OR REPLACE FUNCTION '+name+r'\\(.*?;',definition_source,re.S).group()
             for name in ('pgrust_memory_accounts','pgrust_memory_owner_end','pgrust_memory_owners')]""")
replace("    result=observe(group);result['mapping_summary']=mappings(group);return result", """    result=observe(group);result['mapping_summary']=mappings(group)
    assert DIAGNOSTIC_CONNECTION is not None
    result['diagnostics']={}
    for name in ('pgrust_memory_accounts','pgrust_memory_owner_end','pgrust_memory_owners'):
        cursor=DIAGNOSTIC_CONNECTION.execute('SELECT * FROM '+name+'()')
        result['diagnostics'][name]={'columns':[c.name for c in cursor.description],'rows':cursor.fetchall()}
    result['diagnostics']['decoded_data']=column_cache_stats(DIAGNOSTIC_CONNECTION)
    result['after_diagnostics']=observe(group)
    result['after_diagnostics']['mapping_summary']=mappings(group)
    return result""")
replace('def trial(scope,engine,rows,kind,repeat):', 'def trial(scope,engine,rows,kind,repeat):\n    global DIAGNOSTIC_CONNECTION')
replace("            with psycopg.connect(cluster.dsn,autocommit=True) as con:result['setup_cache_trace']=setup(con,rows,CLIENTS,reference=reference)", """            with psycopg.connect(cluster.dsn,autocommit=True) as con:
                result['setup_cache_trace']=setup(con,rows,CLIENTS,reference=reference)
                for definition in DEFINITIONS:con.execute(definition)""")
replace("            result['before_connections']=observation(group)", """            DIAGNOSTIC_CONNECTION=psycopg.connect(cluster.dsn,autocommit=True,application_name='ownership-observer')
            result['before_connections']=observation(group)""")
replace("            result['measurement']=exercise(cluster.dsn,group,rows,kind)", """            result['measurement']=exercise(cluster.dsn,group,rows,kind)
            DIAGNOSTIC_CONNECTION.close();DIAGNOSTIC_CONNECTION=None""")
replace("        result['shutdown_exit_codes']=cluster.shutdown_exit_codes", """        if DIAGNOSTIC_CONNECTION is not None:
            DIAGNOSTIC_CONNECTION.close();DIAGNOSTIC_CONNECTION=None
        result['shutdown_exit_codes']=cluster.shutdown_exit_codes""")
replace("'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.glob('*.py')}", "'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir() if p.is_file()}")
replace("'purpose':'Phase-localization screen, not performance qualification. Each category gets a fresh cluster and a restart after loading. Clients wait at synchronized stages while smaps is read; background reclamation may run. Endpoint PSS includes all connected clients; later validation SQL is outside those observations.'", "'purpose':'Diagnostic attribution only, not performance qualification. Six workload clients plus one persistent administrative observer. Physical memory sampled immediately before and after diagnostic SQL to expose observer cost. Account and pool capacity counters are not assumed to be physical residency. Fresh cluster and restart for each category; independent query oracles, type checks and restart persistence retained.'")
compile(text, str(source/'memory_ownership.py'), 'exec')
(source/'memory_ownership.py').write_text(text)
shutil.copyfile(Path(__file__), source/Path(__file__).name)
print('Prepared', source)
