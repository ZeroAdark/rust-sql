from pathlib import Path
import ast,hashlib,json,shutil,subprocess,sys

if not __debug__:raise RuntimeError('Assertions must remain enabled')
mode=sys.argv[1];assert mode in ('smoke','full')
base=Path('/home/rustsql');label='memory-localization-'+('pilot-' if mode=='smoke' else '')+'20261031'
source=base/'memory-localization-source-20261031'
assert not (base/label).exists() and not (base/(label+'-command.json')).exists()
active=subprocess.check_output(['systemctl','list-units','rustsql-qualification-*','--state=running','--plain','--no-legend'],text=True)
assert not active.strip(),active
if mode=='smoke':
    source.mkdir(exist_ok=False)
    for name in ['cluster.py','connection_churn_probe.py','connection_queue_probe.py','resource_scope.py']:
        shutil.copyfile(base/'pgrust/scripts/validation'/name,source/name)
    frozen=base/'memory-scaling-restart-source-20261031'
    shutil.copyfile(frozen/'fixed_workload.py',source/'fixed_workload.py')
    text=(frozen/'resource_scope.py').read_text();tree=ast.parse(text)
    observe=ast.get_source_segment(text,next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='observe'))
    path=source/'resource_scope.py';text=path.read_text();assert text.count('class DelegatedScope:')==1
    path.write_text(text.replace('class DelegatedScope:',observe+'\n\n\nclass DelegatedScope:'))
    shutil.copyfile(base/'memory_localization.py',source/'memory_localization.py')
else:
    assert json.loads((base/'memory-localization-pilot-20261031/summary.json').read_text())['complete']
    hashes=json.loads((base/'memory-localization-pilot-20261031/metadata.json').read_text())['source_sha256']
    assert all(hashlib.sha256((source/name).read_bytes()).hexdigest()==sha for name,sha in hashes.items())
for path in source.glob('*.py'):compile(path.read_text(),str(path),'exec')
unit='rustsql-qualification-'+label
cmd=['systemd-run','--unit='+unit,'--uid=rustsql','--gid=rustsql','--wait','--collect',
     '--property=Delegate=cpu memory pids','--property=MemoryMax=8G','--property=MemorySwapMax=0',
     '--property=CPUQuota=600%','--property=LimitSTACK=67108864','--property=RuntimeMaxSec=1800',
     '--property=StandardOutput=append:'+str(base/(label+'.log')),'--property=StandardError=append:'+str(base/(label+'.log')),
     '/usr/bin/python3','-u',str(source/'memory_localization.py')]+(['--smoke'] if mode=='smoke' else [])
save=base/(label+'-command.json');save.write_text(json.dumps({'command':cmd,'state':'starting'},indent=2)+'\n')
r=subprocess.run(cmd,capture_output=True,text=True,timeout=1830)
save.write_text(json.dumps({'command':cmd,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr},indent=2)+'\n')
(base/(label+'-journal.log')).write_bytes(subprocess.check_output(['journalctl','-u',unit+'.service','--no-pager','-o','short-iso']))
print(label,r.returncode,flush=True);print((base/(label+'.log')).read_text()[-1600:],flush=True)
r.check_returncode()
