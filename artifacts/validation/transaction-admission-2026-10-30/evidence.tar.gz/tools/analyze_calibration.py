from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path(sys.argv[3]).resolve()))
from compare_resource import validate_trial,comparison,require
from fixed_workload import SQL,PER_BUNDLE
root=Path(sys.argv[1]);meta=json.loads((root/'metadata.json').read_text());summary=json.loads((root/'summary.json').read_text())
require(summary['passed'] and summary['complete'] and len(summary['trials'])==10,'incomplete calibration')
require(meta['memory_mib']==[4096] and meta['repeats']==5 and meta['clients']==6 and meta['bundles']==400 and meta['warmup']==50 and meta['rows']==1000000,'changed experiment')
repo=Path('/home/rustsql/pgrust')
for rel,digest in meta['source_lf_sha256'].items():require(hashlib.sha256((root/'source'/rel).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==digest,'source changed')
expected={'baseline':'26ba69060488b50cc165b9a450c397eab524c1240870012d7c775e12f4540f77','candidate':'e7d3f26e5f0acfb3de5bd9b0971a4168cbfca2d3a25407c64658721c9e4ac20a'}
require({label:info['sha256'] for label,info in meta['binaries'].items()}==expected,'unexpected binaries')
measurements={}
for item in summary['trials']:
 identity=(item['label'],item['memory_mib'],item['repetition']);require(identity not in measurements,'duplicate trial')
 report=json.loads((root/item['file']).read_text());measurement=validate_trial(report,meta,identity);measurements[identity]=measurement
 require(item['passed'] and item['cpu_us_per_bundle']==measurement['server_cpu_us_per_bundle'] and item['bundles_per_second']==measurement['bundles_per_second'],'summary mismatch')
require(set(measurements)=={(label,4096,rep) for label in ('baseline','candidate') for rep in range(1,6)},'missing trial')
def compare(read):return comparison(*[[read(measurements[label,4096,rep]) for rep in range(1,6)] for label in ('baseline','candidate')])
report={'evidence_valid':True,'production_qualified':False,'scope':f"4 GiB admission calibration, limit {meta.get('max_active_queries',4)}; not the complete memory matrix; baseline bypassed extended admission",'metadata':meta,'trials':10,'measured_statements':10*meta['clients']*meta['bundles']*sum(PER_BUNDLE.values()),'cpu_us_per_bundle':compare(lambda m:m['server_cpu_us_per_bundle']),'bundles_per_second':compare(lambda m:m['bundles_per_second']),'latency_ms':{kind:{f'p{p}':compare(lambda m:m['latency'][kind][f'p{p}_ms']) for p in (50,95,99)} for kind in (*SQL,'bundle')},'memory_mib':{metric:compare(lambda m:m['sampled_resources'][f'sampled_{metric}_peak_bytes']/1024**2) for metric in ('memory_current','summed_rss','summed_pss')},'memory_limit_events':{label:[measurements[label,4096,rep]['memory_event_delta'].get('max',0) for rep in range(1,6)] for label in ('baseline','candidate')},'throttled_usec':{label:[measurements[label,4096,rep]['cpu_delta'].get('throttled_usec',0) for rep in range(1,6)] for label in ('baseline','candidate')}}
report['median_throughput_within_five_percent']=report['bundles_per_second']['median_change_pct']>=-5
report['median_p99_within_five_percent']=all(m['p99']['median_change_pct']<=5 for m in report['latency_ms'].values())
Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'cpu':report['cpu_us_per_bundle'],'throughput_change_pct':report['bundles_per_second']['median_change_pct'],'p99_change_pct':{k:v['p99']['median_change_pct'] for k,v in report['latency_ms'].items()},'memory_change_pct':{k:v['median_change_pct'] for k,v in report['memory_mib'].items()},'throughput_gate':report['median_throughput_within_five_percent'],'p99_gate':report['median_p99_within_five_percent']},indent=2))
