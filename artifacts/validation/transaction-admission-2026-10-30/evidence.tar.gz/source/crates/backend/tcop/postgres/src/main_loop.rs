// PostgresMain + ReadCommand/SocketBackend (postgres.c). The C sigsetjmp
// recovery block is the Err/panic arm of each loop iteration.
use ::elog::ereport;
use ::mcx::{Mcx, MemoryContext, PgVec};
use ::stringinfo::StringInfo;
use ::types_dest::CommandDest;
use ::types_error::{
    ErrorLocation, PgError, PgResult, DEBUG1, ERRCODE_CONNECTION_DOES_NOT_EXIST,
    ERRCODE_CONNECTION_FAILURE, ERRCODE_PROTOCOL_VIOLATION, ERROR, FATAL, LOG,
};

use crate::{
    check_for_interrupts, extended_query, loc, set_doing_command_read,
    set_doing_extended_query_message, set_ignore_till_sync, set_xact_started, simple_query,
    ignore_till_sync,
};

pub(crate) mod pqmsg {
    pub const QUERY: i32 = b'Q' as i32;
    pub const PARSE: i32 = b'P' as i32;
    pub const BIND: i32 = b'B' as i32;
    pub const EXECUTE: i32 = b'E' as i32;
    pub const FUNCTION_CALL: i32 = b'F' as i32;
    pub const CLOSE: i32 = b'C' as i32;
    pub const DESCRIBE: i32 = b'D' as i32;
    pub const FLUSH: i32 = b'H' as i32;
    pub const SYNC: i32 = b'S' as i32;
    pub const TERMINATE: i32 = b'X' as i32;
    pub const COPY_DATA: i32 = b'd' as i32;
    pub const COPY_DONE: i32 = b'c' as i32;
    pub const COPY_FAIL: i32 = b'f' as i32;
    pub const CLOSE_COMPLETE: u8 = b'3';
    pub const BACKEND_KEY_DATA: u8 = b'K';
}

const EOF: i32 = pqcomm::EOF;

const PQ_SMALL_MESSAGE_LIMIT: i32 = 10000;
const PQ_LARGE_MESSAGE_LIMIT: i32 = 0x3fffffff - 1; /* MaxAllocSize - 1 */

// MessageContext's first block (C: ALLOCSET_DEFAULT_INITSIZE, 8 kB). It is kept across the
// per-message reset, so it is sized to hold a short statement's parse, analysis and plan: such a
// message then takes and frees no block.
const MESSAGE_CONTEXT_INIT_SIZE: usize = 64 * 1024;

fn SocketBackend(in_buf: &mut StringInfo<'_>) -> PgResult<i32> {
    // HOLD_CANCEL_INTERRUPTS() ... RESUME_CANCEL_INTERRUPTS(): a query cancel
    // must not fire mid-read and lose FE/BE sync; the guard resumes on every
    // exit path.
    struct CancelHoldoff;
    impl Drop for CancelHoldoff {
        fn drop(&mut self) {
            init_small::globals::ResumeCancelInterrupts();
        }
    }
    init_small::globals::HoldCancelInterrupts();
    let _holdoff = CancelHoldoff;

    pqcomm::pq_startmsgread()?;
    let qtype = pqcomm::pq_getbyte()?;

    if qtype == EOF {
        if xact::IsTransactionState() {
            ereport(types_error::COMMERROR)
                .errcode(ERRCODE_CONNECTION_FAILURE)
                .errmsg("unexpected EOF on client connection with an open transaction")
                .finish(loc(369, "SocketBackend"))?;
        } else {
            // Can't send DEBUG log messages to client at this point
            // (postgres.c:379): the output switch precedes the report.
            elog::config::set_where_to_send_output(CommandDest::None);
            ereport(DEBUG1)
                .errcode(ERRCODE_CONNECTION_DOES_NOT_EXIST)
                .errmsg_internal("unexpected EOF on client connection")
                .finish(loc(380, "SocketBackend"))?;
        }
        return Ok(qtype);
    }

    let maxmsglen = match qtype {
        x if x == pqmsg::QUERY || x == pqmsg::FUNCTION_CALL => {
            set_doing_extended_query_message(false);
            PQ_LARGE_MESSAGE_LIMIT
        }
        x if x == pqmsg::TERMINATE => {
            set_doing_extended_query_message(false);
            set_ignore_till_sync(false);
            PQ_SMALL_MESSAGE_LIMIT
        }
        x if x == pqmsg::BIND || x == pqmsg::PARSE => {
            set_doing_extended_query_message(true);
            PQ_LARGE_MESSAGE_LIMIT
        }
        x if x == pqmsg::CLOSE
            || x == pqmsg::DESCRIBE
            || x == pqmsg::EXECUTE
            || x == pqmsg::FLUSH =>
        {
            set_doing_extended_query_message(true);
            PQ_SMALL_MESSAGE_LIMIT
        }
        x if x == pqmsg::SYNC => {
            set_ignore_till_sync(false);
            set_doing_extended_query_message(false);
            PQ_SMALL_MESSAGE_LIMIT
        }
        x if x == pqmsg::COPY_DATA => {
            set_doing_extended_query_message(false);
            PQ_LARGE_MESSAGE_LIMIT
        }
        x if x == pqmsg::COPY_DONE || x == pqmsg::COPY_FAIL => {
            set_doing_extended_query_message(false);
            PQ_SMALL_MESSAGE_LIMIT
        }
        other => {
            return Err(ereport(FATAL)
                .errcode(ERRCODE_PROTOCOL_VIOLATION)
                .errmsg(format!("invalid frontend message type {other}"))
                .into_error()
                .with_funcname("SocketBackend")
                .into());
        }
    };

    if pqcomm::pq_getmessage(in_buf, maxmsglen)? != 0 {
        return Ok(EOF); /* suitable message already logged */
    }

    Ok(qtype)
}

fn ReadCommand(in_buf: &mut StringInfo<'_>) -> PgResult<i32> {
    if elog::config::where_to_send_output() == CommandDest::Remote {
        SocketBackend(in_buf)
    } else {
        InteractiveBackend(in_buf)
    }
}

// interactive_getc (postgres.c:318): one byte from stdin with the interrupt
// drains around it. C's getc EINTR surface maps to ErrorKind::Interrupted:
// run the read-interrupt drain and retry, as a signal-interrupted getc does.
fn interactive_getc() -> PgResult<Option<u8>> {
    use std::io::Read;
    check_for_interrupts()?;
    loop {
        let mut byte = [0u8; 1];
        let r = std::io::stdin().lock().read(&mut byte);
        crate::ProcessClientReadInterrupt(false)?;
        match r {
            Ok(0) => return Ok(None), /* EOF */
            Ok(_) => return Ok(Some(byte[0])),
            Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
            // getc(3) reports any other read error as EOF.
            Err(_) => return Ok(None),
        }
    }
}

// InteractiveBackend (postgres.c:236): stdin is the query source; the
// interactive delimiter is newline (or ";\n\n" under -j).
fn InteractiveBackend(in_buf: &mut StringInfo<'_>) -> PgResult<i32> {
    use std::io::Write;

    /* display a prompt and obtain input from the user */
    // printf/fflush: write failures are ignored, never a panic.
    let _ = write!(std::io::stdout(), "backend> ");
    let _ = std::io::stdout().flush();

    in_buf.reset();

    /* Read characters until EOF or the appropriate delimiter is seen. */
    let mut saw_eof = true;
    while let Some(c) = interactive_getc()? {
        if c == b'\n' {
            if crate::use_semi_newline_newline() {
                /*
                 * In -j mode, semicolon followed by two newlines ends the
                 * command; otherwise treat newline as regular character.
                 */
                if in_buf.len() > 1
                    && in_buf.as_bytes()[in_buf.len() - 1] == b'\n'
                    && in_buf.as_bytes()[in_buf.len() - 2] == b';'
                {
                    /* might as well drop the second newline */
                    saw_eof = false;
                    break;
                }
            } else {
                /*
                 * In plain mode, newline ends the command unless preceded by
                 * backslash.
                 */
                if in_buf.len() > 0 && in_buf.as_bytes()[in_buf.len() - 1] == b'\\' {
                    /* discard backslash from inBuf */
                    in_buf.truncate(in_buf.len() - 1);
                    /* discard newline too */
                    continue;
                }
                /* keep the newline character, but end the command */
                in_buf.append_byte(b'\n')?;
                saw_eof = false;
                break;
            }
        }

        /* Not newline, or newline treated as regular character */
        in_buf.append_byte(c)?;
    }

    /* No input before EOF signal means time to quit. */
    if saw_eof && in_buf.is_empty() {
        return Ok(EOF);
    }

    /* Add '\0' to make it look the same as message case. */
    in_buf.append_byte(0)?;

    /* if the query echo flag was given, print the query.. */
    if crate::echo_query() {
        let _ = write_echo(&mut std::io::stdout().lock(), in_buf.as_bytes());
    }
    let _ = std::io::stdout().flush();

    Ok(pqmsg::QUERY)
}

// printf("%s", inBuf->data): the echo stops at the first NUL.
pub(crate) fn echoed_statement(buf: &[u8]) -> &[u8] {
    &buf[..buf.iter().position(|&b| b == 0).unwrap_or(buf.len())]
}

// printf("statement: %s\n"): the input bytes go out verbatim, invalid
// UTF-8 included.
pub(crate) fn write_echo(out: &mut impl std::io::Write, buf: &[u8]) -> std::io::Result<()> {
    out.write_all(b"statement: ")?;
    out.write_all(echoed_statement(buf))?;
    out.write_all(b"\n")
}

pub(crate) struct LoopState {
    pub(crate) send_ready_for_query: bool,
    pub(crate) idle_in_transaction_timeout_enabled: bool,
    pub(crate) idle_session_timeout_enabled: bool,
    /// D3.4 idle passivation timer armed for the current idle period.
    pub(crate) idle_passivate_timeout_enabled: bool,
    /// D4812: the server-log writer this backend had before a condemned statement's error recovery deferred its writes
    /// (`memruntime::memlog::defer_condemned`), put back once the statement's memory is freed (a retried recovery too).
    pub(crate) log_defer_before: Option<Option<elog::ServerLogDefer>>,
}

pub(crate) fn error_recovery(
    err: &PgError,
    state: &mut LoopState,
    first_attempt: bool,
) -> PgResult<()> {
    use init_small::globals as g;

    /* error_context_stack = NULL (postgres.c:4408): the Err-carried chain is
     * gone; emit-time callbacks a panic unwound past are dropped here. */
    elog::clear_emit_context_callbacks();

    // An Err escaping a still-open critical section is a hand-built PgError
    // that bypassed errstart's ERROR->PANIC promotion; recovering here would
    // e.g. abort a transaction whose commit record is already in WAL (issue
    // #58). Give it C's PANIC treatment before the counter reset below.
    elog::panic_on_crit_section_escape(err);

    // C's elog.c ERROR path resets the holdoff counters before longjmp; here
    // the catching frame does it (an unbalanced HOLD_INTERRUPTS on the unwind
    // path would otherwise leak forever).
    g::SetInterruptHoldoffCount(0);
    g::SetQueryCancelHoldoffCount(0);
    g::SetCritSectionCount(0);

    // D4812: a statement the memory watchdog canceled frees its memory in the steps below, after the report; its report
    // and every line until the free go to the memory log's queue, so the free never waits on the server log's sink
    if mcx::governor::take_ended_condemned() && state.log_defer_before.is_none() {
        state.log_defer_before = Some(memruntime::memlog::defer_condemned());
    }

    // GL-ERRFIX-1 (E-4 + E-5) — EMIT THE REPORT ONCE, BEFORE ANY FALLIBLE STEP.
    // Two defects, one placement fixes both:
    //   E-4: the report used to sit AFTER `disable_all_timeouts` (the first
    //        fallible `?`). If that step failed, the original error reached
    //        neither the client nor the log — the connection then died after 16
    //        silent retries with a generic "failed to settle" FATAL and nothing
    //        anywhere said why. Emitting ahead of every `?` means no recovery
    //        step can swallow the original error.
    //   E-5: the keeper retries recovery up to MAX_RECOVERY_ATTEMPTS times, and
    //        on each retry the pending error is the recovery-step failure, so
    //        the client collected up to 16 reports for one original error.
    //        `first_attempt` is false on every retry, so the report is emitted
    //        at most once per original error.
    if first_attempt {
        // D378: a terminate raised while the report goes to a client that does not read (secure_write's
        // ProcessClientWriteInterrupt) ends the backend, as C's ereport(FATAL) from inside the send does.
        if let Err(e) = elog::try_emit_error_report_for(err) {
            if e.level() >= FATAL {
                return Err(e);
            }
        }
    }
    // C: `debug_query_string = NULL;` (postgres.c:4433), after the report.
    elog::clear_retired_debug_query_string();

    timeout_seams::disable_all_timeouts::call(false)?; /* do first to avoid race */
    g::ClearQueryCancelPending(); // D334: with its abort-class byte
    state.idle_in_transaction_timeout_enabled = false;
    state.idle_session_timeout_enabled = false;

    set_doing_command_read(false);

    pqcomm::pq_comm_reset();

    // (the report emission moved to the top of this function — GL-ERRFIX-1 E-4/E-5.)


    xact::AbortCurrentTransaction()?;

    if walsender_seams::am_walsender() {
        walsender_seams::wal_snd_error_cleanup::call()?;
    }

    portalmem::PortalErrorCleanup()?;
    if let Some(before) = state.log_defer_before.take() {
        elog::set_server_log_defer(before);
    }

    // Slots can't be released inside AbortTransaction (C keeps them across
    // sub-xacts); top-level error recovery is the C release point
    // (postgres.c:4457).
    if slot::MyReplicationSlot().is_some() {
        slot::ReplicationSlotRelease()?;
    }
    slot::ReplicationSlotCleanup(false)?;


    elog::FlushErrorState();

    if crate::doing_extended_query_message() {
        set_ignore_till_sync(true);
    }

    set_xact_started(false);

    // D1 transaction-grain admission, release point (3): if the abort above
    // ended the transaction (single-statement or implicit-block error), the
    // slot returns here; an explicit block survives in TBLOCK_ABORT and
    // keeps its slot until the client's ROLLBACK.
    crate::admission::release_if_txn_over();

    if pqcomm::pq_is_reading_msg() {
        return Err(ereport(FATAL)
            .errcode(ERRCODE_PROTOCOL_VIOLATION)
            .errmsg("terminating connection because protocol synchronization was lost")
            .into_error()
            .with_funcname("PostgresMain")
            .into());
    }

    Ok(())
}

// An earlier-or-equal TRANSACTION_TIMEOUT subsumes the idle-in-transaction timer.
fn start_idle_in_transaction_timer(state: &mut LoopState) -> PgResult<()> {
    let idle_in_transaction_timeout = lmgr_proc::globals::IdleInTransactionSessionTimeout();
    let transaction_timeout = lmgr_proc::globals::TransactionTimeout();
    if idle_in_transaction_timeout > 0
        && (idle_in_transaction_timeout < transaction_timeout || transaction_timeout == 0)
    {
        state.idle_in_transaction_timeout_enabled = true;
        timeout_seams::enable_timeout_after::call(
            timeout_seams::IDLE_IN_TRANSACTION_SESSION_TIMEOUT,
            idle_in_transaction_timeout,
        )?;
    }
    Ok(())
}

fn arm_idle_timer(state: &mut LoopState, in_xact: bool) -> PgResult<()> {
    let idle_ms = crate::passivate::arm_idle_timer_ms(in_xact);
    if idle_ms > 0 {
        init_small::globals::SetIdlePassivateTimeoutPending(false);
        state.idle_passivate_timeout_enabled = true;
        timeout_seams::enable_timeout_after::call(timeout_seams::IDLE_PASSIVATE_TIMEOUT, idle_ms)?;
    }
    Ok(())
}

fn ready_state(mcx: Mcx<'_>, state: &mut LoopState) -> PgResult<()> {
    use backend_status_seams::BackendState;
    crate::stmt_trace::probe("ready.begin");

    if xact::IsAbortedTransactionBlockState() {
        ps_status_seams::set_ps_display::call("idle in transaction (aborted)");
        backend_status_seams::pgstat_report_activity::call(
            BackendState::STATE_IDLEINTRANSACTION_ABORTED,
            None,
        );
        start_idle_in_transaction_timer(state)?;
        arm_idle_timer(state, true)?;
    } else if xact::IsTransactionOrTransactionBlock() {
        ps_status_seams::set_ps_display::call("idle in transaction");
        backend_status_seams::pgstat_report_activity::call(
            BackendState::STATE_IDLEINTRANSACTION,
            None,
        );
        start_idle_in_transaction_timer(state)?;
        // the idle memory release stage alone (never passivation): an idle cursor's session gives memory back too
        arm_idle_timer(state, true)?;
    } else {
        if commands_async::notifyInterruptPending() {
            commands_async::ProcessNotifyInterrupt(false)?;
        }

        let stats_timeout = pgstat::pending::pgstat_report_stat(false);
        if stats_timeout > 0 {
            if !timeout_seams::get_timeout_active::call(timeout_seams::IDLE_STATS_UPDATE_TIMEOUT) {
                timeout_seams::enable_timeout_after::call(
                    timeout_seams::IDLE_STATS_UPDATE_TIMEOUT,
                    stats_timeout as i32,
                )?;
            }
        } else if timeout_seams::get_timeout_active::call(timeout_seams::IDLE_STATS_UPDATE_TIMEOUT)
        {
            timeout_seams::disable_timeout::call(timeout_seams::IDLE_STATS_UPDATE_TIMEOUT, false)?;
        }

        ps_status_seams::set_ps_display::call("idle");
        backend_status_seams::pgstat_report_activity::call(BackendState::STATE_IDLE, None);

        let idle_session_timeout = lmgr_proc::globals::IdleSessionTimeout();
        if idle_session_timeout > 0 {
            state.idle_session_timeout_enabled = true;
            timeout_seams::enable_timeout_after::call(
                timeout_seams::IDLE_SESSION_TIMEOUT,
                idle_session_timeout,
            )?;
        }

        // D3.4 idle passivation: one-shot timer per idle period. Fires once →
        // the ProcessInterrupts arm passivates → the backend keeps waiting; no
        // re-arm until the next command completes and we come back here.
        // The same timer first runs the idle memory release
        // (pgrust.memory_release_idle) when that comes earlier.
        arm_idle_timer(state, false)?;
    }

    guc::report::report_changed_guc_options();

    log_connection_ready_durations()?;

    crate::stmt_trace::probe("ready.pre_rfq");
    // D2395: a reserve spent by a rescued allocation is taken again once the backend is idle (a cheap load when armed)
    init_small::oom::arm_reserve();
    // G1-A: the statement's committed bytes end with it (its trace record under PGRUST_MEMPOLICY=trace=1)
    memledger::statement_end();
    // memledger `unattr`: the statement's in-server unattributed check (PGRUST_MEMLEDGER_UNATTR=1): one LOG line when over
    if let Some(r) = memledger::unattr::end_report() {
        log_unattributed(&r);
    }
    tcop_dest::ReadyForQuery(mcx, elog::config::where_to_send_output())?;
    // purge timing: what this thread purges from here to its next command is off the client's latency
    mcx::purge_phase(2);
    crate::stmt_trace::probe("rfq.flushed");
    crate::stmt_trace::flush();
    state.send_ready_for_query = false;
    // D3652 P8: the cache cap trims, off the statement's latency (after its ReadyForQuery) and before the memory release.
    crate::passivate::trim_caches_at_idle()?;
    crate::passivate::release_after_statement()?;
    fd::ShedIdleFiles()?;

    Ok(())
}

// postgres.c: first ReadyForQuery of an external-connection backend logs the
// connection-establishment durations under log_connections=setup_durations.
fn log_connection_ready_durations() -> PgResult<()> {
    use types_core::init::BackendType;

    let timing = backend_startup::conn_timing::get();
    // TIMESTAMP_MINUS_INFINITY (types_startup) is i64::MIN.
    if timing.ready_for_use != i64::MIN
        || backend_startup::log_connections::get()
            & backend_startup::LOG_CONNECTION_SETUP_DURATIONS
            == 0
        || !matches!(
            miscinit::GetMyBackendType(),
            BackendType::Backend | BackendType::WalSender
        )
    {
        return Ok(());
    }

    let now = crate::get_current_timestamp();
    backend_startup::conn_timing::set_ready_for_use(now);

    let diff_us = |start: i64, stop: i64| -> u64 {
        if start >= stop { 0 } else { (stop - start) as u64 }
    };
    let total = diff_us(timing.socket_create, now);
    let fork = diff_us(timing.fork_start, timing.fork_end);
    let auth = diff_us(timing.auth_start, timing.auth_end);

    ereport(LOG)
        .errmsg(format!(
            "connection ready: setup total={:.3} ms, fork={:.3} ms, authentication={:.3} ms",
            total as f64 / 1000.0,
            fork as f64 / 1000.0,
            auth as f64 / 1000.0,
        ))
        .finish(types_error::ErrorLocation::new(
            "src/backend/tcop/postgres.c",
            4677,
            "PostgresMain",
        ))
}

// postgres.c:4760 walsender 'Q' arm; #[cold] keeps the serial query path's
// icache untouched (layout-hygiene convention).
#[cold]
#[inline(never)]
fn walsender_query<'mcx>(mcx: Mcx<'mcx>, query_string: &'mcx str) -> PgResult<()> {
    if !walsender_seams::exec_replication_command::call(query_string)? {
        simple_query::exec_simple_query(mcx, query_string)?;
    }
    Ok(())
}

// forbidden_in_wal_sender (postgres.c:5030): a replication connection speaks
// only the simple-query protocol.
fn forbidden_in_wal_sender(firstchar: i32) -> PgResult<()> {
    if walsender_seams::am_walsender() {
        forbidden_in_wal_sender_error(firstchar)?;
    }
    Ok(())
}

#[cold]
#[inline(never)]
pub(crate) fn forbidden_in_wal_sender_error(firstchar: i32) -> PgResult<()> {
    let (msg, line) = if firstchar == pqmsg::FUNCTION_CALL {
        ("fastpath function calls not supported in a replication connection", 5043)
    } else {
        ("extended query protocol not supported in a replication connection", 5047)
    };
    ereport(ERROR)
        .errcode(ERRCODE_PROTOCOL_VIOLATION)
        .errmsg(msg)
        .finish(loc(line, "forbidden_in_wal_sender"))
}

/// A message that starts a statement (or continues one: Parse, Bind and Execute until their Sync): its start time, and
/// G1-A's statement on this backend's memory account.
fn statement_start() {
    xact::SetCurrentStatementStartTimestamp();
    memledger::statement_begin();
}

fn dispatch_message<'mcx>(
    mcx: Mcx<'mcx>,
    firstchar: i32,
    input_message: &mut StringInfo<'mcx>,
    state: &mut LoopState,
) -> PgResult<()> {
    match firstchar {
        x if x == pqmsg::QUERY => {
            statement_start();

            let query_string: &'mcx str = {
                let s = pqformat::pq_getmsgstring(mcx, input_message)?;
                let verified =
                    matches!(s, pqformat::PqString::Borrowed(_)) && mbutils::client_to_server_verifies_utf8();
                leak_str_in(mcx, s.as_bytes(), verified)?
            };
            pqformat::pq_getmsgend(input_message)?;

            if walsender_seams::am_walsender() {
                walsender_query(mcx, query_string)?;
            } else {
                simple_query::exec_simple_query(mcx, query_string)?;
            }

            state.send_ready_for_query = true;
        }

        x if x == pqmsg::PARSE => {
            forbidden_in_wal_sender(firstchar)?;

            statement_start();

            let stmt_name = extended_query::owned_msg_string(mcx, input_message)?;
            let query_string = extended_query::owned_msg_string(mcx, input_message)?;
            let num_params = pqformat::pq_getmsgint(input_message, 2)? as usize;
            let mut param_types: PgVec<'_, types_core::Oid> = PgVec::new_in(mcx);
            param_types
                .try_reserve_exact(num_params)
                .map_err(|_| mcx.oom(num_params))?;
            for _ in 0..num_params {
                param_types.push(pqformat::pq_getmsgint(input_message, 4)?);
            }
            pqformat::pq_getmsgend(input_message)?;

            extended_query::exec_parse_message(
                mcx,
                query_string.as_str(),
                stmt_name.as_str(),
                &param_types,
            )?;
        }

        x if x == pqmsg::BIND => {
            forbidden_in_wal_sender(firstchar)?;

            statement_start();

            /* this message is complex enough that the field extraction is
             * out-of-line, as in C */
            extended_query::exec_bind_message(mcx, input_message)?;
        }

        x if x == pqmsg::EXECUTE => {
            forbidden_in_wal_sender(firstchar)?;

            statement_start();

            let portal_name = extended_query::owned_msg_string(mcx, input_message)?;
            let max_rows = pqformat::pq_getmsgint(input_message, 4)? as i32;
            pqformat::pq_getmsgend(input_message)?;

            extended_query::exec_execute_message(mcx, portal_name.as_str(), max_rows as i64)?;
        }

        x if x == pqmsg::DESCRIBE => {
            forbidden_in_wal_sender(firstchar)?;

            statement_start();

            let describe_type = pqformat::pq_getmsgbyte(input_message)?;
            let describe_target = extended_query::owned_msg_string(mcx, input_message)?;
            pqformat::pq_getmsgend(input_message)?;

            match describe_type as u8 {
                b'S' => {
                    extended_query::exec_describe_statement_message(
                        mcx,
                        describe_target.as_str(),
                    )?;
                }
                b'P' => {
                    extended_query::exec_describe_portal_message(
                        mcx,
                        describe_target.as_str(),
                    )?;
                }
                other => {
                    return Err(ereport(ERROR)
                        .errcode(ERRCODE_PROTOCOL_VIOLATION)
                        .errmsg(format!("invalid DESCRIBE message subtype {other}"))
                        .into_error()
                        .with_funcname("PostgresMain")
                        .into());
                }
            }
        }

        x if x == pqmsg::FUNCTION_CALL => {
            use backend_status_seams::BackendState;

            forbidden_in_wal_sender(firstchar)?;

            statement_start();

            backend_status_seams::pgstat_report_activity::call(BackendState::STATE_FASTPATH, None);
            ps_status_seams::set_ps_display::call("<FASTPATH>");

            let _admission = crate::admission::acquire_for_statement(|| false)?;
            simple_query::start_xact_command()?;

            let call = fastpath::HandleFunctionRequest(mcx, input_message)?;

            match simple_query::check_log_duration(call.was_logged) {
                (1, msec_str) => {
                    ereport(LOG)
                        .errmsg(format!("duration: {msec_str} ms"))
                        .errhidestmt(true)
                        .finish(ErrorLocation::new("fastpath.c", 312, "HandleFunctionRequest"))?;
                }
                (2, msec_str) => {
                    // fastpath.c:316
                    ereport(LOG)
                        .errmsg(format!(
                            "duration: {msec_str} ms  fastpath function call: \"{}\" (OID {})",
                            call.fname, call.fid
                        ))
                        .errhidestmt(true)
                        .finish(ErrorLocation::new("fastpath.c", 316, "HandleFunctionRequest"))?;
                }
                _ => {}
            }

            simple_query::finish_xact_command()?;

            state.send_ready_for_query = true;
        }

        x if x == pqmsg::CLOSE => {
            forbidden_in_wal_sender(firstchar)?;

            let close_type = pqformat::pq_getmsgbyte(input_message)?;
            // postgres.c:4886 pq_getmsgstring: client-to-server conversion
            // (22021 on an invalid byte sequence), as for Parse/Describe.
            let close_target = extended_query::owned_msg_string(mcx, input_message)?;
            pqformat::pq_getmsgend(input_message)?;

            match close_type as u8 {
                b'S' => {
                    if !close_target.is_empty() {
                        prepare_seams::drop_prepared_statement::call(close_target.as_str(), false)?;
                    } else {
                        extended_query::drop_unnamed_stmt();
                    }
                }
                b'P' => {
                    if let Some(portal) = portalmem::GetPortalByName(Some(close_target.as_str())) {
                        portalmem::PortalDrop(&portal, false)?;
                    }
                }
                other => {
                    return Err(ereport(ERROR)
                        .errcode(ERRCODE_PROTOCOL_VIOLATION)
                        .errmsg(format!("invalid CLOSE message subtype {other}"))
                        .into_error()
                        .with_funcname("PostgresMain")
                        .into());
                }
            }

            if elog::config::where_to_send_output() == CommandDest::Remote {
                pqformat::pq_putemptymessage(pqmsg::CLOSE_COMPLETE)?;
            }
        }

        x if x == pqmsg::FLUSH => {
            pqformat::pq_getmsgend(input_message)?;
            if elog::config::where_to_send_output() == CommandDest::Remote {
                pqcomm::pq_flush()?;
            }
        }

        x if x == pqmsg::SYNC => {
            pqformat::pq_getmsgend(input_message)?;
            xact::EndImplicitTransactionBlock();
            simple_query::finish_xact_command()?;
            // D1 transaction-grain admission, release point (2): Sync ends a
            // pipeline's (implicit) transaction outside any statement guard.
            crate::admission::release_if_txn_over();
            crate::stmt_trace::probe("s.commit");
            state.send_ready_for_query = true;
        }

        x if x == EOF || x == pqmsg::TERMINATE => {
            if x == EOF {
                pgstat::database::pgstat_set_session_end_cause(
                    pgstat::database::SessionEndType::DisconnectClientEof,
                );
            }
            if elog::config::where_to_send_output() == CommandDest::Remote {
                elog::config::set_where_to_send_output(CommandDest::None);
            }
            ipc_seams::proc_exit::call(0, init_small::globals::MyProcPid());
        }

        x if x == pqmsg::COPY_DATA || x == pqmsg::COPY_DONE || x == pqmsg::COPY_FAIL => {
        }

        other => {
            return Err(ereport(FATAL)
                .errcode(ERRCODE_PROTOCOL_VIOLATION)
                .errmsg(format!("invalid frontend message type {other}"))
                .into_error()
                .with_funcname("PostgresMain")
                .into());
        }
    }

    Ok(())
}

// `utf8_verified`: pg_client_to_server already verified these bytes as UTF-8 and handed them back unconverted
// (mbutils::client_to_server_verifies_utf8), so the copy skips its own check (D4481).
fn leak_str_in<'mcx>(mcx: Mcx<'mcx>, bytes: &[u8], utf8_verified: bool) -> PgResult<&'mcx str> {
    let mut v: PgVec<'mcx, u8> = PgVec::new_in(mcx);
    mcx::vec_append_bytes(&mut v, bytes)?;
    let slice: &'mcx mut [u8] = v.leak();
    if utf8_verified {
        debug_assert!(core::str::from_utf8(slice).is_ok());
        // SAFETY: the bytes are a copy of a string pg_verify_mbstr(PG_UTF8, ..) accepted (see
        // mbutils::client_to_server_verifies_utf8); that UTF-8 is a subset of what core::str accepts.
        return Ok(unsafe { core::str::from_utf8_unchecked(slice) });
    }
    // Invalid bytes for the database encoding were already rejected by
    // pq_getmsgstring's pg_client_to_server (pg_verify_mbstr, C-shaped
    // 22021); reaching here non-UTF8 means the database encoding itself
    // is one the UTF-8 engine cannot honor.
    core::str::from_utf8(slice).map_err(|_| crate::non_utf8_query_error())
}

// on_proc_exit handler to log end of session (postgres.c log_disconnections).
// Runs on every backend exit once registered: clean Terminate/EOF, FATAL
// teardown, and admin termination all pass through proc_exit's callback walk.
fn log_disconnections(_code: i32, _arg: usize) {
    let now = crate::get_current_timestamp();
    let start = init_small::globals::MyStartTimestamp();
    let diff_us = (now - start).max(0);
    let mut secs = diff_us / 1_000_000;
    let usecs = diff_us % 1_000_000;
    let msecs = usecs / 1000;

    let hours = secs / 3600;
    secs %= 3600;
    let minutes = secs / 60;
    let seconds = secs % 60;

    let msg = init_small::globals::WithMyProcPort(|port| {
        format!(
            "disconnection: session time: {hours}:{minutes:02}:{seconds:02}.{msecs:03} \
             user={} database={} host={}{}{}",
            port.user_name.as_deref().unwrap_or(""),
            port.database_name.as_deref().unwrap_or(""),
            port.remote_host,
            if port.remote_port.is_empty() { "" } else { " port=" },
            port.remote_port,
        )
    });
    let _ = ereport(LOG).errmsg(msg).finish(loc(5168, "log_disconnections"));
}

/// One LOG line for a statement whose backend account's unattributed bytes (its bytes less what its owners
/// hold) passed their bound, max(16 MiB, 2 % of the account), at its end or at a rise (memledger `unattr`). The fire
/// `ledger.unattributed_over` rides on the next gravity report line (the statement's own was written before its end).
#[cold]
#[inline(never)]
fn log_unattributed(r: &memledger::unattr::Report) {
    fires::fire_shared("ledger.unattributed_over");
    let end = r.end.map_or_else(|| "skipped".to_string(), |(u, b)| format!("{u} end_bound={b}")); // alloc: Cold
    let peak = r.peak.map_or_else(|| "-".to_string(), |(u, b, l)| format!("{u} peak_bound={b} peak_level={l}")); // alloc: Cold
    let pid = memledger::account_row(memledger::current()).pid;
    let msg = format!("pgrust memory: unattributed over its bound: pid={pid} end={end} peak={peak} checks={} skipped={}", r.checks, r.skips); // alloc: Cold
    let _ = ereport(LOG).errmsg(msg).finish(loc(0, "log_unattributed"));
}

pub fn PostgresMain(dbname: &str, username: &str) -> ! {
    let outcome = postgres_main_inner(dbname, username);
    if let Err(err) = outcome {
        // An Err escaping here was raised with no handler installed — before
        // PostgresMain's sigsetjmp (InitPostgres and the rest of startup; the
        // command loop swallows its own ERRORs and only lets FATAL+ out).
        // elog.c:375-381: with PG_exception_stack == NULL an ERROR is
        // promoted to FATAL before it is reported.
        report_escaped_error(&err);
    }
    ipc_seams::proc_exit::call(1, init_small::globals::MyProcPid())
}

// errfinish's FATAL arm (elog.c:579): an ERROR reported here was promoted to
// FATAL, so both count as DISCONNECT_FATAL.
pub(crate) fn report_escaped_error(err: &types_error::PgError) {
    elog::emit_unhandled_error_report(err);
    if err.level() < types_error::PANIC {
        pgstat::database::pgstat_set_session_end_cause_fatal();
    }
}

fn postgres_main_inner(dbname: &str, username: &str) -> PgResult<()> {
    elog::clear_retired_debug_query_string();
    assert!(!dbname.is_empty() || !username.is_empty());
    crate::reset_session_statics();

    crate::install_thread_signal_handlers();
    // memledger `unattr`: the in-server unattributed check is process-wide and off unless PGRUST_MEMLEDGER_UNATTR=1 (each
    // backend's start turns it on, never off)
    if std::env::var_os("PGRUST_MEMLEDGER_UNATTR").is_some_and(|v| v == "1") {
        memledger::unattr::set(true);
    }
    // wasm32: the embedder's cancel (a browser page's Stop, psql's Ctrl-C) stands in for SIGINT (ProcessInterrupts)
    #[cfg(target_family = "wasm")]
    init_small::globals::SetHostCancel();
    mcx::governor::set_exempt_probe(|| init_small::globals::CritSectionCount() > 0);
    mcx::governor::set_sleep_probe(block_gate_may_sleep);
    mcx::governor::set_interrupt_probe(block_gate_interrupted);

    timeout_seams::initialize_timeouts::call(); /* establishes SIGALRM handler */

    if elog::config::where_to_send_output() == CommandDest::Remote {
        let len = init_small::globals::WithMyProcPort(|port| {
            const PG_PROTOCOL_3_2: u32 = (3 << 16) | 2;
            if port.proto >= PG_PROTOCOL_3_2 {
                types_core::primitive::MAX_CANCEL_KEY_LENGTH
            } else {
                4
            }
        });
        let mut key = [0u8; types_core::primitive::MAX_CANCEL_KEY_LENGTH];
        pg_strong_random(&mut key[..len])?;
        init_small::globals::SetMyCancelKey(key);
        init_small::globals::SetMyCancelKeyLength(len as i32);
    }

    postinit::BaseInit()?;

    // Honor session_preload_libraries if not dealing with a WAL sender.
    let am_walsender = walsender_seams::am_walsender();
    let top = MemoryContext::new("PostgresMainInit");
    postinit::InitPostgres(
        top.mcx(),
        Some(dbname),
        types_core::primitive::InvalidOid,
        Some(username),
        types_core::primitive::InvalidOid,
        if am_walsender {
            0
        } else {
            postinit::INIT_PG_LOAD_SESSION_LIBS
        },
        None,
    )?;
    mcx::governor::register(
        init_small::globals::MyProcNumber(),
        init_small::globals::MyProcPid(),
    );
    // C5: the spill-request registry reaches this backend's Gravity interrupt byte (REVOKE_BIT) by its slot
    mcx::revoke::register_byte(init_small::globals::abort_pending_flag());
    drop(top);


    miscinit::SetProcessingMode(types_core::ProcessingMode::NormalProcessing);

    guc::report::begin_reporting_guc_options();

    // C postgres.c:4313: set up the session-end logger only now — we have to
    // wait till here to be sure Log_disconnections has its final value
    // (PGC_SU_BACKEND: startup-packet options are applied by InitPostgres).
    if init_small::globals::IsUnderPostmaster() && guc_tables::vars::Log_disconnections.read() {
        ipc::on_proc_exit(log_disconnections, 0);
    }

    pgstat::database::pgstat_report_connect(init_small::globals::MyDatabaseId());

    if am_walsender {
        walsender_seams::init_wal_sender::call();
    }

    if elog::config::where_to_send_output() == CommandDest::Remote {
        let key = init_small::globals::MyCancelKey();
        let len = init_small::globals::MyCancelKeyLength() as usize;
        debug_assert!(len > 0);
        let scratch = MemoryContext::new("CancelKeyMsg");
        let mut buf = pqformat::pq_beginmessage(scratch.mcx(), pqmsg::BACKEND_KEY_DATA)?;
        pqformat::pq_sendint32(&mut buf, init_small::globals::MyProcPid() as u32)?;
        pqformat::pq_sendbytes(&mut buf, &key[..len])?;
        pqformat::pq_endmessage(buf)?;
    }

    /* Welcome banner for standalone case (postgres.c:4341) */
    if elog::config::where_to_send_output() == CommandDest::Debug {
        use std::io::Write;
        let _ = writeln!(std::io::stdout(), "\nPostgreSQL stand-alone backend 18.6");
    }

    let mut message_context =
        MemoryContext::new_wholesale_sized("MessageContext", MESSAGE_CONTEXT_INIT_SIZE);
    message_context.set_owner_session();

    // C postgres.c:4369: fire login event triggers before the main loop; a
    // trigger error here aborts the connection, as C's pre-setjmp ERROR does.
    {
        let scratch = MemoryContext::new("EventTriggerOnLogin");
        event_trigger_seams::event_trigger_on_login::call(scratch.mcx())?;
    }

    // D3652 P8: this session trims its catcache / relcache to the caps at the idle point (ready_state). A WAL sender keeps
    // the insert / commit trims: START_REPLICATION streams (and decodes) for its whole life without coming back to it.
    if !walsender_seams::am_walsender() {
        catcache::SetCatCacheTrimAtIdle(true);
        relcache::SetRelationCacheTrimAtIdle(true);
    }

    let mut state = LoopState {
        send_ready_for_query: true,
        idle_in_transaction_timeout_enabled: false,
        idle_session_timeout_enabled: false,
        idle_passivate_timeout_enabled: false,
        log_defer_before: None,
    };

    loop {
        /*
         * Release storage left over from prior query cycle. C resets the
         * long-lived MessageContext; this is that reset. Stmt-list registry
         * handles are NOT reset here: extended-protocol portals carry them
         * across messages, and PortalDrop frees them.
         */
        message_context.reset();
        let mcx = message_context.mcx();

        let iteration = run_one_iteration(mcx, &mut state);

        match iteration {
            Ok(()) => {}
            Err(err) => {
                if err.level() >= FATAL {
                    return Err(err);
                }
                let mut pending = err;
                const MAX_RECOVERY_ATTEMPTS: u32 = 16;
                let mut settled = false;
                let mut first_attempt = true;
                for _ in 0..MAX_RECOVERY_ATTEMPTS {
                    let attempt_is_first = first_attempt;
                    first_attempt = false;
                    // unwind-ok: stmt-boundary
                    match std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                        error_recovery(&pending, &mut state, attempt_is_first)
                    })) {
                        Ok(Ok(())) => {
                            settled = true;
                            break;
                        }
                        Ok(Err(next)) => {
                            if next.level() >= FATAL {
                                return Err(next);
                            }
                            pending = next;
                        }
                        Err(payload) => {
                            pending = Box::new(pg_error_from_panic(payload));
                        }
                    }
                }
                if !settled {
                    return Err(ereport(FATAL)
                        .errmsg_internal(
                            "error recovery failed to settle the transaction; terminating backend",
                        )
                        .into_error()
                        .into());
                }
                if !ignore_till_sync() {
                    state.send_ready_for_query = true; /* initially, or after error */
                }
            }
        }
    }
}

// One iteration of the C for(;;) body (postgres.c:4516-5021), Err = the
// sigsetjmp path. A structured error unwound as a panic (a PgError payload)
// recovers as C does from ereport(ERROR); a plain Rust panic is C's abort()
// and takes the crash path (D2933, pg_error_from_panic).
pub(crate) fn run_one_iteration(mcx: Mcx<'_>, state: &mut LoopState) -> PgResult<()> {
    // unwind-ok: stmt-boundary
    let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        run_one_iteration_inner(mcx, state)
    }));
    mcx::governor::arm(false);
    mcx::governor::statement_end();
    match outcome {
        Ok(r) => r,
        Err(payload) => Err(Box::new(pg_error_from_panic(payload))),
    }
}

pub(crate) fn pg_error_from_panic(payload: Box<dyn std::any::Any + Send>) -> PgError {
    // proc_exit unwinds ProcExitThread; converting it to an ERROR turns
    // backend exit into an infinite recovery loop (client EOF -> proc_exit(0)
    // -> "recovered" -> ReadCommand panic, ~850/s). Re-raise it.
    // KilledBySignal (SIGKILL crash-test injection) must reach the thread top
    // as a crash, exactly like ProcExitThread/PanicExitThread — demoting it to
    // ERROR would make a SIGKILL'd backend recover as FATAL(1) and skip the
    // postmaster crash cascade.
    if payload.is::<ipc::ProcExitThread>()
        || payload.is::<types_error::PanicExitThread>()
        || payload.is::<ipc::KilledBySignal>()
    {
        std::panic::resume_unwind(payload);
    }
    // D2933 (user 2026-09-29: "when crashing, the whole system should abort
    // like postgres does"): a plain panic (an unwrap, an index, an assert, an
    // unported seam) is C's abort(), not ERROR XX000: the backend thread dies
    // as crashed and the postmaster runs the crash restart. The panic hook
    // already logged its message, location and query.
    match ::types_error::pg_error_from_panic(payload) {
        Ok(e) => e,
        Err(payload) => elog::abort_on_plain_panic(payload),
    }
}

fn run_one_iteration_inner<'mcx>(mcx: Mcx<'mcx>, state: &mut LoopState) -> PgResult<()> {
    elog::clear_retired_debug_query_string();
    set_doing_extended_query_message(false);

    let mut input_message = StringInfo::new_in(mcx)?;

    snapmgr::InvalidateCatalogSnapshotConditionally();

    if state.send_ready_for_query {
        ready_state(mcx, state)?;
    }

    set_doing_command_read(true);

    let firstchar = ReadCommand(&mut input_message)?;
    mcx::purge_phase(1);
    crate::stmt_trace::probe_read(firstchar);

    if state.idle_in_transaction_timeout_enabled {
        timeout_seams::disable_timeout::call(
            timeout_seams::IDLE_IN_TRANSACTION_SESSION_TIMEOUT,
            false,
        )?;
        state.idle_in_transaction_timeout_enabled = false;
    }
    if state.idle_session_timeout_enabled {
        timeout_seams::disable_timeout::call(timeout_seams::IDLE_SESSION_TIMEOUT, false)?;
        state.idle_session_timeout_enabled = false;
    }
    if state.idle_passivate_timeout_enabled {
        timeout_seams::disable_timeout::call(timeout_seams::IDLE_PASSIVATE_TIMEOUT, false)?;
        state.idle_passivate_timeout_enabled = false;
        // A fire that raced the arriving command must not passivate right
        // before we execute it.
        init_small::globals::SetIdlePassivateTimeoutPending(false);
        // Wave-4 stack discipline, reactivation half (macOS accounting):
        // re-mark any stack range the passivation released so pages the
        // arriving command re-dirties are charged again. TLS-check no-op
        // when no passivation released anything.
        crate::stack_mem::reuse_idle_stack();
    }

    check_for_interrupts()?;
    set_doing_command_read(false);

    if interrupt::ConfigReloadPending() {
        interrupt::SetConfigReloadPending(false);
        guc_file::ProcessConfigFile(types_guc_context_sighup())?;
    }

    if ignore_till_sync() && firstchar != EOF {
        return Ok(());
    }

    // memfree Part 2: the statement ledger (pgrust.statement_mem_limit, pgrust.memory_cancel_threshold), per message; C5:
    // pgrust.memory_revoke too (a revoke's registry entry is the ledger's)
    let limit_kb = guc_tables::backing::pgrust_statement_mem_limit().max(0) as usize;
    mcx::governor::statement_start(limit_kb << 10, guc_tables::backing::pgrust_memory_cancel_threshold() > 0 || mcx::revoke::enabled());
    mcx::governor::arm(true);
    let r = dispatch_message(mcx, firstchar, &mut input_message, state);
    mcx::governor::arm(false);
    mcx::governor::statement_end();
    crate::stmt_trace::probe("cycle.end");
    r
}

fn types_guc_context_sighup() -> types_guc::GucContext {
    types_guc::GucContext::PGC_SIGHUP
}

fn pg_strong_random(buf: &mut [u8]) -> PgResult<()> {
    if !pg_strong_random::pg_strong_random(buf) {
        return Err(ereport(ERROR)
            .errmsg("could not generate random cancel key")
            .into_error()
            .into());
    }
    Ok(())
}

/// D4812 (2): whether mcx's block gate may wait inside this thread's allocation: not in a critical section and with no
/// interrupts held off. Every LWLock holder has them held off (LWLockAcquire holds them, as in C), so the gate never
/// waits under an LWLock; buffer pins alone hold none (a bounded wait under a pin is allowed).
pub(crate) fn block_gate_may_sleep() -> bool {
    init_small::globals::CritSectionCount() == 0 && init_small::globals::InterruptHoldoffCount() == 0
}

/// D4812 (2): whether an interrupt is pending on this thread (a query cancel, a statement_timeout, a die: InterruptPending,
/// which every sender raises, or the pending flags themselves): mcx's block gate stops waiting and takes its block, so the
/// next CHECK_FOR_INTERRUPTS answers it at once.
pub(crate) fn block_gate_interrupted() -> bool {
    init_small::globals::InterruptPending() || init_small::globals::QueryCancelPending() || init_small::globals::ProcDiePending()
}
