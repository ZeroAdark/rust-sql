import sys,resource,time,json
from pathlib import Path
sys.path.insert(0,"/home/rustsql/pgrust/scripts/validation")
from cluster import Cluster
import psycopg
resource.setrlimit(resource.RLIMIT_STACK,(67108864,resource.getrlimit(resource.RLIMIT_STACK)[1]))
report={}
with Cluster("/home/rustsql/validity-local/bin","/home/rustsql/conformance",settings=["max_active_queries=1"]) as cluster:
 report["cluster"]=str(cluster.root)
 with psycopg.connect(cluster.dsn,autocommit=True) as admin:
  admin.execute("CREATE ROLE admission_user LOGIN")
  notes=[]
  admin.add_notice_handler(lambda d: notes.append(d.message_primary))
  def stats():
   admin.execute("pgrust: admission stats",prepare=False)
   return notes[-1]
  report["before"]=stats()
  with psycopg.connect(cluster.dsn,user="admission_user",autocommit=True,cursor_factory=psycopg.ClientCursor) as holder, psycopg.connect(cluster.dsn,user="admission_user",autocommit=True,options="-c statement_timeout=350") as client:
   report["preparation"]=client.execute("SELECT %s::int",(42,),prepare=True).fetchall()
   holder.execute("BEGIN")
   report["holding"]=stats()
   for name,params,prepare in [("cached_bind",(42,),True),("new_parse",(41,),False)]:
    start=time.monotonic()
    try: value={"rows":client.execute("SELECT %s::int",params,prepare=prepare).fetchall()}
    except psycopg.Error as error: value={"sqlstate":error.sqlstate,"message":str(error)}
    report[name]={**value,"seconds":time.monotonic()-start,"stats":stats()}
   with psycopg.connect(cluster.dsn,user="admission_user",autocommit=True,cursor_factory=psycopg.ClientCursor,options="-c statement_timeout=350") as simple:
    start=time.monotonic()
    try: value={"rows":simple.execute("SELECT 42").fetchall()}
    except psycopg.Error as error: value={"sqlstate":error.sqlstate,"message":str(error)}
    report["simple_query"]={**value,"seconds":time.monotonic()-start,"stats":stats()}
   holder.execute("COMMIT")
   report["after"]=stats()
print(json.dumps(report,indent=2))
Path("/home/rustsql/admission-investigation-20261030.json").write_text(json.dumps(report,indent=2)+"\n")
