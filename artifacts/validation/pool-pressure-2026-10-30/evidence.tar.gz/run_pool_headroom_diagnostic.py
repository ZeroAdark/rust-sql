from pathlib import Path
import subprocess,json,sys,shutil
base=Path('/home/rustsql');cycles=int(sys.argv[1]);repeats=int(sys.argv[2]);results=[]
for repeat in range(1,repeats+1):
 for variant in (['baseline','candidate'] if repeat%2 else ['candidate','baseline']):
  name=f'pool-headroom-{variant}-{repeat}';source=base/(name+'-source');source.mkdir(exist_ok=False)
  shutil.copyfile(base/'diagnose_pool_headroom.py',source/'diagnose_pool_headroom.py')
  for n in ['spill_probe.py','connection_churn_probe.py','connection_queue_probe.py','cluster.py','resource_scope.py']:shutil.copyfile(base/'pgrust/scripts/validation'/n,source/n)
  script=source/'diagnose_pool_headroom.py';s=script.read_text().replace("sys.path.insert(0,'/home/rustsql/pgrust/scripts/validation')","sys.path.insert(0,str(Path(__file__).parent))");script.write_text(s)
  binary=base/('idle-safe-final-candidate/bin' if variant=='baseline' else 'pool-headroom-candidate/bin')
  command=['systemd-run','--unit=rustsql-qualification-'+name,'--uid=rustsql','--gid=rustsql','--wait','--collect','--property=Delegate=cpu memory pids','--property=MemoryMax=6G','--property=MemorySwapMax=0','--property=CPUQuota=600%','--property=LimitSTACK=67108864','--property=RuntimeMaxSec=600','--property=StandardOutput=append:'+str(base/(name+'.log')),'--property=StandardError=append:'+str(base/(name+'.log')),'/usr/bin/python3','-u',str(script),name,'default',str(binary),str(cycles)]
  r=subprocess.run(command,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=630)
  (base/(name+'-command.json')).write_text(json.dumps({'command':command,'exit':r.returncode,'output':r.stdout},indent=2)+'\n')
  (base/(name+'-journal.log')).write_bytes(subprocess.check_output(['journalctl','-u','rustsql-qualification-'+name+'.service','--no-pager','-o','short-iso']))
  data=json.loads((base/(name+'.json')).read_text());record={'variant':variant,'repetition':repeat,'passed':data['passed'],'exit':r.returncode,'peak_mib':data['final']['memory_peak']/2**20,'events':data['final']['events'],'failed_queries':[q for q in data['queries'] if not q['passed']]};results.append(record);print(json.dumps(record),flush=True)
  (base/'pool-headroom-diagnostic-summary.json').write_text(json.dumps({'complete':False,'trials':results},indent=2)+'\n')
  if data['remaining_pids']:raise RuntimeError('server cgroup still populated')
(base/'pool-headroom-diagnostic-summary.json').write_text(json.dumps({'complete':True,'trials':results},indent=2)+'\n')
