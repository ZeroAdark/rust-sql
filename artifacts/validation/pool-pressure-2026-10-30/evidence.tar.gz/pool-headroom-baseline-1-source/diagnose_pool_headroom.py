from pathlib import Path
import sys,json,hashlib,time,threading,os
sys.path.insert(0,str(Path(__file__).parent))
import psycopg
from connection_churn_probe import CheckedCluster
from resource_scope import DelegatedScope,snapshot
from spill_probe import copy_digest,expected,temp_files
name=sys.argv[1];output=Path('/home/rustsql')/(name+'.json');assert not output.exists();report={'passed':False,'snapshots':[],'queries':[]};scope=DelegatedScope([0,2,4,6],[8,10]);group,launcher=scope.server(1024)
candidate=Path(sys.argv[3]).resolve(); cycles=int(sys.argv[4]); assert 2<=cycles<=40 and cycles%2==0
report['cycles']=cycles
cluster=CheckedCluster(candidate,'/home/rustsql/conformance',launcher=launcher,allocator='hearth',settings=['autovacuum=off','log_temp_files=0'])
report['cluster']=str(cluster.root)
mode=sys.argv[2] if len(sys.argv)>2 else 'default';report['mode']=mode
if mode=='fast':cluster.env['PGRUST_POOL_FAST_RELEASE']='1'
if mode=='ladder':cluster.settings+=['pgrust.memory_ladder=on','pgrust.memory_revoke=on']
if mode=='no-prefault':cluster.env['PGRUST_MEMPOLICY']='pool_warm_zero_max=16777216'
if mode not in ('default','fast','ladder','no-prefault'):raise ValueError(mode)
report['binary_sha256']=hashlib.sha256(Path(cluster.binaries,'postgres').read_bytes()).hexdigest()
done=threading.Event();samples=[]
def monitor():
 while not done.is_set():
  samples.append({'time':time.monotonic(),'resources':snapshot(group)})
  done.wait(.025)
t=threading.Thread(target=monitor);t.start()
try:
 with cluster,psycopg.connect(cluster.dsn,autocommit=True) as c:
  c.execute("CREATE FUNCTION pressure_owner_end(OUT kind text, OUT source text, OUT class text, OUT events bigint, OUT committed_bytes bigint, OUT reserved_bytes bigint, OUT uses bigint, OUT account text, OUT pid int, OUT seq bigint) RETURNS SETOF record LANGUAGE internal VOLATILE AS 'pgrust_memory_owner_end'")
  def capture(label):
   rows=c.execute('SELECT * FROM pressure_owner_end()').fetchall()
   report['snapshots'].append({'label':label,'time':time.monotonic(),'resources':snapshot(group),'owners':rows})
  capture('startup')
  c.execute('CREATE ACCESS METHOD pgrcolumnar TYPE TABLE HANDLER heap_tableam_handler')
  c.execute('CREATE TABLE spill_facts(id integer,grp integer,val integer,payload text) USING pgrcolumnar')
  c.execute("INSERT INTO spill_facts SELECT i,i%97,(i*17)%1000,repeat(lpad(i::text,8,'0'),16) FROM generate_series(1,1000000) i")
  capture('insert')
  c.execute('ANALYZE spill_facts');c.execute("SET statement_timeout='30s'")
  capture('analyze')
  query='SELECT id,grp,val,payload FROM spill_facts ORDER BY grp DESC,id DESC';oracle=expected(1000000)['sort']
  for i,(memory,parallel) in enumerate([('64kB',0),('16MB',2)]*(cycles//2)):
   c.execute("SELECT set_config('work_mem',%s,false)",(memory,));c.execute('SET max_parallel_workers_per_gather='+str(parallel))
   start=time.monotonic()
   try:
    actual=copy_digest(c,query);assert (actual['rows'],actual['sha256'])==oracle
    report['queries'].append({'memory':memory,'parallel':parallel,'passed':True,'start':start,'end':time.monotonic()})
   except psycopg.Error as error:
    report['queries'].append({'memory':memory,'parallel':parallel,'passed':False,'sqlstate':error.sqlstate,'error':str(error),'start':start,'end':time.monotonic()})
   capture('query-'+str(i));assert not temp_files(cluster)
  for delay in [1,4]:time.sleep(delay);capture('settle-'+str(delay))
  report['passed']=all(q['passed'] for q in report['queries'])
finally:
 done.set();t.join();report['samples']=samples;report['shutdown_exit_codes']=cluster.shutdown_exit_codes;report['final']=snapshot(group);report['remaining_pids']=(group/'cgroup.procs').read_text().split();output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':report['passed'],'output':str(output),'queries':report['queries']}),flush=True)
 if not report['remaining_pids']:group.rmdir()

assert report['shutdown_exit_codes']==[0] and not report['remaining_pids']
assert not any(report['final']['events'][k] for k in ['oom','oom_kill','oom_group_kill'])
assert report['final']['memory_swap_current']==0
raise SystemExit(0 if report['passed'] else 1)
