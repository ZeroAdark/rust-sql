//! The ordinary memory budget must reclaim free pages without the optional ladder or changing live allocations.
#![cfg(target_os = "linux")]

mod common;
use common::*;
use pagepool::*;

fn check(enabled: bool, budget: bool, ledger: bool) {
    hooks::grow_guard_switch(enabled);
    let h = Hint::new(Class::Task, Tag::OTHER);
    let live = take(9 * 64 * 1024, 64, h).unwrap();
    let p = live.cast::<u8>().as_ptr() as usize;
    touch(p, live.len());
    let free = span(8 * MIB, h).unwrap();
    let free_addr = free.as_ptr() as usize;
    touch(free_addr, free.len());
    unsafe { give_span(free) };
    assert_eq!(resident(free_addr, 8 * MIB), 8 * MIB);
    let cap = if budget { stats().claimed + 64 * MIB } else { 0 };
    if ledger { memledger::note_b(cap as u64) } else { set_cap(cap) };
    set_claim_room(usize::MAX);
    let before = guard_counts();
    let big = take(64 * MIB, SUPER, Hint::new(Class::Process, Tag::REGION)).unwrap();
    let after = guard_counts();
    if enabled && budget {
        assert!(after.bytes >= before.bytes + (8 * MIB) as u64, "budget must release free pages before growth");
        assert!(after.bytes - before.bytes <= (16 * MIB) as u64, "bounded inline reclaim");
        assert_eq!(resident(free_addr, 8 * MIB), 0);
    } else {
        assert_eq!(after.releases, before.releases, "off or unlimited must not reclaim inline");
        assert_eq!(resident(free_addr, 8 * MIB), 8 * MIB);
    }
    for at in (0..live.len()).step_by(hooks::page_size()) {
        assert_eq!(unsafe { core::ptr::read_volatile((p + at) as *const u8) }, 1, "live data changed");
    }
    set_cap(0);
    memledger::note_b(0);
    unsafe {
        give(big.cast(), big.len());
        give(live.cast(), live.len());
    }
    flush_shelf();
    purge_now(usize::MAX, None);
    balanced();
}

#[test]
fn budget_releases_before_growth_without_ladder() {
    setup();
    assert!(guard_counts().on, "budget guard must default on");
    check(true, false, false);
    check(false, true, false);
    check(true, true, false);
    check(true, true, true);
}
