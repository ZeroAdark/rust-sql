"""Wait for the confirmed builder, then run serial gates; never restart a failed build."""
from pathlib import Path
import json
import subprocess
import time

base = Path('/home/rustsql')
builder = Path('/proc/289/cmdline')
report = base / 'budget-guard-build-20261031/report.json'
assert builder.exists() and b'build_budget_guard_candidate.py' in builder.read_bytes()
deadline = time.monotonic() + 1800
while builder.exists() and b'build_budget_guard_candidate.py' in builder.read_bytes():
    assert time.monotonic() < deadline, 'builder still running; do not restart automatically'
    time.sleep(5)
data = json.loads(report.read_text())
assert data['passed'] and all(c['exit'] == 0 for c in data['commands'] if c['label'] != 'negative-control'), data
raise SystemExit(subprocess.run(['/usr/bin/python3', '-u', '/mnt/c/Users/DarkMoon/Desktop/Rust SQL/screen_budget_guard.py']).returncode)
