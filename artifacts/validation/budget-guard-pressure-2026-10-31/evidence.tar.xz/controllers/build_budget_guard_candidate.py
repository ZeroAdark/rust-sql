"""Build an isolated, unpromoted bounded budget-reclaim experiment."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import time

base = Path('/home/rustsql')
repo = base / 'pgrust'
root = base / 'budget-guard-build-20261031'
root.mkdir(exist_ok=False)
source_repo = Path('/mnt/c/Users/DarkMoon/Desktop/Rust SQL/pgrust')
files = ['crates/_support/pagepool/src/purger.rs', 'crates/_support/pagepool/src/superpage.rs',
         'crates/_support/pagepool/tests/budget_guard.rs']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip() == ''
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head == 'b3d1a667e200da873aa72fda7530cce5c2c9279f'
report = {'passed': False, 'promoted': False, 'base_commit': head, 'source_sha256': {}, 'commands': []}
for name in files:
    content = (source_repo / name).read_bytes().replace(b'\r\n', b'\n')
    (repo / name).write_bytes(content)
    target = root / 'sources' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    report['source_sha256'][name] = hashlib.sha256(content).hexdigest()
(root / 'candidate.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', *files[:-1]], cwd=repo))
cargo = str(base / '.cargo/bin/cargo')

def run(label, command, success=True):
    start = time.monotonic()
    with (root / (label + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    item = {'label': label, 'command': command, 'exit': result.returncode, 'seconds': time.monotonic() - start}
    report['commands'].append(item)
    (root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(item), flush=True)
    if success:
        result.check_returncode()
    return result

test = [cargo, 'test', '--locked', '--release', '-j', '2', '-p', 'pagepool', '--features', 'global']
run('focused', test + ['--test', 'budget_guard', '--test', 'grow_guard', '--test', 'global_cap'])
path = repo / files[0]
original = path.read_bytes()
needle = b'(cap != 0 && cap.saturating_sub(stats::claimed()) < bytes.max(1))'
assert original.count(needle) == 1
try:
    path.write_bytes(original.replace(needle, b'(cap != 0 && false)'))
    result = run('negative-control', test + ['--test', 'budget_guard'], False)
    assert result.returncode != 0 and 'budget must release free pages before growth' in (root / 'negative-control.log').read_text()
finally:
    path.write_bytes(original)
run('pagepool', test + ['--lib', '--tests'])
run('release-build', [cargo, 'build', '--locked', '--release', '-j', '2', '-p', 'main_main', '-p', 'initdb'])
candidate = base / 'budget-guard-candidate/bin'
candidate.mkdir(parents=True, exist_ok=False)
report['binaries'] = {}
for name in ['postgres', 'initdb']:
    shutil.copy2(repo / 'target/release' / name, candidate / name)
    report['binaries'][name] = {'path': str(candidate / name), 'sha256': hashlib.sha256((candidate / name).read_bytes()).hexdigest()}
shutil.copytree(repo / 'target/release/share', candidate / 'share')
assert (candidate / 'share/postgres.bki').exists()
assert all(hashlib.sha256((repo / name).read_bytes()).hexdigest() == sha for name, sha in report['source_sha256'].items())
report['passed'] = True
(root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report['binaries']), flush=True)
