"""Prepare reproducible comparison controllers before the new server is available."""
from pathlib import Path

root = Path(__file__).resolve().parent
pressure = (root / 'run_warm_limit_pressure.py').read_text().replace('warm-limit', 'budget-guard')
start = pressure.index("            if variant == 'candidate-observed' and data['passed']:")
end = pressure.index('\n        else:', start)
pressure = pressure[:start] + '''            if variant == 'candidate-observed' and data['passed']:
                guards = [row for sample in data['ownership'] for row in sample['rows'] if row[1:3] == ['pool', 'grow_guard']]
                switches = [row[4] for sample in data['ownership'] for row in sample['rows'] if row[1:3] == ['pool', 'grow_guard_skips']]
                assert len(guards) == len(switches) == 15
                assert set(switches) == {1}
                assert guards[-1][4] > 0, 'budget guard never released memory'
                record['guard_bytes_released'] = guards[-1][4]
                record['guard_releases'] = guards[-1][3]
                record['budget_guard_verified'] = True
''' + pressure[end:]
# The current probe has its own CPU-set wrapper; use the ordinary repository helper too.
pressure = pressure.replace("root = frozen if filename == 'resource_scope.py' else source_repo", 'root = source_repo')
performance = (root / 'run_warm_limit_performance.py').read_text().replace('warm-limit', 'budget-guard')
performance = performance.replace('prefault-limit candidate', 'bounded budget-reclaim candidate').replace('memory-derived prefault ceiling', 'bounded budget-triggered reclaim')
screen = (root / 'screen_warm_limit.py').read_text().replace('warm-limit', 'budget-guard').replace('warm_limit', 'budget_guard')
screen = screen.replace('memory_derived_ceiling_verified', 'budget_guard_verified')
for filename, content in [('run_budget_guard_pressure.py', pressure), ('run_budget_guard_performance.py', performance), ('screen_budget_guard.py', screen)]:
    path = root / filename
    assert not path.exists()
    compile(content, filename, 'exec')
    path.write_text(content)
    print(filename)

doc = root / 'pgrust/docs/production-readiness.md'
content = doc.read_bytes()
newline = b'\r\n' if b'\r\n' in content else b'\n'
needle = b'## Acceptance policy' + newline
addition = '''
The [sustained-sort investigation](../artifacts/validation/sort-pressure-2026-10-31/README.md) preserves 33 pressure
trials, including three watchdog cancellations in retained-default Rust with ownership observers. Observer and
session choice change the reproducer; successful unobserved runs do not close that pressure gate. A memory-derived
prefault ceiling avoids cancellation in its six pressure trials but increases memory in both five-repeat workload
comparisons. CPU/latency guards pass; the memory regression rejects the candidate, and its runtime changes are
reverted. The retained executable remains `0be60915`. No kernel OOM kill occurred in this fresh campaign, but
earlier OOM incidents and broader production qualification remain open.
'''.encode().replace(b'\n', newline)
assert content.count(needle) == 1 and addition not in content
doc.write_bytes(content.replace(needle, needle + addition))
