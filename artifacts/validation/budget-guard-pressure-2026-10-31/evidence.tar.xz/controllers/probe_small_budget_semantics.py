"""Record the existing known-small-limit versus zero-budget collision; no production source change."""
from pathlib import Path
import hashlib
import json
import subprocess

base = Path('/home/rustsql')
repo = base / 'pgrust'
out = base / 'small-budget-semantics-20261031'
out.mkdir(exist_ok=False)
source = b'''#[test]
fn record_existing_small_limit_budget() {
    const MIB: u64 = 1 << 20;
    for (limit_mib, expected_mib) in [(0, 0), (512, 0), (1024, 0), (2048, 896), (65536, 59392)] {
        let budget = mempolicy::sizes::budget_of(limit_mib * MIB, 0, 0, 0, 0);
        println!("limit_mib={limit_mib} os_reserve_mib={} page_cache_floor_mib={} budget_mib={}",
                 budget.os_reserve / MIB, budget.page_cache_floor / MIB, budget.b / MIB);
        assert_eq!(budget.b, expected_mib * MIB);
    }
}
'''
path = repo / 'crates/_support/mempolicy/tests/small_limit_budget_diagnostic.rs'
assert not path.exists()
path.parent.mkdir(exist_ok=True)
path.write_bytes(source)
(out / path.name).write_bytes(source)
command = [str(base / '.cargo/bin/cargo'), 'test', '--locked', '--release', '-j', '2', '-p', 'mempolicy',
           '--test', 'small_limit_budget_diagnostic', '--', '--nocapture']
try:
    with (out / 'test.log').open('w') as log:
        result = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    record = {'command': command, 'exit': result.returncode, 'source_sha256': hashlib.sha256(source).hexdigest(),
              'existing_behavior_only': True, 'known_one_gib_limit_produces_zero_budget': result.returncode == 0}
    (out / 'report.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    result.check_returncode()
finally:
    assert path.read_bytes() == source
    path.unlink()
