"""Preserve the failed budget-guard experiment, including OOMs and zero-reclaim observations."""
from pathlib import Path
import hashlib
import json
import tarfile

base = Path('/home/rustsql')
workspace = Path('/mnt/c/Users/DarkMoon/Desktop/Rust SQL')
target = workspace / 'pgrust/artifacts/validation/budget-guard-pressure-2026-10-31'
target.mkdir(exist_ok=False)
summary = json.loads((base / 'budget-guard-pressure-20261031-summary.json').read_text())
assert summary['complete'] and len(summary['trials']) == 12
files = {}
def add(path, name=None):
    assert path.is_file(), path
    files[name or path.relative_to(base).as_posix()] = path
for pattern in ('budget-guard-pressure-20261031*', 'budget-guard-screen-20261031.json', 'budget-guard-build-20261031', 'small-budget-semantics-20261031'):
    for path in sorted(base.glob(pattern)):
        if path.is_dir():
            for member in sorted(path.rglob('*')):
                if member.is_file() and '__pycache__' not in member.parts:
                    add(member)
        else:
            add(path)
for entry in summary['trials']:
    trial = json.loads((base / (entry['name'] + '.json')).read_text())
    for filename in ('initdb.log', 'server.log'):
        add(Path(trial['cluster']) / filename, entry['name'] + '-cluster/' + filename)
for filename in ('build_budget_guard_candidate.py', 'prepare_budget_guard_checks.py', 'run_budget_guard_pressure.py',
                 'run_budget_guard_performance.py', 'screen_budget_guard.py', 'after_budget_guard_build.py',
                 'probe_small_budget_semantics.py', 'freeze_budget_guard_evidence.py'):
    add(workspace / filename, 'controllers/' + filename)
archive = target / 'evidence.tar.xz'
with tarfile.open(archive, 'w:xz') as handle:
    for name, path in files.items():
        handle.add(path, arcname=name)
manifest = {'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'members': {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}}
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(target / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
assessment = {'decision': 'rejected', 'promoted': False, 'reason': 'Five of six candidate pressure trials fail; two have cgroup OOM group kills. Observed candidate reclaim counters remain zero.',
              'candidate_sha256': '73addf2f8955a5db2b2116c26041cdd7e5e6778eabf3589355d20e5ea9776d7b',
              'accepted_sha256': '0be60915b40c9f70f39dcb3a0fd1f8918608a20095f767ec081a5b5320caa277',
              'performance_comparison_run': False,
              'next_issue': 'The default 1 GiB OS reserve makes a known 1 GiB limit produce budget zero; the allocator treats zero as unlimited.'}
(target / 'retention-assessment.json').write_text(json.dumps(assessment, indent=2) + '\n')
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size, 'members': len(files)}))
