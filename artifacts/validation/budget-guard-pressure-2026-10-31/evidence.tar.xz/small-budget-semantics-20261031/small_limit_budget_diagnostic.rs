#[test]
fn record_existing_small_limit_budget() {
    const MIB: u64 = 1 << 20;
    for (limit_mib, expected_mib) in [(0, 0), (512, 0), (1024, 0), (2048, 896), (65536, 59392)] {
        let budget = mempolicy::sizes::budget_of(limit_mib * MIB, 0, 0, 0, 0);
        println!("limit_mib={limit_mib} os_reserve_mib={} page_cache_floor_mib={} budget_mib={}",
                 budget.os_reserve / MIB, budget.page_cache_floor / MIB, budget.b / MIB);
        assert_eq!(budget.b, expected_mib * MIB);
    }
}
