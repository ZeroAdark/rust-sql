from pathlib import Path
import json, subprocess, time

base = Path('/home/rustsql')
repo = base/'pgrust'
candidate = base/'vma-residency-candidate/bin'
build = json.loads((base/'vma-residency-build-20261030/report.json').read_text())
assert build['passed']
common = ['--candidate', str(candidate), '--work-dir', str(base/'conformance')]
scripts = repo/'scripts/validation'
cases = [
    ('accounting', [str(scripts/'allocator_residency_probe.py'), '--bin-dir', str(candidate),
                   '--baseline-bin', str(base/'pool-config-fixed-candidate/bin'),
                   '--work-dir', str(base/'conformance'), '--output', str(base/'vma-residency-live-20261030')]),
    ('protocol', [str(scripts/'bind_lifecycle_probe.py'), *common,
                  '--reference', str(base/'postgres18/bin'), '--output', str(base/'vma-residency-protocol-20261030.json')]),
    ('spill', [str(scripts/'spill_probe.py'), *common, '--reference', str(base/'postgres18/bin'),
                '--rows', '500000', '--memory-mib', '1024', '--output', str(base/'vma-residency-spill-20261030.json')]),
]
report = {'passed': False, 'build': build['binaries'], 'commands': []}
for label, args in cases:
    log = base/('vma-residency-'+label+'-20261030.log')
    assert not log.exists()
    command = ['systemd-run', '--unit=rustsql-qualification-vma-'+label+'-20261030',
               '--uid=rustsql', '--gid=rustsql', '--collect', '--wait',
               '--property=Delegate=cpu memory pids', '--property=MemoryMax=8G',
               '--property=MemorySwapMax=0', '--property=CPUQuota=600%',
               '--property=LimitSTACK=67108864', '--property=RuntimeMaxSec=1200',
               '--property=StandardOutput=append:'+str(log), '--property=StandardError=append:'+str(log),
               '/usr/bin/python3', '-u', *args]
    start = time.monotonic()
    result = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=1230)
    item = {'label': label, 'command': command, 'exit': result.returncode,
            'seconds': time.monotonic()-start, 'output': result.stdout}
    report['commands'].append(item)
    (base/'vma-residency-checks-20261030.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(item), flush=True)
    print(log.read_text()[-1500:], flush=True)
    result.check_returncode()
report['passed'] = True
(base/'vma-residency-checks-20261030.json').write_text(json.dumps(report, indent=2)+'\n')
