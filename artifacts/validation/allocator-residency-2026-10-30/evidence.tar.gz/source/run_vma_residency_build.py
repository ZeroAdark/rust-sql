from pathlib import Path
import hashlib, json, shutil, subprocess, time

base = Path('/home/rustsql')
repo = base / 'pgrust'
root = base / 'vma-residency-build-20261030'
root.mkdir(exist_ok=False)
source = repo / 'crates/backend/postmaster/memruntime/src/lib.rs'
fixed = source.read_bytes()
cargo = str(base / '.cargo/bin/cargo')
report = {'passed': False, 'commands': [], 'actions_used': False,
          'source_sha256': hashlib.sha256(fixed).hexdigest(),
          'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()}
(root / 'candidate.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', 'crates/backend/postmaster/memruntime/src/lib.rs'], cwd=repo))
shutil.copyfile(base / 'vma-residency-unit-20261030.log', root / 'unit.log')

def run(label, command):
    start = time.monotonic()
    with (root / (label + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    report['commands'].append({'label': label, 'command': command, 'exit': result.returncode, 'seconds': time.monotonic()-start})
    (root / 'report.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report['commands'][-1]), flush=True)
    return result.returncode

test = [cargo, 'test', '--locked', '--release', '-j', '2', '-p', 'memruntime', '--lib', 'residency_reporting_requires_available_mapping_names']
try:
    old = b'if !vma_names_supported()? {\n'
    assert fixed.count(old) == 1
    source.write_bytes(fixed.replace(old, b'if false && !vma_names_supported()? {\n', 1))
    (root / 'negative-control.patch').write_bytes(subprocess.check_output(['git', 'diff', '--', 'crates/backend/postmaster/memruntime/src/lib.rs'], cwd=repo))
    rc = run('negative-control', test)
    log = (root / 'negative-control.log').read_text()
    assert rc != 0 and 'unknown must not be reported as zero' in log and '1 failed' in log, log[-2500:]
finally:
    source.write_bytes(fixed)
    assert source.read_bytes() == fixed
    report['source_restored_after_control'] = True
    (root / 'report.json').write_text(json.dumps(report, indent=2)+'\n')

assert run('restored-focused', test) == 0
assert run('release-build', [cargo, 'build', '--locked', '--release', '-j', '2', '-p', 'main_main', '-p', 'initdb']) == 0
candidate = base / 'vma-residency-candidate/bin'
candidate.mkdir(parents=True, exist_ok=False)
report['binaries'] = {}
for name in ['postgres', 'initdb']:
    origin = repo / 'target/release' / name
    target = candidate / name
    shutil.copy2(origin, target)
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    assert digest == hashlib.sha256(origin.read_bytes()).hexdigest()
    report['binaries'][name] = {'path': str(target), 'sha256': digest}
report['passed'] = True
(root / 'report.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report['binaries']), flush=True)
