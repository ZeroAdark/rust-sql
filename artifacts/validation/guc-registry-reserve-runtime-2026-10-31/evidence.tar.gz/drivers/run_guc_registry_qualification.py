from pathlib import Path
import hashlib, json, subprocess, time

if not __debug__:
    raise RuntimeError('Assertions must remain enabled')

base = Path('/home/rustsql')
binary = base/'guc-registry-reserve-candidate/bin/postgres'
sha = '0be60915b40c9f70f39dcb3a0fd1f8918608a20095f767ec081a5b5320caa277'
assert hashlib.sha256(binary.read_bytes()).hexdigest() == sha
assert not subprocess.check_output(['systemctl','list-units','rustsql-qualification-*','--state=running','--plain','--no-legend'],text=True).strip()
output = base/'guc-registry-reserve-qualification-20261031.json'
assert not output.exists()
report = {'passed':False, 'candidate_sha256':sha, 'commands':[]}
source = base/'guc-registry-reserve-connections-20261031/source'
validation = base/'guc_registry_reserve_validation.py'
validation.write_text((base/'residency_retained_validation.py').read_text().replace('vma-residency-candidate','guc-registry-reserve-candidate').replace('residency-retained','guc-registry-reserve'))
sources = [validation, Path(__file__), *list((base/'pgrust/scripts/validation').glob('*.py'))]
report['source_sha256'] = {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
tasks = []
for i in range(1,4):
    tasks.append((f'guc-registry-reserve-2g-pilot-{i}-20261031',
                  [str(source/'guc_queue_probe.py'), '--candidate',str(binary.parent),'--work-dir',str(base/'conformance'),
                   '--output',str(base/f'guc-registry-reserve-2g-pilot-{i}-20261031.json'), '--burst','--memory-mib','2048'], True))
tasks += [('guc-registry-reserve-'+mode+'-20261031', [str(validation),mode], False) for mode in ('full','probes')]
for label, args, cpuset in tasks:
    log = base/(label+'.log')
    assert not log.exists()
    command = ['systemd-run','--unit=rustsql-qualification-'+label,'--uid=rustsql','--gid=rustsql','--wait','--collect',
               '--property=MemoryMax=12G','--property=MemorySwapMax=0','--property=LimitSTACK=67108864',
               '--property=RuntimeMaxSec=3600','--property=StandardOutput=append:'+str(log),'--property=StandardError=append:'+str(log)]
    if cpuset:
        command += ['--property=Delegate=cpu memory pids cpuset','--property=AllowedCPUs=0,2,4,6,8,10']
    else:
        command += ['--property=CPUQuota=600%']
    command += ['/usr/bin/python3','-u',*args]
    started = time.monotonic()
    result = subprocess.run(command,capture_output=True,text=True,timeout=3630)
    entry = {'label':label,'command':command,'exit':result.returncode,'seconds':time.monotonic()-started,
             'stdout':result.stdout,'stderr':result.stderr}
    report['commands'].append(entry)
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'label':label,'exit':result.returncode,'seconds':entry['seconds']}),flush=True)
    print(log.read_text()[-1200:],flush=True)
    result.check_returncode()
assert hashlib.sha256(binary.read_bytes()).hexdigest() == sha
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in report['source_sha256'].items())
report['passed']=True
output.write_text(json.dumps(report,indent=2)+'\n')
