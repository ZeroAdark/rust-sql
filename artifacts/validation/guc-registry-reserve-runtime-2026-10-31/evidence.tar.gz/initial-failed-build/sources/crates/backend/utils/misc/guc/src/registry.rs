use std::collections::HashMap;

use elog::{ereport, message_level_is_interesting};
use types_core::{Oid, BOOTSTRAP_SUPERUSERID};
use types_error::{
    ErrorLevel, PgError, PgResult, SqlState, DEBUG3, ERRCODE_CANT_CHANGE_RUNTIME_PARAM,
    ERRCODE_FEATURE_NOT_SUPPORTED, ERRCODE_INSUFFICIENT_PRIVILEGE, ERRCODE_INVALID_PARAMETER_VALUE,
    ERRCODE_INVALID_TRANSACTION_STATE, ERRCODE_UNDEFINED_OBJECT, ERROR, LOG, WARNING,
};
use types_guc::{
    GucContext, GucSource, GUC_ALLOW_IN_PARALLEL, GUC_IS_NAME, GUC_NO_RESET, GUC_REPORT, GUC_UNIT,
    PGC_BACKEND, PGC_INTERNAL, PGC_POSTMASTER, PGC_SIGHUP, PGC_SUSET, PGC_SU_BACKEND, PGC_S_CLIENT,
    PGC_S_DATABASE, PGC_S_DATABASE_USER, PGC_S_DEFAULT, PGC_S_DYNAMIC_DEFAULT, PGC_S_FILE,
    PGC_S_GLOBAL, PGC_S_OVERRIDE, PGC_S_SESSION, PGC_S_USER, PGC_USERSET,
};

use guc_tables::GucHookExtra;

use crate::enum_lookup::{
    config_enum_get_options, config_enum_lookup_by_name, config_enum_lookup_by_value,
};
use crate::model::{
    config_bool, config_enum, config_generic, config_int, config_real, config_string,
    config_var_val, config_var_value, GucStack, SharedExtra, GUC_LOCAL, GUC_NEEDS_REPORT,
    GUC_PENDING_RESTART, GUC_SAVE, GUC_SET, GUC_SET_LOCAL,
};
use crate::name::{fold_name, guc_name_eq, GucNameHasherBuilder, MAP_OLD_GUC_NAMES};
use crate::units::{
    convert_int_from_base_unit, convert_real_from_base_unit, fmt_g, get_config_unit_name,
    parse_int, parse_real, ParseNum,
};
use crate::{GUC_ACTION_LOCAL, GUC_ACTION_SAVE, GUC_ACTION_SET};

pub type GucAction = u32;

/// A registry's name index: the case-folded name to the variable's slot.
pub type BuiltinIndex = HashMap<Box<str>, usize, GucNameHasherBuilder>;

#[derive(Clone, Debug)]
pub enum GucVariable {
    Bool(config_bool),
    Int(config_int),
    Real(config_real),
    String(config_string),
    Enum(config_enum),
}

impl GucVariable {
    pub fn gen(&self) -> &config_generic {
        match self {
            GucVariable::Bool(c) => &c.gen,
            GucVariable::Int(c) => &c.gen,
            GucVariable::Real(c) => &c.gen,
            GucVariable::String(c) => &c.gen,
            GucVariable::Enum(c) => &c.gen,
        }
    }

    pub fn gen_mut(&mut self) -> &mut config_generic {
        match self {
            GucVariable::Bool(c) => &mut c.gen,
            GucVariable::Int(c) => &mut c.gen,
            GucVariable::Real(c) => &mut c.gen,
            GucVariable::String(c) => &mut c.gen,
            GucVariable::Enum(c) => &mut c.gen,
        }
    }

    pub fn name(&self) -> &str {
        &self.gen().name
    }
}

// guc_hashtab plus the three intrusive lists (guc.c:226): guc_stack_list and
// guc_report_list make AtEOXact_GUC / ReportChangedGUCOptions O(changed) not
// O(~400); guc_nondef_list makes ResetAllOptions walk only non-default vars.
#[derive(Clone, Debug, Default)]
pub struct GucRegistry {
    vars: Vec<GucVariable>,
    // D4682 step 2 (a): the built-in variables' names, shared by the registries a process builds after its first
    // (`adopt_builtin_index`): the built-ins are defined in one fixed order, so their indexes are the same in every
    // registry, and `index` then holds only what is defined past them (custom variables and placeholders). None: `index`
    // holds every name.
    builtins: Option<std::sync::Arc<BuiltinIndex>>,
    index: BuiltinIndex,
    stacked: Vec<usize>,
    reported: Vec<usize>,
    nondef: crate::nondef_list::NondefList,
}

impl GucRegistry {
    pub fn new() -> Self {
        Self::default()
    }

    fn note_stacked(&mut self, idx: usize) {
        self.stacked.push(idx);
        // A stale-true hint on a non-TLS registry is harmless (see store.rs).
        crate::store::set_has_stacked_hint(true);
    }

    // Invariant (C's): idx is on `reported` iff its GUC_NEEDS_REPORT bit is set.
    fn note_reportable(&mut self, idx: usize) {
        let g = self.vars[idx].gen_mut();
        if g.flags & GUC_REPORT != 0 && g.status & GUC_NEEDS_REPORT == 0 {
            g.status |= GUC_NEEDS_REPORT;
            self.reported.push(idx);
            crate::store::set_report_pending_hint(true);
        }
    }

    // guc_report_list is head-pushed (guc.c:4272): newest change first.
    pub fn drain_report_list(&mut self) -> Vec<usize> {
        let mut indices = core::mem::take(&mut self.reported);
        indices.reverse();
        for &idx in &indices {
            self.vars[idx].gen_mut().status &= !GUC_NEEDS_REPORT;
        }
        indices
    }

    // set_guc_source (guc.c): keeps guc_nondef_list membership in step with
    // source==PGC_S_DEFAULT transitions.
    fn set_source(&mut self, idx: usize, newsource: GucSource) {
        let g = self.vars[idx].gen_mut();
        if g.source == PGC_S_DEFAULT {
            if newsource != PGC_S_DEFAULT {
                self.nondef.push_tail(idx);
            }
        } else if newsource == PGC_S_DEFAULT {
            self.nondef.remove(idx);
        }
        self.vars[idx].gen_mut().source = newsource;
    }

    /// D4682 step 2 (a): this registry, still empty, takes `builtins` as its built-in variables' names instead of
    /// building its own (its built-in definitions go through `define_builtin`, then `settle_builtin_index`).
    pub fn adopt_builtin_index(&mut self, builtins: std::sync::Arc<BuiltinIndex>) -> PgResult<()> {
        debug_assert!(self.vars.is_empty() && self.index.is_empty(), "a registry adopts the built-in index before any define");
        // The shared index knows the initial slot count. Reserve once instead of copying the growing value array
        // and its non-default links through successive allocations for every session. Custom settings can still grow.
        self.vars.try_reserve_exact(builtins.len()).map_err(|_| oom())?;
        self.nondef.try_grow(builtins.len()).map_err(|_| oom())?;
        self.builtins = Some(builtins);
        Ok(())
    }

    /// The built-in loop's define: with an adopted index the variable's slot is the one the index names (checked in debug
    /// builds) and only its value is built; without one, `define`.
    pub fn define_builtin(&mut self, var: GucVariable) -> PgResult<()> {
        let Some(builtins) = &self.builtins else {
            return self.define(var);
        };
        let idx = self.vars.len();
        debug_assert_eq!(builtins.get(fold_name(var.name()).as_str()).copied(), Some(idx), "the built-in definition order moved");
        self.vars.try_reserve(1).map_err(|_| oom())?;
        self.nondef.try_grow(idx + 1).map_err(|_| oom())?;
        self.vars.push(var);
        Ok(())
    }

    /// After the built-in loop: an adopted index must name exactly the variables defined (its size, and the first and the
    /// last name where they were defined); if not, this registry builds its own index of them instead.
    pub fn settle_builtin_index(&mut self) -> PgResult<()> {
        let Some(builtins) = &self.builtins else {
            return Ok(());
        };
        let at = |i: usize| builtins.get(fold_name(self.vars[i].name()).as_str()).copied() == Some(i);
        let n = self.vars.len();
        if builtins.len() == n && (n == 0 || (at(0) && at(n - 1))) {
            return Ok(());
        }
        self.builtins = None;
        self.index.try_reserve(n).map_err(|_| oom())?;
        for (idx, var) in self.vars.iter().enumerate() {
            self.index.insert(fold_name(var.name()).into_boxed_str(), idx);
        }
        Ok(())
    }

    /// The names this registry indexes itself: for the first registry, read right after its built-in loop, every
    /// built-in variable's (what `adopt_builtin_index` shares).
    pub fn own_index(&self) -> BuiltinIndex {
        self.index.clone()
    }

    fn lookup(&self, key: &str) -> Option<usize> {
        if let Some(i) = self.builtins.as_ref().and_then(|b| b.get(key)) {
            return Some(*i);
        }
        self.index.get(key).copied()
    }

    pub fn define(&mut self, var: GucVariable) -> PgResult<()> {
        let idx = self.vars.len();
        let key = fold_name(var.name()).into_boxed_str();
        self.vars.try_reserve(1).map_err(|_| oom())?;
        self.index.try_reserve(1).map_err(|_| oom())?;
        self.nondef.try_grow(idx + 1).map_err(|_| oom())?;
        self.vars.push(var);
        self.index.insert(key, idx);
        Ok(())
    }

    // define_custom_variable's registry half (guc.c:4937): add the new
    // variable, or replace the placeholder of the same name (returned so the
    // caller re-applies its reset / current / stacked values); a
    // non-placeholder of that name is "attempt to redefine parameter".
    // RemoveGUCFromLists (guc.c:1761) for the placeholder is folded in; the
    // index key (the case-folded name) is unchanged, so it stays.
    pub fn define_custom_variable(&mut self, var: GucVariable) -> PgResult<Option<config_string>> {
        let name = var.name();
        let Some(idx) = self.find_index(name) else {
            self.define(var)?;
            return Ok(None);
        };
        if self.vars[idx].gen().flags & types_guc::GUC_CUSTOM_PLACEHOLDER == 0 {
            return Err(Box::new(PgError::error(format!(
                "attempt to redefine parameter \"{name}\""
            ))));
        }
        self.stacked.retain(|&i| i != idx);
        self.reported.retain(|&i| i != idx);
        self.nondef.remove(idx);
        match std::mem::replace(&mut self.vars[idx], var) {
            GucVariable::String(holder) => Ok(Some(holder)),
            _ => unreachable!("a placeholder is a string variable"),
        }
    }

    // reapply_stacked_values' stack bookkeeping (guc.c:5104, :5122): the
    // nest level of the entry the re-application just pushed, or dropping
    // the entry set_config_option pushed for a committed session value.
    pub fn stack_top_nest_level(&mut self, name: &str) -> Option<&mut i32> {
        let idx = self.find_index(name)?;
        self.vars[idx].gen_mut().stack.as_deref_mut().map(|s| &mut s.nest_level)
    }

    pub fn stack_depth(&self, name: &str) -> usize {
        let Some(idx) = self.find_index(name) else {
            return 0;
        };
        let mut depth = 0;
        let mut cur = self.vars[idx].gen().stack.as_deref();
        while let Some(s) = cur {
            depth += 1;
            cur = s.prev.as_deref();
        }
        depth
    }

    pub fn drop_stack(&mut self, name: &str) {
        if let Some(idx) = self.find_index(name) {
            self.stacked.retain(|&i| i != idx);
            self.vars[idx].gen_mut().stack = None;
        }
    }

    pub fn add_placeholder_variable(&mut self, name: &str) -> PgResult<usize> {
        use types_guc::{config_group, config_type};

        // C guc_strdups the name into GUCMemoryContext, which lives exactly
        // as long as the backend; the owned name dies with this registry.
        let gen = config_generic::boot(
            name.to_string(),
            GucContext::PGC_USERSET,
            config_group::CUSTOM_OPTIONS,
            Some("GUC placeholder variable"),
            None,
            types_guc::GUC_NO_SHOW_ALL
                | types_guc::GUC_NOT_IN_SAMPLE
                | types_guc::GUC_CUSTOM_PLACEHOLDER,
            config_type::PGC_STRING,
        );
        let var = GucVariable::String(config_string {
            gen,
            variable: &guc_tables::vars::GucPlaceholderVariable,
            value: None,
            boot_val: None,
            check_hook: None,
            assign_hook: None,
            show_hook: None,
            reset_val: None,
            reset_extra: None,
        });
        let reusable = self.vars.iter().position(|v| {
            let g = v.gen();
            g.status & crate::model::GUC_REMOVED != 0
                && g.flags & types_guc::GUC_CUSTOM_PLACEHOLDER != 0
        });
        let Some(idx) = reusable else {
            let idx = self.vars.len();
            self.define(var)?;
            return Ok(idx);
        };
        let key = fold_name(var.name()).into_boxed_str();
        self.index.try_reserve(1).map_err(|_| oom())?;
        self.vars[idx] = var;
        self.index.insert(key, idx);
        Ok(idx)
    }

    // A fresh backend holds no placeholder a prior session created; slots
    // stay as tombstones that add_placeholder_variable reuses.
    pub fn remove_all_placeholders(&mut self) {
        for idx in 0..self.vars.len() {
            let g = self.vars[idx].gen();
            if g.flags & types_guc::GUC_CUSTOM_PLACEHOLDER == 0
                || g.status & crate::model::GUC_REMOVED != 0
            {
                continue;
            }
            let key = fold_name(&g.name);
            self.index.remove(key.as_str());
            self.stacked.retain(|&i| i != idx);
            self.reported.retain(|&i| i != idx);
            self.nondef.remove(idx);
            let g = self.vars[idx].gen_mut();
            g.status &= !GUC_NEEDS_REPORT;
            g.status |= crate::model::GUC_REMOVED;
        }
    }

    pub fn find_option(&self, name: &str) -> Option<&GucVariable> {
        self.find_index(name).map(|idx| &self.vars[idx])
    }

    pub fn find_option_mut(&mut self, name: &str) -> Option<&mut GucVariable> {
        self.find_index(name).map(|idx| &mut self.vars[idx])
    }

    pub fn find_index(&self, name: &str) -> Option<usize> {
        let direct = if name.bytes().any(|b| b.is_ascii_uppercase()) {
            self.lookup(fold_name(name).as_str())
        } else {
            self.lookup(name)
        };
        if let Some(idx) = direct {
            return Some(idx);
        }
        for (old, new) in MAP_OLD_GUC_NAMES {
            if guc_name_eq(name, old) {
                return self.lookup(new);
            }
        }
        None
    }

    pub fn iter(&self) -> impl Iterator<Item = &GucVariable> {
        self.vars
            .iter()
            .filter(|v| v.gen().status & crate::model::GUC_REMOVED == 0)
    }

    pub fn iter_mut(&mut self) -> impl Iterator<Item = &mut GucVariable> {
        self.vars
            .iter_mut()
            .filter(|v| v.gen().status & crate::model::GUC_REMOVED == 0)
    }

    // MarkGUCPrefixReserved's placeholder purge (guc.c:5285): C removes the
    // guc_hashtab entry and unlinks the var from all lists; our vars slot must
    // keep its index, so it stays behind as a GUC_REMOVED tombstone that
    // find_index/iter can no longer reach. Returns the removed names.
    pub fn remove_reserved_placeholders(&mut self, class_name: &str) -> Vec<String> {
        let mut removed = Vec::new();
        for idx in 0..self.vars.len() {
            let g = self.vars[idx].gen();
            let name = g.name.to_string();
            if g.flags & types_guc::GUC_CUSTOM_PLACEHOLDER == 0
                || g.status & crate::model::GUC_REMOVED != 0
                || name.len() <= class_name.len()
                || !name.starts_with(class_name)
                || name.as_bytes()[class_name.len()] != b'.'
            {
                continue;
            }
            self.index.remove(fold_name(&name).as_str());
            self.stacked.retain(|&i| i != idx);
            self.reported.retain(|&i| i != idx);
            self.nondef.remove(idx);
            let g = self.vars[idx].gen_mut();
            g.status &= !GUC_NEEDS_REPORT;
            g.status |= crate::model::GUC_REMOVED;
            removed.push(name);
        }
        removed
    }

    pub fn len(&self) -> usize {
        self.vars.len()
    }

    // The variable at an index find_index returned before, unless it has
    // become a tombstone since (remove_reserved_placeholders).
    pub(crate) fn live_at(&self, idx: usize) -> Option<&GucVariable> {
        self.vars.get(idx).filter(|v| v.gen().status & crate::model::GUC_REMOVED == 0)
    }

    pub fn is_empty(&self) -> bool {
        self.vars.is_empty()
    }

    pub fn has_stacked(&self) -> bool {
        !self.stacked.is_empty()
    }

    pub fn set_source_pub(&mut self, idx: usize, newsource: GucSource) {
        self.set_source(idx, newsource);
    }
}

impl core::ops::Index<usize> for GucRegistry {
    type Output = GucVariable;
    fn index(&self, i: usize) -> &GucVariable {
        &self.vars[i]
    }
}

impl core::ops::IndexMut<usize> for GucRegistry {
    fn index_mut(&mut self, i: usize) -> &mut GucVariable {
        &mut self.vars[i]
    }
}

#[track_caller]
#[cold]
fn oom() -> Box<PgError> {
    ereport(ERROR)
        .errcode(types_error::ERRCODE_OUT_OF_MEMORY)
        .errmsg("out of memory")
        .into_error()
        .into()
}

fn resolve_elevel(elevel: ErrorLevel, source: GucSource) -> ErrorLevel {
    if elevel != ErrorLevel(0) {
        return elevel;
    }
    if source == PGC_S_DEFAULT || source == PGC_S_FILE {
        if init_small::globals::IsUnderPostmaster() {
            DEBUG3
        } else {
            LOG
        }
    } else if source == PGC_S_GLOBAL
        || source == PGC_S_DATABASE
        || source == PGC_S_USER
        || source == PGC_S_DATABASE_USER
    {
        WARNING
    } else {
        ERROR
    }
}

#[cold]
fn err(sqlstate: SqlState, message: String) -> PgError {
    ereport(ERROR)
        .errcode(sqlstate)
        .errmsg(message)
        .into_error()
}

// C return convention: ereport(elevel) throws at >= ERROR, else logs and the
// set returns 0.
pub(crate) fn reject(elevel: ErrorLevel, e: PgError) -> PgResult<i32> {
    if elevel >= ERROR {
        Err(e.into())
    } else {
        if message_level_is_interesting(elevel) {
            // C reports AT the demoted level — ereport(elevel, ...) in
            // set_config_option — so a bad per-role/db setting surfaces as
            // a WARNING the client shrugs off. The PgError was built at
            // ERROR; emitting it unchanged sends an 'E' (ERROR) wire
            // message, which at LOGIN makes libpq abort the whole
            // connection: `ALTER ROLE x SET role = <dropped role>` then
            // locked every new pgrust session out ("role ... does not
            // exist" at connect) while C logs a WARNING and connects
            // (found by the round-11 gramwalk role-DDL soak).
            elog::emit_error_report_for(&demoted_for_report(e, elevel));
        }
        Ok(0)
    }
}

/// The report a demoted rejection emits, carrying the DEMOTED level (see
/// reject()). Split out for a direct unit test.
pub(crate) fn demoted_for_report(mut e: PgError, elevel: ErrorLevel) -> PgError {
    e.level = elevel;
    e
}

enum AccessCheck {
    Ok,
    Skip,
    Reject(PgError),
}

fn parameter_acl_set_ok(name: &str, role: Oid) -> PgResult<bool> {
    aclchk_seams::pg_parameter_aclcheck_set::call(name, role)
}

#[allow(clippy::too_many_arguments)]
fn check_can_set(
    record: &config_generic,
    value_is_null: bool,
    context: GucContext,
    source: GucSource,
    srole: Oid,
    action: GucAction,
    change_val: bool,
    is_reload: bool,
) -> PgResult<AccessCheck> {
    let name = record.name.as_ref();

    if xact_seams::is_in_parallel_mode::call()
        && change_val
        && action != GUC_ACTION_SAVE
        && (record.flags & GUC_ALLOW_IN_PARALLEL) == 0
    {
        return Ok(AccessCheck::Reject(err(
            ERRCODE_INVALID_TRANSACTION_STATE,
            format!("parameter \"{name}\" cannot be set during a parallel operation"),
        )));
    }

    match record.context {
        PGC_INTERNAL => {
            if context != PGC_INTERNAL {
                return Ok(AccessCheck::Reject(err(
                    ERRCODE_CANT_CHANGE_RUNTIME_PARAM,
                    format!("parameter \"{name}\" cannot be changed"),
                )));
            }
        }
        PGC_POSTMASTER => {
            if context == PGC_SIGHUP {
                // prohibitValueChange: handled after canonicalizing the value.
            } else if context != PGC_POSTMASTER {
                return Ok(AccessCheck::Reject(err(
                    ERRCODE_CANT_CHANGE_RUNTIME_PARAM,
                    format!("parameter \"{name}\" cannot be changed without restarting the server"),
                )));
            }
        }
        PGC_SIGHUP => {
            if context != PGC_SIGHUP && context != PGC_POSTMASTER {
                return Ok(AccessCheck::Reject(err(
                    ERRCODE_CANT_CHANGE_RUNTIME_PARAM,
                    format!("parameter \"{name}\" cannot be changed now"),
                )));
            }
        }
        PGC_SU_BACKEND => {
            if context == PGC_BACKEND && !parameter_acl_set_ok(name, srole)? {
                return Ok(AccessCheck::Reject(err(
                    ERRCODE_INSUFFICIENT_PRIVILEGE,
                    format!("permission denied to set parameter \"{name}\""),
                )));
            }
            if let Some(r) = backend_context_rules(name, context, source, change_val, is_reload) {
                return Ok(r);
            }
        }
        PGC_BACKEND => {
            if let Some(r) = backend_context_rules(name, context, source, change_val, is_reload) {
                return Ok(r);
            }
        }
        PGC_SUSET => {
            if (context == PGC_USERSET || context == PGC_BACKEND)
                && !parameter_acl_set_ok(name, srole)?
            {
                return Ok(AccessCheck::Reject(err(
                    ERRCODE_INSUFFICIENT_PRIVILEGE,
                    format!("permission denied to set parameter \"{name}\""),
                )));
            }
        }
        PGC_USERSET => {}
    }

    if record.flags & types_guc::GUC_NOT_WHILE_SEC_REST != 0 {
        if miscinit::InLocalUserIdChange() {
            return Ok(AccessCheck::Reject(err(
                ERRCODE_INSUFFICIENT_PRIVILEGE,
                format!("cannot set parameter \"{name}\" within security-definer function"),
            )));
        }
        if miscinit::InSecurityRestrictedOperation() {
            return Ok(AccessCheck::Reject(err(
                ERRCODE_INSUFFICIENT_PRIVILEGE,
                format!("cannot set parameter \"{name}\" within security-restricted operation"),
            )));
        }
    }

    if record.flags & GUC_NO_RESET != 0 {
        if value_is_null {
            return Ok(AccessCheck::Reject(err(
                ERRCODE_FEATURE_NOT_SUPPORTED,
                format!("parameter \"{name}\" cannot be reset"),
            )));
        }
        if action == GUC_ACTION_SAVE {
            return Ok(AccessCheck::Reject(err(
                ERRCODE_FEATURE_NOT_SUPPORTED,
                format!("parameter \"{name}\" cannot be set locally in functions"),
            )));
        }
    }

    Ok(AccessCheck::Ok)
}

fn backend_context_rules(
    name: &str,
    context: GucContext,
    source: GucSource,
    change_val: bool,
    is_reload: bool,
) -> Option<AccessCheck> {
    if context == PGC_SIGHUP {
        // Accept in the postmaster, ignore in existing backends unless reloading.
        if init_small::globals::IsUnderPostmaster() && change_val && !is_reload {
            return Some(AccessCheck::Skip);
        }
        None
    } else if context != PGC_POSTMASTER
        && context != PGC_BACKEND
        && context != PGC_SU_BACKEND
        && source != PGC_S_CLIENT
    {
        Some(AccessCheck::Reject(err(
            ERRCODE_CANT_CHANGE_RUNTIME_PARAM,
            format!("parameter \"{name}\" cannot be set after connection start"),
        )))
    } else {
        None
    }
}

pub fn parse_and_validate_value(
    record: &GucVariable,
    value: &str,
    source: GucSource,
) -> PgResult<(config_var_val, Option<SharedExtra>)> {
    let gen = record.gen();
    let name = gen.name.as_ref();

    match record {
        GucVariable::Bool(conf) => {
            let mut newval = match scalar_seams::parse_bool::call(value) {
                Some(b) => b,
                None => {
                    return Err(err(
                        ERRCODE_INVALID_PARAMETER_VALUE,
                        format!("parameter \"{name}\" requires a Boolean value"),
                    )
                    .into())
                }
            };
            let extra = call_bool_check_hook(conf, &mut newval, source)?;
            Ok((config_var_val::Boolval(newval), extra))
        }
        GucVariable::Int(conf) => {
            let mut newval = match parse_int(value, gen.flags) {
                ParseNum::Ok(v) => v,
                ParseNum::Err { hint } => return Err(invalid_value_error(name, value, hint).into()),
            };
            if newval < conf.min || newval > conf.max {
                let (unit, sp) = unit_and_space(gen.flags);
                return Err(err(
                    ERRCODE_INVALID_PARAMETER_VALUE,
                    format!(
                        "{newval}{sp}{unit} is outside the valid range for parameter \"{name}\" ({}{sp}{unit} .. {}{sp}{unit})",
                        conf.min, conf.max
                    ),
                )
                .into());
            }
            let extra = call_int_check_hook(conf, &mut newval, source)?;
            Ok((config_var_val::Intval(newval), extra))
        }
        GucVariable::Real(conf) => {
            let mut newval = match parse_real(value, gen.flags) {
                ParseNum::Ok(v) => v,
                ParseNum::Err { hint } => return Err(invalid_value_error(name, value, hint).into()),
            };
            if newval < conf.min || newval > conf.max {
                // guc.c: "%g%s%s is outside the valid range ..." — %g, so
                // 1e10 prints "1e+10" and Infinity "Infinity".
                let (unit, sp) = unit_and_space(gen.flags);
                return Err(err(
                    ERRCODE_INVALID_PARAMETER_VALUE,
                    format!(
                        "{}{sp}{unit} is outside the valid range for parameter \"{name}\" ({}{sp}{unit} .. {}{sp}{unit})",
                        fmt_g(newval),
                        fmt_g(conf.min),
                        fmt_g(conf.max)
                    ),
                )
                .into());
            }
            let extra = call_real_check_hook(conf, &mut newval, source)?;
            Ok((config_var_val::Realval(newval), extra))
        }
        GucVariable::String(conf) => {
            let mut newval = value.to_string();
            if gen.flags & GUC_IS_NAME != 0 {
                newval = truncate_name(&newval)?;
            }
            let mut opt = Some(newval);
            let extra = call_string_check_hook(conf, &mut opt, source)?;
            Ok((config_var_val::Stringval(opt), extra))
        }
        GucVariable::Enum(conf) => {
            let mut newval = match config_enum_lookup_by_name(conf, value) {
                Some(v) => v,
                None => {
                    let hint = config_enum_get_options(conf, "Available values: ", ".", ", ");
                    return Err(ereport(ERROR)
                        .errcode(ERRCODE_INVALID_PARAMETER_VALUE)
                        .errmsg(format!(
                            "invalid value for parameter \"{name}\": \"{value}\""
                        ))
                        .errhint(hint)
                        .into_error()
                        .into());
                }
            };
            let extra = call_enum_check_hook(conf, &mut newval, source)?;
            Ok((config_var_val::Enumval(newval), extra))
        }
    }
}

// truncate_identifier(newval, strlen(newval), true) (scansup.c) for GUC_IS_NAME.
fn truncate_name(s: &str) -> PgResult<String> {
    if s.len() < parser_small1::NAMEDATALEN {
        return Ok(s.to_string());
    }
    let ctx = mcx::MemoryContext::new("guc truncate_identifier");
    let mcx = ctx.mcx();
    let mut ident = mcx::vec_with_capacity_in(mcx, s.len()).map_err(|_| oom())?;
    ident.extend_from_slice(s.as_bytes());
    let encoding = mbutils_seams::get_database_encoding::call();
    parser_small1::truncate_identifier(&mut ident, true, encoding)?;
    Ok(String::from_utf8_lossy(&ident).into_owned())
}

fn invalid_value_error(name: &str, value: &str, hint: Option<&str>) -> PgError {
    let mut b = ereport(ERROR)
        .errcode(ERRCODE_INVALID_PARAMETER_VALUE)
        .errmsg(format!(
            "invalid value for parameter \"{name}\": \"{value}\""
        ));
    if let Some(h) = hint {
        b = b.errhint(h.to_string());
    }
    b.into_error()
}

fn unit_and_space(flags: i32) -> (&'static str, &'static str) {
    match get_config_unit_name(flags & GUC_UNIT) {
        Some(u) => (u, " "),
        None => ("", ""),
    }
}

// call_*_check_hook (guc.c:6809..): an uninstalled slot is an unported owner;
// it behaves as C's check_hook == NULL (boot defaults are valid by construction).
pub(crate) fn check_hook_error(fallback: String) -> PgError {
    let check = crate::take_guc_check_error();
    if check.message.is_none()
        && check.detail.is_none()
        && check.hint.is_none()
        && check.sqlstate == ERRCODE_INVALID_PARAMETER_VALUE
    {
        return err(ERRCODE_INVALID_PARAMETER_VALUE, fallback);
    }
    let mut builder = ereport(ERROR)
        .errcode(check.sqlstate)
        .errmsg(check.message.unwrap_or(fallback));
    if let Some(raw) = check.detail_raw {
        builder = builder.errdetail_raw(raw);
    } else if let Some(detail) = check.detail {
        builder = builder.errdetail_internal(detail);
    }
    if let Some(hint) = check.hint {
        builder = builder.errhint(hint);
    }
    builder.into_error()
}

macro_rules! check_hook_caller {
    ($fname:ident, $conf:ty, $val:ty, $fallback:expr) => {
        fn $fname(
            conf: &$conf,
            newval: &mut $val,
            source: GucSource,
        ) -> PgResult<Option<SharedExtra>> {
            let Some(slot) = conf.check_hook else {
                return Ok(None);
            };
            if !slot.installed() {
                return Ok(None);
            }
            crate::reset_guc_check_error();
            let mut extra: Option<GucHookExtra> = None;
            match (slot.get())(newval, &mut extra, source) {
                Ok(true) => Ok(extra.map(SharedExtra::new)),
                Ok(false) => Err(check_hook_error($fallback(conf, newval)).into()),
                Err(e) => {
                    crate::mark_guc_check_thrown();
                    Err(e)
                }
            }
        }
    };
}

check_hook_caller!(
    call_bool_check_hook,
    config_bool,
    bool,
    |c: &config_bool, v: &bool| format!(
        "invalid value for parameter \"{}\": {}",
        c.gen.name, *v as i32
    )
);
check_hook_caller!(
    call_int_check_hook,
    config_int,
    i32,
    |c: &config_int, v: &i32| format!("invalid value for parameter \"{}\": {}", c.gen.name, v)
);
check_hook_caller!(
    call_real_check_hook,
    config_real,
    f64,
    |c: &config_real, v: &f64| format!("invalid value for parameter \"{}\": {}", c.gen.name, v)
);
check_hook_caller!(
    call_string_check_hook,
    config_string,
    Option<String>,
    |c: &config_string, v: &Option<String>| format!(
        "invalid value for parameter \"{}\": \"{}\"",
        c.gen.name,
        v.as_deref().unwrap_or("")
    )
);
check_hook_caller!(
    call_enum_check_hook,
    config_enum,
    i32,
    |c: &config_enum, v: &i32| format!(
        "invalid value for parameter \"{}\": \"{}\"",
        c.gen.name,
        config_enum_lookup_by_value(c, *v).unwrap_or("?")
    )
);

// InitializeOneGUCOption's hook step (guc.c:1644): run the check hook on the
// boot value for its extra, fire the assign hook, stash extra in gen.extra and
// reset_extra. `publish` false suppresses the assign hook and the backing-var
// write: in C both only touch the child's own address space, but our backing
// vars are process-shared, so a child bring-up installing a boot value that
// its snapshot restore immediately overwrites would publish a transient wrong
// value to concurrently running threads.
pub fn initialize_one_guc_option_hooks(var: &mut GucVariable, publish: bool) -> PgResult<()> {
    match var {
        GucVariable::Bool(conf) => {
            let mut newval = conf.boot_val;
            let extra = call_bool_check_hook(conf, &mut newval, PGC_S_DEFAULT)?;
            if publish {
                if let Some(slot) = conf.assign_hook {
                    if slot.installed() {
                        (slot.get())(newval, extra.as_deref());
                    }
                }
                if conf.variable.installed() {
                    conf.variable.write(newval);
                }
            }
            conf.value = Some(newval);
            conf.gen.extra = extra.clone();
            conf.reset_extra = extra;
        }
        GucVariable::Int(conf) => {
            let mut newval = conf.boot_val;
            let extra = call_int_check_hook(conf, &mut newval, PGC_S_DEFAULT)?;
            if publish {
                if let Some(slot) = conf.assign_hook {
                    if slot.installed() {
                        (slot.get())(newval, extra.as_deref());
                    }
                }
                if conf.variable.installed() {
                    conf.variable.write(newval);
                }
            }
            conf.value = Some(newval);
            conf.gen.extra = extra.clone();
            conf.reset_extra = extra;
        }
        GucVariable::Real(conf) => {
            let mut newval = conf.boot_val;
            let extra = call_real_check_hook(conf, &mut newval, PGC_S_DEFAULT)?;
            if publish {
                if let Some(slot) = conf.assign_hook {
                    if slot.installed() {
                        (slot.get())(newval, extra.as_deref());
                    }
                }
                if conf.variable.installed() {
                    conf.variable.write(newval);
                }
            }
            conf.value = Some(newval);
            conf.gen.extra = extra.clone();
            conf.reset_extra = extra;
        }
        GucVariable::String(conf) => {
            let mut newval = conf.boot_val.clone();
            let extra = call_string_check_hook(conf, &mut newval, PGC_S_DEFAULT)?;
            if publish {
                if let Some(slot) = conf.assign_hook {
                    if slot.installed() {
                        (slot.get())(newval.as_deref(), extra.as_deref());
                    }
                }
                if conf.variable.installed() {
                    conf.variable.write(newval.clone());
                }
            }
            conf.value = Some(newval);
            conf.gen.extra = extra.clone();
            conf.reset_extra = extra;
        }
        GucVariable::Enum(conf) => {
            let mut newval = conf.boot_val;
            let extra = call_enum_check_hook(conf, &mut newval, PGC_S_DEFAULT)?;
            if publish {
                if let Some(slot) = conf.assign_hook {
                    if slot.installed() {
                        (slot.get())(newval, extra.as_deref());
                    }
                }
                if conf.variable.installed() {
                    conf.variable.write(newval);
                }
            }
            conf.value = Some(newval);
            conf.gen.extra = extra.clone();
            conf.reset_extra = extra;
        }
    }
    Ok(())
}

// C ShowGUCOption reads *conf->variable live; read through an installed
// accessor so a direct write to the bound global (e.g. xact.c restoring
// XactReadOnly) is reflected, else the record's tracked value.
fn current_bool(c: &config_bool) -> bool {
    if c.variable.installed() {
        c.variable.read()
    } else {
        c.value.unwrap_or(c.reset_val)
    }
}
fn current_int(c: &config_int) -> i32 {
    if c.variable.installed() {
        c.variable.read()
    } else {
        c.value.unwrap_or(c.reset_val)
    }
}
fn current_real(c: &config_real) -> f64 {
    if c.variable.installed() {
        c.variable.read()
    } else {
        c.value.unwrap_or(c.reset_val)
    }
}
fn current_enum(c: &config_enum) -> i32 {
    if c.variable.installed() {
        c.variable.read()
    } else {
        c.value.unwrap_or(c.reset_val)
    }
}
fn current_string(c: &config_string) -> Option<String> {
    if c.variable.installed() {
        c.variable.read()
    } else {
        c.value.clone().unwrap_or_else(|| c.reset_val.clone())
    }
}

pub(crate) fn raw_config_value(record: &GucVariable) -> String {
    match record {
        GucVariable::Bool(conf) => if current_bool(conf) { "on" } else { "off" }.to_string(),
        GucVariable::Int(conf) => current_int(conf).to_string(),
        GucVariable::Real(conf) => fmt_g(current_real(conf)),
        GucVariable::String(conf) => current_string(conf).unwrap_or_default(),
        GucVariable::Enum(conf) => config_enum_lookup_by_value(conf, current_enum(conf))
            .unwrap_or("?")
            .to_string(),
    }
}

pub fn show_guc_option(record: &GucVariable, use_units: bool) -> String {
    match record {
        GucVariable::Bool(conf) => {
            if let Some(slot) = conf.show_hook {
                if slot.installed() {
                    return (slot.get())();
                }
            }
            if current_bool(conf) {
                "on".to_string()
            } else {
                "off".to_string()
            }
        }
        GucVariable::Int(conf) => {
            if let Some(slot) = conf.show_hook {
                if slot.installed() {
                    return (slot.get())();
                }
            }
            let mut result = current_int(conf) as i64;
            let mut unit = "";
            if use_units && result > 0 && (conf.gen.flags & GUC_UNIT) != 0 {
                let (v, u) = convert_int_from_base_unit(result, conf.gen.flags & GUC_UNIT);
                result = v;
                unit = u;
            }
            format!("{result}{unit}")
        }
        GucVariable::Real(conf) => {
            if let Some(slot) = conf.show_hook {
                if slot.installed() {
                    return (slot.get())();
                }
            }
            let mut result = current_real(conf);
            let mut unit = "";
            if use_units && result > 0.0 && (conf.gen.flags & GUC_UNIT) != 0 {
                let (v, u) = convert_real_from_base_unit(result, conf.gen.flags & GUC_UNIT);
                result = v;
                unit = u;
            }
            format!("{}{unit}", fmt_g(result))
        }
        GucVariable::String(conf) => {
            if let Some(slot) = conf.show_hook {
                if slot.installed() {
                    return (slot.get())();
                }
            }
            current_string(conf)
                .filter(|s| !s.is_empty())
                .unwrap_or_default()
        }
        GucVariable::Enum(conf) => {
            if let Some(slot) = conf.show_hook {
                if slot.installed() {
                    return (slot.get())();
                }
            }
            config_enum_lookup_by_value(conf, current_enum(conf))
                .unwrap_or("?")
                .to_string()
        }
    }
}

pub fn reset_value_string(record: &GucVariable) -> Option<String> {
    Some(match record {
        GucVariable::Bool(c) => {
            if c.reset_val {
                "on".to_string()
            } else {
                "off".to_string()
            }
        }
        GucVariable::Int(c) => format!("{}", c.reset_val),
        GucVariable::Real(c) => fmt_g(c.reset_val),
        GucVariable::String(c) => c.reset_val.clone()?,
        GucVariable::Enum(c) => config_enum_lookup_by_value(c, c.reset_val)?.to_string(),
    })
}

// get_explain_guc_options (guc.c): GUC_EXPLAIN vars whose current value
// differs from boot_val, as (name, GetConfigOptionByName value), in
// guc_nondef_list order (guc.c:5351: the order the vars first left
// PGC_S_DEFAULT — the Settings line is printed in it). `visible` is
// ConfigOptionIsVisible (lives with the ACL deps).
pub fn get_explain_guc_options<'r>(
    reg: &'r GucRegistry,
    visible: &mut dyn FnMut(&GucVariable) -> PgResult<bool>,
) -> PgResult<Vec<(&'r str, Option<String>)>> {
    let mut out = Vec::new();
    for idx in reg.nondef.iter() {
        let conf = &reg.vars[idx];
        let gen = conf.gen();
        if gen.flags & types_guc::GUC_EXPLAIN == 0 {
            continue;
        }
        if !visible(conf)? {
            continue;
        }
        let modified = match conf {
            GucVariable::Bool(c) => current_bool(c) != c.boot_val,
            GucVariable::Int(c) => current_int(c) != c.boot_val,
            GucVariable::Real(c) => current_real(c) != c.boot_val,
            GucVariable::String(c) => match (&c.boot_val, current_string(c)) {
                (None, None) => false,
                (None, Some(_)) | (Some(_), None) => true,
                (Some(b), Some(v)) => *b != v,
            },
            GucVariable::Enum(c) => current_enum(c) != c.boot_val,
        };
        if !modified {
            continue;
        }
        out.push((gen.name.as_ref(), Some(show_guc_option(conf, true))));
    }
    Ok(out)
}

pub fn get_config_option_by_name(
    reg: &GucRegistry,
    name: &str,
    missing_ok: bool,
) -> PgResult<Option<String>> {
    match reg.find_option(name) {
        Some(record) => {
            // C: GetConfigOptionByName (guc.c) always restricts privileged
            // reads — ConfigOptionIsVisible (guc_funcs.c): GUC_SUPERUSER_ONLY
            // needs has_privs_of_role(GetUserId(), ROLE_PG_READ_ALL_SETTINGS).
            if record.gen().flags & types_guc::GUC_SUPERUSER_ONLY != 0
                && !acl_seams::has_privs_of_role::call(
                    miscinit::GetUserId(),
                    crate::ROLE_PG_READ_ALL_SETTINGS,
                )?
            {
                return Err(ereport(ERROR)
                    .errcode(ERRCODE_INSUFFICIENT_PRIVILEGE)
                    .errmsg(format!("permission denied to examine \"{name}\""))
                    .errdetail(
                        "Only roles with privileges of the \"pg_read_all_settings\" role may examine this parameter.",
                    )
                    .into_error()
                    .into());
            }
            Ok(Some(show_guc_option(record, true)))
        }
        None if missing_ok => Ok(None),
        None => Err(unrecognized(name).into()),
    }
}

pub fn get_config_option_flags(reg: &GucRegistry, name: &str, missing_ok: bool) -> PgResult<i32> {
    match reg.find_option(name) {
        Some(record) => Ok(record.gen().flags),
        None if missing_ok => Ok(0),
        None => Err(unrecognized(name).into()),
    }
}

#[cold]
fn unrecognized(name: &str) -> PgError {
    err(
        ERRCODE_UNDEFINED_OBJECT,
        format!("unrecognized configuration parameter \"{name}\""),
    )
}

pub type DeferredAssignHook = Box<dyn FnOnce()>;

pub struct SetConfigPrep {
    idx: usize,
    pub(crate) elevel: ErrorLevel,
    change_val: bool,
    make_default: bool,
}

pub enum SetConfigPrepared {
    Done(PgResult<i32>),
    Pending(SetConfigPrep),
}

// set_config_with_handle (guc.c:3405) up to the value step. Ok(1) applied, Ok(0)
// rejected-below-ERROR, Ok(-1) skipped; Err when the resolved elevel is ERROR.
#[allow(clippy::too_many_arguments)]
pub fn set_config_option_prepare(
    reg: &mut GucRegistry,
    name: &str,
    value: Option<&str>,
    context: GucContext,
    source: GucSource,
    srole: Oid,
    action: GucAction,
    change_val: bool,
    elevel: ErrorLevel,
    is_reload: bool,
) -> SetConfigPrepared {
    let elevel = resolve_elevel(elevel, source);

    // find_option(name, create_placeholders=true, skip_errors=false, elevel).
    let idx = match reg.find_index(name) {
        Some(idx) => idx,
        None => match crate::assignable_custom_variable_name(name, false) {
            Ok(true) => match reg.add_placeholder_variable(name) {
                Ok(idx) => idx,
                Err(e) => return SetConfigPrepared::Done(reject(elevel, *e)),
            },
            Ok(false) => return SetConfigPrepared::Done(Ok(0)),
            Err(e) => return SetConfigPrepared::Done(reject(elevel, *e)),
        },
    };

    let access = match check_can_set(
        reg.vars[idx].gen(),
        value.is_none(),
        context,
        source,
        srole,
        action,
        change_val,
        is_reload,
    ) {
        Ok(access) => access,
        Err(e) => return SetConfigPrepared::Done(Err(e)),
    };
    match access {
        AccessCheck::Ok => {}
        AccessCheck::Skip => return SetConfigPrepared::Done(Ok(-1)),
        AccessCheck::Reject(e) => return SetConfigPrepared::Done(reject(elevel, e)),
    }

    let make_default =
        change_val && (source <= PGC_S_OVERRIDE) && (value.is_some() || source == PGC_S_DEFAULT);

    // Ignore attempted set if overridden by previously processed setting.
    let mut change_val = change_val;
    if reg.vars[idx].gen().source > source {
        if change_val && !make_default {
            return SetConfigPrepared::Done(Ok(-1));
        }
        change_val = false;
    }

    SetConfigPrepared::Pending(SetConfigPrep { idx, elevel, change_val, make_default })
}

// Value step, store borrowed shared: check_datestyle reads the reset value.
pub fn set_config_option_value(
    reg: &GucRegistry,
    prep: &SetConfigPrep,
    value: Option<&str>,
    source: GucSource,
) -> PgResult<(config_var_val, Option<SharedExtra>)> {
    let record = &reg.vars[prep.idx];
    match value {
        Some(v) => parse_and_validate_value(record, v, source),
        None if source == PGC_S_DEFAULT => boot_default_value(record, source),
        None => Ok(reset_value_and_extra(record)),
    }
}

// The apply step of set_config_with_handle (guc.c:3961 onward).
#[allow(clippy::too_many_arguments)]
pub fn set_config_option_apply(
    reg: &mut GucRegistry,
    prep: SetConfigPrep,
    name: &str,
    value: Option<&str>,
    newval: config_var_val,
    newextra: Option<SharedExtra>,
    context: GucContext,
    source: GucSource,
    srole: Oid,
    action: GucAction,
    is_reload: bool,
    deferred_hooks: &mut Vec<DeferredAssignHook>,
) -> PgResult<i32> {
    let SetConfigPrep { idx, elevel, change_val, make_default } = prep;

    // Originals for the session_authorization -> role kluge below.
    let orig_context = context;
    let orig_source = source;
    let orig_srole = srole;

    let (source, context, srole) = if value.is_none() && source != PGC_S_DEFAULT {
        let gen = reg.vars[idx].gen();
        (gen.reset_source, gen.reset_scontext, gen.reset_srole)
    } else {
        (source, context, srole)
    };

    // Re-reading a PGC_POSTMASTER variable from postgresql.conf under SIGHUP.
    let prohibit_value_change =
        reg.vars[idx].gen().context == PGC_POSTMASTER && orig_context == PGC_SIGHUP;
    if prohibit_value_change {
        if current_value_differs(&reg.vars[idx], &newval) {
            reg.vars[idx].gen_mut().status |= GUC_PENDING_RESTART;
            let cname = reg.vars[idx].gen().name.as_ref();
            return reject(
                elevel,
                err(
                    ERRCODE_CANT_CHANGE_RUNTIME_PARAM,
                    format!("parameter \"{cname}\" cannot be changed without restarting the server"),
                ),
            );
        }
        reg.vars[idx].gen_mut().status &= !GUC_PENDING_RESTART;
        return Ok(-1);
    }

    let make_default_extra = if make_default { newextra.clone() } else { None };
    if change_val {
        let record = &mut reg.vars[idx];
        let mut newly_stacked = false;
        if !make_default {
            let was_empty = record.gen().stack.is_none();
            push_old_value(record, action);
            newly_stacked = was_empty && record.gen().stack.is_some();
        }
        if let Some(hook) = apply_value(record, newval.clone(), newextra, context, srole) {
            deferred_hooks.push(hook);
        }
        reg.set_source(idx, source);
        if newly_stacked {
            reg.note_stacked(idx);
        }

        // Ugly hack (guc.c:4116): SET session_authorization forces SET ROLE
        // NONE with the same lifetime; deferred past the store borrow like the
        // assign hooks (it re-enters set_config_option_global).
        if !is_reload && guc_name_eq(name, "session_authorization") {
            let role_value: Option<&'static str> =
                if value.is_some() { Some("none") } else { None };
            let role_source = if orig_source == PGC_S_OVERRIDE {
                PGC_S_DYNAMIC_DEFAULT
            } else {
                orig_source
            };
            deferred_hooks.push(Box::new(move || {
                let _ = crate::store::set_config_option_global(
                    "role",
                    role_value,
                    orig_context,
                    role_source,
                    orig_srole,
                    action,
                    true,
                    elevel,
                    false,
                );
            }));
        }
    }
    if make_default {
        make_default_bookkeeping(
            &mut reg.vars[idx],
            &newval,
            make_default_extra,
            source,
            context,
            srole,
        );
    }

    // The guc_report_list link of every C set-site (guc.c:4267).
    if change_val {
        note_reportable_after_hooks(reg, idx, deferred_hooks);
    }

    Ok(if change_val { 1 } else { -1 })
}

fn boot_default_value(
    record: &GucVariable,
    source: GucSource,
) -> PgResult<(config_var_val, Option<SharedExtra>)> {
    match record {
        GucVariable::Bool(c) => {
            let mut v = c.boot_val;
            let extra = call_bool_check_hook(c, &mut v, source)?;
            Ok((config_var_val::Boolval(v), extra))
        }
        GucVariable::Int(c) => {
            let mut v = c.boot_val;
            let extra = call_int_check_hook(c, &mut v, source)?;
            Ok((config_var_val::Intval(v), extra))
        }
        GucVariable::Real(c) => {
            let mut v = c.boot_val;
            let extra = call_real_check_hook(c, &mut v, source)?;
            Ok((config_var_val::Realval(v), extra))
        }
        GucVariable::String(c) => {
            let mut v = c.boot_val.clone();
            let extra = call_string_check_hook(c, &mut v, source)?;
            Ok((config_var_val::Stringval(v), extra))
        }
        GucVariable::Enum(c) => {
            let mut v = c.boot_val;
            let extra = call_enum_check_hook(c, &mut v, source)?;
            Ok((config_var_val::Enumval(v), extra))
        }
    }
}

// One leader GUC captured for a thread-native parallel worker (§3.4 P-guc):
// the leader-validated value plus its check-hook extra cross by pointer, so
// the worker never reruns check hooks (C contract: check hooks are pure
// validators — all session side effects live in the assign hooks, which DO
// rerun on the worker thread against the shared extra).
pub struct CapturedGuc {
    name: String,
    val: config_var_val,
    extra: Option<SharedExtra>,
    scontext: GucContext,
    source: GucSource,
    srole: Oid,
    // set_config_sourcefile's record (pg_settings.sourcefile/sourceline): C
    // backends inherit it from the postmaster at fork; the base snapshot is
    // pgrust's fork, so it travels with the value.
    sourcefile: Option<String>,
    sourceline: i32,
    // GUC_PENDING_RESTART is fork-inherited status (guc.c set_config_option
    // sets it in the postmaster; every later child reports it).
    pending_restart: bool,
}

impl CapturedGuc {
    pub fn name(&self) -> &str {
        &self.name
    }

    pub fn source(&self) -> GucSource {
        self.source
    }

    pub fn pending_restart(&self) -> bool {
        self.pending_restart
    }

    /// The leader's validated check-hook extra, shared by pointer (carry.rs hands it to a claim thread's assign hook).
    pub(crate) fn extra(&self) -> Option<&SharedExtra> {
        self.extra.as_ref()
    }

    /// The captured (leader-validated) value. Snapshot consumers diff on this
    /// — never on a live process-global backing (the reload dead-diff hazard,
    /// guc::layers).
    pub fn value(&self) -> &config_var_val {
        &self.val
    }

    /// Conservative content equality for the pin re-mint dedup
    /// (layers::current_query_pin): true only when binding `self` and
    /// binding `other` are indistinguishable to a worker. `extra` compares
    /// by Arc identity (a content-equal but re-minted hook extra is a dedup
    /// MISS, never a false hit — int/bool/enum vars, the SET-churn
    /// clientele, carry no extra).
    pub(crate) fn content_eq(&self, other: &Self) -> bool {
        self.name == other.name
            && self.val == other.val
            && self.scontext == other.scontext
            && self.source == other.source
            && self.srole == other.srole
            && match (&self.extra, &other.extra) {
                (None, None) => true,
                (Some(a), Some(b)) => std::sync::Arc::ptr_eq(a, b),
                _ => false,
            }
    }
}

fn current_value(record: &GucVariable) -> config_var_val {
    match record {
        GucVariable::Bool(c) => config_var_val::Boolval(current_bool(c)),
        GucVariable::Int(c) => config_var_val::Intval(current_int(c)),
        GucVariable::Real(c) => config_var_val::Realval(current_real(c)),
        GucVariable::String(c) => config_var_val::Stringval(current_string(c)),
        GucVariable::Enum(c) => config_var_val::Enumval(current_enum(c)),
    }
}

fn stored_value(record: &GucVariable) -> config_var_val {
    match record {
        GucVariable::Bool(c) => config_var_val::Boolval(c.value.unwrap_or(c.boot_val)),
        GucVariable::Int(c) => config_var_val::Intval(c.value.unwrap_or(c.boot_val)),
        GucVariable::Real(c) => config_var_val::Realval(c.value.unwrap_or(c.boot_val)),
        GucVariable::String(c) => {
            config_var_val::Stringval(c.value.clone().unwrap_or_else(|| c.boot_val.clone()))
        }
        GucVariable::Enum(c) => config_var_val::Enumval(c.value.unwrap_or(c.boot_val)),
    }
}

pub(crate) fn clone_current_state(reg: &GucRegistry) -> GucRegistry {
    let mut cloned = reg.clone();
    for (dst, src) in cloned.vars.iter_mut().zip(&reg.vars) {
        let value = current_value(src);
        match (dst, value) {
            (GucVariable::Bool(c), config_var_val::Boolval(v)) => c.value = Some(v),
            (GucVariable::Int(c), config_var_val::Intval(v)) => c.value = Some(v),
            (GucVariable::Real(c), config_var_val::Realval(v)) => c.value = Some(v),
            (GucVariable::String(c), config_var_val::Stringval(v)) => c.value = Some(v),
            (GucVariable::Enum(c), config_var_val::Enumval(v)) => c.value = Some(v),
            _ => unreachable!("GUC registry clone changed variable type"),
        }
    }
    cloned
}

pub(crate) fn activate_current_values(
    reg: &mut GucRegistry,
    deferred_hooks: &mut Vec<DeferredAssignHook>,
) {
    for record in &mut reg.vars {
        let value = stored_value(record);
        if !current_value_differs(record, &value) {
            continue;
        }
        let gen = record.gen();
        let extra = gen.extra.clone();
        let context = gen.scontext;
        let role = gen.srole;
        if let Some(hook) = apply_value(record, value, extra, context, role) {
            deferred_hooks.push(hook);
        }
    }
}

// SerializeGUCState, typed: same variable set as capture_nondefault_variables
// (both sides of a launch share the postmaster snapshot as baseline, so
// nondefault-only transfers the whole leader/worker difference).
// Captured in guc_nondef_list order (guc.c:5684 write_nondefault_variables),
// so a child's own nondef list, and its EXPLAIN (SETTINGS) line, keep the
// order the variables first left PGC_S_DEFAULT.
pub(crate) fn capture_session_gucs(reg: &GucRegistry) -> Vec<CapturedGuc> {
    reg.nondef
        .iter()
        .map(|idx| &reg.vars[idx])
        .filter(|v| {
            v.gen().source != PGC_S_DEFAULT && v.gen().status & crate::model::GUC_REMOVED == 0
        })
        .chain(reg.iter().filter(|v| {
            v.gen().source == PGC_S_DEFAULT && v.gen().status & GUC_PENDING_RESTART != 0
        }))
        .map(|v| CapturedGuc {
            name: v.name().to_string(),
            val: current_value(v),
            extra: v.gen().extra.clone(),
            scontext: v.gen().scontext,
            source: v.gen().source,
            srole: v.gen().srole,
            sourcefile: v.gen().sourcefile.clone(),
            sourceline: v.gen().sourceline,
            pending_restart: v.gen().status & GUC_PENDING_RESTART != 0,
        })
        .collect()
}

// RestoreGUCState for one variable, minus only the parse + check-hook rerun:
// the guard sequence (check_can_set with is_reload semantics, source
// priority, PGC_POSTMASTER reload prohibition) and the end-state writes
// (value, extra, source, scontext, srole, reset_* for source <=
// PGC_S_OVERRIDE, transaction stack push above it, report marking) follow
// set_config_option(value, GUC_ACTION_SET, is_reload=true) exactly.
pub(crate) fn bind_captured_guc(
    reg: &mut GucRegistry,
    cap: &CapturedGuc,
    deferred_hooks: &mut Vec<DeferredAssignHook>,
    exact: bool,
) -> PgResult<()> {
    let elevel = resolve_elevel(ErrorLevel(0), cap.source);
    let idx = match reg.find_index(&cap.name) {
        Some(idx) => idx,
        None => match crate::assignable_custom_variable_name(&cap.name, false) {
            Ok(true) => match reg.add_placeholder_variable(&cap.name) {
                Ok(idx) => idx,
                Err(e) => return reject(elevel, *e).map(drop),
            },
            Ok(false) => return Ok(()),
            Err(e) => return reject(elevel, *e).map(drop),
        },
    };

    if cap.pending_restart {
        reg.vars[idx].gen_mut().status |= GUC_PENDING_RESTART;
    }
    if cap.source == PGC_S_DEFAULT {
        return Ok(());
    }

    match check_can_set(
        reg.vars[idx].gen(),
        false,
        cap.scontext,
        cap.source,
        cap.srole,
        GUC_ACTION_SET,
        true,
        true,
    )? {
        AccessCheck::Ok => {}
        AccessCheck::Skip => return Ok(()),
        AccessCheck::Reject(e) => return reject(elevel, e).map(drop),
    }

    let make_default = cap.source <= PGC_S_OVERRIDE;
    let mut change_val = true;
    if !exact && reg.vars[idx].gen().source > cap.source {
        if !make_default {
            return Ok(());
        }
        change_val = false;
    }

    if reg.vars[idx].gen().context == PGC_POSTMASTER && cap.scontext == PGC_SIGHUP {
        if current_value_differs(&reg.vars[idx], &cap.val) {
            reg.vars[idx].gen_mut().status |= GUC_PENDING_RESTART;
            return reject(
                elevel,
                err(
                    ERRCODE_CANT_CHANGE_RUNTIME_PARAM,
                    format!(
                        "parameter \"{}\" cannot be changed without restarting the server",
                        cap.name
                    ),
                ),
            )
            .map(drop);
        }
        reg.vars[idx].gen_mut().status &= !GUC_PENDING_RESTART;
        return Ok(());
    }

    if change_val {
        let record = &mut reg.vars[idx];
        let mut newly_stacked = false;
        if !make_default {
            let was_empty = record.gen().stack.is_none();
            push_old_value(record, GUC_ACTION_SET);
            newly_stacked = was_empty && record.gen().stack.is_some();
        }
        if let Some(hook) = apply_value(
            record,
            cap.val.clone(),
            cap.extra.clone(),
            cap.scontext,
            cap.srole,
        ) {
            deferred_hooks.push(hook);
        }
        reg.set_source(idx, cap.source);
        if newly_stacked {
            reg.note_stacked(idx);
        }
        // guc.c set_config_sourcefile, as the postmaster's ProcessConfigFile
        // pass recorded it (F3: pg_settings.sourcefile was NULL on every
        // backend because the snapshot carried the value without it).
        if let Some(file) = &cap.sourcefile {
            let gen = reg.vars[idx].gen_mut();
            gen.sourcefile = Some(file.clone());
            gen.sourceline = cap.sourceline;
        }
    }
    if make_default {
        make_default_bookkeeping(
            &mut reg.vars[idx],
            &cap.val,
            cap.extra.clone(),
            cap.source,
            cap.scontext,
            cap.srole,
        );
    }
    if change_val {
        reg.note_reportable(idx);
    }
    Ok(())
}

fn reset_value_and_extra(record: &GucVariable) -> (config_var_val, Option<SharedExtra>) {
    match record {
        GucVariable::Bool(c) => (config_var_val::Boolval(c.reset_val), c.reset_extra.clone()),
        GucVariable::Int(c) => (config_var_val::Intval(c.reset_val), c.reset_extra.clone()),
        GucVariable::Real(c) => (config_var_val::Realval(c.reset_val), c.reset_extra.clone()),
        GucVariable::String(c) => (
            config_var_val::Stringval(c.reset_val.clone()),
            c.reset_extra.clone(),
        ),
        GucVariable::Enum(c) => (config_var_val::Enumval(c.reset_val), c.reset_extra.clone()),
    }
}

fn current_value_differs(record: &GucVariable, newval: &config_var_val) -> bool {
    match (record, newval) {
        (GucVariable::Bool(c), config_var_val::Boolval(nv)) => current_bool(c) != *nv,
        (GucVariable::Int(c), config_var_val::Intval(nv)) => current_int(c) != *nv,
        (GucVariable::Real(c), config_var_val::Realval(nv)) => current_real(c) != *nv,
        (GucVariable::Enum(c), config_var_val::Enumval(nv)) => current_enum(c) != *nv,
        (GucVariable::String(c), config_var_val::Stringval(nv)) => match (current_string(c), nv) {
            (Some(a), Some(b)) => a != *b,
            (None, None) => false,
            _ => true,
        },
        _ => true,
    }
}

// C fires the assign hook, then writes *conf->variable (guc.c:3759). The hook
// is deferred past the store borrow (a hook may recursively re-enter
// set_config_option: assign_session_authorization -> SetOuterUserId ->
// SetConfigOption("is_superuser"), which would re-borrow the RefCell store), so
// the backing write is deferred with it to keep C's order: a hook still sees
// the old value in its variable.
fn defer_assign<T: Copy + 'static>(
    variable: &'static guc_tables::GucSlot<guc_tables::GucVarAccessors<T>>,
    hook: Option<fn(T, Option<&GucHookExtra>)>,
    v: T,
    extra: Option<SharedExtra>,
) -> Option<DeferredAssignHook> {
    match hook {
        Some(f) => Some(Box::new(move || {
            f(v, extra.as_deref());
            if variable.installed() {
                variable.write(v);
            }
        }) as DeferredAssignHook),
        None => {
            if variable.installed() {
                variable.write(v);
            }
            None
        }
    }
}

fn apply_value(
    record: &mut GucVariable,
    newval: config_var_val,
    extra: Option<SharedExtra>,
    context: GucContext,
    srole: Oid,
) -> Option<DeferredAssignHook> {
    let deferred: Option<DeferredAssignHook> = match (&mut *record, newval) {
        (GucVariable::Bool(c), config_var_val::Boolval(v)) => {
            c.value = Some(v);
            defer_assign(c.variable, installed_hook(c.assign_hook), v, extra.clone())
        }
        (GucVariable::Int(c), config_var_val::Intval(v)) => {
            c.value = Some(v);
            defer_assign(c.variable, installed_hook(c.assign_hook), v, extra.clone())
        }
        (GucVariable::Real(c), config_var_val::Realval(v)) => {
            c.value = Some(v);
            defer_assign(c.variable, installed_hook(c.assign_hook), v, extra.clone())
        }
        (GucVariable::String(c), config_var_val::Stringval(s)) => {
            c.value = Some(s.clone());
            let variable = c.variable;
            match installed_hook(c.assign_hook) {
                Some(f) => {
                    let extra = extra.clone();
                    Some(Box::new(move || {
                        f(s.as_deref(), extra.as_deref());
                        if variable.installed() {
                            variable.write(s);
                        }
                    }) as DeferredAssignHook)
                }
                None => {
                    if variable.installed() {
                        variable.write(s);
                    }
                    None
                }
            }
        }
        (GucVariable::Enum(c), config_var_val::Enumval(v)) => {
            c.value = Some(v);
            defer_assign(c.variable, installed_hook(c.assign_hook), v, extra.clone())
        }
        _ => None,
    };

    let gen = record.gen_mut();
    gen.extra = extra;
    gen.scontext = context;
    gen.srole = srole;
    // gen.source is set by the caller through GucRegistry::set_source.

    deferred
}

// apply_value's store half: the value and its provenance, without the assign
// hook or the backing write (publish_later hands those back).
fn store_value(
    record: &mut GucVariable,
    newval: config_var_val,
    extra: Option<SharedExtra>,
    context: GucContext,
    srole: Oid,
) {
    match (&mut *record, newval) {
        (GucVariable::Bool(c), config_var_val::Boolval(v)) => c.value = Some(v),
        (GucVariable::Int(c), config_var_val::Intval(v)) => c.value = Some(v),
        (GucVariable::Real(c), config_var_val::Realval(v)) => c.value = Some(v),
        (GucVariable::String(c), config_var_val::Stringval(s)) => c.value = Some(s),
        (GucVariable::Enum(c), config_var_val::Enumval(v)) => c.value = Some(v),
        _ => {}
    }
    let gen = record.gen_mut();
    gen.extra = extra;
    gen.scontext = context;
    gen.srole = srole;
}

// apply_value's publish half for the variable's current store value: its
// assign hook, then the backing write (C's order, guc.c:3759), as one closure
// that the caller runs later or drops. None when there is neither.
fn publish_later(record: &GucVariable) -> Option<DeferredAssignHook> {
    fn scalar<T: Copy + 'static>(
        variable: &'static guc_tables::GucSlot<guc_tables::GucVarAccessors<T>>,
        hook: Option<fn(T, Option<&GucHookExtra>)>,
        v: Option<T>,
        extra: Option<SharedExtra>,
    ) -> Option<DeferredAssignHook> {
        let v = v?;
        if hook.is_none() && !variable.installed() {
            return None;
        }
        Some(Box::new(move || {
            if let Some(f) = hook {
                f(v, extra.as_deref());
            }
            if variable.installed() {
                variable.write(v);
            }
        }))
    }
    let extra = record.gen().extra.clone();
    match record {
        GucVariable::Bool(c) => scalar(c.variable, installed_hook(c.assign_hook), c.value, extra),
        GucVariable::Int(c) => scalar(c.variable, installed_hook(c.assign_hook), c.value, extra),
        GucVariable::Real(c) => scalar(c.variable, installed_hook(c.assign_hook), c.value, extra),
        GucVariable::Enum(c) => scalar(c.variable, installed_hook(c.assign_hook), c.value, extra),
        GucVariable::String(c) => {
            let s = c.value.clone()?;
            let variable = c.variable;
            let hook = installed_hook(c.assign_hook);
            if hook.is_none() && !variable.installed() {
                return None;
            }
            Some(Box::new(move || {
                if let Some(f) = hook {
                    f(s.as_deref(), extra.as_deref());
                }
                if variable.installed() {
                    variable.write(s);
                }
            }))
        }
    }
}

pub(crate) fn installed_hook<T: Copy + 'static>(slot: Option<&'static guc_tables::GucSlot<T>>) -> Option<T> {
    let slot = slot?;
    if slot.installed() {
        Some(slot.get())
    } else {
        None
    }
}

fn make_default_bookkeeping(
    record: &mut GucVariable,
    newval: &config_var_val,
    extra: Option<SharedExtra>,
    source: GucSource,
    context: GucContext,
    srole: Oid,
) {
    if record.gen().reset_source <= source {
        match (&mut *record, newval) {
            (GucVariable::Bool(c), config_var_val::Boolval(v)) => {
                c.reset_val = *v;
                c.reset_extra = extra.clone();
            }
            (GucVariable::Int(c), config_var_val::Intval(v)) => {
                c.reset_val = *v;
                c.reset_extra = extra.clone();
            }
            (GucVariable::Real(c), config_var_val::Realval(v)) => {
                c.reset_val = *v;
                c.reset_extra = extra.clone();
            }
            (GucVariable::String(c), config_var_val::Stringval(v)) => {
                c.reset_val = v.clone();
                c.reset_extra = extra.clone();
            }
            (GucVariable::Enum(c), config_var_val::Enumval(v)) => {
                c.reset_val = *v;
                c.reset_extra = extra.clone();
            }
            _ => return,
        }
        let gen = record.gen_mut();
        gen.reset_source = source;
        gen.reset_scontext = context;
        gen.reset_srole = srole;
    }
    let mut stack = record.gen_mut().stack.as_deref_mut();
    while let Some(s) = stack {
        if s.source <= source {
            s.prior.val = Some(newval.clone());
            s.prior.extra = extra.clone();
            s.source = source;
            s.scontext = context;
            s.srole = srole;
        }
        stack = s.prev.as_deref_mut();
    }
}

// set_stack_value (guc.c:812).
fn set_stack_value(record: &GucVariable, val: &mut config_var_value) {
    val.val = Some(match record {
        GucVariable::Bool(c) => config_var_val::Boolval(current_bool(c)),
        GucVariable::Int(c) => config_var_val::Intval(current_int(c)),
        GucVariable::Real(c) => config_var_val::Realval(current_real(c)),
        GucVariable::String(c) => config_var_val::Stringval(current_string(c)),
        GucVariable::Enum(c) => config_var_val::Enumval(current_enum(c)),
    });
    val.extra = record.gen().extra.clone();
}

fn discard_stack_value(val: &mut config_var_value) {
    val.val = None;
    val.extra = None;
}

// push_old_value (guc.c:2134).
fn push_old_value(record: &mut GucVariable, action: GucAction) {
    let nest_level = crate::guc_nest_level();
    if nest_level == 0 {
        return;
    }

    let has_current = record
        .gen()
        .stack
        .as_ref()
        .is_some_and(|s| s.nest_level >= nest_level);
    if has_current {
        let masked_snapshot = if action == GUC_ACTION_LOCAL {
            let mut v = config_var_value::default();
            set_stack_value(record, &mut v);
            Some((record.gen().scontext, record.gen().srole, v))
        } else {
            None
        };
        let stack = record.gen_mut().stack.as_mut().unwrap();
        debug_assert!(stack.nest_level == nest_level);
        match action {
            GUC_ACTION_SET => {
                if stack.state == GUC_SET_LOCAL {
                    discard_stack_value(&mut stack.masked);
                }
                stack.state = GUC_SET;
            }
            GUC_ACTION_LOCAL => {
                if stack.state == GUC_SET {
                    let (sc, sr, v) = masked_snapshot.unwrap();
                    stack.masked_scontext = sc;
                    stack.masked_srole = sr;
                    stack.masked = v;
                    stack.state = GUC_SET_LOCAL;
                }
            }
            _ => {
                debug_assert!(stack.state == GUC_SAVE);
            }
        }
        return;
    }

    let mut prior = config_var_value::default();
    set_stack_value(record, &mut prior);

    let gen = record.gen_mut();
    let prev = gen.stack.take();
    let state = match action {
        GUC_ACTION_SET => GUC_SET,
        GUC_ACTION_LOCAL => GUC_LOCAL,
        _ => GUC_SAVE,
    };
    gen.stack = Some(Box::new(GucStack {
        prev,
        nest_level,
        state,
        source: gen.source,
        scontext: gen.scontext,
        masked_scontext: gen.scontext,
        srole: gen.srole,
        masked_srole: gen.srole,
        prior,
        masked: config_var_value::default(),
    }));
}

fn restore_stacked_value(
    record: &mut GucVariable,
    newvalue: &config_var_value,
    pending_restore: bool,
    deferred_hooks: &mut Vec<DeferredAssignHook>,
) -> bool {
    let newextra = newvalue.extra.clone();
    // Earlier pops may have queued backing writes that have not run yet.
    let mut changed = false;
    match (record, newvalue.val.as_ref()) {
        (GucVariable::Bool(c), Some(config_var_val::Boolval(nv))) => {
            let current = if pending_restore { c.value.unwrap() } else { current_bool(c) };
            if current != *nv || extra_differs(&c.gen.extra, &newextra) {
                c.value = Some(*nv);
                if let Some(hook) = defer_assign(
                    c.variable,
                    installed_hook(c.assign_hook),
                    *nv,
                    newextra.clone(),
                ) {
                    deferred_hooks.push(hook);
                }
                c.gen.extra = newextra;
                changed = true;
            }
        }
        (GucVariable::Int(c), Some(config_var_val::Intval(nv))) => {
            let current = if pending_restore { c.value.unwrap() } else { current_int(c) };
            if current != *nv || extra_differs(&c.gen.extra, &newextra) {
                c.value = Some(*nv);
                if let Some(hook) = defer_assign(
                    c.variable,
                    installed_hook(c.assign_hook),
                    *nv,
                    newextra.clone(),
                ) {
                    deferred_hooks.push(hook);
                }
                c.gen.extra = newextra;
                changed = true;
            }
        }
        (GucVariable::Real(c), Some(config_var_val::Realval(nv))) => {
            let current = if pending_restore { c.value.unwrap() } else { current_real(c) };
            if current != *nv || extra_differs(&c.gen.extra, &newextra) {
                c.value = Some(*nv);
                if let Some(hook) = defer_assign(
                    c.variable,
                    installed_hook(c.assign_hook),
                    *nv,
                    newextra.clone(),
                ) {
                    deferred_hooks.push(hook);
                }
                c.gen.extra = newextra;
                changed = true;
            }
        }
        (GucVariable::String(c), Some(config_var_val::Stringval(nv))) => {
            let current = if pending_restore { c.value.clone().unwrap() } else { current_string(c) };
            let differs = match (current, nv) {
                (Some(a), Some(b)) => a != *b,
                (None, None) => false,
                _ => true,
            };
            if differs || extra_differs(&c.gen.extra, &newextra) {
                if let Some(f) = installed_hook(c.assign_hook) {
                    let s = nv.clone();
                    let extra = newextra.clone();
                    let variable = c.variable;
                    deferred_hooks.push(Box::new(move || {
                        f(s.as_deref(), extra.as_deref());
                        if variable.installed() {
                            variable.write(s);
                        }
                    }));
                } else if c.variable.installed() {
                    c.variable.write(nv.clone());
                }
                c.value = Some(nv.clone());
                c.gen.extra = newextra;
                changed = true;
            }
        }
        (GucVariable::Enum(c), Some(config_var_val::Enumval(nv))) => {
            let current = if pending_restore { c.value.unwrap() } else { current_enum(c) };
            if current != *nv || extra_differs(&c.gen.extra, &newextra) {
                c.value = Some(*nv);
                if let Some(hook) = defer_assign(
                    c.variable,
                    installed_hook(c.assign_hook),
                    *nv,
                    newextra.clone(),
                ) {
                    deferred_hooks.push(hook);
                }
                c.gen.extra = newextra;
                changed = true;
            }
        }
        _ => {}
    }
    changed
}

// C compares extra pointers; Rc gives pointer identity back.
fn extra_differs(cur: &Option<SharedExtra>, new: &Option<SharedExtra>) -> bool {
    match (cur, new) {
        (Some(a), Some(b)) => !std::sync::Arc::ptr_eq(a, b),
        (None, None) => false,
        _ => true,
    }
}

// The per-variable walk of AtEOXact_GUC (guc.c:2262); the caller owns the
// GUCNestLevel update.
pub fn at_eoxact_guc(
    reg: &mut GucRegistry,
    is_commit: bool,
    nest_level: i32,
    deferred_hooks: &mut Vec<DeferredAssignHook>,
) {
    debug_assert!(nest_level > 0);
    let indices = core::mem::take(&mut reg.stacked);
    let mut kept: Vec<usize> = Vec::new();
    let _ = kept.try_reserve(indices.len());
    // guc_stack_list is head-pushed and walked newest-first (guc.c:2206,
    // 2276); `stacked` is oldest-first.
    for idx in indices.into_iter().rev() {
        let (changed, newsource) =
            pop_var_stack(&mut reg.vars[idx], is_commit, nest_level, deferred_hooks);
        if let Some(src) = newsource {
            reg.set_source(idx, src);
        }
        if changed && reg.vars[idx].gen().flags & GUC_REPORT != 0 {
            note_reportable_after_hooks(reg, idx, deferred_hooks);
        }
        if reg.vars[idx].gen().stack.is_some() {
            kept.push(idx);
        }
    }
    kept.reverse();
    reg.stacked = kept;
}

// C links a variable into guc_report_list after its assign hook ran
// (guc.c:2533, 4267), so a hook's nested report is sent first.
fn note_reportable_after_hooks(
    reg: &mut GucRegistry,
    idx: usize,
    deferred_hooks: &mut Vec<DeferredAssignHook>,
) {
    if deferred_hooks.is_empty() {
        reg.note_reportable(idx);
    } else {
        deferred_hooks.push(Box::new(move || {
            crate::store::with_store_mut(|r| r.note_reportable(idx));
        }));
    }
}

// The stack-popping loop body. Returns (value changed at any level, the last
// restored source if any restore happened).
fn pop_var_stack(
    record: &mut GucVariable,
    is_commit: bool,
    nest_level: i32,
    deferred_hooks: &mut Vec<DeferredAssignHook>,
) -> (bool, Option<GucSource>) {
    let mut any_changed = false;
    let mut last_source: Option<GucSource> = None;
    loop {
        let top_level = match record.gen().stack.as_ref() {
            Some(s) if s.nest_level >= nest_level => s.nest_level,
            _ => break,
        };

        let mut stack = record.gen_mut().stack.take().unwrap();
        let prev_opt = stack.prev.take();
        let prev_level = prev_opt.as_ref().map(|p| p.nest_level);

        let mut restore_prior = false;
        let mut restore_masked = false;

        if !is_commit {
            restore_prior = true;
        } else if stack.state == GUC_SAVE {
            restore_prior = true;
        } else if stack.nest_level == 1 {
            // Transaction commit.
            if stack.state == GUC_SET_LOCAL {
                restore_masked = true;
            } else if stack.state == GUC_SET {
                discard_stack_value(&mut stack.prior);
            } else {
                restore_prior = true;
            }
        } else if prev_opt.is_none() || prev_level.unwrap() < stack.nest_level - 1 {
            // Decrement entry's level and do not pop it.
            stack.nest_level = top_level - 1;
            stack.prev = prev_opt;
            record.gen_mut().stack = Some(stack);
            continue;
        } else {
            // Merge this stack entry into prev.
            let mut prev = prev_opt.unwrap();
            match stack.state {
                GUC_SET => {
                    discard_stack_value(&mut stack.prior);
                    if prev.state == GUC_SET_LOCAL {
                        discard_stack_value(&mut prev.masked);
                    }
                    prev.state = GUC_SET;
                }
                GUC_LOCAL => {
                    if prev.state == GUC_SET {
                        prev.masked_scontext = stack.scontext;
                        prev.masked_srole = stack.srole;
                        prev.masked = core::mem::take(&mut stack.prior);
                        prev.state = GUC_SET_LOCAL;
                    } else {
                        discard_stack_value(&mut stack.prior);
                    }
                }
                GUC_SET_LOCAL => {
                    discard_stack_value(&mut stack.prior);
                    prev.masked_scontext = stack.masked_scontext;
                    prev.masked_srole = stack.masked_srole;
                    if prev.state == GUC_SET_LOCAL {
                        discard_stack_value(&mut prev.masked);
                    }
                    prev.masked = core::mem::take(&mut stack.masked);
                    prev.state = GUC_SET_LOCAL;
                }
                _ => debug_assert!(false, "GUC_SAVE can't get here"),
            }
            record.gen_mut().stack = Some(prev);
            continue;
        }

        let mut changed = false;
        if restore_prior || restore_masked {
            let (newvalue, newsource, newscontext, newsrole) = if restore_masked {
                (
                    core::mem::take(&mut stack.masked),
                    PGC_S_SESSION,
                    stack.masked_scontext,
                    stack.masked_srole,
                )
            } else {
                (
                    core::mem::take(&mut stack.prior),
                    stack.source,
                    stack.scontext,
                    stack.srole,
                )
            };

            changed = restore_stacked_value(record, &newvalue, any_changed, deferred_hooks);

            discard_stack_value(&mut stack.prior);
            discard_stack_value(&mut stack.masked);

            last_source = Some(newsource);
            let gen = record.gen_mut();
            gen.scontext = newscontext;
            gen.srole = newsrole;
        }

        record.gen_mut().stack = prev_opt;
        any_changed |= changed;
    }
    (any_changed, last_source)
}

// ResetAllOptions (guc.c:2003): walks only guc_nondef_list.
pub fn reset_all_options(reg: &mut GucRegistry) {
    use types_guc::GUC_NO_RESET_ALL;

    // dlist_foreach_modify: only the visited variable can be unlinked.
    let mut cur = reg.nondef.first();
    while let Some(idx) = cur {
        cur = reg.nondef.next_of(idx);
        let gen = reg.vars[idx].gen();
        if gen.context != PGC_SUSET && gen.context != PGC_USERSET {
            continue;
        }
        if gen.flags & GUC_NO_RESET_ALL != 0 {
            continue;
        }
        if gen.source <= PGC_S_OVERRIDE {
            continue;
        }

        let was_empty = reg.vars[idx].gen().stack.is_none();
        push_old_value(&mut reg.vars[idx], GUC_ACTION_SET);
        if was_empty && reg.vars[idx].gen().stack.is_some() {
            reg.note_stacked(idx);
        }
        reset_one(&mut reg.vars[idx]);

        let reset_source = reg.vars[idx].gen().reset_source;
        reg.set_source(idx, reset_source);
        reg.note_reportable(idx);
    }
}

// The RESET ALL per-type body: reset_val re-applied with reset_extra.
fn reset_one(var: &mut GucVariable) {
    match var {
        GucVariable::Bool(c) => {
            if let Some(f) = installed_hook(c.assign_hook) {
                f(c.reset_val, c.reset_extra.as_deref());
            }
            c.value = Some(c.reset_val);
            if c.variable.installed() {
                c.variable.write(c.reset_val);
            }
            c.gen.extra = c.reset_extra.clone();
        }
        GucVariable::Int(c) => {
            if let Some(f) = installed_hook(c.assign_hook) {
                f(c.reset_val, c.reset_extra.as_deref());
            }
            c.value = Some(c.reset_val);
            if c.variable.installed() {
                c.variable.write(c.reset_val);
            }
            c.gen.extra = c.reset_extra.clone();
        }
        GucVariable::Real(c) => {
            if let Some(f) = installed_hook(c.assign_hook) {
                f(c.reset_val, c.reset_extra.as_deref());
            }
            c.value = Some(c.reset_val);
            if c.variable.installed() {
                c.variable.write(c.reset_val);
            }
            c.gen.extra = c.reset_extra.clone();
        }
        GucVariable::String(c) => {
            if let Some(f) = installed_hook(c.assign_hook) {
                f(c.reset_val.as_deref(), c.reset_extra.as_deref());
            }
            c.value = Some(c.reset_val.clone());
            if c.variable.installed() {
                c.variable.write(c.reset_val.clone());
            }
            c.gen.extra = c.reset_extra.clone();
        }
        GucVariable::Enum(c) => {
            if let Some(f) = installed_hook(c.assign_hook) {
                f(c.reset_val, c.reset_extra.as_deref());
            }
            c.value = Some(c.reset_val);
            if c.variable.installed() {
                c.variable.write(c.reset_val);
            }
            c.gen.extra = c.reset_extra.clone();
        }
    }
    let reset_scontext = var.gen().reset_scontext;
    let reset_srole = var.gen().reset_srole;
    let gen = var.gen_mut();
    gen.scontext = reset_scontext;
    gen.srole = reset_srole;
}

// Full fresh-backend reset for one variable: BOTH the live value and the reset
// default return to the compiled boot_val (with its check-hook extra), the
// stack is discarded, and all provenance except gen.source (left for the
// caller's set_source, which keeps guc_nondef_list membership in step) returns
// to bootstrap. Unlike reset_one (the RESET ALL body), this DISCARDS any
// reset_val/reset_source a prior session's make_default bookkeeping stamped --
// values sourced <= PGC_S_OVERRIDE (client startup options, ALTER
// ROLE/DATABASE SET). That stamp is the mechanism by which a reused pooled
// worker thread would otherwise carry one session's GUCs into another's task.
//
// `publish` false leaves the assign hook AND the backing write unrun and hands
// both back as the returned closure (publish_later), for a caller that is
// about to overwrite the variable anyway (D3649).
fn reset_one_to_boot(var: &mut GucVariable, publish: bool) -> Option<DeferredAssignHook> {
    let (bootval, bootextra) = match boot_default_value(var, PGC_S_DEFAULT) {
        Ok(v) => v,
        // boot_val always passes its own check hook; on the impossible error
        // path leave the variable untouched rather than corrupt it.
        Err(_) => return None,
    };
    // The assign hook is handed back to run past the store borrow: the
    // GUC_NO_RESET_ALL hooks (assign_session_authorization / assign_role) go
    // through SetConfigOption("is_superuser") and would re-borrow the store.
    let hook = if publish {
        apply_value(var, bootval.clone(), bootextra.clone(), PGC_INTERNAL, BOOTSTRAP_SUPERUSERID)
    } else {
        store_value(var, bootval.clone(), bootextra.clone(), PGC_INTERNAL, BOOTSTRAP_SUPERUSERID);
        publish_later(var)
    };
    match (&mut *var, &bootval) {
        (GucVariable::Bool(c), config_var_val::Boolval(v)) => {
            c.reset_val = *v;
            c.reset_extra = bootextra.clone();
        }
        (GucVariable::Int(c), config_var_val::Intval(v)) => {
            c.reset_val = *v;
            c.reset_extra = bootextra.clone();
        }
        (GucVariable::Real(c), config_var_val::Realval(v)) => {
            c.reset_val = *v;
            c.reset_extra = bootextra.clone();
        }
        (GucVariable::String(c), config_var_val::Stringval(v)) => {
            c.reset_val = v.clone();
            c.reset_extra = bootextra.clone();
        }
        (GucVariable::Enum(c), config_var_val::Enumval(v)) => {
            c.reset_val = *v;
            c.reset_extra = bootextra.clone();
        }
        _ => {}
    }
    let gen = var.gen_mut();
    gen.reset_source = PGC_S_DEFAULT;
    gen.reset_scontext = PGC_INTERNAL;
    gen.reset_srole = BOOTSTRAP_SUPERUSERID;
    gen.stack = None;
    hook
}

// Fresh-backend scrub of every session-settable (USERSET/SUSET) variable, for
// a REUSED pooled/retained worker thread. Unlike reset_all_options (guc.c RESET
// ALL, which by C parity PRESERVES values sourced <= PGC_S_OVERRIDE and never
// rebuilds reset_val), this returns each variable to its boot default,
// discarding both the live value AND the reset_val/reset_source stamps a PRIOR
// session's client-startup or ALTER ROLE|DATABASE SET installed. A C parallel
// worker is a fresh process, so such values can never survive into another
// session's task; a reused pgrust thread must be scrubbed to the same baseline
// before the new leader's GUC state is applied. The caller re-overlays the
// postmaster config base (bind_base) to restore postgresql.conf-sourced values,
// reproducing a freshly initialized backend store exactly.
// GUC_NO_RESET_ALL variables (session_authorization, role, transaction_*)
// are scrubbed too: RESET ALL keeps them by C parity, but a fresh worker
// process never inherited them, and a prior session's PGC_S_SESSION value
// would outrank the next leader's PGC_S_OVERRIDE capture.
pub fn reset_session_options_to_boot(
    reg: &mut GucRegistry,
    deferred_hooks: &mut Vec<DeferredAssignHook>,
) {
    // dlist_foreach_modify: only the visited variable can be unlinked.
    let mut cur = reg.nondef.first();
    while let Some(idx) = cur {
        cur = reg.nondef.next_of(idx);
        let gen = reg.vars[idx].gen();
        if gen.context != PGC_SUSET && gen.context != PGC_USERSET {
            continue;
        }
        // reset_one_to_boot discards any transaction GUC stack; keep the
        // registry's guc_stack_list membership in step so a later AtEOXact_GUC
        // never pops an already-cleared entry. (At the pooled-worker claim site
        // the targeted <= PGC_S_OVERRIDE values carry no stack, so this is
        // normally a no-op, but the invariant must hold for every caller.)
        let had_stack = reg.vars[idx].gen().stack.is_some();
        if let Some(hook) = reset_one_to_boot(&mut reg.vars[idx], true) {
            deferred_hooks.push(hook);
        }
        if had_stack {
            reg.stacked.retain(|&i| i != idx);
        }
        // set_source(PGC_S_DEFAULT) drops idx from guc_nondef_list.
        reg.set_source(idx, PGC_S_DEFAULT);
        reg.note_reportable(idx);
    }
}

// RestoreGUCState's first pass (guc.c:6236): every variable the worker holds
// at a non-default source, except those can_skip_gucvar (guc.c:5842) keeps,
// goes back to its boot value before the leader's state is applied, so a
// config value the leader has not adopted yet cannot survive into the worker.
//
// A variable `held` names is reset in the store only: its publish (assign
// hook + backing write) goes to `parked` with its index, unrun (D3649). In C
// this pass touches only the worker's own copy; here the backings of SIGHUP
// variables are process-wide (guc_tables backing.rs), so publishing a boot
// value the caller's capture is about to overwrite shows it to every other
// session in between. The caller runs unapplied_publishes after the capture.
pub(crate) fn reset_restorable_to_boot(
    reg: &mut GucRegistry,
    deferred_hooks: &mut Vec<DeferredAssignHook>,
    held: impl Fn(&str) -> bool,
    parked: &mut Vec<(usize, DeferredAssignHook)>,
) {
    // dlist_foreach_modify: only the visited variable can be unlinked.
    let mut cur = reg.nondef.first();
    while let Some(idx) = cur {
        cur = reg.nondef.next_of(idx);
        let gen = reg.vars[idx].gen();
        if gen.context == PGC_POSTMASTER || gen.context == PGC_INTERNAL || gen.source == PGC_S_DEFAULT {
            continue;
        }
        if reg.vars[idx].gen().stack.is_some() {
            reg.stacked.retain(|&i| i != idx);
        }
        let publish = !held(reg.vars[idx].name());
        if let Some(hook) = reset_one_to_boot(&mut reg.vars[idx], publish) {
            if publish {
                deferred_hooks.push(hook);
            } else {
                parked.push((idx, hook));
            }
        }
        reg.set_source(idx, PGC_S_DEFAULT);
    }
}

// Whether the capture carries `name` at a non-default source, i.e. sets it
// again (bind_captured_guc returns early for PGC_S_DEFAULT captures).
pub(crate) fn recaptured(caps: &[CapturedGuc], name: &str) -> bool {
    caps.iter().any(|c| c.source != PGC_S_DEFAULT && guc_name_eq(&c.name, name))
}

// The parked boot publishes (reset_restorable_to_boot) of variables the
// capture did not re-apply: still at PGC_S_DEFAULT, so the boot value stands
// and its backing must say so. A re-applied variable's capture published its
// own value, and its parked boot publish is dropped.
pub(crate) fn unapplied_publishes(
    reg: &GucRegistry,
    parked: Vec<(usize, DeferredAssignHook)>,
) -> Vec<DeferredAssignHook> {
    parked
        .into_iter()
        .filter(|(idx, _)| reg.vars[*idx].gen().source == PGC_S_DEFAULT)
        .map(|(_, hook)| hook)
        .collect()
}
