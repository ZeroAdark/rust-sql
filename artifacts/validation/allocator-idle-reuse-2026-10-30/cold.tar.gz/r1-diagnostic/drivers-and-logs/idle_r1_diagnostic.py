"""Diagnostic counters around mixed SQL; not a performance comparison."""
import sys,re,hashlib
from pathlib import Path
sys.path.insert(0,'/home/rustsql/pgrust/scripts/validation')
import resource_workload as work
sql=Path('/home/rustsql/pgrust/scripts/memory-broker-views.sql').read_text()
declaration=re.search(r'CREATE OR REPLACE FUNCTION pgrust_memory_owner_end\(.*?;',sql,re.S).group()
class DiagnosticCluster(work.Cluster):
 def start(self):
  super().start()
  with work.psycopg.connect(self.dsn,autocommit=True) as c:c.execute(declaration,prepare=False)
work.Cluster=DiagnosticCluster
original=work.exercise
def exercise(dsn,*a,**kw):
 def counts():
  with work.psycopg.connect(dsn,autocommit=True) as c:return c.execute("SELECT class,events,committed_bytes,reserved_bytes,uses FROM pgrust_memory_owner_end() WHERE source='pool' AND (class LIKE 'r1_%' OR class IN ('end_give','grow_guard')) ORDER BY class").fetchall()
 before=counts();result=original(dsn,*a,**kw);after=counts()
 result['r1_diagnostic']={'before':before,'after':after,'wrapper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'diagnostic_only':True}
 return result
work.exercise=exercise
work.main()
