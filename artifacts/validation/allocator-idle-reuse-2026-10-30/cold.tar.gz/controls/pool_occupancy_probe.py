"""Instrumented pool occupancy capture, not a CPU/latency benchmark."""
import sys,os,re,asyncio,struct,time,hashlib
from pathlib import Path
sys.path.insert(0,'/home/rustsql/pgrust/scripts/validation')
import connection_queue_probe as probe
policy=os.environ.get('POOL_PROBE_POLICY','')
assert policy in ('','pool_warm_zero=0,pool_warm_zero_max=0')
snapshots=[];witnesses=[];seen=set()
view_source=Path('/home/rustsql/pgrust/scripts/memory-broker-views.sql').read_text()
declarations=[re.search(r'CREATE OR REPLACE FUNCTION '+name+r'\(.*?;',view_source,re.S).group() for name in ('pgrust_memory_settings','pgrust_memory_owner_end')]
class DiagnosticCluster(probe.Cluster):
    def __init__(self,*a,**kw):
        kw['allocator']='hearth';super().__init__(*a,**kw)
        if policy:self.env['PGRUST_MEMPOLICY']=policy
    def start(self):
        super().start()
        with probe.psycopg.connect(self.dsn,autocommit=True) as conn:
            for sql in declarations:conn.execute(sql,prepare=False)
            rows=conn.execute("SELECT name,value,source FROM pgrust_memory_settings() WHERE name IN ('pool_warm_zero','pool_warm_zero_max') ORDER BY name").fetchall()
            expected={'pool_warm_zero':0 if policy else 16*1048576,'pool_warm_zero_max':0 if policy else 256*1048576}
            assert {name:int(value) for name,value,source in rows}==expected,rows
            witnesses.append({'allocator':conn.execute('SHOW pgrust.allocator').fetchone()[0],'settings':rows})
probe.Cluster=DiagnosticCluster
async def query(client,sql):
    payload=sql.encode()+b'\0';await asyncio.get_running_loop().sock_sendall(client.socket,b'Q'+struct.pack('!I',len(payload)+4)+payload)
    columns=[];rows=[]
    while True:
        kind,p=await client.message_async()
        if kind==b'E':raise RuntimeError(p.decode('utf8','replace'))
        if kind==b'T':
            count=struct.unpack_from('!H',p)[0];at=2
            for _ in range(count):
                end=p.index(0,at);columns.append(p[at:end].decode());at=end+1+18
            assert at==len(p)
        elif kind==b'D':
            count=struct.unpack_from('!H',p)[0];at=2;row=[]
            assert count==len(columns)
            for _ in range(count):
                size=struct.unpack_from('!i',p,at)[0];at+=4
                if size==-1:row.append(None)
                else:
                    assert size>=0 and at+size<=len(p);row.append(p[at:at+size].decode());at+=size
            assert at==len(p);rows.append(dict(zip(columns,row)));assert len(rows)<=4096
        elif kind==b'Z':return rows
original_stats=probe.Startup.stats_async
async def stats(self):
    state=await original_stats(self)
    key=state['total_queued']
    if state['queued']==300 and key not in seen:
        seen.add(key);start=time.monotonic()
        rows=await query(self,"SELECT kind,source,class,events,committed_bytes,reserved_bytes,uses FROM pgrust_memory_owner_end() WHERE source IN ('pool','pool_reserve','allocator') ORDER BY source,class,kind")
        snapshots.append({'wave':len(snapshots)+1,'queue_state':state,'seconds':time.monotonic()-start,'rows':rows})
    return state
probe.Startup.stats_async=stats
original_run=probe.run_burst
def run(args,report):
    try:original_run(args,report)
    finally:
        report.update(diagnostic_only=True,requested_policy=policy,setting_witnesses=witnesses,pool_snapshots=snapshots,declarations=declarations,wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),view_source_sha256=hashlib.sha256(view_source.encode()).hexdigest())
probe.run_burst=run
probe.main()
