#![cfg(all(feature="global",not(target_family="wasm")))]
mod common;
use std::{alloc::{GlobalAlloc,Layout},sync::{Arc,Barrier}};
use pagepool::{PoolAlloc,Tag};
#[test]
fn idle_exit_retention_probe(){
 common::setup(); let barrier=Arc::new(Barrier::new(64)); let mut threads=Vec::new();
 for _ in 0..64 {let b=barrier.clone();threads.push(std::thread::spawn(move||{
  let mut held=Vec::new(); for size in [64,256,1024] {let l=Layout::from_size_align(size,8).unwrap();let p=unsafe{PoolAlloc.alloc(l)};assert!(!p.is_null()&&pagepool::owns(p));unsafe{p.write_bytes(42,size)};held.push((p,l));}
  b.wait();for(p,l)in held{unsafe{PoolAlloc.dealloc(p,l)}};pagepool::idle_point();
 }));}
 for t in threads{t.join().unwrap();}
 let cap=||pagepool::stats().in_use[Tag::SMALL.0 as usize];
 let after_exit=cap();let release_heap=pagepool::release_heap();let after_release=cap();let return_warm=pagepool::return_warm_now(usize::MAX);let after_warm=cap();let swept=pagepool::flush_remote();let after_sweep=cap();
 println!("after_exit={after_exit} release_heap_runs={release_heap} after_release={after_release} return_warm_bytes={return_warm} after_warm={after_warm} swept_runs={swept} after_sweep={after_sweep}");assert_eq!(pagepool::global_live(),0);assert_eq!(after_sweep,0);
}
