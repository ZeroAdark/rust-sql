from pathlib import Path
import json,re
home=Path('/home/rustsql');repo=home/'pgrust';windows=Path('/mnt/c/Users/DarkMoon/Desktop/Rust SQL/pgrust');package=home/'idle-cold-evidence-package-20261030'
load=lambda name:json.loads((package/name).read_text())
checks=load('checks.json');mixed=load('mixed-comparison.json');connection=load('connection-comparison.json');manifest=load('manifest.json')
assert mixed['evidence_valid'] and all(r['median_p99_within_five_percent'] and r['median_throughput_within_five_percent'] for r in mixed['limits'])
pct=lambda n:f'{n:+.2f}%'
rows=[]
for r in mixed['limits']:
 rows.append('| '+str(r['memory_mib']//1024)+' GiB | '+pct(r['cpu_us_per_bundle']['median_change_pct'])+' | '+pct(r['bundles_per_second']['median_change_pct'])+' | '+pct(max(v['p99']['median_change_pct'] for v in r['latency_ms'].values()))+' | '+pct(r['sampled_memory_mib']['memory_current']['median_change_pct'])+' | '+pct(r['sampled_memory_mib']['summed_pss']['median_change_pct'])+' |')
table='\n'.join(['| Limit | CPU/bundle | Throughput | Largest p99 change | Peak cgroup memory | Peak PSS |','| --- | ---: | ---: | ---: | ---: | ---: |',*rows])
peaks=[r['peak_mib'] for r in checks['pressure']];headroom=2048-max(peaks)
suite=json.loads((home/'idle-cold-full-suites-20261030.json').read_text());raw=(Path(suite['cluster'])/'regression/regression.out').read_text();match=re.search(r'# (\d+) of (\d+) tests failed',raw);assert match;failed,total=map(int,match.groups());assert total==231
cpu=connection['cpu_us_per_accepted_startup'];shutdown=connection['cpu_us_per_accepted_startup_including_shutdown'];memory=connection['peak_cgroup_mib'];source=checks['candidate'];sha=source['binaries']['postgres'];window=checks['window_oracle']['candidate']['checks']
measurements=f'''{table}

Forty interleaved trials execute 1,824,000 measured statements plus warmups. Both binaries explicitly use Hearth, six ordinary-role clients, one million fact rows, 400 measured bundles and 50 warmup bundles per client, a six-transaction cap, four server CPUs and durability enabled. All results, committed updates and clean restarts pass; no OOM, swap, memory-limit or measured CPU-throttling event occurs. Every median throughput/p99 change meets the provisional 5% guardrail. The table uses ratios of independent medians; JSON retains every paired change. No general additional CPU speedup is claimed.

Five separate 4 GiB connection pairs complete 16,000 accepted startups and 20 overflow rejections. Median peak cgroup memory changes by {pct(memory['median_change_pct'])}; startup-phase CPU per accepted startup changes by {pct(cpu['median_change_pct'])}, and CPU through clean shutdown by {pct(shutdown['median_change_pct'])}. The latter paired range is {pct(shutdown['paired_change_pct']['min'])} to {pct(shutdown['paired_change_pct']['max'])}. These short, variable runs do not establish a reliable CPU saving. Four server CPUs are affinity-checked for every held task, with a five-CPU quota on both sides to avoid CFS period-boundary throttling. Server and parent CPU counters are complete and show no throttling, including server teardown. This quota differs from the mixed matrix and is recorded in metadata. Wave times include orchestration and diagnostic snapshots, not just authentication.

Three 2 GiB pilots each complete two waves of 500 admitted plus 300 queued connections. Peaks are {', '.join(f'{p:.2f}' for p in peaks)} MiB, leaving at least {headroom:.2f} MiB ({headroom/2048*100:.2f}%). These pilots do not qualify 500 concurrent active queries, long churn or a production service. Previous baseline 2 GiB OOM failures remain retained.
'''
validation=f'''The final binary passes 115 allocator tests (one helper intentionally ignored), 12 smoke checks, 510 isolation cases, 231/231 reviewed SQL cases, 87 differential checks, 52 admission checks, 12 connection-contract checks, 12 idle-session checks and 21 TLS/authentication checks. Ten whole-process crash cycles and logical dump/restore checks pass. Raw PostgreSQL expectations still report {failed}/231 mismatches; that profile remains separate. The independent window oracle passes {window:,} comparisons on each of the candidate and separately patched PostgreSQL. The PostgreSQL EXCLUDE TIES bug difference remains intentional.
'''
section=f'''\n## Idle allocator reuse (2026-10-30)

Current runs can now be reused by other threads after connection setup and through the existing idle timer. Empty runs stay formatted until reclamation. Busy sessions keep local current runs between commands, and general allocation gains no handoff bookkeeping. Synchronous pressure release collects abandoned empty runs before estimating what it can release. See [implementation and bounds](idle-allocator.md).

The final binary is `{sha}`; the unchanged comparison baseline is `2f35e3a361d2b660a73c5aefb739af6178ee3f4dfbd5b9b63f48b165e5d5ec3c`. This measures the allocator change relative to the connection-queue baseline, not the earlier validity-forwarding baseline. The separate percentage changes must not be combined arithmetically.

{measurements}
{validation}
Immediate empty-run return rebuilt 600 runs in 200 idle cycles and failed a latency guardrail. Keeping empty runs exposed an inline reclamation gap, although the existing background sweep still reclaimed them. Handoff after every ReadyForQuery later failed the 4 GiB range p99 guardrail (+5.29%). Moving handoff to actual idle periods passed those guardrails; its remaining allocation bookkeeping was then removed. Separate diagnostics at 1 and 4 GiB recorded no pressure-release calls during the mixed workload.

[Complete reports, controls, source hashes and portable replay](../artifacts/validation/allocator-idle-reuse-2026-10-30/README.md) retain all candidates. This remains WSL development evidence. Large spills, pressure recovery, prolonged churn and representative Linux-server qualification remain open.
'''
path=Path('docs/performance.md');current=(repo/path).read_text();assert '## Idle allocator reuse (2026-10-30)' not in current;writes={path:current.rstrip()+'\n'+section}
path=Path('docs/production-readiness.md');text=(repo/path).read_text();lines=text.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| SQL compatibility |'):
  lines[i]=f'| SQL compatibility | PostgreSQL 18.6 regression and isolation suites, differential driver/application corpus | The latest allocator binary passes 231/231 reviewed cases ({failed} raw PostgreSQL mismatches), 510 isolation cases, 87 differential checks, 12 smoke checks, 12 idle-session checks and the independent window oracle. Broader application/driver coverage remains open |'
 elif line.startswith('| Resource limits |'):
  lines[i]='| Resource limits | cgroup limits at 1/2/4/8 GiB, competing OLTP/OLAP, bounded admission, cancellation, no OOM deaths | The latest allocator binary passes forty mixed trials at 1/2/4/8 GiB, 52 admission checks, 12 connection-contract checks, five connection pairs at 4 GiB and three two-wave startup pilots at 2 GiB. Successful trials have no OOM, swap or memory-limit events. Baseline 2 GiB OOM controls remain retained. Active-query capacity, large spills, pressure recovery and sustained maintenance remain open |'
 elif line.startswith('| Performance |'):
  lines[i]='| Performance | Interleaved baseline/candidate runs; CPU seconds per operation, peak RSS/PSS/cgroup memory, throughput, p50/p95/p99 | Earlier validity forwarding lowered CPU by 4.42-6.08% in its scoped comparison. The latest allocator matrix meets throughput/p99 guardrails and the separate connection calibration reduces peak memory. CPU distributions and limits are reported without a new general CPU-speedup claim in [performance evidence](performance.md#idle-allocator-reuse-2026-10-30). Representative Linux-server qualification remains pending |'
text='\n'.join(lines)+'\n';text=text.replace('These measurements do not benchmark the subsequent connection-queue change. A complete memory matrix for the latest binary remains open.', 'These are historical comparisons. The latest allocator binary has its own complete memory matrix below.').replace('Targeted pool memory work remains open.', 'The targeted pool work below keeps Hearth.').replace("The current runtime's failed 2 GiB connection gate remains open.", "That experiment did not repair the retained runtime's 2 GiB connection gate.")
paragraph=f'''The [idle allocator change](idle-allocator.md) now passes a fresh forty-trial matrix, with all throughput/p99 changes inside 5%, and reduces median 4 GiB connection-burst peak memory by {-memory['median_change_pct']:.2f}%. Three two-wave 2 GiB pilots pass with {headroom:.2f} MiB minimum headroom. CPU is reported with paired distributions and shutdown cleanup; this is not a general CPU-speedup or production-capacity claim. Fresh SQL, isolation, idle-session, TLS, window-oracle and recovery checks bind to the final binary. Baseline OOM failures and rejected/superseded candidates remain in the [evidence archive](../artifacts/validation/allocator-idle-reuse-2026-10-30/README.md).

''';text=text.replace('## Acceptance policy',paragraph+'## Acceptance policy');writes[path]=text
archive_table='\n'.join(['| Archive | Bytes | Regular files | SHA-256 |','| --- | ---: | ---: | --- |',*[f"| `{a['file']}` | {a['bytes']:,} | {len(a['members']):,} | `{a['sha256']}` |" for a in manifest['archives']]])
readme=f'''# Idle allocator reuse evidence

The final change shares current runs after connection setup and through existing idle timers, keeps empty runs formatted, and makes synchronous pressure release see abandoned empty runs. General allocation has no added handoff bookkeeping. [Implementation and bounds](../../../docs/idle-allocator.md) describe the fixed class-slot scan and linear remote-free/pressure work.

Status: development validation only; **not production qualified**. CPU has priority over memory.

## Final measurements

{measurements}
## Correctness and source identity

{validation}
Final `postgres` SHA-256: `{sha}`. Unchanged baseline: `2f35e3a361d2b660a73c5aefb739af6178ee3f4dfbd5b9b63f48b165e5d5ec3c`. Source parent: `{source['source_head']}`. Runtime snapshots, patch, build commands and LF-normalized hashes are archived; this is not an independently reproduced build. The focused CI command passes four tests with default thread-stack settings.

The idle-session probe witnesses timer execution by session, then checks prepared statements, transaction cursors, held cursors and transaction state after resumption. The 64-thread live-allocation negative control retains 12 MiB; sharing uses 256 KiB. The pressure negative control retains 12 MiB after exited idle threads until an explicit sweep; the fix reclaims it synchronously.

## Experiment history

| Stage | Disposition |
| --- | --- |
| `idle-handoff` | Immediate empty-run return rebuilt 600 runs in 200 idle cycles, raised mixed median CPU 1.06%, and failed join p99. Its startup dataset has a CFS throttle event and is not accepted as a CPU comparison. |
| `idle-reuse` | Kept empty runs formatted. Mixed matrix guardrails passed, but a lifecycle test exposed a synchronous release estimate that skipped abandoned empty runs. The existing background sweep still reclaimed them. |
| `idle-reclaim` | Fixed immediate reclamation and duplicate sweeps. Correctness passed, but every-command handoff failed 4 GiB range p99 (+5.29%). |
| `idle-boundary` | Moved handoff to setup/idle timers. All throughput/p99 guardrails passed; 1 GiB independent median CPU rose 1.62% (paired median +0.36%). Superseded to remove allocation bookkeeping. |
| `idle-cold` | Final implementation: fixed-slot inspection at handoff, with no added general-allocation bookkeeping. |

Separate instrumented 1/4 GiB workloads record zero R1 pressure-release calls. They are diagnostic evidence, not performance comparisons. The initial reuse startup-driver import failure and a root-user CI-command failure occurred before their respective tests and remain archived; corrected runs are separate. Boundary startup analysis retains its original version before adding shutdown CPU and stricter counter checks; raw trial records were unchanged.

## Archive integrity and replay

{archive_table}

`manifest.json` hashes every regular member. Archives contain reports, complete SQL outputs, native results and pinned expectations for the final audit, source snapshots, runners, journals and server logs. Database files, executables, TLS private keys and live credentials are excluded.

From a trusted checkout with Python 3.12 or newer:

```sh
python3 artifacts/validation/allocator-idle-reuse-2026-10-30/replay.py
```

Replay verifies archive/member bytes, recomputes six mixed-work comparisons and four valid startup comparisons, and reruns all 231 reviewed SQL cases against archived native results and pinned policies. It starts no server and does not reproduce binaries or live measurements. New measurements require the recorded build/delegated-cgroup setup and separately frozen binaries. This remains WSL x86-64 evidence; production Linux hardware, sustained workloads and remaining [qualification gates](../../../docs/production-readiness.md) are still required.
'''
writes[Path('artifacts/validation/allocator-idle-reuse-2026-10-30/README.md')]=readme
for path,text in writes.items():
 (repo/path).parent.mkdir(parents=True,exist_ok=True);(repo/path).write_text(text);(windows/path).parent.mkdir(parents=True,exist_ok=True);(windows/path).write_text(text)
print(json.dumps({'raw_failed':failed,'window_comparisons_per_server':window,'minimum_2g_headroom_mib':headroom,'files':[str(p) for p in writes]}))
