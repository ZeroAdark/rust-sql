import sys, hashlib
from pathlib import Path
sys.path.insert(0, '/home/rustsql/pgrust/scripts/validation')
import connection_queue_probe as probe
import resource_scope as resources
witnesses=[]
class HearthCluster(probe.Cluster):
    def __init__(self,*a,**kw):
        kw['allocator']='hearth'
        super().__init__(*a,**kw)
    def start(self):
        super().start()
        with probe.psycopg.connect(self.dsn,autocommit=True) as conn:
            actual=conn.execute('SHOW pgrust.allocator').fetchone()[0]
        assert actual=='hearth'
        witnesses.append(actual)
probe.Cluster=HearthCluster
# Keep the same four-core affinity, but leave one core of CFS quota headroom to avoid period-boundary throttling.
parent=[]
class HeadroomScope(resources.DelegatedScope):
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw)
        parent.append({'path':self.root,'before':resources.snapshot(self.root)['cpu']})
    def server(self,memory_mib):
        assert self.server_cpus=={0,2,4,6}
        group,launcher=super().server(memory_mib)
        assert not (group/'cgroup.procs').read_text().strip()
        (group/'cpu.max').write_text('500000 100000')
        return group,launcher
resources.DelegatedScope=HeadroomScope
original=probe.run_burst
def run_burst(args,report):
    try:
        original(args,report)
    finally:
        report['allocator']={'requested':'hearth','live_witnesses':witnesses}
        report['cpu_quota_headroom']={'server_cpu_max':'500000 100000','server_affinity':[0,2,4,6]}
        report['parent_cpu_delta']=[resources.delta(item['before'],resources.snapshot(item['path'])['cpu']) for item in parent]
        report['wrapper_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
probe.run_burst=run_burst
probe.main()
