from pathlib import Path
import subprocess,os
repo=Path('/home/rustsql/pgrust');env=dict(os.environ);env.pop('RUST_MIN_STACK',None)
log=Path('/home/rustsql/idle-safe-final-ci-command-20261030.log')
with log.open('w') as stream:r=subprocess.run(['/home/rustsql/.cargo/bin/cargo','+1.96.0','test','--locked','--release','-j','2','-p','pagepool','--features','global','--test','frames','--test','idle_handoff','--test','idle_fallback'],cwd=repo,env=env,stdout=stream,stderr=subprocess.STDOUT)
print('CI command exit',r.returncode,flush=True);print(log.read_text()[-900:],flush=True);r.check_returncode()
