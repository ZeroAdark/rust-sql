from pathlib import Path
import copy,importlib.util,json,hashlib,io,tarfile,tempfile
base=Path('/home/rustsql');stem='idle-safe-final'
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
analyzer=module('connection_evidence_validator',base/'compare_idle_safe_final_connections.py')
root=base/(stem+'-connection-calibration-20261030');meta=json.loads((root/'metadata.json').read_text());record=json.loads((root/'baseline-1.json').read_text())
analyzer.validate(record,meta,'baseline');results={'valid_reference_accepted':True,'negative_controls':[]}
def reject(name,change):
 r,m=copy.deepcopy(record),copy.deepcopy(meta);change(r,m)
 try:analyzer.validate(r,m,'baseline')
 except ValueError as error:results['negative_controls'].append({'name':name,'rejected':True,'reason':str(error)})
 else:raise AssertionError('validator accepted '+name)
reject('wrong_binary',lambda r,m:r.__setitem__('binary_sha256','0'*64))
reject('wrong_wrapper',lambda r,m:r.__setitem__('wrapper_sha256','0'*64))
reject('wrong_memory_limit',lambda r,m:r['limits'].__setitem__('memory.max',str(2048*1048576)))
reject('wrong_cpu_quota',lambda r,m:r['limits'].__setitem__('cpu.max','400000 100000'))
reject('missing_parent_cpu_counter',lambda r,m:r['parent_cpu_delta'][0].pop('nr_throttled'))
reject('missing_server_cpu_counter',lambda r,m:r['resources_after_shutdown']['cpu'].pop('throttled_usec'))
reject('server_teardown_throttling',lambda r,m:r['resources_after_shutdown']['cpu'].__setitem__('nr_throttled',r['resources_before']['cpu']['nr_throttled']+1))
reject('parent_throttling',lambda r,m:r['parent_cpu_delta'][0].__setitem__('throttled_usec',1))
reject('missing_memory_event',lambda r,m:r['resources_after_shutdown']['events'].pop('oom_kill'))
reject('oom_event',lambda r,m:r['resources_after_shutdown']['events'].__setitem__('oom_kill',1))
reject('unfinished_startups',lambda r,m:r['waves'][0].__setitem__('accepted',799))
reject('missing_startup_timing',lambda r,m:r['waves'][0]['startup_seconds'].pop())
reject('server_left_alive',lambda r,m:r.__setitem__('remaining_server_pids',[12345]))
reject('missing_task_affinity',lambda r,m:r['waves'][0]['resources_while_held'].__setitem__('thread_affinity_counts',{}))
replay=module('idle_archive_replay',base/'pgrust/artifacts/validation/allocator-idle-reuse-2026-10-30/replay.py')
with tempfile.TemporaryDirectory(prefix='idle-archive-control-') as temp:
 d=Path(temp);payload=b'archive integrity control';archive=d/'control.tar.gz'
 with tarfile.open(archive,'w:gz') as tar:
  info=tarfile.TarInfo('control.txt');info.size=len(payload);tar.addfile(info,io.BytesIO(payload))
 data=archive.read_bytes();manifest={'file':archive.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'members':{'control.txt':{'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}}}
 assert replay.unpack(d,manifest,d/'valid')==1
 archive.write_bytes(data[:-1]+bytes([data[-1]^1]))
 try:replay.unpack(d,manifest,d/'invalid')
 except ValueError as error:results['negative_controls'].append({'name':'archive_byte_tamper','rejected':True,'reason':str(error)})
 else:raise AssertionError('archive tampering accepted')
 assert not (d/'invalid').exists()
results['passed']=True
(base/(stem+'-validator-controls-20261030.json')).write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
