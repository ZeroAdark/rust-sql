from pathlib import Path
import hashlib,json,os,subprocess,time
base=Path('/home/rustsql');needle=b'/home/rustsql/build_idle_safe_final.py'
def active():
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   if needle in (p/'cmdline').read_bytes().split(b'\0'):return True
  except OSError:pass
 return False
while active():time.sleep(3)
manifest=json.loads((base/'idle-safe-final-candidate/manifest.json').read_text())
for name,sha in manifest['binaries'].items():assert hashlib.sha256((base/'idle-safe-final-candidate/bin'/name).read_bytes()).hexdigest()==sha
for name,sha in manifest['source_lf_sha256'].items():assert hashlib.sha256((base/'pgrust'/name).read_bytes()).hexdigest()==sha
print('Frozen binary verified',manifest['binaries']['postgres'],flush=True)
env=dict(os.environ,HOME='/home/rustsql',USER='rustsql',LOGNAME='rustsql');env.pop('RUSTUP_HOME',None);env.pop('CARGO_HOME',None)
subprocess.run(['runuser','-u','rustsql','--','/usr/bin/python3','-u',str(base/'run_idle_safe_final_ci.py')],env=env,check=True)
subprocess.run(['/usr/bin/python3','-u',str(base/'run_idle_safe_final_qualification.py')],check=True)
subprocess.run(['/usr/bin/python3',str(base/'check_idle_safe_final_evidence.py')],check=True)
print('Qualification campaign completed; inspect performance guardrails before publication.',flush=True)
