//! A parked, still-live thread must not pin one mostly empty current run per size class.
#![cfg(all(feature = "global", not(target_family = "wasm"), not(miri)))]

mod common;
use pagepool::{PoolAlloc, Tag};
use std::alloc::{GlobalAlloc, Layout};
use std::sync::mpsc;

#[test]
fn idle_threads_share_current_runs_and_resume_after_remote_frees() {
    common::setup();
    let before = pagepool::stats().in_use[Tag::SMALL.0 as usize];
    let live_before = pagepool::global_live();
    let mut threads = Vec::new();
    let mut wakes = Vec::new();
    let mut allocations = Vec::new();
    for id in 0..64u8 {
        let (send, receive) = mpsc::channel();
        let (wake, sleep) = mpsc::channel();
        wakes.push(wake);
        threads.push(std::thread::spawn(move || {
            let mut held = Vec::new();
            for size in [64, 256, 1024] {
                let layout = Layout::from_size_align(size, 8).unwrap();
                // SAFETY: a valid nonzero layout. Ownership is sent to the parent for one remote free.
                let p = unsafe { PoolAlloc.alloc(layout) };
                assert!(!p.is_null() && pagepool::owns(p));
                unsafe { p.write_bytes(id, size) };
                held.push((p as usize, layout, id));
            }
            pagepool::idle_point();
            send.send(held).unwrap();
            sleep.recv().unwrap();
            // The original owner stays alive and later allocates again, after another thread freed its blocks.
            for n in 0..256 {
                let layout = Layout::from_size_align([64, 256, 1024][n % 3], 8).unwrap();
                let p = unsafe { PoolAlloc.alloc(layout) };
                assert!(!p.is_null());
                unsafe {
                    p.write_bytes(id, layout.size());
                    assert!(std::slice::from_raw_parts(p, layout.size()).iter().all(|&b| b == id));
                    PoolAlloc.dealloc(p, layout);
                }
            }
            pagepool::idle_point();
        }));
        // Deliberately establish idle runs before the next thread starts, so reuse is deterministic.
        allocations.extend(receive.recv().unwrap());
    }
    let capacity = pagepool::stats().in_use[Tag::SMALL.0 as usize] - before;
    for (address, layout, id) in allocations {
        // SAFETY: the still-parked threads transferred ownership; check before freeing each block once.
        unsafe {
            let p = address as *mut u8;
            assert!(std::slice::from_raw_parts(p, layout.size()).iter().all(|&b| b == id));
            PoolAlloc.dealloc(p, layout);
        }
    }
    for wake in wakes { wake.send(()).unwrap(); }
    for thread in threads { thread.join().unwrap(); }
    pagepool::flush_remote();
    assert_eq!(pagepool::stats().in_use[Tag::SMALL.0 as usize], before);
    assert_eq!(pagepool::global_live(), live_before);
    // Three classes need four runs for these live blocks; allow two spare runs, not 64 private sets.
    assert!(capacity <= 6 * (64 << 10), "idle threads retained {capacity} bytes of small-run capacity");
}
