from pathlib import Path
import subprocess,json
home=Path('/home/rustsql')
def service(name,argv,timeout=1800):
 log=home/(name+'.log');unit='rustsql-qualification-'+name
 cmd=['systemd-run','--unit='+unit,'--uid=rustsql','--gid=rustsql','--collect','--wait','--property=Delegate=cpu memory pids','--property=MemoryMax=8G','--property=MemorySwapMax=0','--property=CPUQuota=600%','--property=LimitSTACK=67108864','--property=RuntimeMaxSec='+str(timeout),'--property=StandardOutput=append:'+str(log),'--property=StandardError=append:'+str(log),'/usr/bin/python3','-u']+argv
 r=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout+30)
 (home/(name+'-command.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode,'output':r.stdout},indent=2)+'\n')
 (home/(name+'-journal.log')).write_bytes(subprocess.check_output(['journalctl','-u',unit+'.service','--no-pager','-o','short-iso']))
 print(name,r.returncode,r.stdout,flush=True);r.check_returncode()
service('idle-reuse-calibration-20261030',['/home/rustsql/pgrust/scripts/validation/resource_workload.py','--baseline','/home/rustsql/connection-queue-fixed/bin','--candidate','/home/rustsql/idle-reuse-candidate/bin','--baseline-allocator','hearth','--candidate-allocator','hearth','--max-active-queries','6','--memory-mib','4096','--rows','1000000','--clients','6','--bundles','400','--warmup','50','--repeats','5','--work-dir','/home/rustsql/conformance','--output-dir','/home/rustsql/idle-reuse-calibration-20261030'])
subprocess.run(['/usr/bin/python3','/home/rustsql/pgrust/scripts/validation/compare_resource.py','--input-dir','/home/rustsql/idle-reuse-calibration-20261030','--source-dir','/home/rustsql/idle-reuse-calibration-source-20261030','--calibration','--output','/home/rustsql/idle-reuse-calibration-comparison-20261030.json'],check=True)
subprocess.run(['/usr/bin/python3','-u','/home/rustsql/run_idle_reuse_connection_comparison.py'],check=True)
subprocess.run(['/usr/bin/python3','/home/rustsql/compare_idle_reuse_connections.py','--input-dir','/home/rustsql/idle-reuse-connection-calibration-20261030','--output','/home/rustsql/idle-reuse-connection-comparison-20261030.json'],check=True)
for repeat in range(1,4):
 name='idle-reuse-2g-'+str(repeat)+'-20261030'
 service(name,['/home/rustsql/idle_reuse_queue_probe.py','--candidate','/home/rustsql/idle-reuse-candidate/bin','--work-dir','/home/rustsql/conformance','--output',str(home/(name+'.json')),'--burst','--memory-mib','2048'],180)
 d=json.loads((home/(name+'.json')).read_text());print('2g',repeat,d['passed'],d['resources_after_shutdown']['memory_peak']/1048576,flush=True)
