import subprocess
from pathlib import Path
subprocess.run(['/usr/bin/python3','-u','/home/rustsql/measure_idle_boundary_matrix.py'],check=True)
subprocess.run(['/usr/bin/python3','-u','/home/rustsql/run_idle_boundary_connection_comparison.py'],check=True)
subprocess.run(['/usr/bin/python3','/home/rustsql/compare_idle_boundary_connections.py','--input-dir','/home/rustsql/idle-boundary-connection-calibration-20261030','--output','/home/rustsql/idle-boundary-connection-comparison-20261030.json'],check=True)
subprocess.run(['/usr/bin/python3','-u','/home/rustsql/measure_idle_boundary_2g.py'],check=True)
for mode in ('full','probes'):
 name='idle-boundary-qualification-'+mode+'-20261030';unit='rustsql-qualification-'+name;log='/home/rustsql/'+name+'.log'
 command=['systemd-run','--unit='+unit,'--uid=rustsql','--gid=rustsql','--collect','--wait','--property=MemoryMax=12G','--property=MemorySwapMax=0','--property=CPUQuota=600%','--property=LimitSTACK=67108864','--property=RuntimeMaxSec=3600','--property=StandardOutput=append:'+log,'--property=StandardError=append:'+log,'/usr/bin/python3','-u','/home/rustsql/idle_boundary_validation.py',mode]
 r=subprocess.run(command,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=3630)
 import json
 Path('/home/rustsql/'+name+'-command.json').write_text(json.dumps({'command':command,'exit':r.returncode,'output':r.stdout},indent=2)+'\n')
 Path('/home/rustsql/'+name+'-journal.log').write_bytes(subprocess.check_output(['journalctl','-u',unit+'.service','--no-pager','-o','short-iso']))
 print(mode,r.returncode,r.stdout,flush=True);r.check_returncode()
