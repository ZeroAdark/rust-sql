import subprocess,sys,resource,os,json
from pathlib import Path
resource.setrlimit(resource.RLIMIT_STACK,(67108864,resource.getrlimit(resource.RLIMIT_STACK)[1]))
root=Path('/home/rustsql/pgrust');mode=sys.argv[1];bin='/home/rustsql/idle-boundary-candidate/bin';base='/home/rustsql/idle-boundary-';env=dict(os.environ,RUST_MIN_STACK='33554432')
commands={
'unit':[['/home/rustsql/.cargo/bin/cargo','+1.96.0','test','--locked','--release','-j2','-p','lmgr_proc','--lib'],['python3','-m','unittest','discover','-s','scripts/validation','-p','test_*.py']],
'full':[['python3','scripts/validation/server_smoke.py','--bin-dir',bin,'--psql','/home/rustsql/postgres18/bin/psql','--work-dir','/home/rustsql/conformance','--output',base+'full-suites-20261030.json','--capture-regression','--regression-dir','/home/rustsql/postgres-reference-build/src/test/regress','--isolation-dir','/home/rustsql/postgres-reference-build/src/test/isolation','--isolation-overlay',str(root/'regress/isolation-overlay'),'--reference-bin','/home/rustsql/postgres18/bin'],['python3','scripts/validation/engine_regression_audit.py','--fixtures','/home/rustsql/postgres-reference-build/src/test/regress','--reference-report','/home/rustsql/native-regression-control.json','--candidate-report',base+'full-suites-20261030.json','--output','/home/rustsql/conformance/idle-boundary-audit-20261030']],
'probes':[['python3','scripts/validation/idle_allocator_probe.py','--candidate',bin,'--work-dir','/home/rustsql/conformance','--output',base+'idle-contract-20261030.json'],['python3','scripts/validation/connection_queue_probe.py','--candidate',bin,'--work-dir','/home/rustsql/conformance','--output',base+'connection-contract-20261030.json'],['python3','scripts/validation/admission_probe.py','--candidate',bin,'--work-dir','/home/rustsql/conformance','--output',base+'admission-20261030.json'],['python3','scripts/validation/compatibility_probe.py','--candidate',bin,'--reference','/home/rustsql/postgres18/bin','--work-dir','/home/rustsql/conformance','--output',base+'compatibility-20261030.json'],['python3','scripts/validation/recovery_probe.py','--candidate',bin,'--reference-clients','/home/rustsql/postgres18/bin','--work-dir','/home/rustsql/conformance','--output',base+'recovery-20261030.json','--cycles','10']]
}[mode]
results=[]
for index,command in enumerate(commands):
 with open(base+mode+'-'+str(index)+'-20261030.log','w') as log:
  r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=2400)
 results.append({'command':command,'exit':r.returncode});print(mode,index,'exit',r.returncode,flush=True)
 Path(base+mode+'-commands-20261030.json').write_text(json.dumps(results,indent=2)+'\n')
 r.check_returncode()
