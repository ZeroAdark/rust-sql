from pathlib import Path
import json,hashlib,tarfile,io,gzip,re,subprocess,shutil,sys
base=Path('/home/rustsql');repo=base/'pgrust';out=base/'idle-boundary-evidence-package-20261030'
def digest(b):return hashlib.sha256(b).hexdigest()
def units(stem):
 s=(base/(stem+'-pool-tests-20261030.log')).read_text();rows=[tuple(map(int,x)) for x in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;',s)]
 return dict(zip(['passed','failed','ignored'],[sum(r[i] for r in rows) for i in range(3)]))|{'executables':len(rows)}
def archive(name,stages,final=False):
 files={}
 def add(label,path):
  path=Path(path);assert path.is_file() and not path.is_symlink(),path
  assert not label.startswith('/') and '..' not in Path(label).parts
  data=path.read_bytes();assert label not in files;files[label]=data
 def tree(label,path):
  for p in sorted(Path(path).rglob('*')):
   if p.is_file():add(label+'/'+p.relative_to(path).as_posix(),p)
 def logs(label,d):
  seen=set()
  def walk(value,parts):
   if isinstance(value,dict):
    for k,v in value.items():walk(v,parts+[str(k)])
   elif isinstance(value,list):
    for i,v in enumerate(value):walk(v,parts+[str(i)])
   elif isinstance(value,str) and value.startswith('/home/rustsql/conformance/'):
    root=Path(value)
    if root in seen:return
    seen.add(root)
    for n in ['server.log','initdb.log']:
     if (root/n).is_file():add(label+'/'+('/'.join(parts) or 'cluster')+'/'+n,root/n)
  walk(d,[])
 for stem in stages:
  candidate=base/(stem+'-candidate');add(stem+'/candidate/manifest.json',candidate/'manifest.json');add(stem+'/candidate/candidate.patch',candidate/'candidate.patch');tree(stem+'/candidate/source',candidate/'source')
  for p in sorted(base.glob(stem+'-*')):
   if p.is_file() and p.suffix in ('.json','.log'):add(stem+'/reports/'+p.name,p)
   elif p.is_dir() and any(t in p.name for t in ['calibration','matrix']):tree(stem+'/'+p.name,p)
  for p in sorted(base.glob('*'+stem.replace('-','_')+'*.py')):add(stem+'/drivers/'+p.name,p)
  # Every report with cluster paths gets its complete server/init logs, never database files or credentials.
  reports=list(base.glob(stem+'-*.json'))
  for p in sorted(base.glob(stem+'-*')):
   if p.is_dir() and any(t in p.name for t in ['calibration','matrix']):reports.extend(p.glob('*.json'))
  for p in reports:
   try:d=json.loads(p.read_text())
   except (ValueError,UnicodeError):continue
   logs(stem+'/cluster-logs/'+p.parent.name+'/'+p.stem,d)
  suite=base/(stem+'-full-suites-20261030.json')
  if suite.exists():
   d=json.loads(suite.read_text());root=Path(d['cluster']);tree(stem+'/sql/regression',root/'regression');tree(stem+'/sql/isolation',root/'isolation');tree(stem+'/sql/audit',base/'conformance'/(stem+'-audit-20261030'))
   add(stem+'/sql/isolation-runner.log',root/'isolation.log');add(stem+'/sql/regression-runner.log',root/'regression.log')
 for p in repo.iterdir():
  if p.is_file() and p.name.upper().startswith(('LICENSE','COPYRIGHT')):add('licenses/'+p.name,p)
 add('baseline/manifest.json',base/'connection-queue-fixed/manifest.json')
 add('reference/native-regression-control.json',base/'native-regression-control.json')
 if final:
  native=json.loads((base/'native-regression-control.json').read_text())
  tree('reference/results',Path(native['results'])/'results')
  fixture=base/'postgres-reference-build/src/test/regress'
  add('reference/fixtures/parallel_schedule',fixture/'parallel_schedule')
  tree('reference/fixtures/sql',fixture/'sql')
  tree('reference/fixtures/expected',fixture/'expected')
 for p in sorted((repo/'scripts/validation').glob('*.py')):add('validation-source/'+p.name,p)
 tree('policy',repo/'regress')
 if not final:
  for p in sorted(base.glob('pool-occupancy-*')):
   if p.is_file():add('occupancy/'+p.name,p)
  for name2 in ['pool_occupancy_probe.py','idle_retention_probe.rs','idle-headroom-validator-checks-20261030.json']:
   add('controls/'+name2,base/name2)
 if not final:
  tree('r1-diagnostic/reports',base/'idle-r1-diagnostic-20261030')
  for p in [base/'idle_r1_diagnostic.py',base/'run_idle_r1_diagnostic.py']+list(base.glob('idle-r1-diagnostic-20261030.*'))+list(base.glob('idle-r1-diagnostic-20261030-*')):
   if p.is_file():add('r1-diagnostic/drivers-and-logs/'+p.name,p)
 add('packager/package_idle_boundary_evidence.py',Path(__file__))
 manifest={p:{'bytes':len(b),'sha256':digest(b)} for p,b in sorted(files.items())}
 raw=io.BytesIO()
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for p,b in sorted(files.items()):
    info=tarfile.TarInfo(p);info.size=len(b);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(b))
 data=raw.getvalue();(out/name).write_bytes(data)
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as tar:
  members=tar.getmembers();assert len(members)==len(manifest)
  for member in members:
   assert member.isfile();b=tar.extractfile(member).read();assert {'bytes':len(b),'sha256':digest(b)}==manifest[member.name]
 return {'file':name,'bytes':len(data),'sha256':digest(data),'members':manifest}
# Do not create the publication package before the final candidate's qualification is complete.
cm=json.loads((base/'idle-boundary-candidate/manifest.json').read_text());assert all(digest((repo/p).read_bytes())==h for p,h in cm['source_lf_sha256'].items())
assert digest((base/'idle-boundary-candidate/bin/postgres').read_bytes())==cm['binaries']['postgres']
matrix=json.loads((base/'idle-boundary-matrix-comparison-20261030.json').read_text());assert matrix['evidence_valid'] and matrix['trials']==40
assert all(q['median_throughput_within_five_percent'] and q['median_p99_within_five_percent'] for q in matrix['limits'])
conn=json.loads((base/'idle-boundary-connection-comparison-20261030.json').read_text());assert conn['accepted_startups']==16000
assert matrix['metadata']['binaries']['candidate']['sha256']==cm['binaries']['postgres']
connection_meta=json.loads((base/'idle-boundary-connection-calibration-20261030/metadata.json').read_text())
assert connection_meta['binaries']['candidate']['sha256']==cm['binaries']['postgres']
assert matrix['metadata']['binaries']['baseline']['sha256']==connection_meta['binaries']['baseline']['sha256']=='2f35e3a361d2b660a73c5aefb739af6178ee3f4dfbd5b9b63f48b165e5d5ec3c'
checks={'production_qualified':False,'candidate':cm,'allocator_tests':units('idle-boundary'),'full_matrix':{'trials':matrix['trials'],'measured_statements':matrix['measured_statements']},'startup_calibration':{'accepted_startups':conn['accepted_startups']},'probes':{},'pressure':[]}
assert checks['allocator_tests']=={'passed':115,'failed':0,'ignored':1,'executables':83}
sys.path.insert(0,str(repo/'scripts/validation'))
from regression_capture import validate_run
suite=json.loads((base/'idle-boundary-full-suites-20261030.json').read_text());validate_run(suite)
assert len(suite['checks'])==12 and suite['isolation']['returncode']==0
assert '# All 510 tests passed.' in (Path(suite['cluster'])/'isolation.log').read_text()
checks['full_suites']={'smoke_checks':len(suite['checks']),'isolation_cases':510,'raw_regression_exit':suite['regression']['returncode'],'capture_complete':suite['capture_complete']}
assert 'test result: ok. 3 passed; 0 failed;' in (base/'idle-boundary-ci-command-20261030.log').read_text()
for label in ['admission','connection-contract','compatibility','recovery','idle-contract']:
 d=json.loads((base/('idle-boundary-'+label+'-20261030.json')).read_text());assert d['passed'];checks['probes'][label]={'passed':True,'checks':len(d['checks'])}
audit=json.loads((base/'conformance/idle-boundary-audit-20261030/summary.json').read_text());assert audit['passed'] and audit['accepted']==audit['total']==231;checks['reviewed_regression']=audit
for i in range(1,4):
 d=json.loads((base/f'idle-boundary-2g-{i}-20261030.json').read_text());assert d['passed'] and not d['remaining_server_pids'];checks['pressure'].append({'peak_mib':d['resources_after_shutdown']['memory_peak']/1048576,'events':d['resources_after_shutdown']['events'],'waves':len(d['waves'])})
out.mkdir(exist_ok=False)
archives=[archive('experiments.tar.gz',['idle-handoff','idle-reuse','idle-reclaim']),archive('evidence.tar.gz',['idle-boundary'],final=True)]
(out/'manifest.json').write_text(json.dumps({'archives':archives},indent=2)+'\n');(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
for n,source in [('mixed-comparison.json','idle-boundary-matrix-comparison-20261030.json'),('connection-comparison.json','idle-boundary-connection-comparison-20261030.json')]:shutil.copyfile(base/source,out/n)
print(json.dumps({'archives':[{k:v for k,v in a.items() if k!='members'}|{'members':len(a['members'])} for a in archives],'out':str(out)}),flush=True)
