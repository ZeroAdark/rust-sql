from pathlib import Path
import subprocess,json,hashlib
root=Path('/home/rustsql/idle-boundary-connection-calibration-20261030');root.mkdir(exist_ok=False)
binaries={'baseline':'/home/rustsql/connection-queue-fixed/bin','candidate':'/home/rustsql/idle-boundary-candidate/bin'}
metadata={'repeats':5,'memory_mib':4096,'allocator':'hearth','server_cpus':[0,2,4,6],'client_cpus':[8,10],'waves':2,'accepted_per_wave':800,'binaries':{k:{'path':v,'sha256':hashlib.sha256((Path(v)/'postgres').read_bytes()).hexdigest()} for k,v in binaries.items()},'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path('/home/rustsql/idle_boundary_queue_probe.py'),Path('/home/rustsql/pgrust/scripts/validation/connection_queue_probe.py'),Path('/home/rustsql/pgrust/scripts/validation/cluster.py'),Path('/home/rustsql/pgrust/scripts/validation/resource_scope.py')]}}
metadata['server_cpu_max']='500000 100000'
source=root/'source';source.mkdir()
for path,sha in metadata['source_sha256'].items():
 p=Path(path);data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==sha;(source/p.name).write_bytes(data)
(root/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
records=[]
for repeat in range(1,6):
 for label in (('baseline','candidate') if repeat%2 else ('candidate','baseline')):
  name=f'idle-boundary-conn-{label}-{repeat}-20261030';unit='rustsql-qualification-'+name;log=root/(label+'-'+str(repeat)+'.log');report=root/(label+'-'+str(repeat)+'.json')
  cmd=['systemd-run','--unit='+unit,'--uid=rustsql','--gid=rustsql','--collect','--wait','--property=Delegate=cpu memory pids','--property=MemoryMax=8G','--property=MemorySwapMax=0','--property=CPUQuota=600%','--property=LimitSTACK=67108864','--property=RuntimeMaxSec=180','--property=StandardOutput=append:'+str(log),'--property=StandardError=append:'+str(log),'/usr/bin/python3','-u','/home/rustsql/idle_boundary_queue_probe.py','--candidate',binaries[label],'--work-dir','/home/rustsql/conformance','--output',str(report),'--burst','--memory-mib','4096']
  # systemd executes the child as rustsql, so its report directory must be writable by that user.
  root.chmod(0o755)
  import os
  os.chown(root,1000,1000)
  r=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=210)
  (root/(label+'-'+str(repeat)+'-journal.log')).write_bytes(subprocess.check_output(['journalctl','-u',unit+'.service','--no-pager','-o','short-iso']))
  d=json.loads(report.read_text()) if report.exists() else {'passed':False}
  record={'label':label,'repeat':repeat,'command':cmd,'exit':r.returncode,'systemd_output':r.stdout,'report':report.name,'passed':d['passed']}
  records.append(record);(root/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
  print(json.dumps({'label':label,'repeat':repeat,'passed':d['passed'],'cpu_us':d.get('cpu_delta',{}).get('usage_usec'),'peak_mib':d.get('resources_after_shutdown',{}).get('memory_peak',0)/1048576,'waves_seconds':[w['seconds'] for w in d.get('waves',[])]}),flush=True)
  if r.returncode or not d['passed']:raise RuntimeError('connection trial failed; retained its raw report')
