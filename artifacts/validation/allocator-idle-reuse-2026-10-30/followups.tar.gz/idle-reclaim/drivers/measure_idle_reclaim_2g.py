from pathlib import Path
import subprocess,json
home=Path('/home/rustsql')
def service(name,argv,timeout=1800):
 log=home/(name+'.log');unit='rustsql-qualification-'+name
 cmd=['systemd-run','--unit='+unit,'--uid=rustsql','--gid=rustsql','--collect','--wait','--property=Delegate=cpu memory pids','--property=MemoryMax=8G','--property=MemorySwapMax=0','--property=CPUQuota=600%','--property=LimitSTACK=67108864','--property=RuntimeMaxSec='+str(timeout),'--property=StandardOutput=append:'+str(log),'--property=StandardError=append:'+str(log),'/usr/bin/python3','-u']+argv
 r=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout+30)
 (home/(name+'-command.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode,'output':r.stdout},indent=2)+'\n')
 (home/(name+'-journal.log')).write_bytes(subprocess.check_output(['journalctl','-u',unit+'.service','--no-pager','-o','short-iso']))
 print(name,r.returncode,r.stdout,flush=True);r.check_returncode()
for repeat in range(1,4):
 name='idle-reclaim-2g-'+str(repeat)+'-20261030'
 service(name,['/home/rustsql/idle_reclaim_queue_probe.py','--candidate','/home/rustsql/idle-reclaim-candidate/bin','--work-dir','/home/rustsql/conformance','--output',str(home/(name+'.json')),'--burst','--memory-mib','2048'],180)
 d=json.loads((home/(name+'.json')).read_text());print('2g',repeat,d['passed'],d['resources_after_shutdown']['memory_peak']/1048576,flush=True)
