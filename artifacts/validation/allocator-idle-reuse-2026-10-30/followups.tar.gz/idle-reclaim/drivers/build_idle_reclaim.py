from pathlib import Path
import subprocess,resource,os,hashlib,json,shutil
resource.setrlimit(resource.RLIMIT_STACK,(67108864,resource.getrlimit(resource.RLIMIT_STACK)[1]))
repo=Path('/home/rustsql/pgrust');out=Path('/home/rustsql/idle-reclaim-candidate/bin');out.mkdir(parents=True,exist_ok=False)
paths=['crates/_support/pagepool/src/small.rs','crates/_support/pagepool/src/lib.rs','crates/_support/pagepool/tests/idle_handoff.rs','crates/backend/tcop/postgres/src/main_loop.rs','crates/gravity/hosts/src/membroker/view.rs','crates/_support/pagepool/src/purger.rs','crates/gravity/driver/src/mem/reclaim.rs']
source_hashes={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
for p in paths:
 target=out.parent/'source'/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/p,target)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
(out.parent/'candidate.patch').write_bytes(subprocess.check_output(['git','diff','HEAD','--'],cwd=repo)+subprocess.run(['git','diff','--no-index','--','/dev/null',paths[2]],cwd=repo,stdout=subprocess.PIPE).stdout)
with open('/home/rustsql/idle-reclaim-pool-tests-20261030.log','w') as log:
 r=subprocess.run(['/home/rustsql/.cargo/bin/cargo','+1.96.0','test','--locked','--release','-j2','-p','pagepool','--features','global','--lib','--tests','--','--test-threads=1'],cwd=repo,env=dict(os.environ,RUST_MIN_STACK='33554432'),stdout=log,stderr=subprocess.STDOUT)
print('pool_tests_exit',r.returncode,flush=True);r.check_returncode()
with open('/home/rustsql/idle-reclaim-build-20261030.log','w') as log:
 r=subprocess.run(['/home/rustsql/.cargo/bin/cargo','+1.96.0','build','--locked','--release','-j2','-p','main_main','-p','initdb'],cwd=repo,env=dict(os.environ,RUST_MIN_STACK='33554432'),stdout=log,stderr=subprocess.STDOUT)
print('build_exit',r.returncode,flush=True);r.check_returncode()
assert source_hashes=={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
assert head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
for name in ('postgres','initdb'):shutil.copyfile(repo/'target/release'/name,out/name);(out/name).chmod(0o755)
shutil.copytree('/home/rustsql/connection-queue-fixed/bin/share',out/'share')
manifest={'source_head':head,'binaries':{n:hashlib.sha256((out/n).read_bytes()).hexdigest() for n in ('postgres','initdb')},'source_lf_sha256':source_hashes}
(out.parent/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest),flush=True)
