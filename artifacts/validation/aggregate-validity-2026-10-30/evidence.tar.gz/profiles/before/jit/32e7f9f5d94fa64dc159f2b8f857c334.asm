
/home/rustsql/profile-candidate-20261030d/jit/32e7f9f5d94fa64dc159f2b8f857c334.x86_64.bin:     file format binary


Disassembly of section .data:

0000000000000180 <.data+0x180>:
     180:	55                   	push   %rbp
     181:	48 89 e5             	mov    %rsp,%rbp
     184:	53                   	push   %rbx
     185:	41 54                	push   %r12
     187:	41 55                	push   %r13
     189:	41 56                	push   %r14
     18b:	41 57                	push   %r15
     18d:	48 81 ec 38 02 00 00 	sub    $0x238,%rsp
     194:	48 89 fb             	mov    %rdi,%rbx
     197:	31 c0                	xor    %eax,%eax
     199:	b9 01 00 00 00       	mov    $0x1,%ecx
     19e:	48 8b 53 58          	mov    0x58(%rbx),%rdx
     1a2:	48 8d b5 40 ff ff ff 	lea    -0xc0(%rbp),%rsi
     1a9:	49 89 f4             	mov    %rsi,%r12
     1ac:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
     1b0:	48 85 ff             	test   %rdi,%rdi
     1b3:	0f 85 53 02 00 00    	jne    0x40c
     1b9:	48 bf 01 00 00 00 00 	movabs $0x4000000000001,%rdi
     1c0:	00 04 00 
     1c3:	48 89 7b 50          	mov    %rdi,0x50(%rbx)
     1c7:	48 8b 7a 18          	mov    0x18(%rdx),%rdi
     1cb:	4c 8b 42 20          	mov    0x20(%rdx),%r8
     1cf:	4d 89 c1             	mov    %r8,%r9
     1d2:	49 29 f9             	sub    %rdi,%r9
     1d5:	49 01 c9             	add    %rcx,%r9
     1d8:	49 39 f8             	cmp    %rdi,%r8
     1db:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     1e1:	41 0f 9c c0          	setl   %r8b
     1e5:	49 89 c2             	mov    %rax,%r10
     1e8:	4d 85 c0             	test   %r8,%r8
     1eb:	4d 0f 44 d1          	cmove  %r9,%r10
     1ef:	41 b8 99 19 00 00    	mov    $0x1999,%r8d
     1f5:	4c 8b 4a 28          	mov    0x28(%rdx),%r9
     1f9:	49 39 c1             	cmp    %rax,%r9
     1fc:	41 bb 00 00 00 00    	mov    $0x0,%r11d
     202:	41 0f 94 c3          	sete   %r11b
     206:	4d 85 db             	test   %r11,%r11
     209:	4d 0f 44 c1          	cmove  %r9,%r8
     20d:	49 39 c2             	cmp    %rax,%r10
     210:	41 bd 00 00 00 00    	mov    $0x0,%r13d
     216:	41 0f 94 c5          	sete   %r13b
     21a:	4d 89 d6             	mov    %r10,%r14
     21d:	49 01 ce             	add    %rcx,%r14
     220:	49 89 c7             	mov    %rax,%r15
     223:	4d 85 ed             	test   %r13,%r13
     226:	4d 0f 44 fe          	cmove  %r14,%r15
     22a:	4d 85 ed             	test   %r13,%r13
     22d:	4d 0f 44 c7          	cmove  %r15,%r8
     231:	41 bd 99 19 00 00    	mov    $0x1999,%r13d
     237:	4d 85 db             	test   %r11,%r11
     23a:	4d 0f 44 e9          	cmove  %r9,%r13
     23e:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
     244:	4d 39 e8             	cmp    %r13,%r8
     247:	4d 0f 47 c5          	cmova  %r13,%r8
     24b:	4d 39 c8             	cmp    %r9,%r8
     24e:	4d 0f 47 c1          	cmova  %r9,%r8
     252:	4c 8d 8d 10 ff ff ff 	lea    -0xf0(%rbp),%r9
     259:	4d 89 cb             	mov    %r9,%r11
     25c:	41 bd 02 02 01 01    	mov    $0x1010202,%r13d
     262:	4d 89 2b             	mov    %r13,(%r11)
     265:	41 bd 00 00 00 01    	mov    $0x1000000,%r13d
     26b:	4d 89 6b 08          	mov    %r13,0x8(%r11)
     26f:	41 bd 00 00 10 18    	mov    $0x18100000,%r13d
     275:	4d 89 6b 10          	mov    %r13,0x10(%r11)
     279:	49 bd 00 00 28 01 10 	movabs $0x201001280000,%r13
     280:	20 00 00 
     283:	4d 89 6b 18          	mov    %r13,0x18(%r11)
     287:	45 31 ed             	xor    %r13d,%r13d
     28a:	4d 89 6b 20          	mov    %r13,0x20(%r11)
     28e:	41 bd 99 19 00 00    	mov    $0x1999,%r13d
     294:	4c 8b 72 28          	mov    0x28(%rdx),%r14
     298:	49 39 c6             	cmp    %rax,%r14
     29b:	ba 00 00 00 00       	mov    $0x0,%edx
     2a0:	0f 94 c2             	sete   %dl
     2a3:	48 85 d2             	test   %rdx,%rdx
     2a6:	4d 0f 44 ee          	cmove  %r14,%r13
     2aa:	ba cd cc cc 00       	mov    $0xcccccd,%edx
     2af:	49 39 d5             	cmp    %rdx,%r13
     2b2:	41 be 00 00 00 00    	mov    $0x0,%r14d
     2b8:	41 0f 97 c6          	seta   %r14b
     2bc:	4d 85 f6             	test   %r14,%r14
     2bf:	49 0f 44 d5          	cmove  %r13,%rdx
     2c3:	41 bd 28 00 00 00    	mov    $0x28,%r13d
     2c9:	49 0f af d5          	imul   %r13,%rdx
     2cd:	48 81 c2 ff ff 03 00 	add    $0x3ffff,%rdx
     2d4:	48 c1 ea 12          	shr    $0x12,%rdx
     2d8:	48 83 fa 01          	cmp    $0x1,%rdx
     2dc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
     2e2:	41 0f 97 c5          	seta   %r13b
     2e6:	48 83 ea 01          	sub    $0x1,%rdx
     2ea:	4c 0f bd f2          	bsr    %rdx,%r14
     2ee:	ba 7f 00 00 00       	mov    $0x7f,%edx
     2f3:	49 0f 45 d6          	cmovne %r14,%rdx
     2f7:	83 f2 3f             	xor    $0x3f,%edx
     2fa:	41 be 40 00 00 00    	mov    $0x40,%r14d
     300:	49 29 d6             	sub    %rdx,%r14
     303:	ba 0b 00 00 00       	mov    $0xb,%edx
     308:	49 39 d6             	cmp    %rdx,%r14
     30b:	be 00 00 00 00       	mov    $0x0,%esi
     310:	40 0f 97 c6          	seta   %sil
     314:	48 85 f6             	test   %rsi,%rsi
     317:	49 0f 44 d6          	cmove  %r14,%rdx
     31b:	31 f6                	xor    %esi,%esi
     31d:	4d 85 ed             	test   %r13,%r13
     320:	48 0f 44 d6          	cmove  %rsi,%rdx
     324:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
     328:	48 89 df             	mov    %rbx,%rdi
     32b:	4c 89 e6             	mov    %r12,%rsi
     32e:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
     335:	4c 89 da             	mov    %r11,%rdx
     338:	48 8b 8d b8 fe ff ff 	mov    -0x148(%rbp),%rcx
     33f:	4c 89 95 b0 fe ff ff 	mov    %r10,-0x150(%rbp)
     346:	4c 89 9d a8 fe ff ff 	mov    %r11,-0x158(%rbp)
     34d:	e8 ae fc ff ff       	call   0x0
     352:	48 83 f8 00          	cmp    $0x0,%rax
     356:	0f 8d 08 00 00 00    	jge    0x364
     35c:	49 89 c5             	mov    %rax,%r13
     35f:	e9 7a 1a 00 00       	jmp    0x1dde
     364:	31 c0                	xor    %eax,%eax
     366:	48 89 df             	mov    %rbx,%rdi
     369:	48 89 c6             	mov    %rax,%rsi
     36c:	48 8b 95 a8 fe ff ff 	mov    -0x158(%rbp),%rdx
     373:	48 8b 8d b8 fe ff ff 	mov    -0x148(%rbp),%rcx
     37a:	e8 91 fc ff ff       	call   0x10
     37f:	49 8b 04 24          	mov    (%r12),%rax
     383:	31 c9                	xor    %ecx,%ecx
     385:	48 8d 54 08 10       	lea    0x10(%rax,%rcx,1),%rdx
     38a:	49 89 54 24 40       	mov    %rdx,0x40(%r12)
     38f:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
     394:	49 8b 04 24          	mov    (%r12),%rax
     398:	0f b6 50 0d          	movzbl 0xd(%rax),%edx
     39c:	48 83 e2 01          	and    $0x1,%rdx
     3a0:	49 89 54 24 68       	mov    %rdx,0x68(%r12)
     3a5:	49 8b 04 24          	mov    (%r12),%rax
     3a9:	8b 30                	mov    (%rax),%esi
     3ab:	b8 01 00 00 00       	mov    $0x1,%eax
     3b0:	49 29 c7             	sub    %rax,%r15
     3b3:	49 39 f7             	cmp    %rsi,%r15
     3b6:	41 bf 00 00 00 00    	mov    $0x0,%r15d
     3bc:	41 0f 92 c7          	setb   %r15b
     3c0:	48 39 ca             	cmp    %rcx,%rdx
     3c3:	ba 00 00 00 00       	mov    $0x0,%edx
     3c8:	0f 94 c2             	sete   %dl
     3cb:	4d 85 ff             	test   %r15,%r15
     3ce:	48 0f 44 d1          	cmove  %rcx,%rdx
     3d2:	49 8d 74 0c 70       	lea    0x70(%r12,%rcx,1),%rsi
     3d7:	48 89 16             	mov    %rdx,(%rsi)
     3da:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
     3de:	48 89 56 08          	mov    %rdx,0x8(%rsi)
     3e2:	48 8b 95 b0 fe ff ff 	mov    -0x150(%rbp),%rdx
     3e9:	48 89 56 10          	mov    %rdx,0x10(%rsi)
     3ed:	31 d2                	xor    %edx,%edx
     3ef:	48 89 df             	mov    %rbx,%rdi
     3f2:	48 89 d6             	mov    %rdx,%rsi
     3f5:	e8 26 fc ff ff       	call   0x20
     3fa:	48 83 f8 00          	cmp    $0x0,%rax
     3fe:	0f 8d 08 00 00 00    	jge    0x40c
     404:	49 89 c5             	mov    %rax,%r13
     407:	e9 d2 19 00 00       	jmp    0x1dde
     40c:	48 8b 43 18          	mov    0x18(%rbx),%rax
     410:	48 85 c0             	test   %rax,%rax
     413:	0f 84 0c 00 00 00    	je     0x425
     419:	0f b6 08             	movzbl (%rax),%ecx
     41c:	48 85 c9             	test   %rcx,%rcx
     41f:	0f 85 41 19 00 00    	jne    0x1d66
     425:	31 c0                	xor    %eax,%eax
     427:	48 89 df             	mov    %rbx,%rdi
     42a:	48 89 c6             	mov    %rax,%rsi
     42d:	e8 fe fb ff ff       	call   0x30
     432:	48 83 f8 00          	cmp    $0x0,%rax
     436:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
     43d:	0f 8e 40 19 00 00    	jle    0x1d83
     443:	8b 8b 00 01 00 00    	mov    0x100(%rbx),%ecx
     449:	8b 93 fc 00 00 00    	mov    0xfc(%rbx),%edx
     44f:	4c 8b b3 d0 00 00 00 	mov    0xd0(%rbx),%r14
     456:	31 f6                	xor    %esi,%esi
     458:	49 39 f6             	cmp    %rsi,%r14
     45b:	41 bf 00 00 00 00    	mov    $0x0,%r15d
     461:	41 0f 94 c7          	sete   %r15b
     465:	8b bb 04 01 00 00    	mov    0x104(%rbx),%edi
     46b:	4d 85 ff             	test   %r15,%r15
     46e:	48 0f 44 d7          	cmove  %rdi,%rdx
     472:	48 8b bb a0 00 00 00 	mov    0xa0(%rbx),%rdi
     479:	4c 8b 07             	mov    (%rdi),%r8
     47c:	4c 8b 4f 08          	mov    0x8(%rdi),%r9
     480:	49 39 f1             	cmp    %rsi,%r9
     483:	41 ba 00 00 00 00    	mov    $0x0,%r10d
     489:	41 0f 94 c2          	sete   %r10b
     48d:	4c 8b 5f 20          	mov    0x20(%rdi),%r11
     491:	48 8b 47 28          	mov    0x28(%rdi),%rax
     495:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
     499:	48 39 f0             	cmp    %rsi,%rax
     49c:	bf 00 00 00 00       	mov    $0x0,%edi
     4a1:	40 0f 94 c7          	sete   %dil
     4a5:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
     4a9:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
     4b0:	8b 46 1c             	mov    0x1c(%rsi),%eax
     4b3:	31 f6                	xor    %esi,%esi
     4b5:	48 39 f0             	cmp    %rsi,%rax
     4b8:	b8 00 00 00 00       	mov    $0x0,%eax
     4bd:	0f 95 c0             	setne  %al
     4c0:	48 85 c0             	test   %rax,%rax
     4c3:	48 89 85 a8 fe ff ff 	mov    %rax,-0x158(%rbp)
     4ca:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
     4d1:	48 89 95 98 fe ff ff 	mov    %rdx,-0x168(%rbp)
     4d8:	48 89 bd 90 fe ff ff 	mov    %rdi,-0x170(%rbp)
     4df:	4c 89 85 88 fe ff ff 	mov    %r8,-0x178(%rbp)
     4e6:	4c 89 8d 80 fe ff ff 	mov    %r9,-0x180(%rbp)
     4ed:	4c 89 95 78 fe ff ff 	mov    %r10,-0x188(%rbp)
     4f4:	4c 89 9d 70 fe ff ff 	mov    %r11,-0x190(%rbp)
     4fb:	0f 85 08 00 00 00    	jne    0x509
     501:	48 89 f7             	mov    %rsi,%rdi
     504:	e9 0d 00 00 00       	jmp    0x516
     509:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
     50d:	4d 8b 11             	mov    (%r9),%r10
     510:	4d 63 0a             	movslq (%r10),%r9
     513:	4c 89 cf             	mov    %r9,%rdi
     516:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
     51d:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
     524:	48 89 c2             	mov    %rax,%rdx
     527:	48 21 ca             	and    %rcx,%rdx
     52a:	48 be df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rsi
     531:	82 28 52 
     534:	31 ff                	xor    %edi,%edi
     536:	4c 21 fa             	and    %r15,%rdx
     539:	48 85 d2             	test   %rdx,%rdx
     53c:	0f 85 b8 09 00 00    	jne    0xefa
     542:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
     549:	48 89 55 d0          	mov    %rdx,-0x30(%rbp)
     54d:	31 d2                	xor    %edx,%edx
     54f:	48 89 95 68 fe ff ff 	mov    %rdx,-0x198(%rbp)
     556:	31 d2                	xor    %edx,%edx
     558:	48 89 95 60 fe ff ff 	mov    %rdx,-0x1a0(%rbp)
     55f:	31 d2                	xor    %edx,%edx
     561:	48 89 95 58 fe ff ff 	mov    %rdx,-0x1a8(%rbp)
     568:	48 89 b5 50 fe ff ff 	mov    %rsi,-0x1b0(%rbp)
     56f:	31 d2                	xor    %edx,%edx
     571:	48 89 95 48 fe ff ff 	mov    %rdx,-0x1b8(%rbp)
     578:	31 d2                	xor    %edx,%edx
     57a:	48 89 95 40 fe ff ff 	mov    %rdx,-0x1c0(%rbp)
     581:	48 89 bd 38 fe ff ff 	mov    %rdi,-0x1c8(%rbp)
     588:	31 d2                	xor    %edx,%edx
     58a:	48 89 95 30 fe ff ff 	mov    %rdx,-0x1d0(%rbp)
     591:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
     595:	48 8b 8d 98 fe ff ff 	mov    -0x168(%rbp),%rcx
     59c:	48 39 c8             	cmp    %rcx,%rax
     59f:	0f 8c 75 00 00 00    	jl     0x61a
     5a5:	48 8b 95 68 fe ff ff 	mov    -0x198(%rbp),%rdx
     5ac:	48 89 95 28 fe ff ff 	mov    %rdx,-0x1d8(%rbp)
     5b3:	48 8b 95 48 fe ff ff 	mov    -0x1b8(%rbp),%rdx
     5ba:	48 89 95 20 fe ff ff 	mov    %rdx,-0x1e0(%rbp)
     5c1:	48 8b 95 40 fe ff ff 	mov    -0x1c0(%rbp),%rdx
     5c8:	48 89 95 18 fe ff ff 	mov    %rdx,-0x1e8(%rbp)
     5cf:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
     5d6:	48 89 95 10 fe ff ff 	mov    %rdx,-0x1f0(%rbp)
     5dd:	48 8b 95 58 fe ff ff 	mov    -0x1a8(%rbp),%rdx
     5e4:	48 89 95 08 fe ff ff 	mov    %rdx,-0x1f8(%rbp)
     5eb:	48 8b 95 38 fe ff ff 	mov    -0x1c8(%rbp),%rdx
     5f2:	48 89 95 00 fe ff ff 	mov    %rdx,-0x200(%rbp)
     5f9:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
     600:	48 89 95 f8 fd ff ff 	mov    %rdx,-0x208(%rbp)
     607:	48 8b 95 50 fe ff ff 	mov    -0x1b0(%rbp),%rdx
     60e:	48 89 95 f0 fd ff ff 	mov    %rdx,-0x210(%rbp)
     615:	e9 43 11 00 00       	jmp    0x175d
     61a:	4d 85 ff             	test   %r15,%r15
     61d:	0f 84 08 00 00 00    	je     0x62b
     623:	48 89 c6             	mov    %rax,%rsi
     626:	e9 09 00 00 00       	jmp    0x634
     62b:	49 8d 14 86          	lea    (%r14,%rax,4),%rdx
     62f:	8b 3a                	mov    (%rdx),%edi
     631:	48 89 fe             	mov    %rdi,%rsi
     634:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
     63b:	48 8d 0c b0          	lea    (%rax,%rsi,4),%rcx
     63f:	48 89 f2             	mov    %rsi,%rdx
     642:	48 c1 ea 06          	shr    $0x6,%rdx
     646:	48 8b bd 80 fe ff ff 	mov    -0x180(%rbp),%rdi
     64d:	4c 8d 04 d7          	lea    (%rdi,%rdx,8),%r8
     651:	48 8b 95 78 fe ff ff 	mov    -0x188(%rbp),%rdx
     658:	49 89 d9             	mov    %rbx,%r9
     65b:	48 85 d2             	test   %rdx,%rdx
     65e:	4d 0f 44 c8          	cmove  %r8,%r9
     662:	4d 8b 01             	mov    (%r9),%r8
     665:	49 89 f1             	mov    %rsi,%r9
     668:	49 83 e1 3f          	and    $0x3f,%r9
     66c:	48 89 8d e8 fd ff ff 	mov    %rcx,-0x218(%rbp)
     673:	4c 89 c9             	mov    %r9,%rcx
     676:	49 d3 e8             	shr    %cl,%r8
     679:	b9 01 00 00 00       	mov    $0x1,%ecx
     67e:	49 21 c8             	and    %rcx,%r8
     681:	45 31 c9             	xor    %r9d,%r9d
     684:	4d 39 c8             	cmp    %r9,%r8
     687:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     68d:	41 0f 94 c0          	sete   %r8b
     691:	41 ba 01 00 00 00    	mov    $0x1,%r10d
     697:	49 89 d3             	mov    %rdx,%r11
     69a:	4d 31 d3             	xor    %r10,%r11
     69d:	4d 21 d8             	and    %r11,%r8
     6a0:	4c 8b 95 70 fe ff ff 	mov    -0x190(%rbp),%r10
     6a7:	4d 8d 1c b2          	lea    (%r10,%rsi,4),%r11
     6ab:	48 89 f2             	mov    %rsi,%rdx
     6ae:	48 c1 ea 06          	shr    $0x6,%rdx
     6b2:	48 8b bd b8 fe ff ff 	mov    -0x148(%rbp),%rdi
     6b9:	48 8d 04 d7          	lea    (%rdi,%rdx,8),%rax
     6bd:	48 8b 95 90 fe ff ff 	mov    -0x170(%rbp),%rdx
     6c4:	48 89 df             	mov    %rbx,%rdi
     6c7:	48 85 d2             	test   %rdx,%rdx
     6ca:	48 0f 44 f8          	cmove  %rax,%rdi
     6ce:	48 8b 07             	mov    (%rdi),%rax
     6d1:	48 83 e6 3f          	and    $0x3f,%rsi
     6d5:	48 89 f1             	mov    %rsi,%rcx
     6d8:	48 d3 e8             	shr    %cl,%rax
     6db:	b9 01 00 00 00       	mov    $0x1,%ecx
     6e0:	48 21 c8             	and    %rcx,%rax
     6e3:	4c 39 c8             	cmp    %r9,%rax
     6e6:	b8 00 00 00 00       	mov    $0x0,%eax
     6eb:	0f 94 c0             	sete   %al
     6ee:	be 01 00 00 00       	mov    $0x1,%esi
     6f3:	48 89 d7             	mov    %rdx,%rdi
     6f6:	48 31 f7             	xor    %rsi,%rdi
     6f9:	48 21 f8             	and    %rdi,%rax
     6fc:	48 8b b5 68 fe ff ff 	mov    -0x198(%rbp),%rsi
     703:	48 89 f7             	mov    %rsi,%rdi
     706:	48 83 c7 01          	add    $0x1,%rdi
     70a:	48 8b 95 e8 fd ff ff 	mov    -0x218(%rbp),%rdx
     711:	48 63 32             	movslq (%rdx),%rsi
     714:	31 d2                	xor    %edx,%edx
     716:	4d 85 c0             	test   %r8,%r8
     719:	48 0f 44 d6          	cmove  %rsi,%rdx
     71d:	48 8b b5 a8 fe ff ff 	mov    -0x158(%rbp),%rsi
     724:	48 85 f6             	test   %rsi,%rsi
     727:	48 89 85 e8 fd ff ff 	mov    %rax,-0x218(%rbp)
     72e:	48 89 95 e0 fd ff ff 	mov    %rdx,-0x220(%rbp)
     735:	48 89 bd d8 fd ff ff 	mov    %rdi,-0x228(%rbp)
     73c:	4c 89 85 d0 fd ff ff 	mov    %r8,-0x230(%rbp)
     743:	4c 89 9d c8 fd ff ff 	mov    %r11,-0x238(%rbp)
     74a:	0f 84 10 00 00 00    	je     0x760
     750:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
     757:	48 85 c0             	test   %rax,%rax
     75a:	0f 85 40 00 00 00    	jne    0x7a0
     760:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
     767:	48 8b 8d e0 fd ff ff 	mov    -0x220(%rbp),%rcx
     76e:	48 39 c8             	cmp    %rcx,%rax
     771:	ba 00 00 00 00       	mov    $0x0,%edx
     776:	0f 94 c2             	sete   %dl
     779:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
     780:	48 8b bd d0 fd ff ff 	mov    -0x230(%rbp),%rdi
     787:	48 39 fe             	cmp    %rdi,%rsi
     78a:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     790:	41 0f 94 c0          	sete   %r8b
     794:	4c 21 c2             	and    %r8,%rdx
     797:	48 85 d2             	test   %rdx,%rdx
     79a:	0f 84 67 00 00 00    	je     0x807
     7a0:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
     7a7:	48 89 c1             	mov    %rax,%rcx
     7aa:	48 83 c1 01          	add    $0x1,%rcx
     7ae:	ba 01 00 00 00       	mov    $0x1,%edx
     7b3:	48 8b b5 c8 fd ff ff 	mov    -0x238(%rbp),%rsi
     7ba:	48 63 3e             	movslq (%rsi),%rdi
     7bd:	4c 8b 85 e8 fd ff ff 	mov    -0x218(%rbp),%r8
     7c4:	4d 89 c1             	mov    %r8,%r9
     7c7:	49 31 d1             	xor    %rdx,%r9
     7ca:	31 d2                	xor    %edx,%edx
     7cc:	4d 85 c9             	test   %r9,%r9
     7cf:	48 0f 44 fa          	cmove  %rdx,%rdi
     7d3:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
     7da:	49 89 d2             	mov    %rdx,%r10
     7dd:	4d 01 ca             	add    %r9,%r10
     7e0:	4c 8b 8d 38 fe ff ff 	mov    -0x1c8(%rbp),%r9
     7e7:	4d 89 cb             	mov    %r9,%r11
     7ea:	49 01 fb             	add    %rdi,%r11
     7ed:	48 89 8d 40 fe ff ff 	mov    %rcx,-0x1c0(%rbp)
     7f4:	4c 89 9d 38 fe ff ff 	mov    %r11,-0x1c8(%rbp)
     7fb:	4c 89 95 30 fe ff ff 	mov    %r10,-0x1d0(%rbp)
     802:	e9 c6 06 00 00       	jmp    0xecd
     807:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
     80e:	48 85 c0             	test   %rax,%rax
     811:	0f 84 1d 06 00 00    	je     0xe34
     817:	31 c9                	xor    %ecx,%ecx
     819:	49 8d 54 0c 70       	lea    0x70(%r12,%rcx,1),%rdx
     81e:	48 8b 32             	mov    (%rdx),%rsi
     821:	48 85 f6             	test   %rsi,%rsi
     824:	0f 84 3d 02 00 00    	je     0xa67
     82a:	49 8d 54 0c 70       	lea    0x70(%r12,%rcx,1),%rdx
     82f:	48 8b 72 08          	mov    0x8(%rdx),%rsi
     833:	49 8b 3c 24          	mov    (%r12),%rdi
     837:	44 8b 07             	mov    (%rdi),%r8d
     83a:	48 8b bd 60 fe ff ff 	mov    -0x1a0(%rbp),%rdi
     841:	49 89 f9             	mov    %rdi,%r9
     844:	49 29 f1             	sub    %rsi,%r9
     847:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
     84e:	48 39 ce             	cmp    %rcx,%rsi
     851:	41 ba 00 00 00 00    	mov    $0x0,%r10d
     857:	41 0f 95 c2          	setne  %r10b
     85b:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
     85f:	4c 89 da             	mov    %r11,%rdx
     862:	4d 85 d2             	test   %r10,%r10
     865:	49 0f 44 d1          	cmove  %r9,%rdx
     869:	4d 85 d2             	test   %r10,%r10
     86c:	4d 0f 44 c3          	cmove  %r11,%r8
     870:	4d 8b 4c 24 10       	mov    0x10(%r12),%r9
     875:	41 ba 28 00 00 00    	mov    $0x28,%r10d
     87b:	49 89 d3             	mov    %rdx,%r11
     87e:	4d 0f af da          	imul   %r10,%r11
     882:	4f 8d 14 19          	lea    (%r9,%r11,1),%r10
     886:	4c 39 c2             	cmp    %r8,%rdx
     889:	0f 83 b2 00 00 00    	jae    0x941
     88f:	4d 8b 42 10          	mov    0x10(%r10),%r8
     893:	4d 85 c0             	test   %r8,%r8
     896:	0f 84 16 00 00 00    	je     0x8b2
     89c:	4c 89 95 c0 fd ff ff 	mov    %r10,-0x240(%rbp)
     8a3:	45 31 c0             	xor    %r8d,%r8d
     8a6:	4c 89 85 b8 fd ff ff 	mov    %r8,-0x248(%rbp)
     8ad:	e9 7c 04 00 00       	jmp    0xd2e
     8b2:	45 31 c0             	xor    %r8d,%r8d
     8b5:	49 89 3a             	mov    %rdi,(%r10)
     8b8:	49 89 72 08          	mov    %rsi,0x8(%r10)
     8bc:	4d 89 42 10          	mov    %r8,0x10(%r10)
     8c0:	4d 89 42 18          	mov    %r8,0x18(%r10)
     8c4:	4d 89 42 20          	mov    %r8,0x20(%r10)
     8c8:	4d 8b 04 24          	mov    (%r12),%r8
     8cc:	45 8b 48 04          	mov    0x4(%r8),%r9d
     8d0:	41 bb 01 00 00 00    	mov    $0x1,%r11d
     8d6:	4d 01 d9             	add    %r11,%r9
     8d9:	45 89 48 04          	mov    %r9d,0x4(%r8)
     8dd:	4d 8b 4c 24 38       	mov    0x38(%r12),%r9
     8e2:	b8 40 00 00 00       	mov    $0x40,%eax
     8e7:	4c 29 c8             	sub    %r9,%rax
     8ea:	48 8b b5 50 fe ff ff 	mov    -0x1b0(%rbp),%rsi
     8f1:	48 89 c1             	mov    %rax,%rcx
     8f4:	48 89 f7             	mov    %rsi,%rdi
     8f7:	48 d3 ef             	shr    %cl,%rdi
     8fa:	31 c0                	xor    %eax,%eax
     8fc:	49 39 c1             	cmp    %rax,%r9
     8ff:	41 b9 00 00 00 00    	mov    $0x0,%r9d
     905:	41 0f 94 c1          	sete   %r9b
     909:	4d 85 c9             	test   %r9,%r9
     90c:	48 0f 44 c7          	cmove  %rdi,%rax
     910:	41 8b 48 4c          	mov    0x4c(%r8),%ecx
     914:	49 8d 3c 08          	lea    (%r8,%rcx,1),%rdi
     918:	48 8d 0c 97          	lea    (%rdi,%rdx,4),%rcx
     91c:	89 01                	mov    %eax,(%rcx)
     91e:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
     925:	41 89 40 50          	mov    %eax,0x50(%r8)
     929:	4c 89 95 c0 fd ff ff 	mov    %r10,-0x240(%rbp)
     930:	b8 01 00 00 00       	mov    $0x1,%eax
     935:	48 89 85 b8 fd ff ff 	mov    %rax,-0x248(%rbp)
     93c:	e9 ed 03 00 00       	jmp    0xd2e
     941:	49 8b 44 24 38       	mov    0x38(%r12),%rax
     946:	b9 40 00 00 00       	mov    $0x40,%ecx
     94b:	48 29 c1             	sub    %rax,%rcx
     94e:	48 89 8d b0 fd ff ff 	mov    %rcx,-0x250(%rbp)
     955:	48 8b 95 50 fe ff ff 	mov    -0x1b0(%rbp),%rdx
     95c:	48 8b b5 b0 fd ff ff 	mov    -0x250(%rbp),%rsi
     963:	48 89 f1             	mov    %rsi,%rcx
     966:	48 89 d7             	mov    %rdx,%rdi
     969:	48 d3 ef             	shr    %cl,%rdi
     96c:	31 c9                	xor    %ecx,%ecx
     96e:	48 39 c8             	cmp    %rcx,%rax
     971:	b8 00 00 00 00       	mov    $0x0,%eax
     976:	0f 94 c0             	sete   %al
     979:	48 85 c0             	test   %rax,%rax
     97c:	48 0f 44 cf          	cmove  %rdi,%rcx
     980:	49 8b 44 24 08       	mov    0x8(%r12),%rax
     985:	48 8d 34 c8          	lea    (%rax,%rcx,8),%rsi
     989:	48 8b 06             	mov    (%rsi),%rax
     98c:	48 bf 00 00 00 00 00 	movabs $0x28000000000000,%rdi
     993:	00 28 00 
     996:	48 39 f8             	cmp    %rdi,%rax
     999:	48 89 b5 b0 fd ff ff 	mov    %rsi,-0x250(%rbp)
     9a0:	0f 82 0c 00 00 00    	jb     0x9b2
     9a6:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
     9ad:	e9 36 00 00 00       	jmp    0x9e8
     9b2:	49 8b 44 24 60       	mov    0x60(%r12),%rax
     9b7:	48 89 df             	mov    %rbx,%rdi
     9ba:	4c 89 e6             	mov    %r12,%rsi
     9bd:	48 89 ca             	mov    %rcx,%rdx
     9c0:	48 89 c1             	mov    %rax,%rcx
     9c3:	e8 78 f6 ff ff       	call   0x40
     9c8:	31 c9                	xor    %ecx,%ecx
     9ca:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
     9cf:	48 83 f8 00          	cmp    $0x0,%rax
     9d3:	0f 8f 08 00 00 00    	jg     0x9e1
     9d9:	49 89 c5             	mov    %rax,%r13
     9dc:	e9 fd 13 00 00       	jmp    0x1dde
     9e1:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
     9e8:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
     9ef:	48 89 c1             	mov    %rax,%rcx
     9f2:	48 83 c1 28          	add    $0x28,%rcx
     9f6:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
     9fd:	00 28 00 
     a00:	48 29 d1             	sub    %rdx,%rcx
     a03:	48 8b 95 b0 fd ff ff 	mov    -0x250(%rbp),%rdx
     a0a:	48 89 0a             	mov    %rcx,(%rdx)
     a0d:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
     a14:	ff 00 00 
     a17:	48 21 c8             	and    %rcx,%rax
     a1a:	31 c9                	xor    %ecx,%ecx
     a1c:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
     a23:	48 89 10             	mov    %rdx,(%rax)
     a26:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
     a2d:	48 89 70 08          	mov    %rsi,0x8(%rax)
     a31:	48 89 48 10          	mov    %rcx,0x10(%rax)
     a35:	48 89 48 18          	mov    %rcx,0x18(%rax)
     a39:	48 89 48 20          	mov    %rcx,0x20(%rax)
     a3d:	49 8b 4c 24 60       	mov    0x60(%r12),%rcx
     a42:	bf 01 00 00 00       	mov    $0x1,%edi
     a47:	48 01 f9             	add    %rdi,%rcx
     a4a:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
     a4f:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
     a56:	b8 01 00 00 00       	mov    $0x1,%eax
     a5b:	48 89 85 b8 fd ff ff 	mov    %rax,-0x248(%rbp)
     a62:	e9 c7 02 00 00       	jmp    0xd2e
     a67:	49 8b 44 24 68       	mov    0x68(%r12),%rax
     a6c:	48 85 c0             	test   %rax,%rax
     a6f:	0f 84 2f 01 00 00    	je     0xba4
     a75:	49 8b 44 24 38       	mov    0x38(%r12),%rax
     a7a:	b9 40 00 00 00       	mov    $0x40,%ecx
     a7f:	48 29 c1             	sub    %rax,%rcx
     a82:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
     a89:	48 8b 95 50 fe ff ff 	mov    -0x1b0(%rbp),%rdx
     a90:	48 8b b5 a8 fd ff ff 	mov    -0x258(%rbp),%rsi
     a97:	48 89 f1             	mov    %rsi,%rcx
     a9a:	48 89 d7             	mov    %rdx,%rdi
     a9d:	48 d3 ef             	shr    %cl,%rdi
     aa0:	31 c9                	xor    %ecx,%ecx
     aa2:	48 39 c8             	cmp    %rcx,%rax
     aa5:	b8 00 00 00 00       	mov    $0x0,%eax
     aaa:	0f 94 c0             	sete   %al
     aad:	48 85 c0             	test   %rax,%rax
     ab0:	48 0f 44 cf          	cmove  %rdi,%rcx
     ab4:	49 8b 44 24 08       	mov    0x8(%r12),%rax
     ab9:	48 8d 34 c8          	lea    (%rax,%rcx,8),%rsi
     abd:	48 8b 06             	mov    (%rsi),%rax
     ac0:	48 bf 00 00 00 00 00 	movabs $0x28000000000000,%rdi
     ac7:	00 28 00 
     aca:	48 39 f8             	cmp    %rdi,%rax
     acd:	48 89 b5 a8 fd ff ff 	mov    %rsi,-0x258(%rbp)
     ad4:	0f 82 0c 00 00 00    	jb     0xae6
     ada:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
     ae1:	e9 36 00 00 00       	jmp    0xb1c
     ae6:	49 8b 44 24 60       	mov    0x60(%r12),%rax
     aeb:	48 89 df             	mov    %rbx,%rdi
     aee:	4c 89 e6             	mov    %r12,%rsi
     af1:	48 89 ca             	mov    %rcx,%rdx
     af4:	48 89 c1             	mov    %rax,%rcx
     af7:	e8 44 f5 ff ff       	call   0x40
     afc:	31 c9                	xor    %ecx,%ecx
     afe:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
     b03:	48 83 f8 00          	cmp    $0x0,%rax
     b07:	0f 8f 08 00 00 00    	jg     0xb15
     b0d:	49 89 c5             	mov    %rax,%r13
     b10:	e9 c9 12 00 00       	jmp    0x1dde
     b15:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
     b1c:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
     b23:	48 89 c1             	mov    %rax,%rcx
     b26:	48 83 c1 28          	add    $0x28,%rcx
     b2a:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
     b31:	00 28 00 
     b34:	48 29 d1             	sub    %rdx,%rcx
     b37:	48 8b 95 a8 fd ff ff 	mov    -0x258(%rbp),%rdx
     b3e:	48 89 0a             	mov    %rcx,(%rdx)
     b41:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
     b48:	ff 00 00 
     b4b:	48 21 c8             	and    %rcx,%rax
     b4e:	31 c9                	xor    %ecx,%ecx
     b50:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
     b57:	48 89 10             	mov    %rdx,(%rax)
     b5a:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
     b61:	48 89 70 08          	mov    %rsi,0x8(%rax)
     b65:	48 89 48 10          	mov    %rcx,0x10(%rax)
     b69:	48 89 48 18          	mov    %rcx,0x18(%rax)
     b6d:	48 89 48 20          	mov    %rcx,0x20(%rax)
     b71:	49 8b 4c 24 60       	mov    0x60(%r12),%rcx
     b76:	bf 01 00 00 00       	mov    $0x1,%edi
     b7b:	48 01 f9             	add    %rdi,%rcx
     b7e:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
     b83:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
     b8a:	b8 01 00 00 00       	mov    $0x1,%eax
     b8f:	48 89 85 b8 fd ff ff 	mov    %rax,-0x248(%rbp)
     b96:	31 c0                	xor    %eax,%eax
     b98:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
     b9f:	e9 8a 01 00 00       	jmp    0xd2e
     ba4:	49 8b 74 24 10       	mov    0x10(%r12),%rsi
     ba9:	49 8b 44 24 18       	mov    0x18(%r12),%rax
     bae:	48 89 c1             	mov    %rax,%rcx
     bb1:	f3 48 0f b8 c9       	popcnt %rcx,%rcx
     bb6:	ba 40 00 00 00       	mov    $0x40,%edx
     bbb:	48 29 ca             	sub    %rcx,%rdx
     bbe:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
     bc5:	48 8b bd 50 fe ff ff 	mov    -0x1b0(%rbp),%rdi
     bcc:	48 89 d1             	mov    %rdx,%rcx
     bcf:	49 89 f8             	mov    %rdi,%r8
     bd2:	49 d3 e8             	shr    %cl,%r8
     bd5:	31 c9                	xor    %ecx,%ecx
     bd7:	48 8b 95 a8 fd ff ff 	mov    -0x258(%rbp),%rdx
     bde:	48 39 ca             	cmp    %rcx,%rdx
     be1:	ba 00 00 00 00       	mov    $0x0,%edx
     be6:	0f 94 c2             	sete   %dl
     be9:	48 85 d2             	test   %rdx,%rdx
     bec:	49 0f 44 c8          	cmove  %r8,%rcx
     bf0:	ba 01 00 00 00       	mov    $0x1,%edx
     bf5:	49 89 c8             	mov    %rcx,%r8
     bf8:	49 01 d0             	add    %rdx,%r8
     bfb:	49 21 c0             	and    %rax,%r8
     bfe:	b8 28 00 00 00       	mov    $0x28,%eax
     c03:	48 0f af c8          	imul   %rax,%rcx
     c07:	48 8d 04 0e          	lea    (%rsi,%rcx,1),%rax
     c0b:	48 8b 48 10          	mov    0x10(%rax),%rcx
     c0f:	48 85 c9             	test   %rcx,%rcx
     c12:	0f 84 aa 00 00 00    	je     0xcc2
     c18:	48 8b 08             	mov    (%rax),%rcx
     c1b:	4c 8b 48 08          	mov    0x8(%rax),%r9
     c1f:	4c 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%r10
     c26:	49 39 ca             	cmp    %rcx,%r10
     c29:	41 bb 00 00 00 00    	mov    $0x0,%r11d
     c2f:	41 0f 94 c3          	sete   %r11b
     c33:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
     c3a:	4c 39 c9             	cmp    %r9,%rcx
     c3d:	bf 00 00 00 00       	mov    $0x0,%edi
     c42:	40 0f 94 c7          	sete   %dil
     c46:	49 21 fb             	and    %rdi,%r11
     c49:	4d 85 db             	test   %r11,%r11
     c4c:	0f 84 0c 00 00 00    	je     0xc5e
     c52:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
     c59:	e9 4d 00 00 00       	jmp    0xcab
     c5e:	b8 28 00 00 00       	mov    $0x28,%eax
     c63:	4c 0f af c0          	imul   %rax,%r8
     c67:	4a 8d 04 06          	lea    (%rsi,%r8,1),%rax
     c6b:	48 8b 70 10          	mov    0x10(%rax),%rsi
     c6f:	48 85 f6             	test   %rsi,%rsi
     c72:	0f 84 4a 00 00 00    	je     0xcc2
     c78:	48 8b 30             	mov    (%rax),%rsi
     c7b:	48 8b 78 08          	mov    0x8(%rax),%rdi
     c7f:	49 39 f2             	cmp    %rsi,%r10
     c82:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     c88:	41 0f 94 c0          	sete   %r8b
     c8c:	48 39 f9             	cmp    %rdi,%rcx
     c8f:	be 00 00 00 00       	mov    $0x0,%esi
     c94:	40 0f 94 c6          	sete   %sil
     c98:	49 21 f0             	and    %rsi,%r8
     c9b:	4d 85 c0             	test   %r8,%r8
     c9e:	0f 84 1e 00 00 00    	je     0xcc2
     ca4:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
     cab:	31 c0                	xor    %eax,%eax
     cad:	48 89 85 b8 fd ff ff 	mov    %rax,-0x248(%rbp)
     cb4:	31 c0                	xor    %eax,%eax
     cb6:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
     cbd:	e9 6c 00 00 00       	jmp    0xd2e
     cc2:	48 8d 85 d0 fe ff ff 	lea    -0x130(%rbp),%rax
     cc9:	48 89 c1             	mov    %rax,%rcx
     ccc:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
     cd3:	48 89 11             	mov    %rdx,(%rcx)
     cd6:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
     cdd:	48 89 71 08          	mov    %rsi,0x8(%rcx)
     ce1:	48 89 df             	mov    %rbx,%rdi
     ce4:	4c 89 e6             	mov    %r12,%rsi
     ce7:	48 89 ca             	mov    %rcx,%rdx
     cea:	e8 61 f3 ff ff       	call   0x50
     cef:	48 83 f8 00          	cmp    $0x0,%rax
     cf3:	0f 8d 08 00 00 00    	jge    0xd01
     cf9:	49 89 c5             	mov    %rax,%r13
     cfc:	e9 dd 10 00 00       	jmp    0x1dde
     d01:	49 8b 0c 24          	mov    (%r12),%rcx
     d05:	0f b6 51 0d          	movzbl 0xd(%rcx),%edx
     d09:	48 83 e2 01          	and    $0x1,%rdx
     d0d:	49 89 54 24 68       	mov    %rdx,0x68(%r12)
     d12:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
     d19:	b8 01 00 00 00       	mov    $0x1,%eax
     d1e:	48 89 85 b8 fd ff ff 	mov    %rax,-0x248(%rbp)
     d25:	31 c0                	xor    %eax,%eax
     d27:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
     d2e:	48 8b 85 b8 fd ff ff 	mov    -0x248(%rbp),%rax
     d35:	48 85 c0             	test   %rax,%rax
     d38:	0f 84 68 00 00 00    	je     0xda6
     d3e:	48 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%rax
     d45:	48 8b 8d 40 fe ff ff 	mov    -0x1c0(%rbp),%rcx
     d4c:	48 89 48 10          	mov    %rcx,0x10(%rax)
     d50:	31 d2                	xor    %edx,%edx
     d52:	48 39 d1             	cmp    %rdx,%rcx
     d55:	be 00 00 00 00       	mov    $0x0,%esi
     d5a:	40 0f 95 c6          	setne  %sil
     d5e:	0f b6 78 20          	movzbl 0x20(%rax),%edi
     d62:	48 09 f7             	or     %rsi,%rdi
     d65:	40 88 78 20          	mov    %dil,0x20(%rax)
     d69:	48 8b b5 38 fe ff ff 	mov    -0x1c8(%rbp),%rsi
     d70:	48 89 70 18          	mov    %rsi,0x18(%rax)
     d74:	48 8b bd 30 fe ff ff 	mov    -0x1d0(%rbp),%rdi
     d7b:	48 39 d7             	cmp    %rdx,%rdi
     d7e:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     d84:	41 0f 95 c0          	setne  %r8b
     d88:	44 0f b6 48 20       	movzbl 0x20(%rax),%r9d
     d8d:	41 ba 02 00 00 00    	mov    $0x2,%r10d
     d93:	4d 85 c0             	test   %r8,%r8
     d96:	4c 0f 44 d2          	cmove  %rdx,%r10
     d9a:	4d 09 d1             	or     %r10,%r9
     d9d:	44 88 48 20          	mov    %r9b,0x20(%rax)
     da1:	e9 8e 00 00 00       	jmp    0xe34
     da6:	48 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%rax
     dad:	48 8b 48 10          	mov    0x10(%rax),%rcx
     db1:	48 8b 95 40 fe ff ff 	mov    -0x1c0(%rbp),%rdx
     db8:	48 01 d1             	add    %rdx,%rcx
     dbb:	48 89 48 10          	mov    %rcx,0x10(%rax)
     dbf:	31 f6                	xor    %esi,%esi
     dc1:	48 39 f1             	cmp    %rsi,%rcx
     dc4:	b9 00 00 00 00       	mov    $0x0,%ecx
     dc9:	0f 95 c1             	setne  %cl
     dcc:	0f b6 78 20          	movzbl 0x20(%rax),%edi
     dd0:	48 09 cf             	or     %rcx,%rdi
     dd3:	40 88 78 20          	mov    %dil,0x20(%rax)
     dd7:	48 8b 48 18          	mov    0x18(%rax),%rcx
     ddb:	0f b6 78 20          	movzbl 0x20(%rax),%edi
     ddf:	48 83 e7 02          	and    $0x2,%rdi
     de3:	48 39 f7             	cmp    %rsi,%rdi
     de6:	bf 00 00 00 00       	mov    $0x0,%edi
     deb:	40 0f 95 c7          	setne  %dil
     def:	45 31 c0             	xor    %r8d,%r8d
     df2:	48 85 ff             	test   %rdi,%rdi
     df5:	49 0f 44 c8          	cmove  %r8,%rcx
     df9:	4c 8b 85 30 fe ff ff 	mov    -0x1d0(%rbp),%r8
     e00:	4c 01 c7             	add    %r8,%rdi
     e03:	4c 8b 8d 38 fe ff ff 	mov    -0x1c8(%rbp),%r9
     e0a:	4c 01 c9             	add    %r9,%rcx
     e0d:	48 89 48 18          	mov    %rcx,0x18(%rax)
     e11:	48 39 f7             	cmp    %rsi,%rdi
     e14:	bf 00 00 00 00       	mov    $0x0,%edi
     e19:	40 0f 95 c7          	setne  %dil
     e1d:	0f b6 48 20          	movzbl 0x20(%rax),%ecx
     e21:	41 ba 02 00 00 00    	mov    $0x2,%r10d
     e27:	48 85 ff             	test   %rdi,%rdi
     e2a:	4c 0f 44 d6          	cmove  %rsi,%r10
     e2e:	4c 09 d1             	or     %r10,%rcx
     e31:	88 48 20             	mov    %cl,0x20(%rax)
     e34:	b8 01 00 00 00       	mov    $0x1,%eax
     e39:	48 8b 8d c8 fd ff ff 	mov    -0x238(%rbp),%rcx
     e40:	48 63 11             	movslq (%rcx),%rdx
     e43:	48 8b 8d e8 fd ff ff 	mov    -0x218(%rbp),%rcx
     e4a:	48 31 c1             	xor    %rax,%rcx
     e4d:	31 c0                	xor    %eax,%eax
     e4f:	48 85 c9             	test   %rcx,%rcx
     e52:	48 0f 44 d0          	cmove  %rax,%rdx
     e56:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
     e5d:	79 37 9e 
     e60:	48 be 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%rsi
     e67:	79 37 9e 
     e6a:	48 8b bd e0 fd ff ff 	mov    -0x220(%rbp),%rdi
     e71:	48 31 fe             	xor    %rdi,%rsi
     e74:	48 0f af f0          	imul   %rax,%rsi
     e78:	49 89 f0             	mov    %rsi,%r8
     e7b:	49 c1 e8 1d          	shr    $0x1d,%r8
     e7f:	4c 31 c6             	xor    %r8,%rsi
     e82:	4c 8b 85 d0 fd ff ff 	mov    -0x230(%rbp),%r8
     e89:	4c 31 c6             	xor    %r8,%rsi
     e8c:	48 0f af f0          	imul   %rax,%rsi
     e90:	49 89 f1             	mov    %rsi,%r9
     e93:	49 c1 e9 1d          	shr    $0x1d,%r9
     e97:	4c 31 ce             	xor    %r9,%rsi
     e9a:	48 0f af f0          	imul   %rax,%rsi
     e9e:	48 89 bd 60 fe ff ff 	mov    %rdi,-0x1a0(%rbp)
     ea5:	4c 89 85 58 fe ff ff 	mov    %r8,-0x1a8(%rbp)
     eac:	48 89 b5 50 fe ff ff 	mov    %rsi,-0x1b0(%rbp)
     eb3:	b8 01 00 00 00       	mov    $0x1,%eax
     eb8:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
     ebf:	48 89 95 38 fe ff ff 	mov    %rdx,-0x1c8(%rbp)
     ec6:	48 89 8d 30 fe ff ff 	mov    %rcx,-0x1d0(%rbp)
     ecd:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
     ed1:	b9 01 00 00 00       	mov    $0x1,%ecx
     ed6:	48 89 c2             	mov    %rax,%rdx
     ed9:	48 01 ca             	add    %rcx,%rdx
     edc:	48 89 55 d0          	mov    %rdx,-0x30(%rbp)
     ee0:	48 8b 95 d8 fd ff ff 	mov    -0x228(%rbp),%rdx
     ee7:	48 89 95 68 fe ff ff 	mov    %rdx,-0x198(%rbp)
     eee:	48 89 8d 48 fe ff ff 	mov    %rcx,-0x1b8(%rbp)
     ef5:	e9 97 f6 ff ff       	jmp    0x591
     efa:	4c 8b b5 a0 fe ff ff 	mov    -0x160(%rbp),%r14
     f01:	45 31 ff             	xor    %r15d,%r15d
     f04:	31 c0                	xor    %eax,%eax
     f06:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
     f0d:	31 c0                	xor    %eax,%eax
     f0f:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
     f16:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
     f1d:	82 28 52 
     f20:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
     f27:	31 c0                	xor    %eax,%eax
     f29:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
     f30:	31 c0                	xor    %eax,%eax
     f32:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
     f39:	31 c0                	xor    %eax,%eax
     f3b:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
     f3f:	31 c0                	xor    %eax,%eax
     f41:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
     f48:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
     f4f:	49 39 c6             	cmp    %rax,%r14
     f52:	0f 8c 6b 00 00 00    	jl     0xfc3
     f58:	4c 89 bd 28 fe ff ff 	mov    %r15,-0x1d8(%rbp)
     f5f:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
     f66:	48 89 8d 10 fe ff ff 	mov    %rcx,-0x1f0(%rbp)
     f6d:	48 8b 8d 80 fe ff ff 	mov    -0x180(%rbp),%rcx
     f74:	48 89 8d 08 fe ff ff 	mov    %rcx,-0x1f8(%rbp)
     f7b:	48 8b 8d 78 fe ff ff 	mov    -0x188(%rbp),%rcx
     f82:	48 89 8d f0 fd ff ff 	mov    %rcx,-0x210(%rbp)
     f89:	48 8b 8d b8 fe ff ff 	mov    -0x148(%rbp),%rcx
     f90:	48 89 8d 20 fe ff ff 	mov    %rcx,-0x1e0(%rbp)
     f97:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
     f9e:	48 89 8d 18 fe ff ff 	mov    %rcx,-0x1e8(%rbp)
     fa5:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
     fa9:	48 89 8d 00 fe ff ff 	mov    %rcx,-0x200(%rbp)
     fb0:	48 8b 8d 68 fe ff ff 	mov    -0x198(%rbp),%rcx
     fb7:	48 89 8d f8 fd ff ff 	mov    %rcx,-0x208(%rbp)
     fbe:	e9 9a 07 00 00       	jmp    0x175d
     fc3:	48 8b 8d 88 fe ff ff 	mov    -0x178(%rbp),%rcx
     fca:	4a 8d 14 b1          	lea    (%rcx,%r14,4),%rdx
     fce:	48 8b b5 70 fe ff ff 	mov    -0x190(%rbp),%rsi
     fd5:	4a 8d 3c b6          	lea    (%rsi,%r14,4),%rdi
     fd9:	4d 89 f8             	mov    %r15,%r8
     fdc:	49 83 c0 01          	add    $0x1,%r8
     fe0:	4c 63 0a             	movslq (%rdx),%r9
     fe3:	48 8b 95 a8 fe ff ff 	mov    -0x158(%rbp),%rdx
     fea:	48 85 d2             	test   %rdx,%rdx
     fed:	48 89 bd 60 fe ff ff 	mov    %rdi,-0x1a0(%rbp)
     ff4:	4c 89 85 58 fe ff ff 	mov    %r8,-0x1a8(%rbp)
     ffb:	4c 89 8d 50 fe ff ff 	mov    %r9,-0x1b0(%rbp)
    1002:	0f 84 10 00 00 00    	je     0x1018
    1008:	4c 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%r10
    100f:	4d 85 d2             	test   %r10,%r10
    1012:	0f 85 39 00 00 00    	jne    0x1051
    1018:	48 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%rax
    101f:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
    1026:	48 39 c8             	cmp    %rcx,%rax
    1029:	ba 00 00 00 00       	mov    $0x0,%edx
    102e:	0f 94 c2             	sete   %dl
    1031:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
    1038:	48 83 fe 00          	cmp    $0x0,%rsi
    103c:	bf 00 00 00 00       	mov    $0x0,%edi
    1041:	40 0f 94 c7          	sete   %dil
    1045:	48 21 fa             	and    %rdi,%rdx
    1048:	48 85 d2             	test   %rdx,%rdx
    104b:	0f 84 47 00 00 00    	je     0x1098
    1051:	48 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%rax
    1058:	48 89 c1             	mov    %rax,%rcx
    105b:	48 83 c1 01          	add    $0x1,%rcx
    105f:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
    1066:	48 63 32             	movslq (%rdx),%rsi
    1069:	48 8b bd 68 fe ff ff 	mov    -0x198(%rbp),%rdi
    1070:	49 89 f8             	mov    %rdi,%r8
    1073:	49 83 c0 01          	add    $0x1,%r8
    1077:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
    107b:	4d 89 ca             	mov    %r9,%r10
    107e:	49 01 f2             	add    %rsi,%r10
    1081:	48 89 8d 90 fe ff ff 	mov    %rcx,-0x170(%rbp)
    1088:	4c 89 55 d0          	mov    %r10,-0x30(%rbp)
    108c:	4c 89 85 68 fe ff ff 	mov    %r8,-0x198(%rbp)
    1093:	e9 a4 06 00 00       	jmp    0x173c
    1098:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
    109f:	48 85 c0             	test   %rax,%rax
    10a2:	0f 84 19 06 00 00    	je     0x16c1
    10a8:	31 c9                	xor    %ecx,%ecx
    10aa:	49 8d 54 0c 70       	lea    0x70(%r12,%rcx,1),%rdx
    10af:	48 8b 32             	mov    (%rdx),%rsi
    10b2:	48 85 f6             	test   %rsi,%rsi
    10b5:	0f 84 3d 02 00 00    	je     0x12f8
    10bb:	49 8d 54 0c 70       	lea    0x70(%r12,%rcx,1),%rdx
    10c0:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    10c4:	49 8b 3c 24          	mov    (%r12),%rdi
    10c8:	44 8b 07             	mov    (%rdi),%r8d
    10cb:	48 8b bd a0 fe ff ff 	mov    -0x160(%rbp),%rdi
    10d2:	49 89 f9             	mov    %rdi,%r9
    10d5:	49 29 f1             	sub    %rsi,%r9
    10d8:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
    10df:	48 39 ce             	cmp    %rcx,%rsi
    10e2:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    10e8:	41 0f 95 c2          	setne  %r10b
    10ec:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    10f0:	4c 89 da             	mov    %r11,%rdx
    10f3:	4d 85 d2             	test   %r10,%r10
    10f6:	49 0f 44 d1          	cmove  %r9,%rdx
    10fa:	4d 85 d2             	test   %r10,%r10
    10fd:	4d 0f 44 c3          	cmove  %r11,%r8
    1101:	4d 8b 4c 24 10       	mov    0x10(%r12),%r9
    1106:	41 ba 28 00 00 00    	mov    $0x28,%r10d
    110c:	49 89 d3             	mov    %rdx,%r11
    110f:	4d 0f af da          	imul   %r10,%r11
    1113:	4f 8d 14 19          	lea    (%r9,%r11,1),%r10
    1117:	4c 39 c2             	cmp    %r8,%rdx
    111a:	0f 83 b2 00 00 00    	jae    0x11d2
    1120:	4d 8b 42 10          	mov    0x10(%r10),%r8
    1124:	4d 85 c0             	test   %r8,%r8
    1127:	0f 84 16 00 00 00    	je     0x1143
    112d:	4c 89 95 48 fe ff ff 	mov    %r10,-0x1b8(%rbp)
    1134:	45 31 c0             	xor    %r8d,%r8d
    1137:	4c 89 85 40 fe ff ff 	mov    %r8,-0x1c0(%rbp)
    113e:	e9 7e 04 00 00       	jmp    0x15c1
    1143:	45 31 c0             	xor    %r8d,%r8d
    1146:	49 89 3a             	mov    %rdi,(%r10)
    1149:	49 89 72 08          	mov    %rsi,0x8(%r10)
    114d:	4d 89 42 10          	mov    %r8,0x10(%r10)
    1151:	4d 89 42 18          	mov    %r8,0x18(%r10)
    1155:	4d 89 42 20          	mov    %r8,0x20(%r10)
    1159:	4d 8b 04 24          	mov    (%r12),%r8
    115d:	45 8b 48 04          	mov    0x4(%r8),%r9d
    1161:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    1167:	4d 01 d9             	add    %r11,%r9
    116a:	45 89 48 04          	mov    %r9d,0x4(%r8)
    116e:	4d 8b 4c 24 38       	mov    0x38(%r12),%r9
    1173:	b8 40 00 00 00       	mov    $0x40,%eax
    1178:	4c 29 c8             	sub    %r9,%rax
    117b:	48 8b b5 78 fe ff ff 	mov    -0x188(%rbp),%rsi
    1182:	48 89 c1             	mov    %rax,%rcx
    1185:	48 89 f7             	mov    %rsi,%rdi
    1188:	48 d3 ef             	shr    %cl,%rdi
    118b:	31 c0                	xor    %eax,%eax
    118d:	49 39 c1             	cmp    %rax,%r9
    1190:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    1196:	41 0f 94 c1          	sete   %r9b
    119a:	4d 85 c9             	test   %r9,%r9
    119d:	48 0f 44 c7          	cmove  %rdi,%rax
    11a1:	41 8b 48 4c          	mov    0x4c(%r8),%ecx
    11a5:	49 8d 3c 08          	lea    (%r8,%rcx,1),%rdi
    11a9:	48 8d 0c 97          	lea    (%rdi,%rdx,4),%rcx
    11ad:	89 01                	mov    %eax,(%rcx)
    11af:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    11b6:	41 89 40 50          	mov    %eax,0x50(%r8)
    11ba:	4c 89 95 48 fe ff ff 	mov    %r10,-0x1b8(%rbp)
    11c1:	b8 01 00 00 00       	mov    $0x1,%eax
    11c6:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
    11cd:	e9 ef 03 00 00       	jmp    0x15c1
    11d2:	49 8b 44 24 38       	mov    0x38(%r12),%rax
    11d7:	b9 40 00 00 00       	mov    $0x40,%ecx
    11dc:	48 29 c1             	sub    %rax,%rcx
    11df:	48 89 8d 38 fe ff ff 	mov    %rcx,-0x1c8(%rbp)
    11e6:	48 8b 95 78 fe ff ff 	mov    -0x188(%rbp),%rdx
    11ed:	48 8b b5 38 fe ff ff 	mov    -0x1c8(%rbp),%rsi
    11f4:	48 89 f1             	mov    %rsi,%rcx
    11f7:	48 89 d7             	mov    %rdx,%rdi
    11fa:	48 d3 ef             	shr    %cl,%rdi
    11fd:	31 c9                	xor    %ecx,%ecx
    11ff:	48 39 c8             	cmp    %rcx,%rax
    1202:	b8 00 00 00 00       	mov    $0x0,%eax
    1207:	0f 94 c0             	sete   %al
    120a:	48 85 c0             	test   %rax,%rax
    120d:	48 0f 44 cf          	cmove  %rdi,%rcx
    1211:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    1216:	48 8d 34 c8          	lea    (%rax,%rcx,8),%rsi
    121a:	48 8b 06             	mov    (%rsi),%rax
    121d:	48 bf 00 00 00 00 00 	movabs $0x28000000000000,%rdi
    1224:	00 28 00 
    1227:	48 39 f8             	cmp    %rdi,%rax
    122a:	48 89 b5 38 fe ff ff 	mov    %rsi,-0x1c8(%rbp)
    1231:	0f 82 0c 00 00 00    	jb     0x1243
    1237:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
    123e:	e9 36 00 00 00       	jmp    0x1279
    1243:	49 8b 44 24 60       	mov    0x60(%r12),%rax
    1248:	48 89 df             	mov    %rbx,%rdi
    124b:	4c 89 e6             	mov    %r12,%rsi
    124e:	48 89 ca             	mov    %rcx,%rdx
    1251:	48 89 c1             	mov    %rax,%rcx
    1254:	e8 e7 ed ff ff       	call   0x40
    1259:	31 c9                	xor    %ecx,%ecx
    125b:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
    1260:	48 83 f8 00          	cmp    $0x0,%rax
    1264:	0f 8f 08 00 00 00    	jg     0x1272
    126a:	49 89 c5             	mov    %rax,%r13
    126d:	e9 6c 0b 00 00       	jmp    0x1dde
    1272:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
    1279:	48 8b 85 30 fe ff ff 	mov    -0x1d0(%rbp),%rax
    1280:	48 89 c1             	mov    %rax,%rcx
    1283:	48 83 c1 28          	add    $0x28,%rcx
    1287:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    128e:	00 28 00 
    1291:	48 29 d1             	sub    %rdx,%rcx
    1294:	48 8b 95 38 fe ff ff 	mov    -0x1c8(%rbp),%rdx
    129b:	48 89 0a             	mov    %rcx,(%rdx)
    129e:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    12a5:	ff 00 00 
    12a8:	48 21 c8             	and    %rcx,%rax
    12ab:	31 c9                	xor    %ecx,%ecx
    12ad:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
    12b4:	48 89 10             	mov    %rdx,(%rax)
    12b7:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
    12be:	48 89 70 08          	mov    %rsi,0x8(%rax)
    12c2:	48 89 48 10          	mov    %rcx,0x10(%rax)
    12c6:	48 89 48 18          	mov    %rcx,0x18(%rax)
    12ca:	48 89 48 20          	mov    %rcx,0x20(%rax)
    12ce:	49 8b 4c 24 60       	mov    0x60(%r12),%rcx
    12d3:	bf 01 00 00 00       	mov    $0x1,%edi
    12d8:	48 01 f9             	add    %rdi,%rcx
    12db:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
    12e0:	48 89 85 48 fe ff ff 	mov    %rax,-0x1b8(%rbp)
    12e7:	b8 01 00 00 00       	mov    $0x1,%eax
    12ec:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
    12f3:	e9 c9 02 00 00       	jmp    0x15c1
    12f8:	49 8b 44 24 68       	mov    0x68(%r12),%rax
    12fd:	48 85 c0             	test   %rax,%rax
    1300:	0f 84 2f 01 00 00    	je     0x1435
    1306:	49 8b 44 24 38       	mov    0x38(%r12),%rax
    130b:	b9 40 00 00 00       	mov    $0x40,%ecx
    1310:	48 29 c1             	sub    %rax,%rcx
    1313:	48 89 8d 30 fe ff ff 	mov    %rcx,-0x1d0(%rbp)
    131a:	48 8b 95 78 fe ff ff 	mov    -0x188(%rbp),%rdx
    1321:	48 8b b5 30 fe ff ff 	mov    -0x1d0(%rbp),%rsi
    1328:	48 89 f1             	mov    %rsi,%rcx
    132b:	48 89 d7             	mov    %rdx,%rdi
    132e:	48 d3 ef             	shr    %cl,%rdi
    1331:	31 c9                	xor    %ecx,%ecx
    1333:	48 39 c8             	cmp    %rcx,%rax
    1336:	b8 00 00 00 00       	mov    $0x0,%eax
    133b:	0f 94 c0             	sete   %al
    133e:	48 85 c0             	test   %rax,%rax
    1341:	48 0f 44 cf          	cmove  %rdi,%rcx
    1345:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    134a:	48 8d 34 c8          	lea    (%rax,%rcx,8),%rsi
    134e:	48 8b 06             	mov    (%rsi),%rax
    1351:	48 bf 00 00 00 00 00 	movabs $0x28000000000000,%rdi
    1358:	00 28 00 
    135b:	48 39 f8             	cmp    %rdi,%rax
    135e:	48 89 b5 30 fe ff ff 	mov    %rsi,-0x1d0(%rbp)
    1365:	0f 82 0c 00 00 00    	jb     0x1377
    136b:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
    1372:	e9 36 00 00 00       	jmp    0x13ad
    1377:	49 8b 44 24 60       	mov    0x60(%r12),%rax
    137c:	48 89 df             	mov    %rbx,%rdi
    137f:	4c 89 e6             	mov    %r12,%rsi
    1382:	48 89 ca             	mov    %rcx,%rdx
    1385:	48 89 c1             	mov    %rax,%rcx
    1388:	e8 b3 ec ff ff       	call   0x40
    138d:	31 c9                	xor    %ecx,%ecx
    138f:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
    1394:	48 83 f8 00          	cmp    $0x0,%rax
    1398:	0f 8f 08 00 00 00    	jg     0x13a6
    139e:	49 89 c5             	mov    %rax,%r13
    13a1:	e9 38 0a 00 00       	jmp    0x1dde
    13a6:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
    13ad:	48 8b 85 38 fe ff ff 	mov    -0x1c8(%rbp),%rax
    13b4:	48 89 c1             	mov    %rax,%rcx
    13b7:	48 83 c1 28          	add    $0x28,%rcx
    13bb:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    13c2:	00 28 00 
    13c5:	48 29 d1             	sub    %rdx,%rcx
    13c8:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
    13cf:	48 89 0a             	mov    %rcx,(%rdx)
    13d2:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    13d9:	ff 00 00 
    13dc:	48 21 c8             	and    %rcx,%rax
    13df:	31 c9                	xor    %ecx,%ecx
    13e1:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
    13e8:	48 89 10             	mov    %rdx,(%rax)
    13eb:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
    13f2:	48 89 70 08          	mov    %rsi,0x8(%rax)
    13f6:	48 89 48 10          	mov    %rcx,0x10(%rax)
    13fa:	48 89 48 18          	mov    %rcx,0x18(%rax)
    13fe:	48 89 48 20          	mov    %rcx,0x20(%rax)
    1402:	49 8b 4c 24 60       	mov    0x60(%r12),%rcx
    1407:	bf 01 00 00 00       	mov    $0x1,%edi
    140c:	48 01 f9             	add    %rdi,%rcx
    140f:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
    1414:	48 89 85 48 fe ff ff 	mov    %rax,-0x1b8(%rbp)
    141b:	b8 01 00 00 00       	mov    $0x1,%eax
    1420:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
    1427:	31 c0                	xor    %eax,%eax
    1429:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
    1430:	e9 8c 01 00 00       	jmp    0x15c1
    1435:	49 8b 74 24 10       	mov    0x10(%r12),%rsi
    143a:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    143f:	48 89 c1             	mov    %rax,%rcx
    1442:	f3 48 0f b8 c9       	popcnt %rcx,%rcx
    1447:	ba 40 00 00 00       	mov    $0x40,%edx
    144c:	48 29 ca             	sub    %rcx,%rdx
    144f:	48 89 8d 30 fe ff ff 	mov    %rcx,-0x1d0(%rbp)
    1456:	48 8b bd 78 fe ff ff 	mov    -0x188(%rbp),%rdi
    145d:	48 89 d1             	mov    %rdx,%rcx
    1460:	49 89 f8             	mov    %rdi,%r8
    1463:	49 d3 e8             	shr    %cl,%r8
    1466:	31 c9                	xor    %ecx,%ecx
    1468:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
    146f:	48 39 ca             	cmp    %rcx,%rdx
    1472:	ba 00 00 00 00       	mov    $0x0,%edx
    1477:	0f 94 c2             	sete   %dl
    147a:	48 85 d2             	test   %rdx,%rdx
    147d:	49 0f 44 c8          	cmove  %r8,%rcx
    1481:	ba 01 00 00 00       	mov    $0x1,%edx
    1486:	49 89 c8             	mov    %rcx,%r8
    1489:	49 01 d0             	add    %rdx,%r8
    148c:	4d 89 c1             	mov    %r8,%r9
    148f:	49 21 c1             	and    %rax,%r9
    1492:	b8 28 00 00 00       	mov    $0x28,%eax
    1497:	48 0f af c8          	imul   %rax,%rcx
    149b:	4c 8d 04 0e          	lea    (%rsi,%rcx,1),%r8
    149f:	49 8b 40 10          	mov    0x10(%r8),%rax
    14a3:	48 85 c0             	test   %rax,%rax
    14a6:	0f 84 a9 00 00 00    	je     0x1555
    14ac:	49 8b 00             	mov    (%r8),%rax
    14af:	49 8b 48 08          	mov    0x8(%r8),%rcx
    14b3:	4c 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%r10
    14ba:	49 39 c2             	cmp    %rax,%r10
    14bd:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    14c3:	41 0f 94 c3          	sete   %r11b
    14c7:	48 8b 85 80 fe ff ff 	mov    -0x180(%rbp),%rax
    14ce:	48 39 c8             	cmp    %rcx,%rax
    14d1:	bf 00 00 00 00       	mov    $0x0,%edi
    14d6:	40 0f 94 c7          	sete   %dil
    14da:	49 21 fb             	and    %rdi,%r11
    14dd:	4d 85 db             	test   %r11,%r11
    14e0:	0f 84 0c 00 00 00    	je     0x14f2
    14e6:	4c 89 85 48 fe ff ff 	mov    %r8,-0x1b8(%rbp)
    14ed:	e9 4c 00 00 00       	jmp    0x153e
    14f2:	b9 28 00 00 00       	mov    $0x28,%ecx
    14f7:	4c 0f af c9          	imul   %rcx,%r9
    14fb:	4a 8d 3c 0e          	lea    (%rsi,%r9,1),%rdi
    14ff:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    1503:	48 85 c9             	test   %rcx,%rcx
    1506:	0f 84 49 00 00 00    	je     0x1555
    150c:	48 8b 0f             	mov    (%rdi),%rcx
    150f:	48 8b 77 08          	mov    0x8(%rdi),%rsi
    1513:	49 39 ca             	cmp    %rcx,%r10
    1516:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    151c:	41 0f 94 c0          	sete   %r8b
    1520:	48 39 f0             	cmp    %rsi,%rax
    1523:	b9 00 00 00 00       	mov    $0x0,%ecx
    1528:	0f 94 c1             	sete   %cl
    152b:	49 21 c8             	and    %rcx,%r8
    152e:	4d 85 c0             	test   %r8,%r8
    1531:	0f 84 1e 00 00 00    	je     0x1555
    1537:	48 89 bd 48 fe ff ff 	mov    %rdi,-0x1b8(%rbp)
    153e:	31 c0                	xor    %eax,%eax
    1540:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
    1547:	31 c0                	xor    %eax,%eax
    1549:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
    1550:	e9 6c 00 00 00       	jmp    0x15c1
    1555:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
    155c:	48 89 c1             	mov    %rax,%rcx
    155f:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
    1566:	48 89 11             	mov    %rdx,(%rcx)
    1569:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
    1570:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    1574:	48 89 df             	mov    %rbx,%rdi
    1577:	4c 89 e6             	mov    %r12,%rsi
    157a:	48 89 ca             	mov    %rcx,%rdx
    157d:	e8 ce ea ff ff       	call   0x50
    1582:	48 83 f8 00          	cmp    $0x0,%rax
    1586:	0f 8d 08 00 00 00    	jge    0x1594
    158c:	49 89 c5             	mov    %rax,%r13
    158f:	e9 4a 08 00 00       	jmp    0x1dde
    1594:	49 8b 0c 24          	mov    (%r12),%rcx
    1598:	0f b6 51 0d          	movzbl 0xd(%rcx),%edx
    159c:	48 83 e2 01          	and    $0x1,%rdx
    15a0:	49 89 54 24 68       	mov    %rdx,0x68(%r12)
    15a5:	48 89 85 48 fe ff ff 	mov    %rax,-0x1b8(%rbp)
    15ac:	b8 01 00 00 00       	mov    $0x1,%eax
    15b1:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
    15b8:	31 c0                	xor    %eax,%eax
    15ba:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
    15c1:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
    15c8:	48 85 c0             	test   %rax,%rax
    15cb:	0f 84 65 00 00 00    	je     0x1636
    15d1:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
    15d8:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
    15df:	48 89 48 10          	mov    %rcx,0x10(%rax)
    15e3:	31 d2                	xor    %edx,%edx
    15e5:	48 39 d1             	cmp    %rdx,%rcx
    15e8:	be 00 00 00 00       	mov    $0x0,%esi
    15ed:	40 0f 95 c6          	setne  %sil
    15f1:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    15f5:	48 09 f7             	or     %rsi,%rdi
    15f8:	40 88 78 20          	mov    %dil,0x20(%rax)
    15fc:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
    1600:	48 89 70 18          	mov    %rsi,0x18(%rax)
    1604:	48 8b bd 68 fe ff ff 	mov    -0x198(%rbp),%rdi
    160b:	48 39 d7             	cmp    %rdx,%rdi
    160e:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1614:	41 0f 95 c0          	setne  %r8b
    1618:	44 0f b6 48 20       	movzbl 0x20(%rax),%r9d
    161d:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    1623:	4d 85 c0             	test   %r8,%r8
    1626:	4c 0f 44 d2          	cmove  %rdx,%r10
    162a:	4d 09 d1             	or     %r10,%r9
    162d:	44 88 48 20          	mov    %r9b,0x20(%rax)
    1631:	e9 8b 00 00 00       	jmp    0x16c1
    1636:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
    163d:	48 8b 48 10          	mov    0x10(%rax),%rcx
    1641:	48 8b 95 90 fe ff ff 	mov    -0x170(%rbp),%rdx
    1648:	48 01 d1             	add    %rdx,%rcx
    164b:	48 89 48 10          	mov    %rcx,0x10(%rax)
    164f:	31 f6                	xor    %esi,%esi
    1651:	48 39 f1             	cmp    %rsi,%rcx
    1654:	b9 00 00 00 00       	mov    $0x0,%ecx
    1659:	0f 95 c1             	setne  %cl
    165c:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    1660:	48 09 cf             	or     %rcx,%rdi
    1663:	40 88 78 20          	mov    %dil,0x20(%rax)
    1667:	48 8b 48 18          	mov    0x18(%rax),%rcx
    166b:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    166f:	48 83 e7 02          	and    $0x2,%rdi
    1673:	48 39 f7             	cmp    %rsi,%rdi
    1676:	bf 00 00 00 00       	mov    $0x0,%edi
    167b:	40 0f 95 c7          	setne  %dil
    167f:	45 31 c0             	xor    %r8d,%r8d
    1682:	48 85 ff             	test   %rdi,%rdi
    1685:	49 0f 44 c8          	cmove  %r8,%rcx
    1689:	4c 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%r8
    1690:	4c 01 c7             	add    %r8,%rdi
    1693:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
    1697:	4c 01 c9             	add    %r9,%rcx
    169a:	48 89 48 18          	mov    %rcx,0x18(%rax)
    169e:	48 39 f7             	cmp    %rsi,%rdi
    16a1:	bf 00 00 00 00       	mov    $0x0,%edi
    16a6:	40 0f 95 c7          	setne  %dil
    16aa:	0f b6 48 20          	movzbl 0x20(%rax),%ecx
    16ae:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    16b4:	48 85 ff             	test   %rdi,%rdi
    16b7:	4c 0f 44 d6          	cmove  %rsi,%r10
    16bb:	4c 09 d1             	or     %r10,%rcx
    16be:	88 48 20             	mov    %cl,0x20(%rax)
    16c1:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
    16c8:	48 63 08             	movslq (%rax),%rcx
    16cb:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    16d2:	79 37 9e 
    16d5:	48 ba 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%rdx
    16dc:	79 37 9e 
    16df:	48 8b b5 50 fe ff ff 	mov    -0x1b0(%rbp),%rsi
    16e6:	48 31 f2             	xor    %rsi,%rdx
    16e9:	48 0f af d0          	imul   %rax,%rdx
    16ed:	48 89 d7             	mov    %rdx,%rdi
    16f0:	48 c1 ef 1d          	shr    $0x1d,%rdi
    16f4:	48 31 fa             	xor    %rdi,%rdx
    16f7:	48 0f af d0          	imul   %rax,%rdx
    16fb:	48 89 d7             	mov    %rdx,%rdi
    16fe:	48 c1 ef 1d          	shr    $0x1d,%rdi
    1702:	48 31 fa             	xor    %rdi,%rdx
    1705:	48 0f af d0          	imul   %rax,%rdx
    1709:	48 89 b5 a0 fe ff ff 	mov    %rsi,-0x160(%rbp)
    1710:	31 c0                	xor    %eax,%eax
    1712:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
    1719:	48 89 95 78 fe ff ff 	mov    %rdx,-0x188(%rbp)
    1720:	b8 01 00 00 00       	mov    $0x1,%eax
    1725:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
    172c:	48 89 4d d0          	mov    %rcx,-0x30(%rbp)
    1730:	b8 01 00 00 00       	mov    $0x1,%eax
    1735:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
    173c:	b8 01 00 00 00       	mov    $0x1,%eax
    1741:	4c 89 f1             	mov    %r14,%rcx
    1744:	48 01 c1             	add    %rax,%rcx
    1747:	49 89 ce             	mov    %rcx,%r14
    174a:	4c 8b bd 58 fe ff ff 	mov    -0x1a8(%rbp),%r15
    1751:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
    1758:	e9 eb f7 ff ff       	jmp    0xf48
    175d:	48 8b 85 20 fe ff ff 	mov    -0x1e0(%rbp),%rax
    1764:	48 85 c0             	test   %rax,%rax
    1767:	0f 84 cf 05 00 00    	je     0x1d3c
    176d:	31 c0                	xor    %eax,%eax
    176f:	49 8d 4c 04 70       	lea    0x70(%r12,%rax,1),%rcx
    1774:	48 8b 11             	mov    (%rcx),%rdx
    1777:	48 85 d2             	test   %rdx,%rdx
    177a:	0f 84 2a 02 00 00    	je     0x19aa
    1780:	49 8d 4c 04 70       	lea    0x70(%r12,%rax,1),%rcx
    1785:	48 8b 51 08          	mov    0x8(%rcx),%rdx
    1789:	49 8b 34 24          	mov    (%r12),%rsi
    178d:	8b 3e                	mov    (%rsi),%edi
    178f:	48 8b b5 10 fe ff ff 	mov    -0x1f0(%rbp),%rsi
    1796:	49 89 f0             	mov    %rsi,%r8
    1799:	49 29 d0             	sub    %rdx,%r8
    179c:	48 8b 95 08 fe ff ff 	mov    -0x1f8(%rbp),%rdx
    17a3:	48 39 c2             	cmp    %rax,%rdx
    17a6:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    17ac:	41 0f 95 c1          	setne  %r9b
    17b0:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    17b4:	4c 89 d1             	mov    %r10,%rcx
    17b7:	4d 85 c9             	test   %r9,%r9
    17ba:	49 0f 44 c8          	cmove  %r8,%rcx
    17be:	4d 85 c9             	test   %r9,%r9
    17c1:	49 0f 44 fa          	cmove  %r10,%rdi
    17c5:	4d 8b 44 24 10       	mov    0x10(%r12),%r8
    17ca:	41 b9 28 00 00 00    	mov    $0x28,%r9d
    17d0:	49 89 ca             	mov    %rcx,%r10
    17d3:	4d 0f af d1          	imul   %r9,%r10
    17d7:	4f 8d 0c 10          	lea    (%r8,%r10,1),%r9
    17db:	48 39 f9             	cmp    %rdi,%rcx
    17de:	0f 83 aa 00 00 00    	jae    0x188e
    17e4:	49 8b 79 10          	mov    0x10(%r9),%rdi
    17e8:	48 85 ff             	test   %rdi,%rdi
    17eb:	0f 84 0b 00 00 00    	je     0x17fc
    17f1:	4d 89 ce             	mov    %r9,%r14
    17f4:	45 31 ff             	xor    %r15d,%r15d
    17f7:	e9 50 04 00 00       	jmp    0x1c4c
    17fc:	31 ff                	xor    %edi,%edi
    17fe:	49 89 31             	mov    %rsi,(%r9)
    1801:	49 89 51 08          	mov    %rdx,0x8(%r9)
    1805:	49 89 79 10          	mov    %rdi,0x10(%r9)
    1809:	49 89 79 18          	mov    %rdi,0x18(%r9)
    180d:	49 89 79 20          	mov    %rdi,0x20(%r9)
    1811:	49 8b 3c 24          	mov    (%r12),%rdi
    1815:	44 8b 47 04          	mov    0x4(%rdi),%r8d
    1819:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    181f:	4d 01 d0             	add    %r10,%r8
    1822:	44 89 47 04          	mov    %r8d,0x4(%rdi)
    1826:	4d 8b 44 24 38       	mov    0x38(%r12),%r8
    182b:	41 bb 40 00 00 00    	mov    $0x40,%r11d
    1831:	4d 29 c3             	sub    %r8,%r11
    1834:	48 89 8d 20 fe ff ff 	mov    %rcx,-0x1e0(%rbp)
    183b:	48 8b 95 f0 fd ff ff 	mov    -0x210(%rbp),%rdx
    1842:	4c 89 d9             	mov    %r11,%rcx
    1845:	48 89 d6             	mov    %rdx,%rsi
    1848:	48 d3 ee             	shr    %cl,%rsi
    184b:	31 c9                	xor    %ecx,%ecx
    184d:	49 39 c8             	cmp    %rcx,%r8
    1850:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1856:	41 0f 94 c0          	sete   %r8b
    185a:	4d 85 c0             	test   %r8,%r8
    185d:	48 0f 44 ce          	cmove  %rsi,%rcx
    1861:	8b 77 4c             	mov    0x4c(%rdi),%esi
    1864:	4c 8d 04 37          	lea    (%rdi,%rsi,1),%r8
    1868:	48 8b b5 20 fe ff ff 	mov    -0x1e0(%rbp),%rsi
    186f:	4d 8d 1c b0          	lea    (%r8,%rsi,4),%r11
    1873:	41 89 0b             	mov    %ecx,(%r11)
    1876:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    187d:	89 4f 50             	mov    %ecx,0x50(%rdi)
    1880:	4d 89 ce             	mov    %r9,%r14
    1883:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    1889:	e9 be 03 00 00       	jmp    0x1c4c
    188e:	49 8b 44 24 38       	mov    0x38(%r12),%rax
    1893:	b9 40 00 00 00       	mov    $0x40,%ecx
    1898:	48 29 c1             	sub    %rax,%rcx
    189b:	48 89 8d 20 fe ff ff 	mov    %rcx,-0x1e0(%rbp)
    18a2:	48 8b 95 f0 fd ff ff 	mov    -0x210(%rbp),%rdx
    18a9:	48 8b b5 20 fe ff ff 	mov    -0x1e0(%rbp),%rsi
    18b0:	48 89 f1             	mov    %rsi,%rcx
    18b3:	48 89 d7             	mov    %rdx,%rdi
    18b6:	48 d3 ef             	shr    %cl,%rdi
    18b9:	31 c9                	xor    %ecx,%ecx
    18bb:	48 39 c8             	cmp    %rcx,%rax
    18be:	b8 00 00 00 00       	mov    $0x0,%eax
    18c3:	0f 94 c0             	sete   %al
    18c6:	48 85 c0             	test   %rax,%rax
    18c9:	48 0f 44 cf          	cmove  %rdi,%rcx
    18cd:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    18d2:	48 8d 34 c8          	lea    (%rax,%rcx,8),%rsi
    18d6:	48 8b 06             	mov    (%rsi),%rax
    18d9:	48 bf 00 00 00 00 00 	movabs $0x28000000000000,%rdi
    18e0:	00 28 00 
    18e3:	48 39 f8             	cmp    %rdi,%rax
    18e6:	48 89 b5 20 fe ff ff 	mov    %rsi,-0x1e0(%rbp)
    18ed:	0f 82 0c 00 00 00    	jb     0x18ff
    18f3:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
    18fa:	e9 36 00 00 00       	jmp    0x1935
    18ff:	49 8b 44 24 60       	mov    0x60(%r12),%rax
    1904:	48 89 df             	mov    %rbx,%rdi
    1907:	4c 89 e6             	mov    %r12,%rsi
    190a:	48 89 ca             	mov    %rcx,%rdx
    190d:	48 89 c1             	mov    %rax,%rcx
    1910:	e8 2b e7 ff ff       	call   0x40
    1915:	31 c9                	xor    %ecx,%ecx
    1917:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
    191c:	48 83 f8 00          	cmp    $0x0,%rax
    1920:	0f 8f 08 00 00 00    	jg     0x192e
    1926:	49 89 c5             	mov    %rax,%r13
    1929:	e9 b0 04 00 00       	jmp    0x1dde
    192e:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
    1935:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
    193c:	48 89 c1             	mov    %rax,%rcx
    193f:	48 83 c1 28          	add    $0x28,%rcx
    1943:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    194a:	00 28 00 
    194d:	48 29 d1             	sub    %rdx,%rcx
    1950:	48 8b 95 20 fe ff ff 	mov    -0x1e0(%rbp),%rdx
    1957:	48 89 0a             	mov    %rcx,(%rdx)
    195a:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    1961:	ff 00 00 
    1964:	48 21 c8             	and    %rcx,%rax
    1967:	31 c9                	xor    %ecx,%ecx
    1969:	48 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%rdx
    1970:	48 89 10             	mov    %rdx,(%rax)
    1973:	48 8b b5 08 fe ff ff 	mov    -0x1f8(%rbp),%rsi
    197a:	48 89 70 08          	mov    %rsi,0x8(%rax)
    197e:	48 89 48 10          	mov    %rcx,0x10(%rax)
    1982:	48 89 48 18          	mov    %rcx,0x18(%rax)
    1986:	48 89 48 20          	mov    %rcx,0x20(%rax)
    198a:	49 8b 4c 24 60       	mov    0x60(%r12),%rcx
    198f:	bf 01 00 00 00       	mov    $0x1,%edi
    1994:	48 01 f9             	add    %rdi,%rcx
    1997:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
    199c:	49 89 c6             	mov    %rax,%r14
    199f:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    19a5:	e9 a2 02 00 00       	jmp    0x1c4c
    19aa:	49 8b 44 24 68       	mov    0x68(%r12),%rax
    19af:	48 85 c0             	test   %rax,%rax
    19b2:	0f 84 25 01 00 00    	je     0x1add
    19b8:	49 8b 44 24 38       	mov    0x38(%r12),%rax
    19bd:	b9 40 00 00 00       	mov    $0x40,%ecx
    19c2:	48 29 c1             	sub    %rax,%rcx
    19c5:	48 89 8d 88 fe ff ff 	mov    %rcx,-0x178(%rbp)
    19cc:	48 8b 95 f0 fd ff ff 	mov    -0x210(%rbp),%rdx
    19d3:	48 8b b5 88 fe ff ff 	mov    -0x178(%rbp),%rsi
    19da:	48 89 f1             	mov    %rsi,%rcx
    19dd:	48 89 d7             	mov    %rdx,%rdi
    19e0:	48 d3 ef             	shr    %cl,%rdi
    19e3:	31 c9                	xor    %ecx,%ecx
    19e5:	48 39 c8             	cmp    %rcx,%rax
    19e8:	b8 00 00 00 00       	mov    $0x0,%eax
    19ed:	0f 94 c0             	sete   %al
    19f0:	48 85 c0             	test   %rax,%rax
    19f3:	48 0f 44 cf          	cmove  %rdi,%rcx
    19f7:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    19fc:	48 8d 34 c8          	lea    (%rax,%rcx,8),%rsi
    1a00:	48 8b 06             	mov    (%rsi),%rax
    1a03:	48 bf 00 00 00 00 00 	movabs $0x28000000000000,%rdi
    1a0a:	00 28 00 
    1a0d:	48 39 f8             	cmp    %rdi,%rax
    1a10:	48 89 b5 88 fe ff ff 	mov    %rsi,-0x178(%rbp)
    1a17:	0f 82 0c 00 00 00    	jb     0x1a29
    1a1d:	48 89 85 20 fe ff ff 	mov    %rax,-0x1e0(%rbp)
    1a24:	e9 36 00 00 00       	jmp    0x1a5f
    1a29:	49 8b 44 24 60       	mov    0x60(%r12),%rax
    1a2e:	48 89 df             	mov    %rbx,%rdi
    1a31:	4c 89 e6             	mov    %r12,%rsi
    1a34:	48 89 ca             	mov    %rcx,%rdx
    1a37:	48 89 c1             	mov    %rax,%rcx
    1a3a:	e8 01 e6 ff ff       	call   0x40
    1a3f:	31 c9                	xor    %ecx,%ecx
    1a41:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
    1a46:	48 83 f8 00          	cmp    $0x0,%rax
    1a4a:	0f 8f 08 00 00 00    	jg     0x1a58
    1a50:	49 89 c5             	mov    %rax,%r13
    1a53:	e9 86 03 00 00       	jmp    0x1dde
    1a58:	48 89 85 20 fe ff ff 	mov    %rax,-0x1e0(%rbp)
    1a5f:	48 8b 85 20 fe ff ff 	mov    -0x1e0(%rbp),%rax
    1a66:	48 89 c1             	mov    %rax,%rcx
    1a69:	48 83 c1 28          	add    $0x28,%rcx
    1a6d:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    1a74:	00 28 00 
    1a77:	48 29 d1             	sub    %rdx,%rcx
    1a7a:	48 8b 95 88 fe ff ff 	mov    -0x178(%rbp),%rdx
    1a81:	48 89 0a             	mov    %rcx,(%rdx)
    1a84:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    1a8b:	ff 00 00 
    1a8e:	48 21 c8             	and    %rcx,%rax
    1a91:	31 c9                	xor    %ecx,%ecx
    1a93:	48 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%rdx
    1a9a:	48 89 10             	mov    %rdx,(%rax)
    1a9d:	48 8b b5 08 fe ff ff 	mov    -0x1f8(%rbp),%rsi
    1aa4:	48 89 70 08          	mov    %rsi,0x8(%rax)
    1aa8:	48 89 48 10          	mov    %rcx,0x10(%rax)
    1aac:	48 89 48 18          	mov    %rcx,0x18(%rax)
    1ab0:	48 89 48 20          	mov    %rcx,0x20(%rax)
    1ab4:	49 8b 4c 24 60       	mov    0x60(%r12),%rcx
    1ab9:	bf 01 00 00 00       	mov    $0x1,%edi
    1abe:	48 01 f9             	add    %rdi,%rcx
    1ac1:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
    1ac6:	49 89 c6             	mov    %rax,%r14
    1ac9:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    1acf:	31 c0                	xor    %eax,%eax
    1ad1:	48 89 85 20 fe ff ff 	mov    %rax,-0x1e0(%rbp)
    1ad8:	e9 6f 01 00 00       	jmp    0x1c4c
    1add:	49 8b 44 24 10       	mov    0x10(%r12),%rax
    1ae2:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    1ae7:	48 89 ca             	mov    %rcx,%rdx
    1aea:	f3 48 0f b8 d2       	popcnt %rdx,%rdx
    1aef:	be 40 00 00 00       	mov    $0x40,%esi
    1af4:	48 29 d6             	sub    %rdx,%rsi
    1af7:	48 89 8d 88 fe ff ff 	mov    %rcx,-0x178(%rbp)
    1afe:	48 8b bd f0 fd ff ff 	mov    -0x210(%rbp),%rdi
    1b05:	48 89 f1             	mov    %rsi,%rcx
    1b08:	48 d3 ef             	shr    %cl,%rdi
    1b0b:	31 c9                	xor    %ecx,%ecx
    1b0d:	48 39 ca             	cmp    %rcx,%rdx
    1b10:	ba 00 00 00 00       	mov    $0x0,%edx
    1b15:	0f 94 c2             	sete   %dl
    1b18:	48 85 d2             	test   %rdx,%rdx
    1b1b:	48 0f 44 cf          	cmove  %rdi,%rcx
    1b1f:	ba 01 00 00 00       	mov    $0x1,%edx
    1b24:	48 89 ce             	mov    %rcx,%rsi
    1b27:	48 01 d6             	add    %rdx,%rsi
    1b2a:	48 8b bd 88 fe ff ff 	mov    -0x178(%rbp),%rdi
    1b31:	48 21 fe             	and    %rdi,%rsi
    1b34:	bf 28 00 00 00       	mov    $0x28,%edi
    1b39:	48 0f af cf          	imul   %rdi,%rcx
    1b3d:	48 8d 3c 08          	lea    (%rax,%rcx,1),%rdi
    1b41:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    1b45:	48 85 c9             	test   %rcx,%rcx
    1b48:	0f 84 9c 00 00 00    	je     0x1bea
    1b4e:	48 8b 0f             	mov    (%rdi),%rcx
    1b51:	4c 8b 47 08          	mov    0x8(%rdi),%r8
    1b55:	4c 8b 8d 10 fe ff ff 	mov    -0x1f0(%rbp),%r9
    1b5c:	49 39 c9             	cmp    %rcx,%r9
    1b5f:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    1b65:	41 0f 94 c2          	sete   %r10b
    1b69:	48 8b 8d 08 fe ff ff 	mov    -0x1f8(%rbp),%rcx
    1b70:	4c 39 c1             	cmp    %r8,%rcx
    1b73:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    1b79:	41 0f 94 c3          	sete   %r11b
    1b7d:	4d 21 da             	and    %r11,%r10
    1b80:	4d 85 d2             	test   %r10,%r10
    1b83:	0f 84 08 00 00 00    	je     0x1b91
    1b89:	49 89 fe             	mov    %rdi,%r14
    1b8c:	e9 48 00 00 00       	jmp    0x1bd9
    1b91:	bf 28 00 00 00       	mov    $0x28,%edi
    1b96:	48 0f af f7          	imul   %rdi,%rsi
    1b9a:	48 8d 3c 30          	lea    (%rax,%rsi,1),%rdi
    1b9e:	48 8b 47 10          	mov    0x10(%rdi),%rax
    1ba2:	48 85 c0             	test   %rax,%rax
    1ba5:	0f 84 3f 00 00 00    	je     0x1bea
    1bab:	48 8b 07             	mov    (%rdi),%rax
    1bae:	48 8b 77 08          	mov    0x8(%rdi),%rsi
    1bb2:	49 39 c1             	cmp    %rax,%r9
    1bb5:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1bbb:	41 0f 94 c0          	sete   %r8b
    1bbf:	48 39 f1             	cmp    %rsi,%rcx
    1bc2:	b8 00 00 00 00       	mov    $0x0,%eax
    1bc7:	0f 94 c0             	sete   %al
    1bca:	49 21 c0             	and    %rax,%r8
    1bcd:	4d 85 c0             	test   %r8,%r8
    1bd0:	0f 84 14 00 00 00    	je     0x1bea
    1bd6:	49 89 fe             	mov    %rdi,%r14
    1bd9:	45 31 ff             	xor    %r15d,%r15d
    1bdc:	31 c0                	xor    %eax,%eax
    1bde:	48 89 85 20 fe ff ff 	mov    %rax,-0x1e0(%rbp)
    1be5:	e9 62 00 00 00       	jmp    0x1c4c
    1bea:	48 8d 85 c0 fe ff ff 	lea    -0x140(%rbp),%rax
    1bf1:	48 89 c1             	mov    %rax,%rcx
    1bf4:	48 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%rdx
    1bfb:	48 89 11             	mov    %rdx,(%rcx)
    1bfe:	48 8b 95 08 fe ff ff 	mov    -0x1f8(%rbp),%rdx
    1c05:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    1c09:	48 89 df             	mov    %rbx,%rdi
    1c0c:	4c 89 e6             	mov    %r12,%rsi
    1c0f:	48 89 ca             	mov    %rcx,%rdx
    1c12:	e8 39 e4 ff ff       	call   0x50
    1c17:	48 83 f8 00          	cmp    $0x0,%rax
    1c1b:	0f 8d 08 00 00 00    	jge    0x1c29
    1c21:	49 89 c5             	mov    %rax,%r13
    1c24:	e9 b5 01 00 00       	jmp    0x1dde
    1c29:	49 8b 0c 24          	mov    (%r12),%rcx
    1c2d:	0f b6 51 0d          	movzbl 0xd(%rcx),%edx
    1c31:	48 83 e2 01          	and    $0x1,%rdx
    1c35:	49 89 54 24 68       	mov    %rdx,0x68(%r12)
    1c3a:	49 89 c6             	mov    %rax,%r14
    1c3d:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    1c43:	31 c0                	xor    %eax,%eax
    1c45:	48 89 85 20 fe ff ff 	mov    %rax,-0x1e0(%rbp)
    1c4c:	4d 85 ff             	test   %r15,%r15
    1c4f:	0f 84 60 00 00 00    	je     0x1cb5
    1c55:	48 8b 85 18 fe ff ff 	mov    -0x1e8(%rbp),%rax
    1c5c:	49 89 46 10          	mov    %rax,0x10(%r14)
    1c60:	31 c9                	xor    %ecx,%ecx
    1c62:	48 39 c8             	cmp    %rcx,%rax
    1c65:	ba 00 00 00 00       	mov    $0x0,%edx
    1c6a:	0f 95 c2             	setne  %dl
    1c6d:	41 0f b6 76 20       	movzbl 0x20(%r14),%esi
    1c72:	48 09 d6             	or     %rdx,%rsi
    1c75:	41 88 76 20          	mov    %sil,0x20(%r14)
    1c79:	48 8b 95 00 fe ff ff 	mov    -0x200(%rbp),%rdx
    1c80:	49 89 56 18          	mov    %rdx,0x18(%r14)
    1c84:	48 8b b5 f8 fd ff ff 	mov    -0x208(%rbp),%rsi
    1c8b:	48 39 ce             	cmp    %rcx,%rsi
    1c8e:	bf 00 00 00 00       	mov    $0x0,%edi
    1c93:	40 0f 95 c7          	setne  %dil
    1c97:	45 0f b6 46 20       	movzbl 0x20(%r14),%r8d
    1c9c:	41 b9 02 00 00 00    	mov    $0x2,%r9d
    1ca2:	48 85 ff             	test   %rdi,%rdi
    1ca5:	4c 0f 44 c9          	cmove  %rcx,%r9
    1ca9:	4d 09 c8             	or     %r9,%r8
    1cac:	45 88 46 20          	mov    %r8b,0x20(%r14)
    1cb0:	e9 87 00 00 00       	jmp    0x1d3c
    1cb5:	49 8b 46 10          	mov    0x10(%r14),%rax
    1cb9:	48 8b 8d 18 fe ff ff 	mov    -0x1e8(%rbp),%rcx
    1cc0:	48 01 c8             	add    %rcx,%rax
    1cc3:	49 89 46 10          	mov    %rax,0x10(%r14)
    1cc7:	31 c9                	xor    %ecx,%ecx
    1cc9:	48 39 c8             	cmp    %rcx,%rax
    1ccc:	b8 00 00 00 00       	mov    $0x0,%eax
    1cd1:	0f 95 c0             	setne  %al
    1cd4:	41 0f b6 56 20       	movzbl 0x20(%r14),%edx
    1cd9:	48 09 c2             	or     %rax,%rdx
    1cdc:	41 88 56 20          	mov    %dl,0x20(%r14)
    1ce0:	49 8b 46 18          	mov    0x18(%r14),%rax
    1ce4:	41 0f b6 56 20       	movzbl 0x20(%r14),%edx
    1ce9:	48 83 e2 02          	and    $0x2,%rdx
    1ced:	48 39 ca             	cmp    %rcx,%rdx
    1cf0:	ba 00 00 00 00       	mov    $0x0,%edx
    1cf5:	0f 95 c2             	setne  %dl
    1cf8:	31 f6                	xor    %esi,%esi
    1cfa:	48 85 d2             	test   %rdx,%rdx
    1cfd:	48 0f 44 c6          	cmove  %rsi,%rax
    1d01:	48 8b b5 f8 fd ff ff 	mov    -0x208(%rbp),%rsi
    1d08:	48 01 f2             	add    %rsi,%rdx
    1d0b:	48 8b b5 00 fe ff ff 	mov    -0x200(%rbp),%rsi
    1d12:	48 01 f0             	add    %rsi,%rax
    1d15:	49 89 46 18          	mov    %rax,0x18(%r14)
    1d19:	48 39 ca             	cmp    %rcx,%rdx
    1d1c:	ba 00 00 00 00       	mov    $0x0,%edx
    1d21:	0f 95 c2             	setne  %dl
    1d24:	41 0f b6 46 20       	movzbl 0x20(%r14),%eax
    1d29:	be 02 00 00 00       	mov    $0x2,%esi
    1d2e:	48 85 d2             	test   %rdx,%rdx
    1d31:	48 0f 44 f1          	cmove  %rcx,%rsi
    1d35:	48 09 f0             	or     %rsi,%rax
    1d38:	41 88 46 20          	mov    %al,0x20(%r14)
    1d3c:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    1d43:	48 8b 8d 28 fe ff ff 	mov    -0x1d8(%rbp),%rcx
    1d4a:	48 01 c8             	add    %rcx,%rax
    1d4d:	48 89 83 e8 00 00 00 	mov    %rax,0xe8(%rbx)
    1d54:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
    1d5b:	89 83 00 01 00 00    	mov    %eax,0x100(%rbx)
    1d61:	e9 a6 e6 ff ff       	jmp    0x40c
    1d66:	48 89 df             	mov    %rbx,%rdi
    1d69:	e8 f2 e2 ff ff       	call   0x60
    1d6e:	48 85 c0             	test   %rax,%rax
    1d71:	0f 84 ae e6 ff ff    	je     0x425
    1d77:	49 c7 c5 fe ff ff ff 	mov    $0xfffffffffffffffe,%r13
    1d7e:	e9 5b 00 00 00       	jmp    0x1dde
    1d83:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
    1d8a:	48 85 c0             	test   %rax,%rax
    1d8d:	0f 84 08 00 00 00    	je     0x1d9b
    1d93:	49 89 c5             	mov    %rax,%r13
    1d96:	e9 43 00 00 00       	jmp    0x1dde
    1d9b:	49 8b 04 24          	mov    (%r12),%rax
    1d9f:	49 8b 4c 24 60       	mov    0x60(%r12),%rcx
    1da4:	48 8b 50 58          	mov    0x58(%rax),%rdx
    1da8:	48 01 ca             	add    %rcx,%rdx
    1dab:	48 89 50 58          	mov    %rdx,0x58(%rax)
    1daf:	31 c0                	xor    %eax,%eax
    1db1:	49 89 44 24 60       	mov    %rax,0x60(%r12)
    1db6:	48 89 df             	mov    %rbx,%rdi
    1db9:	4c 89 e6             	mov    %r12,%rsi
    1dbc:	e8 af e2 ff ff       	call   0x70
    1dc1:	48 83 f8 00          	cmp    $0x0,%rax
    1dc5:	0f 8d 08 00 00 00    	jge    0x1dd3
    1dcb:	49 89 c5             	mov    %rax,%r13
    1dce:	e9 0b 00 00 00       	jmp    0x1dde
    1dd3:	48 89 df             	mov    %rbx,%rdi
    1dd6:	e8 a5 e2 ff ff       	call   0x80
    1ddb:	49 89 c5             	mov    %rax,%r13
    1dde:	4c 89 e8             	mov    %r13,%rax
    1de1:	48 81 c4 38 02 00 00 	add    $0x238,%rsp
    1de8:	41 5f                	pop    %r15
    1dea:	41 5e                	pop    %r14
    1dec:	41 5d                	pop    %r13
    1dee:	41 5c                	pop    %r12
    1df0:	5b                   	pop    %rbx
    1df1:	5d                   	pop    %rbp
    1df2:	c3                   	ret
    1df3:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    1dfa:	00 00 
    1dfc:	0f 1f 40 00          	nopl   0x0(%rax)
    1e00:	55                   	push   %rbp
    1e01:	48 89 e5             	mov    %rsp,%rbp
    1e04:	53                   	push   %rbx
    1e05:	41 54                	push   %r12
    1e07:	41 55                	push   %r13
    1e09:	41 56                	push   %r14
    1e0b:	41 57                	push   %r15
    1e0d:	48 81 ec d8 01 00 00 	sub    $0x1d8,%rsp
    1e14:	48 89 fb             	mov    %rdi,%rbx
    1e17:	31 c0                	xor    %eax,%eax
    1e19:	48 8b 4b 58          	mov    0x58(%rbx),%rcx
    1e1d:	4c 8b a3 50 01 00 00 	mov    0x150(%rbx),%r12
    1e24:	48 8b 53 50          	mov    0x50(%rbx),%rdx
    1e28:	48 85 d2             	test   %rdx,%rdx
    1e2b:	48 89 4d d0          	mov    %rcx,-0x30(%rbp)
    1e2f:	0f 85 d2 01 00 00    	jne    0x2007
    1e35:	48 ba 01 00 00 00 00 	movabs $0x4000000000001,%rdx
    1e3c:	00 04 00 
    1e3f:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    1e43:	31 d2                	xor    %edx,%edx
    1e45:	49 89 14 24          	mov    %rdx,(%r12)
    1e49:	31 d2                	xor    %edx,%edx
    1e4b:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    1e50:	31 d2                	xor    %edx,%edx
    1e52:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    1e57:	31 d2                	xor    %edx,%edx
    1e59:	49 89 54 24 18       	mov    %rdx,0x18(%r12)
    1e5e:	31 d2                	xor    %edx,%edx
    1e60:	49 89 54 24 20       	mov    %rdx,0x20(%r12)
    1e65:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    1e69:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    1e6d:	0f 85 84 00 00 00    	jne    0x1ef7
    1e73:	48 8d 95 10 ff ff ff 	lea    -0xf0(%rbp),%rdx
    1e7a:	48 89 d6             	mov    %rdx,%rsi
    1e7d:	bf 02 02 01 01       	mov    $0x1010202,%edi
    1e82:	48 89 3e             	mov    %rdi,(%rsi)
    1e85:	bf 00 00 00 01       	mov    $0x1000000,%edi
    1e8a:	48 89 7e 08          	mov    %rdi,0x8(%rsi)
    1e8e:	bf 00 00 10 18       	mov    $0x18100000,%edi
    1e93:	48 89 7e 10          	mov    %rdi,0x10(%rsi)
    1e97:	48 bf 00 00 28 01 10 	movabs $0x201001280000,%rdi
    1e9e:	20 00 00 
    1ea1:	48 89 7e 18          	mov    %rdi,0x18(%rsi)
    1ea5:	31 ff                	xor    %edi,%edi
    1ea7:	48 89 7e 20          	mov    %rdi,0x20(%rsi)
    1eab:	48 bf 00 00 00 00 02 	movabs $0x200000000,%rdi
    1eb2:	00 00 00 
    1eb5:	48 89 7e 28          	mov    %rdi,0x28(%rsi)
    1eb9:	bf 01 00 00 00       	mov    $0x1,%edi
    1ebe:	48 89 7e 30          	mov    %rdi,0x30(%rsi)
    1ec2:	bf 00 00 01 00       	mov    $0x10000,%edi
    1ec7:	48 89 7e 38          	mov    %rdi,0x38(%rsi)
    1ecb:	48 8b 79 30          	mov    0x30(%rcx),%rdi
    1ecf:	48 89 bd 18 fe ff ff 	mov    %rdi,-0x1e8(%rbp)
    1ed6:	48 89 df             	mov    %rbx,%rdi
    1ed9:	48 8b 95 18 fe ff ff 	mov    -0x1e8(%rbp),%rdx
    1ee0:	e8 ab e1 ff ff       	call   0x90
    1ee5:	48 83 f8 00          	cmp    $0x0,%rax
    1ee9:	0f 8d 08 00 00 00    	jge    0x1ef7
    1eef:	49 89 c5             	mov    %rax,%r13
    1ef2:	e9 8c 02 00 00       	jmp    0x2183
    1ef7:	48 8d 85 50 fe ff ff 	lea    -0x1b0(%rbp),%rax
    1efe:	48 89 c1             	mov    %rax,%rcx
    1f01:	ba 02 02 01 01       	mov    $0x1010202,%edx
    1f06:	48 89 11             	mov    %rdx,(%rcx)
    1f09:	ba 00 00 00 01       	mov    $0x1000000,%edx
    1f0e:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    1f12:	ba 00 00 10 18       	mov    $0x18100000,%edx
    1f17:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    1f1b:	48 ba 00 00 28 01 10 	movabs $0x201001280000,%rdx
    1f22:	20 00 00 
    1f25:	48 89 51 18          	mov    %rdx,0x18(%rcx)
    1f29:	31 d2                	xor    %edx,%edx
    1f2b:	48 89 51 20          	mov    %rdx,0x20(%rcx)
    1f2f:	48 ba 00 00 00 00 02 	movabs $0x200000000,%rdx
    1f36:	00 00 00 
    1f39:	48 89 51 28          	mov    %rdx,0x28(%rcx)
    1f3d:	ba 01 00 00 00       	mov    $0x1,%edx
    1f42:	48 89 51 30          	mov    %rdx,0x30(%rcx)
    1f46:	ba 00 00 01 00       	mov    $0x10000,%edx
    1f4b:	48 89 51 38          	mov    %rdx,0x38(%rcx)
    1f4f:	31 d2                	xor    %edx,%edx
    1f51:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    1f55:	48 89 df             	mov    %rbx,%rdi
    1f58:	48 89 ce             	mov    %rcx,%rsi
    1f5b:	48 89 8d 18 fe ff ff 	mov    %rcx,-0x1e8(%rbp)
    1f62:	e8 39 e1 ff ff       	call   0xa0
    1f67:	48 b9 01 00 00 00 00 	movabs $0x4000000000001,%rcx
    1f6e:	00 04 00 
    1f71:	48 89 4b 50          	mov    %rcx,0x50(%rbx)
    1f75:	48 85 c0             	test   %rax,%rax
    1f78:	0f 85 0c 00 00 00    	jne    0x1f8a
    1f7e:	49 c7 c6 fa fd ff ff 	mov    $0xfffffffffffffdfa,%r14
    1f85:	e9 6b 00 00 00       	jmp    0x1ff5
    1f8a:	48 8b 08             	mov    (%rax),%rcx
    1f8d:	48 8b 50 10          	mov    0x10(%rax),%rdx
    1f91:	48 89 50 10          	mov    %rdx,0x10(%rax)
    1f95:	48 89 df             	mov    %rbx,%rdi
    1f98:	48 89 c6             	mov    %rax,%rsi
    1f9b:	48 89 95 10 fe ff ff 	mov    %rdx,-0x1f0(%rbp)
    1fa2:	48 8b 95 18 fe ff ff 	mov    -0x1e8(%rbp),%rdx
    1fa9:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
    1fb0:	48 89 8d 08 fe ff ff 	mov    %rcx,-0x1f8(%rbp)
    1fb7:	e8 f4 e0 ff ff       	call   0xb0
    1fbc:	48 83 f8 00          	cmp    $0x0,%rax
    1fc0:	0f 8d 08 00 00 00    	jge    0x1fce
    1fc6:	49 89 c6             	mov    %rax,%r14
    1fc9:	e9 27 00 00 00       	jmp    0x1ff5
    1fce:	48 8b 85 18 fe ff ff 	mov    -0x1e8(%rbp),%rax
    1fd5:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    1fda:	48 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%rax
    1fe1:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    1fe6:	48 8b 85 10 fe ff ff 	mov    -0x1f0(%rbp),%rax
    1fed:	49 89 44 24 10       	mov    %rax,0x10(%r12)
    1ff2:	45 31 f6             	xor    %r14d,%r14d
    1ff5:	49 83 fe 00          	cmp    $0x0,%r14
    1ff9:	0f 8d 08 00 00 00    	jge    0x2007
    1fff:	4d 89 f5             	mov    %r14,%r13
    2002:	e9 7c 01 00 00       	jmp    0x2183
    2007:	48 8b 43 18          	mov    0x18(%rbx),%rax
    200b:	48 85 c0             	test   %rax,%rax
    200e:	0f 84 0c 00 00 00    	je     0x2020
    2014:	0f b6 08             	movzbl (%rax),%ecx
    2017:	48 85 c9             	test   %rcx,%rcx
    201a:	0f 85 e9 00 00 00    	jne    0x2109
    2020:	49 8b 44 24 10       	mov    0x10(%r12),%rax
    2025:	49 8b 34 24          	mov    (%r12),%rsi
    2029:	48 39 c6             	cmp    %rax,%rsi
    202c:	0f 8d f4 00 00 00    	jge    0x2126
    2032:	48 89 f1             	mov    %rsi,%rcx
    2035:	48 81 c1 00 10 00 00 	add    $0x1000,%rcx
    203c:	48 39 c1             	cmp    %rax,%rcx
    203f:	ba 00 00 00 00       	mov    $0x0,%edx
    2044:	0f 9f c2             	setg   %dl
    2047:	48 89 c7             	mov    %rax,%rdi
    204a:	48 85 d2             	test   %rdx,%rdx
    204d:	48 0f 44 f9          	cmove  %rcx,%rdi
    2051:	45 31 c0             	xor    %r8d,%r8d
    2054:	48 39 fe             	cmp    %rdi,%rsi
    2057:	0f 8d a3 00 00 00    	jge    0x2100
    205d:	48 89 f0             	mov    %rsi,%rax
    2060:	48 83 c0 01          	add    $0x1,%rax
    2064:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
    2069:	48 8d 14 f1          	lea    (%rcx,%rsi,8),%rdx
    206d:	48 8b 0a             	mov    (%rdx),%rcx
    2070:	48 8d 95 20 fe ff ff 	lea    -0x1e0(%rbp),%rdx
    2077:	49 89 d1             	mov    %rdx,%r9
    207a:	49 89 49 20          	mov    %rcx,0x20(%r9)
    207e:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    2082:	4d 89 11             	mov    %r10,(%r9)
    2085:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    208b:	4d 89 51 08          	mov    %r10,0x8(%r9)
    208f:	4c 8b 51 18          	mov    0x18(%rcx),%r10
    2093:	44 0f b6 59 20       	movzbl 0x20(%rcx),%r11d
    2098:	49 83 e3 02          	and    $0x2,%r11
    209c:	45 31 f6             	xor    %r14d,%r14d
    209f:	4d 39 f3             	cmp    %r14,%r11
    20a2:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    20a8:	41 0f 95 c3          	setne  %r11b
    20ac:	45 31 ff             	xor    %r15d,%r15d
    20af:	4d 85 db             	test   %r11,%r11
    20b2:	4d 0f 44 d7          	cmove  %r15,%r10
    20b6:	4d 39 f3             	cmp    %r14,%r11
    20b9:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    20bf:	41 0f 94 c3          	sete   %r11b
    20c3:	4d 89 51 10          	mov    %r10,0x10(%r9)
    20c7:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    20cd:	4d 31 d3             	xor    %r10,%r11
    20d0:	4d 89 59 18          	mov    %r11,0x18(%r9)
    20d4:	4d 8b 4c 24 20       	mov    0x20(%r12),%r9
    20d9:	4d 8b 54 24 08       	mov    0x8(%r12),%r10
    20de:	4f 8d 1c ca          	lea    (%r10,%r9,8),%r11
    20e2:	49 89 0b             	mov    %rcx,(%r11)
    20e5:	49 83 c1 01          	add    $0x1,%r9
    20e9:	4d 89 4c 24 20       	mov    %r9,0x20(%r12)
    20ee:	4c 89 c1             	mov    %r8,%rcx
    20f1:	48 83 c1 01          	add    $0x1,%rcx
    20f5:	48 89 c6             	mov    %rax,%rsi
    20f8:	49 89 c8             	mov    %rcx,%r8
    20fb:	e9 54 ff ff ff       	jmp    0x2054
    2100:	49 89 3c 24          	mov    %rdi,(%r12)
    2104:	e9 fe fe ff ff       	jmp    0x2007
    2109:	48 89 df             	mov    %rbx,%rdi
    210c:	e8 4f df ff ff       	call   0x60
    2111:	48 85 c0             	test   %rax,%rax
    2114:	0f 84 06 ff ff ff    	je     0x2020
    211a:	49 c7 c5 fe ff ff ff 	mov    $0xfffffffffffffffe,%r13
    2121:	e9 5d 00 00 00       	jmp    0x2183
    2126:	31 c0                	xor    %eax,%eax
    2128:	48 85 c0             	test   %rax,%rax
    212b:	0f 84 08 00 00 00    	je     0x2139
    2131:	49 89 c5             	mov    %rax,%r13
    2134:	e9 4a 00 00 00       	jmp    0x2183
    2139:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    213e:	49 8b 4c 24 20       	mov    0x20(%r12),%rcx
    2143:	48 85 c0             	test   %rax,%rax
    2146:	0f 84 2c 00 00 00    	je     0x2178
    214c:	48 89 48 10          	mov    %rcx,0x10(%rax)
    2150:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    2154:	48 83 fa 40          	cmp    $0x40,%rdx
    2158:	0f 83 1a 00 00 00    	jae    0x2178
    215e:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
    2162:	48 8b 7e 30          	mov    0x30(%rsi),%rdi
    2166:	48 6b f2 10          	imul   $0x10,%rdx,%rsi
    216a:	48 8d 34 37          	lea    (%rdi,%rsi,1),%rsi
    216e:	48 8b 10             	mov    (%rax),%rdx
    2171:	48 89 16             	mov    %rdx,(%rsi)
    2174:	48 89 4e 08          	mov    %rcx,0x8(%rsi)
    2178:	48 89 df             	mov    %rbx,%rdi
    217b:	e8 00 df ff ff       	call   0x80
    2180:	49 89 c5             	mov    %rax,%r13
    2183:	4c 89 e8             	mov    %r13,%rax
    2186:	48 81 c4 d8 01 00 00 	add    $0x1d8,%rsp
    218d:	41 5f                	pop    %r15
    218f:	41 5e                	pop    %r14
    2191:	41 5d                	pop    %r13
    2193:	41 5c                	pop    %r12
    2195:	5b                   	pop    %rbx
    2196:	5d                   	pop    %rbp
    2197:	c3                   	ret
    2198:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    219f:	00 00 
    21a1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    21a8:	00 00 
    21aa:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    21b1:	00 00 
    21b3:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    21ba:	00 00 
    21bc:	0f 1f 40 00          	nopl   0x0(%rax)
    21c0:	55                   	push   %rbp
    21c1:	48 89 e5             	mov    %rsp,%rbp
    21c4:	53                   	push   %rbx
    21c5:	41 54                	push   %r12
    21c7:	41 55                	push   %r13
    21c9:	41 56                	push   %r14
    21cb:	41 57                	push   %r15
    21cd:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    21d4:	48 89 fb             	mov    %rdi,%rbx
    21d7:	31 c0                	xor    %eax,%eax
    21d9:	48 8b 4b 58          	mov    0x58(%rbx),%rcx
    21dd:	4c 8b a3 50 01 00 00 	mov    0x150(%rbx),%r12
    21e4:	48 8b 53 50          	mov    0x50(%rbx),%rdx
    21e8:	48 85 d2             	test   %rdx,%rdx
    21eb:	0f 85 f4 00 00 00    	jne    0x22e5
    21f1:	48 ba 01 00 00 00 00 	movabs $0x4000000000001,%rdx
    21f8:	00 04 00 
    21fb:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    21ff:	31 d2                	xor    %edx,%edx
    2201:	49 89 54 24 28       	mov    %rdx,0x28(%r12)
    2206:	31 d2                	xor    %edx,%edx
    2208:	49 89 54 24 30       	mov    %rdx,0x30(%r12)
    220d:	31 d2                	xor    %edx,%edx
    220f:	49 89 54 24 38       	mov    %rdx,0x38(%r12)
    2214:	31 d2                	xor    %edx,%edx
    2216:	49 89 54 24 40       	mov    %rdx,0x40(%r12)
    221b:	48 8d 95 10 ff ff ff 	lea    -0xf0(%rbp),%rdx
    2222:	48 89 d6             	mov    %rdx,%rsi
    2225:	bf 02 02 01 01       	mov    $0x1010202,%edi
    222a:	48 89 3e             	mov    %rdi,(%rsi)
    222d:	bf 00 00 00 01       	mov    $0x1000000,%edi
    2232:	48 89 7e 08          	mov    %rdi,0x8(%rsi)
    2236:	bf 00 00 10 18       	mov    $0x18100000,%edi
    223b:	48 89 7e 10          	mov    %rdi,0x10(%rsi)
    223f:	48 bf 00 00 28 01 10 	movabs $0x201001280000,%rdi
    2246:	20 00 00 
    2249:	48 89 7e 18          	mov    %rdi,0x18(%rsi)
    224d:	31 ff                	xor    %edi,%edi
    224f:	48 89 7e 20          	mov    %rdi,0x20(%rsi)
    2253:	48 bf 00 00 00 00 02 	movabs $0x200000000,%rdi
    225a:	00 00 00 
    225d:	48 89 7e 28          	mov    %rdi,0x28(%rsi)
    2261:	bf 01 00 00 00       	mov    $0x1,%edi
    2266:	48 89 7e 30          	mov    %rdi,0x30(%rsi)
    226a:	bf 00 00 01 00       	mov    $0x10000,%edi
    226f:	48 89 7e 38          	mov    %rdi,0x38(%rsi)
    2273:	48 8b 79 30          	mov    0x30(%rcx),%rdi
    2277:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    227e:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
    2282:	48 89 df             	mov    %rbx,%rdi
    2285:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
    2289:	e8 32 de ff ff       	call   0xc0
    228e:	49 89 c5             	mov    %rax,%r13
    2291:	49 83 fd 00          	cmp    $0x0,%r13
    2295:	0f 8d 08 00 00 00    	jge    0x22a3
    229b:	4d 89 ee             	mov    %r13,%r14
    229e:	e9 33 00 00 00       	jmp    0x22d6
    22a3:	4d 85 ed             	test   %r13,%r13
    22a6:	0f 85 0c 00 00 00    	jne    0x22b8
    22ac:	49 c7 c6 fa fd ff ff 	mov    $0xfffffffffffffdfa,%r14
    22b3:	e9 1e 00 00 00       	jmp    0x22d6
    22b8:	49 8b 45 00          	mov    0x0(%r13),%rax
    22bc:	49 8b 4d 10          	mov    0x10(%r13),%rcx
    22c0:	49 89 4d 10          	mov    %rcx,0x10(%r13)
    22c4:	4d 89 6c 24 40       	mov    %r13,0x40(%r12)
    22c9:	49 89 44 24 30       	mov    %rax,0x30(%r12)
    22ce:	49 89 4c 24 38       	mov    %rcx,0x38(%r12)
    22d3:	45 31 f6             	xor    %r14d,%r14d
    22d6:	49 83 fe 00          	cmp    $0x0,%r14
    22da:	0f 8d 05 00 00 00    	jge    0x22e5
    22e0:	e9 75 02 00 00       	jmp    0x255a
    22e5:	48 8b 43 18          	mov    0x18(%rbx),%rax
    22e9:	48 85 c0             	test   %rax,%rax
    22ec:	0f 84 0c 00 00 00    	je     0x22fe
    22f2:	0f b6 08             	movzbl (%rax),%ecx
    22f5:	48 85 c9             	test   %rcx,%rcx
    22f8:	0f 85 ec 01 00 00    	jne    0x24ea
    22fe:	49 8b 44 24 38       	mov    0x38(%r12),%rax
    2303:	49 8b 74 24 28       	mov    0x28(%r12),%rsi
    2308:	48 39 c6             	cmp    %rax,%rsi
    230b:	0f 8d f6 01 00 00    	jge    0x2507
    2311:	48 89 f1             	mov    %rsi,%rcx
    2314:	48 81 c1 00 10 00 00 	add    $0x1000,%rcx
    231b:	48 39 c1             	cmp    %rax,%rcx
    231e:	ba 00 00 00 00       	mov    $0x0,%edx
    2323:	0f 9f c2             	setg   %dl
    2326:	49 89 c5             	mov    %rax,%r13
    2329:	48 85 d2             	test   %rdx,%rdx
    232c:	4c 0f 44 e9          	cmove  %rcx,%r13
    2330:	49 89 f7             	mov    %rsi,%r15
    2333:	31 c0                	xor    %eax,%eax
    2335:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
    2339:	4d 39 ef             	cmp    %r13,%r15
    233c:	0f 8d 9e 01 00 00    	jge    0x24e0
    2342:	4c 89 f8             	mov    %r15,%rax
    2345:	48 83 c0 01          	add    $0x1,%rax
    2349:	49 8b 4c 24 30       	mov    0x30(%r12),%rcx
    234e:	4a 8d 14 f9          	lea    (%rcx,%r15,8),%rdx
    2352:	48 8b 0a             	mov    (%rdx),%rcx
    2355:	48 8b 51 08          	mov    0x8(%rcx),%rdx
    2359:	48 83 e2 01          	and    $0x1,%rdx
    235d:	31 f6                	xor    %esi,%esi
    235f:	48 39 f2             	cmp    %rsi,%rdx
    2362:	ba 00 00 00 00       	mov    $0x0,%edx
    2367:	0f 95 c2             	setne  %dl
    236a:	48 8b 39             	mov    (%rcx),%rdi
    236d:	4c 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%r8
    2374:	4d 89 c1             	mov    %r8,%r9
    2377:	49 89 49 20          	mov    %rcx,0x20(%r9)
    237b:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    237f:	4d 89 11             	mov    %r10,(%r9)
    2382:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    2388:	4d 89 59 08          	mov    %r11,0x8(%r9)
    238c:	4c 8b 41 18          	mov    0x18(%rcx),%r8
    2390:	0f b6 71 20          	movzbl 0x20(%rcx),%esi
    2394:	48 83 e6 02          	and    $0x2,%rsi
    2398:	31 c9                	xor    %ecx,%ecx
    239a:	48 39 ce             	cmp    %rcx,%rsi
    239d:	be 00 00 00 00       	mov    $0x0,%esi
    23a2:	40 0f 95 c6          	setne  %sil
    23a6:	31 c9                	xor    %ecx,%ecx
    23a8:	48 85 f6             	test   %rsi,%rsi
    23ab:	4c 0f 44 c1          	cmove  %rcx,%r8
    23af:	31 c9                	xor    %ecx,%ecx
    23b1:	48 39 ce             	cmp    %rcx,%rsi
    23b4:	be 00 00 00 00       	mov    $0x0,%esi
    23b9:	40 0f 94 c6          	sete   %sil
    23bd:	4d 89 41 10          	mov    %r8,0x10(%r9)
    23c1:	b9 01 00 00 00       	mov    $0x1,%ecx
    23c6:	48 31 ce             	xor    %rcx,%rsi
    23c9:	49 89 71 18          	mov    %rsi,0x18(%r9)
    23cd:	b9 01 00 00 00       	mov    $0x1,%ecx
    23d2:	49 83 fb 00          	cmp    $0x0,%r11
    23d6:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    23dc:	41 0f 95 c3          	setne  %r11b
    23e0:	49 31 cb             	xor    %rcx,%r11
    23e3:	48 83 fe 00          	cmp    $0x0,%rsi
    23e7:	be 00 00 00 00       	mov    $0x0,%esi
    23ec:	40 0f 95 c6          	setne  %sil
    23f0:	48 31 ce             	xor    %rcx,%rsi
    23f3:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    23f7:	4c 8b 49 10          	mov    0x10(%rcx),%r9
    23fb:	48 89 95 d8 fe ff ff 	mov    %rdx,-0x128(%rbp)
    2402:	48 8b 11             	mov    (%rcx),%rdx
    2405:	48 89 95 d0 fe ff ff 	mov    %rdx,-0x130(%rbp)
    240c:	48 8b 51 08          	mov    0x8(%rcx),%rdx
    2410:	48 89 95 c8 fe ff ff 	mov    %rdx,-0x138(%rbp)
    2417:	ba 03 00 00 00       	mov    $0x3,%edx
    241c:	48 89 b5 c0 fe ff ff 	mov    %rsi,-0x140(%rbp)
    2423:	4c 89 ce             	mov    %r9,%rsi
    2426:	48 0f af f2          	imul   %rdx,%rsi
    242a:	48 8b 95 d0 fe ff ff 	mov    -0x130(%rbp),%rdx
    2431:	48 89 bd b8 fe ff ff 	mov    %rdi,-0x148(%rbp)
    2438:	48 8d 3c f2          	lea    (%rdx,%rsi,8),%rdi
    243c:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
    2443:	4c 89 85 d0 fe ff ff 	mov    %r8,-0x130(%rbp)
    244a:	4c 8d 04 32          	lea    (%rdx,%rsi,1),%r8
    244e:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
    2455:	48 89 17             	mov    %rdx,(%rdi)
    2458:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
    245f:	41 88 10             	mov    %dl,(%r8)
    2462:	4c 89 57 08          	mov    %r10,0x8(%rdi)
    2466:	45 88 58 01          	mov    %r11b,0x1(%r8)
    246a:	48 8b 95 d0 fe ff ff 	mov    -0x130(%rbp),%rdx
    2471:	48 89 57 10          	mov    %rdx,0x10(%rdi)
    2475:	48 8b 95 c0 fe ff ff 	mov    -0x140(%rbp),%rdx
    247c:	41 88 50 02          	mov    %dl,0x2(%r8)
    2480:	49 83 c1 01          	add    $0x1,%r9
    2484:	4c 89 49 10          	mov    %r9,0x10(%rcx)
    2488:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
    248c:	48 89 d6             	mov    %rdx,%rsi
    248f:	48 83 c6 01          	add    $0x1,%rsi
    2493:	48 8b 79 18          	mov    0x18(%rcx),%rdi
    2497:	49 39 f9             	cmp    %rdi,%r9
    249a:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
    24a1:	48 89 b5 d0 fe ff ff 	mov    %rsi,-0x130(%rbp)
    24a8:	0f 8c 18 00 00 00    	jl     0x24c6
    24ae:	48 89 df             	mov    %rbx,%rdi
    24b1:	e8 1a dc ff ff       	call   0xd0
    24b6:	48 85 c0             	test   %rax,%rax
    24b9:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
    24c0:	0f 85 64 00 00 00    	jne    0x252a
    24c6:	4c 89 f8             	mov    %r15,%rax
    24c9:	48 83 c0 01          	add    $0x1,%rax
    24cd:	49 89 c7             	mov    %rax,%r15
    24d0:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
    24d7:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
    24db:	e9 59 fe ff ff       	jmp    0x2339
    24e0:	4d 89 6c 24 28       	mov    %r13,0x28(%r12)
    24e5:	e9 fb fd ff ff       	jmp    0x22e5
    24ea:	48 89 df             	mov    %rbx,%rdi
    24ed:	e8 6e db ff ff       	call   0x60
    24f2:	48 85 c0             	test   %rax,%rax
    24f5:	0f 84 03 fe ff ff    	je     0x22fe
    24fb:	49 c7 c6 fe ff ff ff 	mov    $0xfffffffffffffffe,%r14
    2502:	e9 53 00 00 00       	jmp    0x255a
    2507:	31 c0                	xor    %eax,%eax
    2509:	48 85 c0             	test   %rax,%rax
    250c:	0f 84 08 00 00 00    	je     0x251a
    2512:	49 89 c6             	mov    %rax,%r14
    2515:	e9 40 00 00 00       	jmp    0x255a
    251a:	48 89 df             	mov    %rbx,%rdi
    251d:	e8 5e db ff ff       	call   0x80
    2522:	49 89 c6             	mov    %rax,%r14
    2525:	e9 30 00 00 00       	jmp    0x255a
    252a:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
    2531:	49 89 44 24 28       	mov    %rax,0x28(%r12)
    2536:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    253d:	48 83 f8 00          	cmp    $0x0,%rax
    2541:	0f 8d 08 00 00 00    	jge    0x254f
    2547:	49 89 c6             	mov    %rax,%r14
    254a:	e9 0b 00 00 00       	jmp    0x255a
    254f:	48 89 df             	mov    %rbx,%rdi
    2552:	e8 89 db ff ff       	call   0xe0
    2557:	49 89 c6             	mov    %rax,%r14
    255a:	4c 89 f0             	mov    %r14,%rax
    255d:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    2564:	41 5f                	pop    %r15
    2566:	41 5e                	pop    %r14
    2568:	41 5d                	pop    %r13
    256a:	41 5c                	pop    %r12
    256c:	5b                   	pop    %rbx
    256d:	5d                   	pop    %rbp
    256e:	c3                   	ret
	...
    2fff:	00 14 00             	add    %dl,(%rax,%rax,1)
    3002:	00 00                	add    %al,(%rax)
    3004:	00 00                	add    %al,(%rax)
    3006:	00 00                	add    %al,(%rax)
    3008:	01 7a 52             	add    %edi,0x52(%rdx)
    300b:	00 01                	add    %al,(%rcx)
    300d:	78 10                	js     0x301f
    300f:	01 1b                	add    %ebx,(%rbx)
    3011:	0c 07                	or     $0x7,%al
    3013:	08 90 01 00 00 28    	or     %dl,0x28000001(%rax)
    3019:	00 00                	add    %al,(%rax)
    301b:	00 1c 00             	add    %bl,(%rax,%rax,1)
    301e:	00 00                	add    %al,(%rax)
    3020:	60                   	(bad)
    3021:	d1 ff                	sar    $1,%edi
    3023:	ff 73 1c             	push   0x1c(%rbx)
    3026:	00 00                	add    %al,(%rax)
    3028:	00 0a                	add    %cl,(%rdx)
    302a:	41 0e                	rex.B (bad)
    302c:	10 86 02 43 0d 06    	adc    %al,0x60d4302(%rsi)
    3032:	50                   	push   %rax
    3033:	83 03 8c             	addl   $0xffffff8c,(%rbx)
    3036:	04 8d                	add    $0x8d,%al
    3038:	05 8e 06 8f 07       	add    $0x78f068e,%eax
    303d:	03 5e 1c             	add    0x1c(%rsi),%ebx
    3040:	0b 00                	or     (%rax),%eax
    3042:	00 00                	add    %al,(%rax)
    3044:	28 00                	sub    %al,(%rax)
    3046:	00 00                	add    %al,(%rax)
    3048:	48 00 00             	rex.W add %al,(%rax)
    304b:	00 b4 ed ff ff 98 03 	add    %dh,0x398ffff(%rbp,%rbp,8)
    3052:	00 00                	add    %al,(%rax)
    3054:	00 0a                	add    %cl,(%rdx)
    3056:	41 0e                	rex.B (bad)
    3058:	10 86 02 43 0d 06    	adc    %al,0x60d4302(%rsi)
    305e:	50                   	push   %rax
    305f:	83 03 8c             	addl   $0xffffff8c,(%rbx)
    3062:	04 8d                	add    $0x8d,%al
    3064:	05 8e 06 8f 07       	add    $0x78f068e,%eax
    3069:	03 83 03 0b 00 00    	add    0xb03(%rbx),%eax
    306f:	00 2c 00             	add    %ch,(%rax,%rax,1)
    3072:	00 00                	add    %al,(%rax)
    3074:	74 00                	je     0x3076
    3076:	00 00                	add    %al,(%rax)
    3078:	48 f1                	rex.W int1
    307a:	ff                   	(bad)
    307b:	ff af 03 00 00 00    	ljmp   *0x3(%rdi)
    3081:	0a 41 0e             	or     0xe(%rcx),%al
    3084:	10 86 02 43 0d 06    	adc    %al,0x60d4302(%rsi)
    308a:	50                   	push   %rax
    308b:	83 03 8c             	addl   $0xffffff8c,(%rbx)
    308e:	04 8d                	add    $0x8d,%al
    3090:	05 8e 06 8f 07       	add    $0x78f068e,%eax
    3095:	03 9a 03 0b 00 00    	add    0xb03(%rdx),%ebx
	...
