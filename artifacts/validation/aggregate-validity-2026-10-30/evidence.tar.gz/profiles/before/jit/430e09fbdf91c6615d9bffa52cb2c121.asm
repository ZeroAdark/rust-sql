
/home/rustsql/profile-candidate-20261030d/jit/430e09fbdf91c6615d9bffa52cb2c121.x86_64.bin:     file format binary


Disassembly of section .data:

0000000000000240 <.data+0x240>:
     240:	55                   	push   %rbp
     241:	48 89 e5             	mov    %rsp,%rbp
     244:	53                   	push   %rbx
     245:	41 54                	push   %r12
     247:	41 55                	push   %r13
     249:	41 56                	push   %r14
     24b:	41 57                	push   %r15
     24d:	48 81 ec 18 01 00 00 	sub    $0x118,%rsp
     254:	48 89 fb             	mov    %rdi,%rbx
     257:	31 c0                	xor    %eax,%eax
     259:	48 8b 4b 50          	mov    0x50(%rbx),%rcx
     25d:	48 85 c9             	test   %rcx,%rcx
     260:	0f 85 9b 00 00 00    	jne    0x301
     266:	48 b9 01 00 00 00 00 	movabs $0x4000000000001,%rcx
     26d:	00 04 00 
     270:	48 89 4b 50          	mov    %rcx,0x50(%rbx)
     274:	48 8b 0b             	mov    (%rbx),%rcx
     277:	48 8b 51 28          	mov    0x28(%rcx),%rdx
     27b:	48 8b 0a             	mov    (%rdx),%rcx
     27e:	0f b6 11             	movzbl (%rcx),%edx
     281:	48 85 d2             	test   %rdx,%rdx
     284:	0f 85 58 00 00 00    	jne    0x2e2
     28a:	8b 51 08             	mov    0x8(%rcx),%edx
     28d:	48 89 51 38          	mov    %rdx,0x38(%rcx)
     291:	48 89 51 50          	mov    %rdx,0x50(%rcx)
     295:	48 89 41 10          	mov    %rax,0x10(%rcx)
     299:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
     2a0:	ff ff 7f 
     2a3:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
     2aa:	00 00 80 
     2ad:	48 89 51 18          	mov    %rdx,0x18(%rcx)
     2b1:	48 89 71 20          	mov    %rsi,0x20(%rcx)
     2b5:	ba 01 00 00 00       	mov    $0x1,%edx
     2ba:	88 11                	mov    %dl,(%rcx)
     2bc:	48 c7 c2 83 ff ff ff 	mov    $0xffffffffffffff83,%rdx
     2c3:	88 51 03             	mov    %dl,0x3(%rcx)
     2c6:	ba 07 00 00 00       	mov    $0x7,%edx
     2cb:	88 51 0f             	mov    %dl,0xf(%rcx)
     2ce:	31 d2                	xor    %edx,%edx
     2d0:	be 06 00 00 00       	mov    $0x6,%esi
     2d5:	31 ff                	xor    %edi,%edi
     2d7:	88 51 70             	mov    %dl,0x70(%rcx)
     2da:	40 88 71 71          	mov    %sil,0x71(%rcx)
     2de:	48 89 79 78          	mov    %rdi,0x78(%rcx)
     2e2:	31 c0                	xor    %eax,%eax
     2e4:	48 89 df             	mov    %rbx,%rdi
     2e7:	48 89 c6             	mov    %rax,%rsi
     2ea:	e8 11 fd ff ff       	call   0x0
     2ef:	48 83 f8 00          	cmp    $0x0,%rax
     2f3:	0f 8d 08 00 00 00    	jge    0x301
     2f9:	49 89 c4             	mov    %rax,%r12
     2fc:	e9 af 0c 00 00       	jmp    0xfb0
     301:	48 8b 43 18          	mov    0x18(%rbx),%rax
     305:	48 85 c0             	test   %rax,%rax
     308:	0f 84 0c 00 00 00    	je     0x31a
     30e:	0f b6 08             	movzbl (%rax),%ecx
     311:	48 85 c9             	test   %rcx,%rcx
     314:	0f 85 fc 0b 00 00    	jne    0xf16
     31a:	31 c0                	xor    %eax,%eax
     31c:	48 89 df             	mov    %rbx,%rdi
     31f:	48 89 c6             	mov    %rax,%rsi
     322:	e8 e9 fc ff ff       	call   0x10
     327:	48 83 f8 00          	cmp    $0x0,%rax
     32b:	0f 8f 08 00 00 00    	jg     0x339
     331:	49 89 c5             	mov    %rax,%r13
     334:	e9 f3 0b 00 00       	jmp    0xf2c
     339:	8b 83 00 01 00 00    	mov    0x100(%rbx),%eax
     33f:	8b 8b fc 00 00 00    	mov    0xfc(%rbx),%ecx
     345:	4c 8b b3 d0 00 00 00 	mov    0xd0(%rbx),%r14
     34c:	31 d2                	xor    %edx,%edx
     34e:	49 39 d6             	cmp    %rdx,%r14
     351:	41 bf 00 00 00 00    	mov    $0x0,%r15d
     357:	41 0f 94 c7          	sete   %r15b
     35b:	8b b3 04 01 00 00    	mov    0x104(%rbx),%esi
     361:	4d 85 ff             	test   %r15,%r15
     364:	48 0f 44 ce          	cmove  %rsi,%rcx
     368:	48 8b b3 38 01 00 00 	mov    0x138(%rbx),%rsi
     36f:	0f b7 bb 2c 01 00 00 	movzwl 0x12c(%rbx),%edi
     376:	49 89 f8             	mov    %rdi,%r8
     379:	49 83 e0 08          	and    $0x8,%r8
     37d:	49 89 f9             	mov    %rdi,%r9
     380:	49 83 e1 0a          	and    $0xa,%r9
     384:	49 89 fa             	mov    %rdi,%r10
     387:	49 83 e2 03          	and    $0x3,%r10
     38b:	49 89 fb             	mov    %rdi,%r11
     38e:	49 83 e3 10          	and    $0x10,%r11
     392:	49 39 d0             	cmp    %rdx,%r8
     395:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     39b:	41 0f 95 c0          	setne  %r8b
     39f:	49 39 d1             	cmp    %rdx,%r9
     3a2:	41 b9 00 00 00 00    	mov    $0x0,%r9d
     3a8:	41 0f 95 c1          	setne  %r9b
     3ac:	49 83 fa 03          	cmp    $0x3,%r10
     3b0:	41 ba 00 00 00 00    	mov    $0x0,%r10d
     3b6:	41 0f 94 c2          	sete   %r10b
     3ba:	49 39 d3             	cmp    %rdx,%r11
     3bd:	41 bb 00 00 00 00    	mov    $0x0,%r11d
     3c3:	41 0f 95 c3          	setne  %r11b
     3c7:	4d 09 c2             	or     %r8,%r10
     3ca:	4d 89 c8             	mov    %r9,%r8
     3cd:	4d 21 d8             	and    %r11,%r8
     3d0:	4d 85 c9             	test   %r9,%r9
     3d3:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     3d7:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
     3db:	48 89 75 b0          	mov    %rsi,-0x50(%rbp)
     3df:	48 89 7d a8          	mov    %rdi,-0x58(%rbp)
     3e3:	4c 89 45 a0          	mov    %r8,-0x60(%rbp)
     3e7:	4c 89 55 98          	mov    %r10,-0x68(%rbp)
     3eb:	0f 85 46 00 00 00    	jne    0x437
     3f1:	45 31 c9             	xor    %r9d,%r9d
     3f4:	48 89 df             	mov    %rbx,%rdi
     3f7:	31 f6                	xor    %esi,%esi
     3f9:	4c 89 ca             	mov    %r9,%rdx
     3fc:	e8 1f fc ff ff       	call   0x20
     401:	48 83 f8 00          	cmp    $0x0,%rax
     405:	0f 8d 08 00 00 00    	jge    0x413
     40b:	49 89 c5             	mov    %rax,%r13
     40e:	e9 19 0b 00 00       	jmp    0xf2c
     413:	b8 01 00 00 00       	mov    $0x1,%eax
     418:	48 89 df             	mov    %rbx,%rdi
     41b:	31 f6                	xor    %esi,%esi
     41d:	48 89 c2             	mov    %rax,%rdx
     420:	e8 fb fb ff ff       	call   0x20
     425:	48 83 f8 00          	cmp    $0x0,%rax
     429:	0f 8d 08 00 00 00    	jge    0x437
     42f:	49 89 c5             	mov    %rax,%r13
     432:	e9 f5 0a 00 00       	jmp    0xf2c
     437:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
     43e:	48 8b 48 40          	mov    0x40(%rax),%rcx
     442:	48 8b 10             	mov    (%rax),%rdx
     445:	48 8b 70 20          	mov    0x20(%rax),%rsi
     449:	48 8b 78 28          	mov    0x28(%rax),%rdi
     44d:	31 c0                	xor    %eax,%eax
     44f:	48 39 c7             	cmp    %rax,%rdi
     452:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     458:	41 0f 94 c0          	sete   %r8b
     45c:	4c 8b 0b             	mov    (%rbx),%r9
     45f:	4d 8b 51 28          	mov    0x28(%r9),%r10
     463:	4d 8b 0a             	mov    (%r10),%r9
     466:	4d 8b 51 10          	mov    0x10(%r9),%r10
     46a:	4d 8b 59 18          	mov    0x18(%r9),%r11
     46e:	49 8b 41 20          	mov    0x20(%r9),%rax
     472:	48 89 45 90          	mov    %rax,-0x70(%rbp)
     476:	48 8b 45 98          	mov    -0x68(%rbp),%rax
     47a:	4c 21 f8             	and    %r15,%rax
     47d:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
     481:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
     485:	4c 21 c8             	and    %r9,%rax
     488:	48 85 c0             	test   %rax,%rax
     48b:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
     48f:	48 89 55 88          	mov    %rdx,-0x78(%rbp)
     493:	48 89 75 80          	mov    %rsi,-0x80(%rbp)
     497:	48 89 bd 78 ff ff ff 	mov    %rdi,-0x88(%rbp)
     49e:	4c 89 85 70 ff ff ff 	mov    %r8,-0x90(%rbp)
     4a5:	0f 85 3d 00 00 00    	jne    0x4e8
     4ab:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     4af:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
     4b6:	31 c0                	xor    %eax,%eax
     4b8:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
     4bf:	4c 89 95 58 ff ff ff 	mov    %r10,-0xa8(%rbp)
     4c6:	4c 89 9d 50 ff ff ff 	mov    %r11,-0xb0(%rbp)
     4cd:	48 8b 45 90          	mov    -0x70(%rbp),%rax
     4d1:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
     4d8:	48 8b 45 98          	mov    -0x68(%rbp),%rax
     4dc:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
     4e3:	e9 66 03 00 00       	jmp    0x84e
     4e8:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     4ec:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
     4f3:	4c 89 5d c0          	mov    %r11,-0x40(%rbp)
     4f7:	48 8b 45 90          	mov    -0x70(%rbp),%rax
     4fb:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
     502:	31 c0                	xor    %eax,%eax
     504:	48 89 45 90          	mov    %rax,-0x70(%rbp)
     508:	4c 89 95 28 ff ff ff 	mov    %r10,-0xd8(%rbp)
     50f:	48 8b 45 98          	mov    -0x68(%rbp),%rax
     513:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
     51a:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
     521:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
     525:	48 39 c8             	cmp    %rcx,%rax
     528:	0f 8c 42 00 00 00    	jl     0x570
     52e:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
     535:	48 89 55 98          	mov    %rdx,-0x68(%rbp)
     539:	48 8b 55 90          	mov    -0x70(%rbp),%rdx
     53d:	48 89 95 18 ff ff ff 	mov    %rdx,-0xe8(%rbp)
     544:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
     54b:	48 89 95 10 ff ff ff 	mov    %rdx,-0xf0(%rbp)
     552:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
     556:	48 89 95 08 ff ff ff 	mov    %rdx,-0xf8(%rbp)
     55d:	48 8b 95 30 ff ff ff 	mov    -0xd0(%rbp),%rdx
     564:	48 89 95 00 ff ff ff 	mov    %rdx,-0x100(%rbp)
     56b:	e9 24 09 00 00       	jmp    0xe94
     570:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
     574:	48 8d 74 82 18       	lea    0x18(%rdx,%rax,4),%rsi
     579:	8b 3e                	mov    (%rsi),%edi
     57b:	48 81 e7 ff 7f 00 00 	and    $0x7fff,%rdi
     582:	48 8d 34 3a          	lea    (%rdx,%rdi,1),%rsi
     586:	0f b6 7e 16          	movzbl 0x16(%rsi),%edi
     58a:	44 8b 46 12          	mov    0x12(%rsi),%r8d
     58e:	4d 89 c1             	mov    %r8,%r9
     591:	49 81 e1 00 00 01 00 	and    $0x10000,%r9
     598:	4d 85 c9             	test   %r9,%r9
     59b:	0f 85 5f 02 00 00    	jne    0x800
     5a1:	49 81 e0 ff 07 00 00 	and    $0x7ff,%r8
     5a8:	49 83 f8 02          	cmp    $0x2,%r8
     5ac:	0f 82 4e 02 00 00    	jb     0x800
     5b2:	4c 8d 04 3e          	lea    (%rsi,%rdi,1),%r8
     5b6:	49 63 30             	movslq (%r8),%rsi
     5b9:	4d 8d 40 04          	lea    0x4(%r8),%r8
     5bd:	49 63 38             	movslq (%r8),%rdi
     5c0:	48 63 f6             	movslq %esi,%rsi
     5c3:	48 89 b5 f8 fe ff ff 	mov    %rsi,-0x108(%rbp)
     5ca:	48 89 bd f0 fe ff ff 	mov    %rdi,-0x110(%rbp)
     5d1:	4c 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%r8
     5d8:	4c 89 85 e8 fe ff ff 	mov    %r8,-0x118(%rbp)
     5df:	4c 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%r8
     5e6:	4c 89 85 e0 fe ff ff 	mov    %r8,-0x120(%rbp)
     5ed:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
     5f4:	48 8b 48 38          	mov    0x38(%rax),%rcx
     5f8:	ba 18 00 00 00       	mov    $0x18,%edx
     5fd:	48 8b b5 e0 fe ff ff 	mov    -0x120(%rbp),%rsi
     604:	48 89 f7             	mov    %rsi,%rdi
     607:	48 0f af fa          	imul   %rdx,%rdi
     60b:	48 8d 94 38 c0 00 00 	lea    0xc0(%rax,%rdi,1),%rdx
     612:	00 
     613:	48 81 c7 d8 00 00 00 	add    $0xd8,%rdi
     61a:	48 39 cf             	cmp    %rcx,%rdi
     61d:	48 89 8d d8 fe ff ff 	mov    %rcx,-0x128(%rbp)
     624:	48 89 95 d0 fe ff ff 	mov    %rdx,-0x130(%rbp)
     62b:	0f 8e dc 00 00 00    	jle    0x70d
     631:	48 8b 7b 18          	mov    0x18(%rbx),%rdi
     635:	48 85 ff             	test   %rdi,%rdi
     638:	0f 84 0d 00 00 00    	je     0x64b
     63e:	44 0f b6 07          	movzbl (%rdi),%r8d
     642:	4d 85 c0             	test   %r8,%r8
     645:	0f 85 ac 00 00 00    	jne    0x6f7
     64b:	b8 01 00 00 00       	mov    $0x1,%eax
     650:	48 8b 8d e8 fe ff ff 	mov    -0x118(%rbp),%rcx
     657:	88 41 02             	mov    %al,0x2(%rcx)
     65a:	b8 01 00 00 00       	mov    $0x1,%eax
     65f:	88 41 0d             	mov    %al,0xd(%rcx)
     662:	31 c0                	xor    %eax,%eax
     664:	88 41 37             	mov    %al,0x37(%rcx)
     667:	b8 01 00 00 00       	mov    $0x1,%eax
     66c:	88 41 01             	mov    %al,0x1(%rcx)
     66f:	b8 18 00 00 00       	mov    $0x18,%eax
     674:	ba 18 00 00 00       	mov    $0x18,%edx
     679:	89 41 04             	mov    %eax,0x4(%rcx)
     67c:	89 51 58             	mov    %edx,0x58(%rcx)
     67f:	31 c0                	xor    %eax,%eax
     681:	66 89 81 80 00 00 00 	mov    %ax,0x80(%rcx)
     688:	48 8d 45 d0          	lea    -0x30(%rbp),%rax
     68c:	48 89 c2             	mov    %rax,%rdx
     68f:	be 18 00 00 00       	mov    $0x18,%esi
     694:	48 89 df             	mov    %rbx,%rdi
     697:	48 89 ce             	mov    %rcx,%rsi
     69a:	48 89 95 c8 fe ff ff 	mov    %rdx,-0x138(%rbp)
     6a1:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
     6a8:	b9 18 00 00 00       	mov    $0x18,%ecx
     6ad:	4c 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%r8
     6b4:	4c 8b 8d c8 fe ff ff 	mov    -0x138(%rbp),%r9
     6bb:	e8 70 f9 ff ff       	call   0x30
     6c0:	48 85 c0             	test   %rax,%rax
     6c3:	0f 85 11 00 00 00    	jne    0x6da
     6c9:	b9 80 00 00 00       	mov    $0x80,%ecx
     6ce:	48 89 8d c0 fe ff ff 	mov    %rcx,-0x140(%rbp)
     6d5:	e9 c1 08 00 00       	jmp    0xf9b
     6da:	48 8b 8d c8 fe ff ff 	mov    -0x138(%rbp),%rcx
     6e1:	48 8b 11             	mov    (%rcx),%rdx
     6e4:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
     6eb:	48 89 95 e0 fe ff ff 	mov    %rdx,-0x120(%rbp)
     6f2:	e9 f6 fe ff ff       	jmp    0x5ed
     6f7:	48 89 df             	mov    %rbx,%rdi
     6fa:	e8 41 f9 ff ff       	call   0x40
     6ff:	48 85 c0             	test   %rax,%rax
     702:	0f 84 43 ff ff ff    	je     0x64b
     708:	e9 82 08 00 00       	jmp    0xf8f
     70d:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
     714:	48 8b 8d f8 fe ff ff 	mov    -0x108(%rbp),%rcx
     71b:	48 89 08             	mov    %rcx,(%rax)
     71e:	48 8b 95 f0 fe ff ff 	mov    -0x110(%rbp),%rdx
     725:	48 89 50 10          	mov    %rdx,0x10(%rax)
     729:	31 d2                	xor    %edx,%edx
     72b:	48 89 50 08          	mov    %rdx,0x8(%rax)
     72f:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
     736:	0f b6 50 70          	movzbl 0x70(%rax),%edx
     73a:	48 85 d2             	test   %rdx,%rdx
     73d:	0f 85 11 00 00 00    	jne    0x754
     743:	ba 01 00 00 00       	mov    $0x1,%edx
     748:	48 89 95 d0 fe ff ff 	mov    %rdx,-0x130(%rbp)
     74f:	e9 3b 00 00 00       	jmp    0x78f
     754:	48 89 df             	mov    %rbx,%rdi
     757:	48 89 c6             	mov    %rax,%rsi
     75a:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
     761:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
     768:	e8 e3 f8 ff ff       	call   0x50
     76d:	48 83 f8 00          	cmp    $0x0,%rax
     771:	0f 8d 11 00 00 00    	jge    0x788
     777:	b9 80 00 00 00       	mov    $0x80,%ecx
     77c:	48 89 8d c0 fe ff ff 	mov    %rcx,-0x140(%rbp)
     783:	e9 13 08 00 00       	jmp    0xf9b
     788:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
     78f:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     793:	48 8b 8d f8 fe ff ff 	mov    -0x108(%rbp),%rcx
     79a:	48 89 c2             	mov    %rax,%rdx
     79d:	48 39 ca             	cmp    %rcx,%rdx
     7a0:	48 0f 4f d1          	cmovg  %rcx,%rdx
     7a4:	48 8b b5 30 ff ff ff 	mov    -0xd0(%rbp),%rsi
     7ab:	48 89 f7             	mov    %rsi,%rdi
     7ae:	48 39 cf             	cmp    %rcx,%rdi
     7b1:	48 0f 4c f9          	cmovl  %rcx,%rdi
     7b5:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
     7bc:	4c 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%r8
     7c3:	4c 01 c1             	add    %r8,%rcx
     7c6:	4c 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%r8
     7cd:	4d 89 c1             	mov    %r8,%r9
     7d0:	49 83 c1 01          	add    $0x1,%r9
     7d4:	4c 89 8d 38 ff ff ff 	mov    %r9,-0xc8(%rbp)
     7db:	48 89 8d 28 ff ff ff 	mov    %rcx,-0xd8(%rbp)
     7e2:	48 89 55 c0          	mov    %rdx,-0x40(%rbp)
     7e6:	48 89 bd 30 ff ff ff 	mov    %rdi,-0xd0(%rbp)
     7ed:	48 8b 8d e8 fe ff ff 	mov    -0x118(%rbp),%rcx
     7f4:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
     7fb:	e9 1a fd ff ff       	jmp    0x51a
     800:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
     807:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
     80e:	48 8b 45 90          	mov    -0x70(%rbp),%rax
     812:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
     819:	48 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%rax
     820:	48 89 85 58 ff ff ff 	mov    %rax,-0xa8(%rbp)
     827:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     82b:	48 89 85 50 ff ff ff 	mov    %rax,-0xb0(%rbp)
     832:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
     839:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
     840:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
     847:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
     84e:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
     855:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
     859:	48 39 c8             	cmp    %rcx,%rax
     85c:	0f 8c 48 00 00 00    	jl     0x8aa
     862:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
     869:	48 89 95 18 ff ff ff 	mov    %rdx,-0xe8(%rbp)
     870:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
     877:	48 89 95 10 ff ff ff 	mov    %rdx,-0xf0(%rbp)
     87e:	48 8b 95 50 ff ff ff 	mov    -0xb0(%rbp),%rdx
     885:	48 89 95 08 ff ff ff 	mov    %rdx,-0xf8(%rbp)
     88c:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
     893:	48 89 95 00 ff ff ff 	mov    %rdx,-0x100(%rbp)
     89a:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
     8a1:	48 89 55 98          	mov    %rdx,-0x68(%rbp)
     8a5:	e9 ea 05 00 00       	jmp    0xe94
     8aa:	4d 85 ff             	test   %r15,%r15
     8ad:	0f 84 0c 00 00 00    	je     0x8bf
     8b3:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
     8ba:	e9 0d 00 00 00       	jmp    0x8cc
     8bf:	49 8d 14 86          	lea    (%r14,%rax,4),%rdx
     8c3:	8b 32                	mov    (%rdx),%esi
     8c5:	48 89 b5 20 ff ff ff 	mov    %rsi,-0xe0(%rbp)
     8cc:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
     8d0:	48 89 c1             	mov    %rax,%rcx
     8d3:	48 83 e1 03          	and    $0x3,%rcx
     8d7:	48 83 f9 03          	cmp    $0x3,%rcx
     8db:	0f 85 5d 00 00 00    	jne    0x93e
     8e1:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
     8e5:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
     8ec:	48 8d 34 51          	lea    (%rcx,%rdx,2),%rsi
     8f0:	0f b7 3e             	movzwl (%rsi),%edi
     8f3:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
     8f7:	4c 8d 44 be 14       	lea    0x14(%rsi,%rdi,4),%r8
     8fc:	41 8b 38             	mov    (%r8),%edi
     8ff:	48 81 e7 ff 7f 00 00 	and    $0x7fff,%rdi
     906:	4c 8d 04 3e          	lea    (%rsi,%rdi,1),%r8
     90a:	41 0f b6 78 16       	movzbl 0x16(%r8),%edi
     90f:	4d 8d 0c 38          	lea    (%r8,%rdi,1),%r9
     913:	49 63 39             	movslq (%r9),%rdi
     916:	4d 8d 49 04          	lea    0x4(%r9),%r9
     91a:	4d 63 01             	movslq (%r9),%r8
     91d:	45 31 c9             	xor    %r9d,%r9d
     920:	4c 89 8d 30 ff ff ff 	mov    %r9,-0xd0(%rbp)
     927:	48 89 7d c0          	mov    %rdi,-0x40(%rbp)
     92b:	4c 89 85 28 ff ff ff 	mov    %r8,-0xd8(%rbp)
     932:	45 31 c9             	xor    %r9d,%r9d
     935:	4c 89 4d 90          	mov    %r9,-0x70(%rbp)
     939:	e9 25 03 00 00       	jmp    0xc63
     93e:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
     942:	48 89 c1             	mov    %rax,%rcx
     945:	48 83 e1 0a          	and    $0xa,%rcx
     949:	48 85 c9             	test   %rcx,%rcx
     94c:	0f 84 7c 02 00 00    	je     0xbce
     952:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
     956:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
     95d:	48 8d 34 51          	lea    (%rcx,%rdx,2),%rsi
     961:	0f b7 3e             	movzwl (%rsi),%edi
     964:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
     968:	4c 8d 44 be 14       	lea    0x14(%rsi,%rdi,4),%r8
     96d:	41 8b 38             	mov    (%r8),%edi
     970:	48 81 e7 ff 7f 00 00 	and    $0x7fff,%rdi
     977:	4c 8d 04 3e          	lea    (%rsi,%rdi,1),%r8
     97b:	41 0f b6 78 16       	movzbl 0x16(%r8),%edi
     980:	45 8b 48 12          	mov    0x12(%r8),%r9d
     984:	4d 89 ca             	mov    %r9,%r10
     987:	49 81 e2 ff 07 00 00 	and    $0x7ff,%r10
     98e:	49 83 fa 02          	cmp    $0x2,%r10
     992:	48 89 bd 38 ff ff ff 	mov    %rdi,-0xc8(%rbp)
     999:	4c 89 85 e8 fe ff ff 	mov    %r8,-0x118(%rbp)
     9a0:	4c 89 8d e0 fe ff ff 	mov    %r9,-0x120(%rbp)
     9a7:	0f 83 19 01 00 00    	jae    0xac6
     9ad:	45 31 d2             	xor    %r10d,%r10d
     9b0:	4c 8b 9b a0 00 00 00 	mov    0xa0(%rbx),%r11
     9b7:	4d 8b 0b             	mov    (%r11),%r9
     9ba:	4d 85 c9             	test   %r9,%r9
     9bd:	4c 89 9d d0 fe ff ff 	mov    %r11,-0x130(%rbp)
     9c4:	0f 85 23 00 00 00    	jne    0x9ed
     9ca:	45 31 c9             	xor    %r9d,%r9d
     9cd:	48 89 df             	mov    %rbx,%rdi
     9d0:	4c 89 d6             	mov    %r10,%rsi
     9d3:	4c 89 ca             	mov    %r9,%rdx
     9d6:	e8 45 f6 ff ff       	call   0x20
     9db:	48 83 f8 00          	cmp    $0x0,%rax
     9df:	0f 8d 08 00 00 00    	jge    0x9ed
     9e5:	49 89 c4             	mov    %rax,%r12
     9e8:	e9 c3 05 00 00       	jmp    0xfb0
     9ed:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
     9f4:	48 8b 48 20          	mov    0x20(%rax),%rcx
     9f8:	48 85 c9             	test   %rcx,%rcx
     9fb:	0f 85 24 00 00 00    	jne    0xa25
     a01:	b9 01 00 00 00       	mov    $0x1,%ecx
     a06:	48 89 df             	mov    %rbx,%rdi
     a09:	31 f6                	xor    %esi,%esi
     a0b:	48 89 ca             	mov    %rcx,%rdx
     a0e:	e8 0d f6 ff ff       	call   0x20
     a13:	48 83 f8 00          	cmp    $0x0,%rax
     a17:	0f 8d 08 00 00 00    	jge    0xa25
     a1d:	49 89 c4             	mov    %rax,%r12
     a20:	e9 8b 05 00 00       	jmp    0xfb0
     a25:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
     a2c:	48 8b 08             	mov    (%rax),%rcx
     a2f:	48 8b 50 20          	mov    0x20(%rax),%rdx
     a33:	48 8b 70 28          	mov    0x28(%rax),%rsi
     a37:	31 c0                	xor    %eax,%eax
     a39:	48 39 c6             	cmp    %rax,%rsi
     a3c:	bf 00 00 00 00       	mov    $0x0,%edi
     a41:	40 0f 94 c7          	sete   %dil
     a45:	4c 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%r8
     a4c:	4e 8d 0c c1          	lea    (%rcx,%r8,8),%r9
     a50:	49 8b 09             	mov    (%r9),%rcx
     a53:	4e 8d 0c c2          	lea    (%rdx,%r8,8),%r9
     a57:	49 8b 11             	mov    (%r9),%rdx
     a5a:	4d 89 c1             	mov    %r8,%r9
     a5d:	49 c1 e9 06          	shr    $0x6,%r9
     a61:	4e 8d 14 ce          	lea    (%rsi,%r9,8),%r10
     a65:	48 89 de             	mov    %rbx,%rsi
     a68:	48 85 ff             	test   %rdi,%rdi
     a6b:	49 0f 44 f2          	cmove  %r10,%rsi
     a6f:	4c 8b 0e             	mov    (%rsi),%r9
     a72:	4c 89 c6             	mov    %r8,%rsi
     a75:	48 83 e6 3f          	and    $0x3f,%rsi
     a79:	48 89 8d d0 fe ff ff 	mov    %rcx,-0x130(%rbp)
     a80:	48 89 f1             	mov    %rsi,%rcx
     a83:	49 d3 e9             	shr    %cl,%r9
     a86:	49 83 e1 01          	and    $0x1,%r9
     a8a:	49 39 c1             	cmp    %rax,%r9
     a8d:	41 b9 00 00 00 00    	mov    $0x0,%r9d
     a93:	41 0f 94 c1          	sete   %r9b
     a97:	b9 01 00 00 00       	mov    $0x1,%ecx
     a9c:	48 31 cf             	xor    %rcx,%rdi
     a9f:	49 21 f9             	and    %rdi,%r9
     aa2:	48 8b 8d d0 fe ff ff 	mov    -0x130(%rbp),%rcx
     aa9:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
     aad:	31 c9                	xor    %ecx,%ecx
     aaf:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
     ab3:	48 89 95 28 ff ff ff 	mov    %rdx,-0xd8(%rbp)
     aba:	4c 89 8d 30 ff ff ff 	mov    %r9,-0xd0(%rbp)
     ac1:	e9 03 01 00 00       	jmp    0xbc9
     ac6:	48 8b 85 e0 fe ff ff 	mov    -0x120(%rbp),%rax
     acd:	48 25 00 00 01 00    	and    $0x10000,%rax
     ad3:	48 85 c0             	test   %rax,%rax
     ad6:	0f 85 3b 00 00 00    	jne    0xb17
     adc:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
     ae3:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
     aea:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
     aee:	48 63 32             	movslq (%rdx),%rsi
     af1:	48 8d 52 04          	lea    0x4(%rdx),%rdx
     af5:	48 63 3a             	movslq (%rdx),%rdi
     af8:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
     afc:	31 d2                	xor    %edx,%edx
     afe:	48 89 55 90          	mov    %rdx,-0x70(%rbp)
     b02:	48 89 bd 28 ff ff ff 	mov    %rdi,-0xd8(%rbp)
     b09:	31 d2                	xor    %edx,%edx
     b0b:	48 89 95 30 ff ff ff 	mov    %rdx,-0xd0(%rbp)
     b12:	e9 b2 00 00 00       	jmp    0xbc9
     b17:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
     b1e:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
     b25:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
     b29:	0f b6 48 17          	movzbl 0x17(%rax),%ecx
     b2d:	48 89 ce             	mov    %rcx,%rsi
     b30:	48 83 e6 01          	and    $0x1,%rsi
     b34:	31 ff                	xor    %edi,%edi
     b36:	48 39 fe             	cmp    %rdi,%rsi
     b39:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     b3f:	41 0f 95 c0          	setne  %r8b
     b43:	48 39 fe             	cmp    %rdi,%rsi
     b46:	be 00 00 00 00       	mov    $0x0,%esi
     b4b:	40 0f 94 c6          	sete   %sil
     b4f:	45 31 c9             	xor    %r9d,%r9d
     b52:	4d 85 c0             	test   %r8,%r8
     b55:	4c 0f 44 cf          	cmove  %rdi,%r9
     b59:	49 89 d2             	mov    %rdx,%r10
     b5c:	4d 85 c0             	test   %r8,%r8
     b5f:	4c 0f 44 d0          	cmove  %rax,%r10
     b63:	4f 8d 1c 0a          	lea    (%r10,%r9,1),%r11
     b67:	4d 63 0b             	movslq (%r11),%r9
     b6a:	41 ba 04 00 00 00    	mov    $0x4,%r10d
     b70:	4d 85 c0             	test   %r8,%r8
     b73:	4c 0f 44 d7          	cmove  %rdi,%r10
     b77:	48 d1 e9             	shr    $1,%rcx
     b7a:	48 83 e1 01          	and    $0x1,%rcx
     b7e:	48 39 f9             	cmp    %rdi,%rcx
     b81:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     b87:	41 0f 95 c0          	setne  %r8b
     b8b:	48 39 f9             	cmp    %rdi,%rcx
     b8e:	b9 00 00 00 00       	mov    $0x0,%ecx
     b93:	0f 94 c1             	sete   %cl
     b96:	49 83 c2 03          	add    $0x3,%r10
     b9a:	49 83 e2 fc          	and    $0xfffffffffffffffc,%r10
     b9e:	4d 85 c0             	test   %r8,%r8
     ba1:	4c 0f 44 d7          	cmove  %rdi,%r10
     ba5:	4d 85 c0             	test   %r8,%r8
     ba8:	48 0f 44 d0          	cmove  %rax,%rdx
     bac:	4a 8d 04 12          	lea    (%rdx,%r10,1),%rax
     bb0:	48 63 10             	movslq (%rax),%rdx
     bb3:	4c 89 4d c0          	mov    %r9,-0x40(%rbp)
     bb7:	48 89 75 90          	mov    %rsi,-0x70(%rbp)
     bbb:	48 89 95 28 ff ff ff 	mov    %rdx,-0xd8(%rbp)
     bc2:	48 89 8d 30 ff ff ff 	mov    %rcx,-0xd0(%rbp)
     bc9:	e9 95 00 00 00       	jmp    0xc63
     bce:	48 8b 45 88          	mov    -0x78(%rbp),%rax
     bd2:	48 8b 8d 20 ff ff ff 	mov    -0xe0(%rbp),%rcx
     bd9:	48 8d 14 c8          	lea    (%rax,%rcx,8),%rdx
     bdd:	48 8b 32             	mov    (%rdx),%rsi
     be0:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
     be4:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
     be8:	4c 8b 07             	mov    (%rdi),%r8
     beb:	48 89 cf             	mov    %rcx,%rdi
     bee:	48 c1 ef 06          	shr    $0x6,%rdi
     bf2:	4c 8b 8d 78 ff ff ff 	mov    -0x88(%rbp),%r9
     bf9:	4d 8d 14 f9          	lea    (%r9,%rdi,8),%r10
     bfd:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
     c04:	49 89 db             	mov    %rbx,%r11
     c07:	48 85 ff             	test   %rdi,%rdi
     c0a:	4d 0f 44 da          	cmove  %r10,%r11
     c0e:	4d 8b 13             	mov    (%r11),%r10
     c11:	48 83 e1 3f          	and    $0x3f,%rcx
     c15:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
     c1c:	4c 8b 9d 20 ff ff ff 	mov    -0xe0(%rbp),%r11
     c23:	4c 89 d9             	mov    %r11,%rcx
     c26:	49 d3 ea             	shr    %cl,%r10
     c29:	49 83 e2 01          	and    $0x1,%r10
     c2d:	31 c9                	xor    %ecx,%ecx
     c2f:	49 39 ca             	cmp    %rcx,%r10
     c32:	41 ba 00 00 00 00    	mov    $0x0,%r10d
     c38:	41 0f 94 c2          	sete   %r10b
     c3c:	41 bb 01 00 00 00    	mov    $0x1,%r11d
     c42:	48 89 f8             	mov    %rdi,%rax
     c45:	4c 31 d8             	xor    %r11,%rax
     c48:	49 21 c2             	and    %rax,%r10
     c4b:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
     c4f:	31 c0                	xor    %eax,%eax
     c51:	48 89 45 90          	mov    %rax,-0x70(%rbp)
     c55:	4c 89 85 28 ff ff ff 	mov    %r8,-0xd8(%rbp)
     c5c:	4c 89 95 30 ff ff ff 	mov    %r10,-0xd0(%rbp)
     c63:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     c67:	48 63 c0             	movslq %eax,%rax
     c6a:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     c6e:	48 8b 8d 40 ff ff ff 	mov    -0xc0(%rbp),%rcx
     c75:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
     c79:	48 8b 8d 58 ff ff ff 	mov    -0xa8(%rbp),%rcx
     c80:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
     c87:	48 8b 45 90          	mov    -0x70(%rbp),%rax
     c8b:	48 8b 48 38          	mov    0x38(%rax),%rcx
     c8f:	ba 18 00 00 00       	mov    $0x18,%edx
     c94:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
     c9b:	48 89 f7             	mov    %rsi,%rdi
     c9e:	48 0f af fa          	imul   %rdx,%rdi
     ca2:	48 8d 94 38 c0 00 00 	lea    0xc0(%rax,%rdi,1),%rdx
     ca9:	00 
     caa:	48 81 c7 d8 00 00 00 	add    $0xd8,%rdi
     cb1:	48 39 cf             	cmp    %rcx,%rdi
     cb4:	48 89 8d e8 fe ff ff 	mov    %rcx,-0x118(%rbp)
     cbb:	48 89 95 38 ff ff ff 	mov    %rdx,-0xc8(%rbp)
     cc2:	0f 8e d6 00 00 00    	jle    0xd9e
     cc8:	48 8b 7b 18          	mov    0x18(%rbx),%rdi
     ccc:	48 85 ff             	test   %rdi,%rdi
     ccf:	0f 84 0d 00 00 00    	je     0xce2
     cd5:	44 0f b6 07          	movzbl (%rdi),%r8d
     cd9:	4d 85 c0             	test   %r8,%r8
     cdc:	0f 85 a6 00 00 00    	jne    0xd88
     ce2:	b8 01 00 00 00       	mov    $0x1,%eax
     ce7:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
     ceb:	88 41 02             	mov    %al,0x2(%rcx)
     cee:	b8 01 00 00 00       	mov    $0x1,%eax
     cf3:	88 41 0d             	mov    %al,0xd(%rcx)
     cf6:	31 c0                	xor    %eax,%eax
     cf8:	88 41 37             	mov    %al,0x37(%rcx)
     cfb:	b8 01 00 00 00       	mov    $0x1,%eax
     d00:	88 41 01             	mov    %al,0x1(%rcx)
     d03:	b8 18 00 00 00       	mov    $0x18,%eax
     d08:	ba 18 00 00 00       	mov    $0x18,%edx
     d0d:	89 41 04             	mov    %eax,0x4(%rcx)
     d10:	89 51 58             	mov    %edx,0x58(%rcx)
     d13:	31 c0                	xor    %eax,%eax
     d15:	66 89 81 80 00 00 00 	mov    %ax,0x80(%rcx)
     d1c:	48 8d 45 c8          	lea    -0x38(%rbp),%rax
     d20:	48 89 c2             	mov    %rax,%rdx
     d23:	be 18 00 00 00       	mov    $0x18,%esi
     d28:	48 89 df             	mov    %rbx,%rdi
     d2b:	48 89 ce             	mov    %rcx,%rsi
     d2e:	48 89 95 e0 fe ff ff 	mov    %rdx,-0x120(%rbp)
     d35:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
     d3c:	b9 18 00 00 00       	mov    $0x18,%ecx
     d41:	4c 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%r8
     d48:	4c 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%r9
     d4f:	e8 dc f2 ff ff       	call   0x30
     d54:	48 85 c0             	test   %rax,%rax
     d57:	0f 85 11 00 00 00    	jne    0xd6e
     d5d:	b9 80 00 00 00       	mov    $0x80,%ecx
     d62:	48 89 8d c0 fe ff ff 	mov    %rcx,-0x140(%rbp)
     d69:	e9 2d 02 00 00       	jmp    0xf9b
     d6e:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
     d75:	48 8b 11             	mov    (%rcx),%rdx
     d78:	48 89 45 90          	mov    %rax,-0x70(%rbp)
     d7c:	48 89 95 20 ff ff ff 	mov    %rdx,-0xe0(%rbp)
     d83:	e9 ff fe ff ff       	jmp    0xc87
     d88:	48 89 df             	mov    %rbx,%rdi
     d8b:	e8 b0 f2 ff ff       	call   0x40
     d90:	48 85 c0             	test   %rax,%rax
     d93:	0f 84 49 ff ff ff    	je     0xce2
     d99:	e9 f1 01 00 00       	jmp    0xf8f
     d9e:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
     da5:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
     da9:	48 89 08             	mov    %rcx,(%rax)
     dac:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
     db3:	48 89 50 10          	mov    %rdx,0x10(%rax)
     db7:	48 8b 95 30 ff ff ff 	mov    -0xd0(%rbp),%rdx
     dbe:	48 c1 e2 20          	shl    $0x20,%rdx
     dc2:	48 89 50 08          	mov    %rdx,0x8(%rax)
     dc6:	48 8b 45 90          	mov    -0x70(%rbp),%rax
     dca:	0f b6 50 70          	movzbl 0x70(%rax),%edx
     dce:	48 85 d2             	test   %rdx,%rdx
     dd1:	0f 85 11 00 00 00    	jne    0xde8
     dd7:	ba 01 00 00 00       	mov    $0x1,%edx
     ddc:	48 89 95 38 ff ff ff 	mov    %rdx,-0xc8(%rbp)
     de3:	e9 3b 00 00 00       	jmp    0xe23
     de8:	48 89 df             	mov    %rbx,%rdi
     deb:	48 89 c6             	mov    %rax,%rsi
     dee:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
     df5:	48 8b 8d e8 fe ff ff 	mov    -0x118(%rbp),%rcx
     dfc:	e8 4f f2 ff ff       	call   0x50
     e01:	48 83 f8 00          	cmp    $0x0,%rax
     e05:	0f 8d 11 00 00 00    	jge    0xe1c
     e0b:	b9 80 00 00 00       	mov    $0x80,%ecx
     e10:	48 89 8d c0 fe ff ff 	mov    %rcx,-0x140(%rbp)
     e17:	e9 7f 01 00 00       	jmp    0xf9b
     e1c:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
     e23:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
     e2a:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
     e2e:	48 89 c2             	mov    %rax,%rdx
     e31:	48 39 ca             	cmp    %rcx,%rdx
     e34:	48 0f 4f d1          	cmovg  %rcx,%rdx
     e38:	48 8b b5 48 ff ff ff 	mov    -0xb8(%rbp),%rsi
     e3f:	48 89 f7             	mov    %rsi,%rdi
     e42:	48 39 cf             	cmp    %rcx,%rdi
     e45:	48 0f 4c f9          	cmovl  %rcx,%rdi
     e49:	48 8b 8d 20 ff ff ff 	mov    -0xe0(%rbp),%rcx
     e50:	4c 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%r8
     e57:	4c 01 c1             	add    %r8,%rcx
     e5a:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
     e61:	4d 89 c1             	mov    %r8,%r9
     e64:	49 83 c1 01          	add    $0x1,%r9
     e68:	4c 89 8d 68 ff ff ff 	mov    %r9,-0x98(%rbp)
     e6f:	48 89 8d 58 ff ff ff 	mov    %rcx,-0xa8(%rbp)
     e76:	48 89 95 50 ff ff ff 	mov    %rdx,-0xb0(%rbp)
     e7d:	48 89 bd 48 ff ff ff 	mov    %rdi,-0xb8(%rbp)
     e84:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
     e88:	48 89 8d 40 ff ff ff 	mov    %rcx,-0xc0(%rbp)
     e8f:	e9 ba f9 ff ff       	jmp    0x84e
     e94:	48 8b 45 98          	mov    -0x68(%rbp),%rax
     e98:	48 8b 8d 10 ff ff ff 	mov    -0xf0(%rbp),%rcx
     e9f:	48 89 48 10          	mov    %rcx,0x10(%rax)
     ea3:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
     eaa:	48 89 48 18          	mov    %rcx,0x18(%rax)
     eae:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
     eb5:	48 89 48 20          	mov    %rcx,0x20(%rax)
     eb9:	b9 01 00 00 00       	mov    $0x1,%ecx
     ebe:	88 48 02             	mov    %cl,0x2(%rax)
     ec1:	b9 01 00 00 00       	mov    $0x1,%ecx
     ec6:	88 48 0d             	mov    %cl,0xd(%rax)
     ec9:	31 c9                	xor    %ecx,%ecx
     ecb:	88 48 37             	mov    %cl,0x37(%rax)
     ece:	b9 01 00 00 00       	mov    $0x1,%ecx
     ed3:	88 48 01             	mov    %cl,0x1(%rax)
     ed6:	b9 18 00 00 00       	mov    $0x18,%ecx
     edb:	ba 18 00 00 00       	mov    $0x18,%edx
     ee0:	89 48 04             	mov    %ecx,0x4(%rax)
     ee3:	89 50 58             	mov    %edx,0x58(%rax)
     ee6:	31 c9                	xor    %ecx,%ecx
     ee8:	66 89 88 80 00 00 00 	mov    %cx,0x80(%rax)
     eef:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
     ef6:	48 8b 8d 18 ff ff ff 	mov    -0xe8(%rbp),%rcx
     efd:	48 01 c8             	add    %rcx,%rax
     f00:	48 89 83 e8 00 00 00 	mov    %rax,0xe8(%rbx)
     f07:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
     f0b:	89 83 00 01 00 00    	mov    %eax,0x100(%rbx)
     f11:	e9 eb f3 ff ff       	jmp    0x301
     f16:	48 89 df             	mov    %rbx,%rdi
     f19:	e8 22 f1 ff ff       	call   0x40
     f1e:	48 85 c0             	test   %rax,%rax
     f21:	0f 84 f3 f3 ff ff    	je     0x31a
     f27:	e9 63 00 00 00       	jmp    0xf8f
     f2c:	4d 85 ed             	test   %r13,%r13
     f2f:	0f 84 08 00 00 00    	je     0xf3d
     f35:	4d 89 ec             	mov    %r13,%r12
     f38:	e9 73 00 00 00       	jmp    0xfb0
     f3d:	48 8b 03             	mov    (%rbx),%rax
     f40:	48 8b 48 28          	mov    0x28(%rax),%rcx
     f44:	48 8b 01             	mov    (%rcx),%rax
     f47:	0f b6 48 70          	movzbl 0x70(%rax),%ecx
     f4b:	48 85 c9             	test   %rcx,%rcx
     f4e:	0f 84 2b 00 00 00    	je     0xf7f
     f54:	31 c0                	xor    %eax,%eax
     f56:	48 89 df             	mov    %rbx,%rdi
     f59:	48 89 c6             	mov    %rax,%rsi
     f5c:	48 89 ca             	mov    %rcx,%rdx
     f5f:	e8 fc f0 ff ff       	call   0x60
     f64:	48 83 f8 00          	cmp    $0x0,%rax
     f68:	0f 8d 11 00 00 00    	jge    0xf7f
     f6e:	b8 80 00 00 00       	mov    $0x80,%eax
     f73:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
     f7a:	e9 1c 00 00 00       	jmp    0xf9b
     f7f:	48 89 df             	mov    %rbx,%rdi
     f82:	e8 e9 f0 ff ff       	call   0x70
     f87:	49 89 c4             	mov    %rax,%r12
     f8a:	e9 21 00 00 00       	jmp    0xfb0
     f8f:	49 c7 c4 fe ff ff ff 	mov    $0xfffffffffffffffe,%r12
     f96:	e9 15 00 00 00       	jmp    0xfb0
     f9b:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
     fa2:	48 c1 e0 08          	shl    $0x8,%rax
     fa6:	48 83 c8 03          	or     $0x3,%rax
     faa:	48 f7 d8             	neg    %rax
     fad:	49 89 c4             	mov    %rax,%r12
     fb0:	4c 89 e0             	mov    %r12,%rax
     fb3:	48 81 c4 18 01 00 00 	add    $0x118,%rsp
     fba:	41 5f                	pop    %r15
     fbc:	41 5e                	pop    %r14
     fbe:	41 5d                	pop    %r13
     fc0:	41 5c                	pop    %r12
     fc2:	5b                   	pop    %rbx
     fc3:	5d                   	pop    %rbp
     fc4:	c3                   	ret
     fc5:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     fcc:	00 00 
     fce:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     fd5:	00 00 
     fd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     fde:	00 00 
     fe0:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     fe7:	00 00 
     fe9:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     ff0:	00 00 
     ff2:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     ff9:	00 00 
     ffb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1000:	55                   	push   %rbp
    1001:	48 89 e5             	mov    %rsp,%rbp
    1004:	53                   	push   %rbx
    1005:	41 54                	push   %r12
    1007:	41 55                	push   %r13
    1009:	41 56                	push   %r14
    100b:	41 57                	push   %r15
    100d:	48 81 ec 38 05 00 00 	sub    $0x538,%rsp
    1014:	31 c0                	xor    %eax,%eax
    1016:	b9 01 00 00 00       	mov    $0x1,%ecx
    101b:	48 8b 57 58          	mov    0x58(%rdi),%rdx
    101f:	48 8b 1f             	mov    (%rdi),%rbx
    1022:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    1026:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
    102a:	48 85 db             	test   %rbx,%rbx
    102d:	48 89 55 d0          	mov    %rdx,-0x30(%rbp)
    1031:	48 89 bd 98 fc ff ff 	mov    %rdi,-0x368(%rbp)
    1038:	0f 84 82 00 00 00    	je     0x10c0
    103e:	0f b6 73 0c          	movzbl 0xc(%rbx),%esi
    1042:	44 8b 43 30          	mov    0x30(%rbx),%r8d
    1046:	4c 8b 4b 10          	mov    0x10(%rbx),%r9
    104a:	44 0f b6 53 70       	movzbl 0x70(%rbx),%r10d
    104f:	48 83 fe 01          	cmp    $0x1,%rsi
    1053:	be 00 00 00 00       	mov    $0x0,%esi
    1058:	40 0f 94 c6          	sete   %sil
    105c:	bb 08 00 00 00       	mov    $0x8,%ebx
    1061:	4c 89 c1             	mov    %r8,%rcx
    1064:	48 d3 e3             	shl    %cl,%rbx
    1067:	b9 18 00 00 00       	mov    $0x18,%ecx
    106c:	4c 0f af c9          	imul   %rcx,%r9
    1070:	4c 01 cb             	add    %r9,%rbx
    1073:	48 81 fb 00 00 10 00 	cmp    $0x100000,%rbx
    107a:	bb 00 00 00 00       	mov    $0x0,%ebx
    107f:	0f 97 c3             	seta   %bl
    1082:	48 21 de             	and    %rbx,%rsi
    1085:	49 39 c2             	cmp    %rax,%r10
    1088:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    108e:	41 0f 94 c2          	sete   %r10b
    1092:	4c 21 d6             	and    %r10,%rsi
    1095:	48 85 f6             	test   %rsi,%rsi
    1098:	0f 84 22 00 00 00    	je     0x10c0
    109e:	8b 4f 70             	mov    0x70(%rdi),%ecx
    10a1:	48 81 e1 00 00 01 00 	and    $0x10000,%rcx
    10a8:	48 85 c9             	test   %rcx,%rcx
    10ab:	0f 85 0f 00 00 00    	jne    0x10c0
    10b1:	48 c7 c1 f7 ff ff ff 	mov    $0xfffffffffffffff7,%rcx
    10b8:	48 89 c8             	mov    %rcx,%rax
    10bb:	e9 6a 60 00 00       	jmp    0x712a
    10c0:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    10c7:	48 8b 98 10 02 00 00 	mov    0x210(%rax),%rbx
    10ce:	48 8d 8d 60 ff ff ff 	lea    -0xa0(%rbp),%rcx
    10d5:	48 89 ca             	mov    %rcx,%rdx
    10d8:	48 8b 70 50          	mov    0x50(%rax),%rsi
    10dc:	48 85 f6             	test   %rsi,%rsi
    10df:	48 89 95 90 fc ff ff 	mov    %rdx,-0x370(%rbp)
    10e6:	0f 85 d7 01 00 00    	jne    0x12c3
    10ec:	48 be 01 00 00 00 00 	movabs $0x4000000000001,%rsi
    10f3:	00 04 00 
    10f6:	48 89 70 50          	mov    %rsi,0x50(%rax)
    10fa:	31 f6                	xor    %esi,%esi
    10fc:	48 89 33             	mov    %rsi,(%rbx)
    10ff:	be 99 19 00 00       	mov    $0x1999,%esi
    1104:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    1108:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    110c:	45 31 c9             	xor    %r9d,%r9d
    110f:	4d 39 c8             	cmp    %r9,%r8
    1112:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    1118:	41 0f 94 c2          	sete   %r10b
    111c:	4d 85 d2             	test   %r10,%r10
    111f:	49 0f 44 f0          	cmove  %r8,%rsi
    1123:	41 bb 99 19 00 00    	mov    $0x1999,%r11d
    1129:	4d 85 d2             	test   %r10,%r10
    112c:	4d 0f 44 d8          	cmove  %r8,%r11
    1130:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    1136:	4c 39 de             	cmp    %r11,%rsi
    1139:	49 0f 47 f3          	cmova  %r11,%rsi
    113d:	4c 39 c6             	cmp    %r8,%rsi
    1140:	49 0f 47 f0          	cmova  %r8,%rsi
    1144:	4c 8d 85 30 ff ff ff 	lea    -0xd0(%rbp),%r8
    114b:	4d 89 c2             	mov    %r8,%r10
    114e:	41 bb 02 02 01 01    	mov    $0x1010202,%r11d
    1154:	4d 89 1a             	mov    %r11,(%r10)
    1157:	41 bb 00 00 00 01    	mov    $0x1000000,%r11d
    115d:	4d 89 5a 08          	mov    %r11,0x8(%r10)
    1161:	41 bb 00 00 10 18    	mov    $0x18100000,%r11d
    1167:	4d 89 5a 10          	mov    %r11,0x10(%r10)
    116b:	49 bb 00 00 28 01 10 	movabs $0x201001280000,%r11
    1172:	20 00 00 
    1175:	4d 89 5a 18          	mov    %r11,0x18(%r10)
    1179:	45 31 db             	xor    %r11d,%r11d
    117c:	4d 89 5a 20          	mov    %r11,0x20(%r10)
    1180:	41 bb 99 19 00 00    	mov    $0x1999,%r11d
    1186:	4c 8b 67 10          	mov    0x10(%rdi),%r12
    118a:	4d 39 cc             	cmp    %r9,%r12
    118d:	bf 00 00 00 00       	mov    $0x0,%edi
    1192:	40 0f 94 c7          	sete   %dil
    1196:	48 85 ff             	test   %rdi,%rdi
    1199:	4d 0f 44 dc          	cmove  %r12,%r11
    119d:	bf cd cc cc 00       	mov    $0xcccccd,%edi
    11a2:	49 39 fb             	cmp    %rdi,%r11
    11a5:	41 bc 00 00 00 00    	mov    $0x0,%r12d
    11ab:	41 0f 97 c4          	seta   %r12b
    11af:	4d 85 e4             	test   %r12,%r12
    11b2:	49 0f 44 fb          	cmove  %r11,%rdi
    11b6:	41 bb 28 00 00 00    	mov    $0x28,%r11d
    11bc:	49 0f af fb          	imul   %r11,%rdi
    11c0:	48 81 c7 ff ff 03 00 	add    $0x3ffff,%rdi
    11c7:	48 c1 ef 12          	shr    $0x12,%rdi
    11cb:	48 83 ff 01          	cmp    $0x1,%rdi
    11cf:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    11d5:	41 0f 97 c3          	seta   %r11b
    11d9:	48 83 ef 01          	sub    $0x1,%rdi
    11dd:	4c 0f bd e7          	bsr    %rdi,%r12
    11e1:	bf 7f 00 00 00       	mov    $0x7f,%edi
    11e6:	49 0f 45 fc          	cmovne %r12,%rdi
    11ea:	83 f7 3f             	xor    $0x3f,%edi
    11ed:	41 bc 40 00 00 00    	mov    $0x40,%r12d
    11f3:	49 29 fc             	sub    %rdi,%r12
    11f6:	bf 0b 00 00 00       	mov    $0xb,%edi
    11fb:	49 39 fc             	cmp    %rdi,%r12
    11fe:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    1204:	41 0f 97 c5          	seta   %r13b
    1208:	4d 85 ed             	test   %r13,%r13
    120b:	49 0f 44 fc          	cmove  %r12,%rdi
    120f:	45 31 e4             	xor    %r12d,%r12d
    1212:	4d 85 db             	test   %r11,%r11
    1215:	49 0f 44 fc          	cmove  %r12,%rdi
    1219:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
    121d:	48 89 c7             	mov    %rax,%rdi
    1220:	48 89 b5 88 fc ff ff 	mov    %rsi,-0x378(%rbp)
    1227:	48 89 d6             	mov    %rdx,%rsi
    122a:	4c 89 d2             	mov    %r10,%rdx
    122d:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
    1231:	4c 8b 85 88 fc ff ff 	mov    -0x378(%rbp),%r8
    1238:	4c 89 95 88 fc ff ff 	mov    %r10,-0x378(%rbp)
    123f:	e8 3c ee ff ff       	call   0x80
    1244:	48 83 f8 00          	cmp    $0x0,%rax
    1248:	0f 8d 08 00 00 00    	jge    0x1256
    124e:	49 89 c4             	mov    %rax,%r12
    1251:	e9 d1 5e 00 00       	jmp    0x7127
    1256:	b8 01 00 00 00       	mov    $0x1,%eax
    125b:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    1262:	48 89 c6             	mov    %rax,%rsi
    1265:	48 8b 95 88 fc ff ff 	mov    -0x378(%rbp),%rdx
    126c:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
    1270:	e8 1b ee ff ff       	call   0x90
    1275:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    127c:	48 8b 08             	mov    (%rax),%rcx
    127f:	31 d2                	xor    %edx,%edx
    1281:	48 8d 74 11 10       	lea    0x10(%rcx,%rdx,1),%rsi
    1286:	48 89 70 40          	mov    %rsi,0x40(%rax)
    128a:	48 89 50 60          	mov    %rdx,0x60(%rax)
    128e:	48 8b 08             	mov    (%rax),%rcx
    1291:	0f b6 71 0d          	movzbl 0xd(%rcx),%esi
    1295:	48 83 e6 01          	and    $0x1,%rsi
    1299:	48 89 70 68          	mov    %rsi,0x68(%rax)
    129d:	b9 01 00 00 00       	mov    $0x1,%ecx
    12a2:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    12a9:	48 89 ce             	mov    %rcx,%rsi
    12ac:	e8 ef ed ff ff       	call   0xa0
    12b1:	48 83 f8 00          	cmp    $0x0,%rax
    12b5:	0f 8d 08 00 00 00    	jge    0x12c3
    12bb:	49 89 c4             	mov    %rax,%r12
    12be:	e9 64 5e 00 00       	jmp    0x7127
    12c3:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    12ca:	48 8b 48 18          	mov    0x18(%rax),%rcx
    12ce:	48 85 c9             	test   %rcx,%rcx
    12d1:	0f 84 0c 00 00 00    	je     0x12e3
    12d7:	0f b6 11             	movzbl (%rcx),%edx
    12da:	48 85 d2             	test   %rdx,%rdx
    12dd:	0f 85 53 5d 00 00    	jne    0x7036
    12e3:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    12ea:	48 8b 08             	mov    (%rax),%rcx
    12ed:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    12f1:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
    12f5:	44 0f b6 69 0c       	movzbl 0xc(%rcx),%r13d
    12fa:	4d 85 ed             	test   %r13,%r13
    12fd:	0f 84 65 5d 00 00    	je     0x7068
    1303:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    1307:	48 8d 34 11          	lea    (%rcx,%rdx,1),%rsi
    130b:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    130f:	48 8d 3c 11          	lea    (%rcx,%rdx,1),%rdi
    1313:	8b 51 30             	mov    0x30(%rcx),%edx
    1316:	4c 8b 41 18          	mov    0x18(%rcx),%r8
    131a:	4c 8b 49 20          	mov    0x20(%rcx),%r9
    131e:	4d 29 c1             	sub    %r8,%r9
    1321:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    1327:	4d 01 d1             	add    %r10,%r9
    132a:	49 89 ce             	mov    %rcx,%r14
    132d:	49 81 c6 c0 00 00 00 	add    $0xc0,%r14
    1334:	49 89 fb             	mov    %rdi,%r11
    1337:	49 29 f3             	sub    %rsi,%r11
    133a:	4e 8d 3c 1e          	lea    (%rsi,%r11,1),%r15
    133e:	4e 8d 14 5e          	lea    (%rsi,%r11,2),%r10
    1342:	44 0f b6 59 70       	movzbl 0x70(%rcx),%r11d
    1347:	48 8b 41 78          	mov    0x78(%rcx),%rax
    134b:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
    134f:	0f b6 41 72          	movzbl 0x72(%rcx),%eax
    1353:	49 83 fd 01          	cmp    $0x1,%r13
    1357:	b9 00 00 00 00       	mov    $0x0,%ecx
    135c:	0f 94 c1             	sete   %cl
    135f:	48 89 8d 88 fc ff ff 	mov    %rcx,-0x378(%rbp)
    1366:	31 c9                	xor    %ecx,%ecx
    1368:	48 89 bd 80 fc ff ff 	mov    %rdi,-0x380(%rbp)
    136f:	48 39 c8             	cmp    %rcx,%rax
    1372:	bf 00 00 00 00       	mov    $0x0,%edi
    1377:	40 0f 95 c7          	setne  %dil
    137b:	48 8b 8d 88 fc ff ff 	mov    -0x378(%rbp),%rcx
    1382:	48 21 f9             	and    %rdi,%rcx
    1385:	48 85 c9             	test   %rcx,%rcx
    1388:	48 89 85 88 fc ff ff 	mov    %rax,-0x378(%rbp)
    138f:	48 89 95 78 fc ff ff 	mov    %rdx,-0x388(%rbp)
    1396:	48 89 b5 70 fc ff ff 	mov    %rsi,-0x390(%rbp)
    139d:	4c 89 85 68 fc ff ff 	mov    %r8,-0x398(%rbp)
    13a4:	4c 89 8d 60 fc ff ff 	mov    %r9,-0x3a0(%rbp)
    13ab:	4c 89 95 58 fc ff ff 	mov    %r10,-0x3a8(%rbp)
    13b2:	4c 89 9d 50 fc ff ff 	mov    %r11,-0x3b0(%rbp)
    13b9:	4c 89 bd 48 fc ff ff 	mov    %r15,-0x3b8(%rbp)
    13c0:	0f 85 1a 00 00 00    	jne    0x13e0
    13c6:	45 31 ff             	xor    %r15d,%r15d
    13c9:	31 c9                	xor    %ecx,%ecx
    13cb:	48 89 8d 40 fc ff ff 	mov    %rcx,-0x3c0(%rbp)
    13d2:	31 c9                	xor    %ecx,%ecx
    13d4:	48 89 8d 38 fc ff ff 	mov    %rcx,-0x3c8(%rbp)
    13db:	e9 91 01 00 00       	jmp    0x1571
    13e0:	b9 08 00 00 00       	mov    $0x8,%ecx
    13e5:	bf 08 00 00 00       	mov    $0x8,%edi
    13ea:	48 89 d1             	mov    %rdx,%rcx
    13ed:	48 d3 e7             	shl    %cl,%rdi
    13f0:	48 8d 0c 3e          	lea    (%rsi,%rdi,1),%rcx
    13f4:	31 c0                	xor    %eax,%eax
    13f6:	4c 8d 54 01 40       	lea    0x40(%rcx,%rax,1),%r10
    13fb:	48 81 ff 00 00 10 00 	cmp    $0x100000,%rdi
    1402:	0f 87 1a 00 00 00    	ja     0x1422
    1408:	31 ff                	xor    %edi,%edi
    140a:	48 89 bd 38 fc ff ff 	mov    %rdi,-0x3c8(%rbp)
    1411:	4d 89 d7             	mov    %r10,%r15
    1414:	31 ff                	xor    %edi,%edi
    1416:	48 89 bd 40 fc ff ff 	mov    %rdi,-0x3c0(%rbp)
    141d:	e9 4f 01 00 00       	jmp    0x1571
    1422:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
    1426:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    142a:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    1430:	4c 01 c2             	add    %r8,%rdx
    1433:	48 89 53 10          	mov    %rdx,0x10(%rbx)
    1437:	4c 8b 49 10          	mov    0x10(%rcx),%r9
    143b:	48 85 ff             	test   %rdi,%rdi
    143e:	48 89 95 30 fc ff ff 	mov    %rdx,-0x3d0(%rbp)
    1445:	4c 89 95 28 fc ff ff 	mov    %r10,-0x3d8(%rbp)
    144c:	0f 85 0c 00 00 00    	jne    0x145e
    1452:	4c 89 8d 20 fc ff ff 	mov    %r9,-0x3e0(%rbp)
    1459:	e9 b3 00 00 00       	jmp    0x1511
    145e:	48 89 43 08          	mov    %rax,0x8(%rbx)
    1462:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    1467:	49 89 fa             	mov    %rdi,%r10
    146a:	49 21 d2             	and    %rdx,%r10
    146d:	48 c1 ef 20          	shr    $0x20,%rdi
    1471:	4c 89 d2             	mov    %r10,%rdx
    1474:	48 01 fa             	add    %rdi,%rdx
    1477:	48 8b 39             	mov    (%rcx),%rdi
    147a:	48 01 d7             	add    %rdx,%rdi
    147d:	48 89 39             	mov    %rdi,(%rcx)
    1480:	48 8b 51 08          	mov    0x8(%rcx),%rdx
    1484:	4c 01 d2             	add    %r10,%rdx
    1487:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    148b:	48 81 ff 00 10 00 00 	cmp    $0x1000,%rdi
    1492:	0f 83 0c 00 00 00    	jae    0x14a4
    1498:	4c 89 8d 20 fc ff ff 	mov    %r9,-0x3e0(%rbp)
    149f:	e9 6d 00 00 00       	jmp    0x1511
    14a4:	41 ba 17 00 00 00    	mov    $0x17,%r10d
    14aa:	be 08 00 00 00       	mov    $0x8,%esi
    14af:	49 89 fb             	mov    %rdi,%r11
    14b2:	49 29 d3             	sub    %rdx,%r11
    14b5:	4d 0f af da          	imul   %r10,%r11
    14b9:	48 0f af fe          	imul   %rsi,%rdi
    14bd:	49 39 fb             	cmp    %rdi,%r11
    14c0:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    14c6:	41 0f 96 c3          	setbe  %r11b
    14ca:	49 83 cb 02          	or     $0x2,%r11
    14ce:	4c 89 59 10          	mov    %r11,0x10(%rcx)
    14d2:	48 89 01             	mov    %rax,(%rcx)
    14d5:	48 89 41 08          	mov    %rax,0x8(%rcx)
    14d9:	4d 31 d9             	xor    %r11,%r9
    14dc:	4d 21 c1             	and    %r8,%r9
    14df:	4d 85 c9             	test   %r9,%r9
    14e2:	0f 85 0c 00 00 00    	jne    0x14f4
    14e8:	4c 89 9d 20 fc ff ff 	mov    %r11,-0x3e0(%rbp)
    14ef:	e9 1d 00 00 00       	jmp    0x1511
    14f4:	4c 89 df             	mov    %r11,%rdi
    14f7:	4c 89 9d 18 fc ff ff 	mov    %r11,-0x3e8(%rbp)
    14fe:	e8 ad eb ff ff       	call   0xb0
    1503:	48 8b 85 18 fc ff ff 	mov    -0x3e8(%rbp),%rax
    150a:	48 89 85 20 fc ff ff 	mov    %rax,-0x3e0(%rbp)
    1511:	48 8b 85 30 fc ff ff 	mov    -0x3d0(%rbp),%rax
    1518:	48 83 e0 1f          	and    $0x1f,%rax
    151c:	31 c9                	xor    %ecx,%ecx
    151e:	48 39 c8             	cmp    %rcx,%rax
    1521:	b8 00 00 00 00       	mov    $0x0,%eax
    1526:	0f 94 c0             	sete   %al
    1529:	48 8b 95 20 fc ff ff 	mov    -0x3e0(%rbp),%rdx
    1530:	48 89 d6             	mov    %rdx,%rsi
    1533:	48 83 e6 02          	and    $0x2,%rsi
    1537:	48 39 ce             	cmp    %rcx,%rsi
    153a:	be 00 00 00 00       	mov    $0x0,%esi
    153f:	40 0f 94 c6          	sete   %sil
    1543:	48 09 c6             	or     %rax,%rsi
    1546:	b8 01 00 00 00       	mov    $0x1,%eax
    154b:	48 21 c2             	and    %rax,%rdx
    154e:	48 39 ca             	cmp    %rcx,%rdx
    1551:	ba 00 00 00 00       	mov    $0x0,%edx
    1556:	0f 94 c2             	sete   %dl
    1559:	48 09 f2             	or     %rsi,%rdx
    155c:	48 89 95 38 fc ff ff 	mov    %rdx,-0x3c8(%rbp)
    1563:	4c 8b bd 28 fc ff ff 	mov    -0x3d8(%rbp),%r15
    156a:	48 89 b5 40 fc ff ff 	mov    %rsi,-0x3c0(%rbp)
    1571:	b8 01 00 00 00       	mov    $0x1,%eax
    1576:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    157d:	48 89 c6             	mov    %rax,%rsi
    1580:	e8 3b eb ff ff       	call   0xc0
    1585:	48 83 f8 00          	cmp    $0x0,%rax
    1589:	48 89 85 28 fc ff ff 	mov    %rax,-0x3d8(%rbp)
    1590:	0f 8e ba 5a 00 00    	jle    0x7050
    1596:	48 8b 8d 98 fc ff ff 	mov    -0x368(%rbp),%rcx
    159d:	8b 91 c0 01 00 00    	mov    0x1c0(%rcx),%edx
    15a3:	8b b1 bc 01 00 00    	mov    0x1bc(%rcx),%esi
    15a9:	48 8b b9 90 01 00 00 	mov    0x190(%rcx),%rdi
    15b0:	45 31 c0             	xor    %r8d,%r8d
    15b3:	4c 39 c7             	cmp    %r8,%rdi
    15b6:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    15bc:	41 0f 94 c1          	sete   %r9b
    15c0:	44 8b 91 c4 01 00 00 	mov    0x1c4(%rcx),%r10d
    15c7:	4d 85 c9             	test   %r9,%r9
    15ca:	49 0f 44 f2          	cmove  %r10,%rsi
    15ce:	4c 8b 91 60 01 00 00 	mov    0x160(%rcx),%r10
    15d5:	4d 8b 1a             	mov    (%r10),%r11
    15d8:	49 8b 42 08          	mov    0x8(%r10),%rax
    15dc:	4c 39 c0             	cmp    %r8,%rax
    15df:	b9 00 00 00 00       	mov    $0x0,%ecx
    15e4:	0f 94 c1             	sete   %cl
    15e7:	4d 8b 42 20          	mov    0x20(%r10),%r8
    15eb:	48 89 85 20 fc ff ff 	mov    %rax,-0x3e0(%rbp)
    15f2:	49 8b 42 28          	mov    0x28(%r10),%rax
    15f6:	45 31 d2             	xor    %r10d,%r10d
    15f9:	48 89 bd 30 fc ff ff 	mov    %rdi,-0x3d0(%rbp)
    1600:	4c 39 d0             	cmp    %r10,%rax
    1603:	bf 00 00 00 00       	mov    $0x0,%edi
    1608:	40 0f 94 c7          	sete   %dil
    160c:	49 89 ca             	mov    %rcx,%r10
    160f:	49 21 fa             	and    %rdi,%r10
    1612:	4c 89 95 18 fc ff ff 	mov    %r10,-0x3e8(%rbp)
    1619:	49 83 fd 05          	cmp    $0x5,%r13
    161d:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    1623:	41 0f 94 c2          	sete   %r10b
    1627:	4c 89 95 10 fc ff ff 	mov    %r10,-0x3f0(%rbp)
    162e:	49 83 fd 02          	cmp    $0x2,%r13
    1632:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    1638:	41 0f 94 c2          	sete   %r10b
    163c:	4c 89 95 08 fc ff ff 	mov    %r10,-0x3f8(%rbp)
    1643:	4c 8b 95 10 fc ff ff 	mov    -0x3f0(%rbp),%r10
    164a:	48 89 85 00 fc ff ff 	mov    %rax,-0x400(%rbp)
    1651:	48 8b 85 08 fc ff ff 	mov    -0x3f8(%rbp),%rax
    1658:	49 09 c2             	or     %rax,%r10
    165b:	4d 85 d2             	test   %r10,%r10
    165e:	48 89 8d 10 fc ff ff 	mov    %rcx,-0x3f0(%rbp)
    1665:	48 89 95 08 fc ff ff 	mov    %rdx,-0x3f8(%rbp)
    166c:	48 89 b5 f8 fb ff ff 	mov    %rsi,-0x408(%rbp)
    1673:	48 89 bd f0 fb ff ff 	mov    %rdi,-0x410(%rbp)
    167a:	4c 89 85 e8 fb ff ff 	mov    %r8,-0x418(%rbp)
    1681:	4c 89 8d e0 fb ff ff 	mov    %r9,-0x420(%rbp)
    1688:	4c 89 9d d8 fb ff ff 	mov    %r11,-0x428(%rbp)
    168f:	0f 84 d3 17 00 00    	je     0x2e68
    1695:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
    169c:	82 28 52 
    169f:	45 31 d2             	xor    %r10d,%r10d
    16a2:	48 8b 8d 18 fc ff ff 	mov    -0x3e8(%rbp),%rcx
    16a9:	48 89 cf             	mov    %rcx,%rdi
    16ac:	4c 21 cf             	and    %r9,%rdi
    16af:	48 85 ff             	test   %rdi,%rdi
    16b2:	0f 85 5a 0a 00 00    	jne    0x2112
    16b8:	48 89 95 d0 fb ff ff 	mov    %rdx,-0x430(%rbp)
    16bf:	31 ff                	xor    %edi,%edi
    16c1:	48 89 bd c8 fb ff ff 	mov    %rdi,-0x438(%rbp)
    16c8:	31 ff                	xor    %edi,%edi
    16ca:	48 89 bd c0 fb ff ff 	mov    %rdi,-0x440(%rbp)
    16d1:	31 ff                	xor    %edi,%edi
    16d3:	48 89 bd b8 fb ff ff 	mov    %rdi,-0x448(%rbp)
    16da:	48 89 85 b0 fb ff ff 	mov    %rax,-0x450(%rbp)
    16e1:	31 ff                	xor    %edi,%edi
    16e3:	48 89 bd a8 fb ff ff 	mov    %rdi,-0x458(%rbp)
    16ea:	31 ff                	xor    %edi,%edi
    16ec:	48 89 bd a0 fb ff ff 	mov    %rdi,-0x460(%rbp)
    16f3:	4c 89 95 98 fb ff ff 	mov    %r10,-0x468(%rbp)
    16fa:	31 ff                	xor    %edi,%edi
    16fc:	48 89 bd 90 fb ff ff 	mov    %rdi,-0x470(%rbp)
    1703:	48 8b 85 d0 fb ff ff 	mov    -0x430(%rbp),%rax
    170a:	48 8b 8d f8 fb ff ff 	mov    -0x408(%rbp),%rcx
    1711:	48 39 c8             	cmp    %rcx,%rax
    1714:	0f 8c 75 00 00 00    	jl     0x178f
    171a:	48 8b 95 a8 fb ff ff 	mov    -0x458(%rbp),%rdx
    1721:	48 89 95 88 fb ff ff 	mov    %rdx,-0x478(%rbp)
    1728:	48 8b 95 c8 fb ff ff 	mov    -0x438(%rbp),%rdx
    172f:	48 89 95 80 fb ff ff 	mov    %rdx,-0x480(%rbp)
    1736:	48 8b 95 a0 fb ff ff 	mov    -0x460(%rbp),%rdx
    173d:	48 89 95 78 fb ff ff 	mov    %rdx,-0x488(%rbp)
    1744:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    174b:	48 89 95 70 fb ff ff 	mov    %rdx,-0x490(%rbp)
    1752:	48 8b 95 b8 fb ff ff 	mov    -0x448(%rbp),%rdx
    1759:	48 89 95 68 fb ff ff 	mov    %rdx,-0x498(%rbp)
    1760:	48 8b 95 b0 fb ff ff 	mov    -0x450(%rbp),%rdx
    1767:	48 89 95 60 fb ff ff 	mov    %rdx,-0x4a0(%rbp)
    176e:	48 8b 95 98 fb ff ff 	mov    -0x468(%rbp),%rdx
    1775:	48 89 95 58 fb ff ff 	mov    %rdx,-0x4a8(%rbp)
    177c:	48 8b 95 90 fb ff ff 	mov    -0x470(%rbp),%rdx
    1783:	48 89 95 50 fb ff ff 	mov    %rdx,-0x4b0(%rbp)
    178a:	e9 b8 12 00 00       	jmp    0x2a47
    178f:	48 8b 95 e0 fb ff ff 	mov    -0x420(%rbp),%rdx
    1796:	48 85 d2             	test   %rdx,%rdx
    1799:	0f 84 08 00 00 00    	je     0x17a7
    179f:	48 89 c6             	mov    %rax,%rsi
    17a2:	e9 11 00 00 00       	jmp    0x17b8
    17a7:	48 8b bd 30 fc ff ff 	mov    -0x3d0(%rbp),%rdi
    17ae:	4c 8d 04 87          	lea    (%rdi,%rax,4),%r8
    17b2:	45 8b 08             	mov    (%r8),%r9d
    17b5:	4c 89 ce             	mov    %r9,%rsi
    17b8:	48 8b 85 d8 fb ff ff 	mov    -0x428(%rbp),%rax
    17bf:	48 8d 0c b0          	lea    (%rax,%rsi,4),%rcx
    17c3:	48 89 f2             	mov    %rsi,%rdx
    17c6:	48 c1 ea 06          	shr    $0x6,%rdx
    17ca:	48 8b bd 20 fc ff ff 	mov    -0x3e0(%rbp),%rdi
    17d1:	4c 8d 04 d7          	lea    (%rdi,%rdx,8),%r8
    17d5:	48 8b 95 10 fc ff ff 	mov    -0x3f0(%rbp),%rdx
    17dc:	4c 8b 8d 98 fc ff ff 	mov    -0x368(%rbp),%r9
    17e3:	4d 89 ca             	mov    %r9,%r10
    17e6:	48 85 d2             	test   %rdx,%rdx
    17e9:	4d 0f 44 d0          	cmove  %r8,%r10
    17ed:	4d 8b 02             	mov    (%r10),%r8
    17f0:	49 89 f2             	mov    %rsi,%r10
    17f3:	49 83 e2 3f          	and    $0x3f,%r10
    17f7:	48 89 8d 48 fb ff ff 	mov    %rcx,-0x4b8(%rbp)
    17fe:	4c 89 d1             	mov    %r10,%rcx
    1801:	49 d3 e8             	shr    %cl,%r8
    1804:	b9 01 00 00 00       	mov    $0x1,%ecx
    1809:	49 21 c8             	and    %rcx,%r8
    180c:	45 31 d2             	xor    %r10d,%r10d
    180f:	4d 39 d0             	cmp    %r10,%r8
    1812:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1818:	41 0f 94 c0          	sete   %r8b
    181c:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    1822:	48 89 d7             	mov    %rdx,%rdi
    1825:	4c 31 df             	xor    %r11,%rdi
    1828:	49 21 f8             	and    %rdi,%r8
    182b:	48 8b bd e8 fb ff ff 	mov    -0x418(%rbp),%rdi
    1832:	4c 8d 1c b7          	lea    (%rdi,%rsi,4),%r11
    1836:	48 89 f2             	mov    %rsi,%rdx
    1839:	48 c1 ea 06          	shr    $0x6,%rdx
    183d:	48 8b 85 00 fc ff ff 	mov    -0x400(%rbp),%rax
    1844:	48 8d 3c d0          	lea    (%rax,%rdx,8),%rdi
    1848:	48 8b 95 f0 fb ff ff 	mov    -0x410(%rbp),%rdx
    184f:	4c 89 c8             	mov    %r9,%rax
    1852:	48 85 d2             	test   %rdx,%rdx
    1855:	48 0f 44 c7          	cmove  %rdi,%rax
    1859:	48 8b 38             	mov    (%rax),%rdi
    185c:	48 83 e6 3f          	and    $0x3f,%rsi
    1860:	48 89 f1             	mov    %rsi,%rcx
    1863:	48 d3 ef             	shr    %cl,%rdi
    1866:	b8 01 00 00 00       	mov    $0x1,%eax
    186b:	48 21 c7             	and    %rax,%rdi
    186e:	4c 39 d7             	cmp    %r10,%rdi
    1871:	bf 00 00 00 00       	mov    $0x0,%edi
    1876:	40 0f 94 c7          	sete   %dil
    187a:	b9 01 00 00 00       	mov    $0x1,%ecx
    187f:	48 89 d6             	mov    %rdx,%rsi
    1882:	48 31 ce             	xor    %rcx,%rsi
    1885:	48 21 f7             	and    %rsi,%rdi
    1888:	4d 85 c0             	test   %r8,%r8
    188b:	0f 85 63 08 00 00    	jne    0x20f4
    1891:	48 8b 8d 48 fb ff ff 	mov    -0x4b8(%rbp),%rcx
    1898:	48 63 31             	movslq (%rcx),%rsi
    189b:	48 8b 8d 50 fc ff ff 	mov    -0x3b0(%rbp),%rcx
    18a2:	48 85 c9             	test   %rcx,%rcx
    18a5:	48 89 b5 40 fb ff ff 	mov    %rsi,-0x4c0(%rbp)
    18ac:	48 89 bd 38 fb ff ff 	mov    %rdi,-0x4c8(%rbp)
    18b3:	4c 89 9d 30 fb ff ff 	mov    %r11,-0x4d0(%rbp)
    18ba:	0f 84 47 01 00 00    	je     0x1a07
    18c0:	48 be 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rsi
    18c7:	79 37 9e 
    18ca:	48 8b bd 40 fb ff ff 	mov    -0x4c0(%rbp),%rdi
    18d1:	49 89 fb             	mov    %rdi,%r11
    18d4:	49 c1 eb 2b          	shr    $0x2b,%r11
    18d8:	48 89 fa             	mov    %rdi,%rdx
    18db:	48 c1 ea 2c          	shr    $0x2c,%rdx
    18df:	49 31 d3             	xor    %rdx,%r11
    18e2:	48 89 fa             	mov    %rdi,%rdx
    18e5:	4c 31 da             	xor    %r11,%rdx
    18e8:	48 0f af d6          	imul   %rsi,%rdx
    18ec:	48 89 d6             	mov    %rdx,%rsi
    18ef:	48 c1 ee 1e          	shr    $0x1e,%rsi
    18f3:	49 89 d3             	mov    %rdx,%r11
    18f6:	49 31 f3             	xor    %rsi,%r11
    18f9:	48 be b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rsi
    1900:	47 58 bf 
    1903:	4c 0f af de          	imul   %rsi,%r11
    1907:	4c 89 de             	mov    %r11,%rsi
    190a:	48 c1 ee 1b          	shr    $0x1b,%rsi
    190e:	49 31 f3             	xor    %rsi,%r11
    1911:	48 be eb 11 31 13 bb 	movabs $0x94d049bb133111eb,%rsi
    1918:	49 d0 94 
    191b:	4c 0f af de          	imul   %rsi,%r11
    191f:	4c 89 de             	mov    %r11,%rsi
    1922:	48 c1 ee 1f          	shr    $0x1f,%rsi
    1926:	49 31 f3             	xor    %rsi,%r11
    1929:	be 40 00 00 00       	mov    $0x40,%esi
    192e:	48 29 ce             	sub    %rcx,%rsi
    1931:	48 89 f1             	mov    %rsi,%rcx
    1934:	49 d3 eb             	shr    %cl,%r11
    1937:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
    193b:	4c 89 d9             	mov    %r11,%rcx
    193e:	48 89 f7             	mov    %rsi,%rdi
    1941:	48 d3 ef             	shr    %cl,%rdi
    1944:	48 21 c7             	and    %rax,%rdi
    1947:	48 85 ff             	test   %rdi,%rdi
    194a:	0f 84 b7 00 00 00    	je     0x1a07
    1950:	48 8d 8d b0 fe ff ff 	lea    -0x150(%rbp),%rcx
    1957:	48 89 cf             	mov    %rcx,%rdi
    195a:	48 8b 8d 48 fb ff ff 	mov    -0x4b8(%rbp),%rcx
    1961:	48 63 31             	movslq (%rcx),%rsi
    1964:	31 c9                	xor    %ecx,%ecx
    1966:	48 89 0f             	mov    %rcx,(%rdi)
    1969:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    196d:	4c 89 47 10          	mov    %r8,0x10(%rdi)
    1971:	48 8b 8d 30 fb ff ff 	mov    -0x4d0(%rbp),%rcx
    1978:	48 63 31             	movslq (%rcx),%rsi
    197b:	45 31 c0             	xor    %r8d,%r8d
    197e:	4c 89 47 18          	mov    %r8,0x18(%rdi)
    1982:	48 89 77 20          	mov    %rsi,0x20(%rdi)
    1986:	48 8b b5 38 fb ff ff 	mov    -0x4c8(%rbp),%rsi
    198d:	48 89 77 28          	mov    %rsi,0x28(%rdi)
    1991:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    1997:	48 8b b5 50 fc ff ff 	mov    -0x3b0(%rbp),%rsi
    199e:	48 89 f1             	mov    %rsi,%rcx
    19a1:	49 d3 e0             	shl    %cl,%r8
    19a4:	4d 01 d8             	add    %r11,%r8
    19a7:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    19ac:	41 bb 02 00 00 00    	mov    $0x2,%r11d
    19b2:	48 89 bd 48 fb ff ff 	mov    %rdi,-0x4b8(%rbp)
    19b9:	4c 89 cf             	mov    %r9,%rdi
    19bc:	48 89 ce             	mov    %rcx,%rsi
    19bf:	48 89 95 28 fb ff ff 	mov    %rdx,-0x4d8(%rbp)
    19c6:	48 8b 95 50 fc ff ff 	mov    -0x3b0(%rbp),%rdx
    19cd:	4c 89 c1             	mov    %r8,%rcx
    19d0:	4c 8b 85 28 fb ff ff 	mov    -0x4d8(%rbp),%r8
    19d7:	4c 8b 8d 48 fb ff ff 	mov    -0x4b8(%rbp),%r9
    19de:	4c 89 1c 24          	mov    %r11,(%rsp)
    19e2:	e8 e9 e6 ff ff       	call   0xd0
    19e7:	48 83 f8 00          	cmp    $0x0,%rax
    19eb:	0f 8d 11 00 00 00    	jge    0x1a02
    19f1:	b8 80 00 00 00       	mov    $0x80,%eax
    19f6:	48 89 85 48 fb ff ff 	mov    %rax,-0x4b8(%rbp)
    19fd:	e9 04 57 00 00       	jmp    0x7106
    1a02:	e9 ed 06 00 00       	jmp    0x20f4
    1a07:	49 83 fd 05          	cmp    $0x5,%r13
    1a0b:	0f 85 a7 00 00 00    	jne    0x1ab8
    1a11:	48 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%rax
    1a18:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    1a1f:	48 89 c2             	mov    %rax,%rdx
    1a22:	48 29 ca             	sub    %rcx,%rdx
    1a25:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    1a2c:	48 39 f2             	cmp    %rsi,%rdx
    1a2f:	bf 00 00 00 00       	mov    $0x0,%edi
    1a34:	40 0f 92 c7          	setb   %dil
    1a38:	45 31 c0             	xor    %r8d,%r8d
    1a3b:	48 85 ff             	test   %rdi,%rdi
    1a3e:	49 0f 44 d0          	cmove  %r8,%rdx
    1a42:	49 89 d1             	mov    %rdx,%r9
    1a45:	49 c1 e9 06          	shr    $0x6,%r9
    1a49:	48 83 e2 3f          	and    $0x3f,%rdx
    1a4d:	4c 8b 95 70 fc ff ff 	mov    -0x390(%rbp),%r10
    1a54:	4f 8d 1c ca          	lea    (%r10,%r9,8),%r11
    1a58:	49 8b 03             	mov    (%r11),%rax
    1a5b:	48 89 d1             	mov    %rdx,%rcx
    1a5e:	48 d3 e8             	shr    %cl,%rax
    1a61:	b9 01 00 00 00       	mov    $0x1,%ecx
    1a66:	48 21 c8             	and    %rcx,%rax
    1a69:	49 89 c3             	mov    %rax,%r11
    1a6c:	49 21 fb             	and    %rdi,%r11
    1a6f:	48 8b 85 48 fc ff ff 	mov    -0x3b8(%rbp),%rax
    1a76:	4a 8d 3c c8          	lea    (%rax,%r9,8),%rdi
    1a7a:	48 8b 07             	mov    (%rdi),%rax
    1a7d:	48 89 d1             	mov    %rdx,%rcx
    1a80:	48 d3 e8             	shr    %cl,%rax
    1a83:	b9 01 00 00 00       	mov    $0x1,%ecx
    1a88:	48 89 c7             	mov    %rax,%rdi
    1a8b:	48 21 cf             	and    %rcx,%rdi
    1a8e:	48 8b 85 58 fc ff ff 	mov    -0x3a8(%rbp),%rax
    1a95:	4a 8d 34 c8          	lea    (%rax,%r9,8),%rsi
    1a99:	4c 8b 0e             	mov    (%rsi),%r9
    1a9c:	48 89 d1             	mov    %rdx,%rcx
    1a9f:	49 d3 e9             	shr    %cl,%r9
    1aa2:	b9 01 00 00 00       	mov    $0x1,%ecx
    1aa7:	4c 89 ce             	mov    %r9,%rsi
    1aaa:	48 21 ce             	and    %rcx,%rsi
    1aad:	49 89 f9             	mov    %rdi,%r9
    1ab0:	48 89 f7             	mov    %rsi,%rdi
    1ab3:	e9 96 00 00 00       	jmp    0x1b4e
    1ab8:	48 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%rax
    1abf:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    1ac6:	48 29 c8             	sub    %rcx,%rax
    1ac9:	48 8b 95 60 fc ff ff 	mov    -0x3a0(%rbp),%rdx
    1ad0:	48 39 d0             	cmp    %rdx,%rax
    1ad3:	be 00 00 00 00       	mov    $0x0,%esi
    1ad8:	40 0f 92 c6          	setb   %sil
    1adc:	45 31 c0             	xor    %r8d,%r8d
    1adf:	48 85 f6             	test   %rsi,%rsi
    1ae2:	49 0f 44 c0          	cmove  %r8,%rax
    1ae6:	49 89 c2             	mov    %rax,%r10
    1ae9:	49 c1 ea 06          	shr    $0x6,%r10
    1aed:	48 89 c1             	mov    %rax,%rcx
    1af0:	48 83 e1 3f          	and    $0x3f,%rcx
    1af4:	48 8b 95 70 fc ff ff 	mov    -0x390(%rbp),%rdx
    1afb:	4e 8d 04 d2          	lea    (%rdx,%r10,8),%r8
    1aff:	4d 8b 10             	mov    (%r8),%r10
    1b02:	48 89 8d 40 fb ff ff 	mov    %rcx,-0x4c0(%rbp)
    1b09:	4c 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%r8
    1b10:	4c 89 c1             	mov    %r8,%rcx
    1b13:	49 d3 ea             	shr    %cl,%r10
    1b16:	b9 01 00 00 00       	mov    $0x1,%ecx
    1b1b:	49 21 ca             	and    %rcx,%r10
    1b1e:	49 21 f2             	and    %rsi,%r10
    1b21:	be 10 00 00 00       	mov    $0x10,%esi
    1b26:	48 0f af c6          	imul   %rsi,%rax
    1b2a:	48 8b b5 80 fc ff ff 	mov    -0x380(%rbp),%rsi
    1b31:	4c 8d 44 06 f8       	lea    -0x8(%rsi,%rax,1),%r8
    1b36:	49 8b 40 08          	mov    0x8(%r8),%rax
    1b3a:	49 8b 70 10          	mov    0x10(%r8),%rsi
    1b3e:	48 c1 e8 20          	shr    $0x20,%rax
    1b42:	48 21 c8             	and    %rcx,%rax
    1b45:	4d 89 d3             	mov    %r10,%r11
    1b48:	49 89 f1             	mov    %rsi,%r9
    1b4b:	48 89 c7             	mov    %rax,%rdi
    1b4e:	4d 85 db             	test   %r11,%r11
    1b51:	0f 84 9d 05 00 00    	je     0x20f4
    1b57:	48 83 ff 00          	cmp    $0x0,%rdi
    1b5b:	bf 00 00 00 00       	mov    $0x0,%edi
    1b60:	40 0f 95 c7          	setne  %dil
    1b64:	48 8b 85 c8 fb ff ff 	mov    -0x438(%rbp),%rax
    1b6b:	48 89 c1             	mov    %rax,%rcx
    1b6e:	48 83 c1 01          	add    $0x1,%rcx
    1b72:	4d 63 c9             	movslq %r9d,%r9
    1b75:	31 d2                	xor    %edx,%edx
    1b77:	48 85 ff             	test   %rdi,%rdi
    1b7a:	49 0f 44 d1          	cmove  %r9,%rdx
    1b7e:	48 8b b5 c0 fb ff ff 	mov    -0x440(%rbp),%rsi
    1b85:	48 39 d6             	cmp    %rdx,%rsi
    1b88:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1b8e:	41 0f 94 c0          	sete   %r8b
    1b92:	4c 8b 8d b8 fb ff ff 	mov    -0x448(%rbp),%r9
    1b99:	49 39 f9             	cmp    %rdi,%r9
    1b9c:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    1ba2:	41 0f 94 c2          	sete   %r10b
    1ba6:	4d 21 d0             	and    %r10,%r8
    1ba9:	4d 85 c0             	test   %r8,%r8
    1bac:	48 89 8d 40 fb ff ff 	mov    %rcx,-0x4c0(%rbp)
    1bb3:	48 89 95 28 fb ff ff 	mov    %rdx,-0x4d8(%rbp)
    1bba:	48 89 bd 20 fb ff ff 	mov    %rdi,-0x4e0(%rbp)
    1bc1:	0f 84 69 00 00 00    	je     0x1c30
    1bc7:	4c 8b 85 a0 fb ff ff 	mov    -0x460(%rbp),%r8
    1bce:	4d 89 c2             	mov    %r8,%r10
    1bd1:	49 83 c2 01          	add    $0x1,%r10
    1bd5:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    1bdb:	48 8b 95 30 fb ff ff 	mov    -0x4d0(%rbp),%rdx
    1be2:	48 63 3a             	movslq (%rdx),%rdi
    1be5:	48 8b 95 38 fb ff ff 	mov    -0x4c8(%rbp),%rdx
    1bec:	48 89 d1             	mov    %rdx,%rcx
    1bef:	4c 31 d9             	xor    %r11,%rcx
    1bf2:	45 31 db             	xor    %r11d,%r11d
    1bf5:	48 85 c9             	test   %rcx,%rcx
    1bf8:	49 0f 44 fb          	cmove  %r11,%rdi
    1bfc:	4c 8b 9d 90 fb ff ff 	mov    -0x470(%rbp),%r11
    1c03:	4c 89 da             	mov    %r11,%rdx
    1c06:	48 01 ca             	add    %rcx,%rdx
    1c09:	48 8b 8d 98 fb ff ff 	mov    -0x468(%rbp),%rcx
    1c10:	48 89 c8             	mov    %rcx,%rax
    1c13:	48 01 f8             	add    %rdi,%rax
    1c16:	4c 89 95 a0 fb ff ff 	mov    %r10,-0x460(%rbp)
    1c1d:	48 89 85 98 fb ff ff 	mov    %rax,-0x468(%rbp)
    1c24:	48 89 95 90 fb ff ff 	mov    %rdx,-0x470(%rbp)
    1c2b:	e9 aa 04 00 00       	jmp    0x20da
    1c30:	48 8b 85 a8 fb ff ff 	mov    -0x458(%rbp),%rax
    1c37:	48 85 c0             	test   %rax,%rax
    1c3a:	0f 84 01 04 00 00    	je     0x2041
    1c40:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    1c47:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    1c4b:	48 85 d2             	test   %rdx,%rdx
    1c4e:	0f 84 40 01 00 00    	je     0x1d94
    1c54:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    1c58:	be 40 00 00 00       	mov    $0x40,%esi
    1c5d:	48 29 d6             	sub    %rdx,%rsi
    1c60:	48 8b bd b0 fb ff ff 	mov    -0x450(%rbp),%rdi
    1c67:	48 89 f1             	mov    %rsi,%rcx
    1c6a:	49 89 f8             	mov    %rdi,%r8
    1c6d:	49 d3 e8             	shr    %cl,%r8
    1c70:	31 c9                	xor    %ecx,%ecx
    1c72:	48 39 ca             	cmp    %rcx,%rdx
    1c75:	ba 00 00 00 00       	mov    $0x0,%edx
    1c7a:	0f 94 c2             	sete   %dl
    1c7d:	48 85 d2             	test   %rdx,%rdx
    1c80:	49 0f 44 c8          	cmove  %r8,%rcx
    1c84:	48 8b 95 90 fc ff ff 	mov    -0x370(%rbp),%rdx
    1c8b:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    1c8f:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    1c93:	49 8b 30             	mov    (%r8),%rsi
    1c96:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    1c9d:	00 28 00 
    1ca0:	4c 39 ce             	cmp    %r9,%rsi
    1ca3:	4c 89 85 18 fb ff ff 	mov    %r8,-0x4e8(%rbp)
    1caa:	0f 82 0c 00 00 00    	jb     0x1cbc
    1cb0:	48 89 b5 10 fb ff ff 	mov    %rsi,-0x4f0(%rbp)
    1cb7:	e9 4a 00 00 00       	jmp    0x1d06
    1cbc:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    1cc0:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    1cc7:	48 89 b5 08 fb ff ff 	mov    %rsi,-0x4f8(%rbp)
    1cce:	48 89 d6             	mov    %rdx,%rsi
    1cd1:	48 89 ca             	mov    %rcx,%rdx
    1cd4:	48 8b 8d 08 fb ff ff 	mov    -0x4f8(%rbp),%rcx
    1cdb:	e8 00 e4 ff ff       	call   0xe0
    1ce0:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    1ce7:	31 d2                	xor    %edx,%edx
    1ce9:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    1ced:	48 83 f8 00          	cmp    $0x0,%rax
    1cf1:	0f 8f 08 00 00 00    	jg     0x1cff
    1cf7:	49 89 c4             	mov    %rax,%r12
    1cfa:	e9 28 54 00 00       	jmp    0x7127
    1cff:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    1d06:	48 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%rax
    1d0d:	48 89 c1             	mov    %rax,%rcx
    1d10:	48 83 c1 28          	add    $0x28,%rcx
    1d14:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    1d1b:	00 28 00 
    1d1e:	48 29 d1             	sub    %rdx,%rcx
    1d21:	48 8b 95 18 fb ff ff 	mov    -0x4e8(%rbp),%rdx
    1d28:	48 89 0a             	mov    %rcx,(%rdx)
    1d2b:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    1d32:	ff 00 00 
    1d35:	48 21 c8             	and    %rcx,%rax
    1d38:	31 c9                	xor    %ecx,%ecx
    1d3a:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    1d41:	48 89 10             	mov    %rdx,(%rax)
    1d44:	48 8b b5 b8 fb ff ff 	mov    -0x448(%rbp),%rsi
    1d4b:	48 89 70 08          	mov    %rsi,0x8(%rax)
    1d4f:	48 89 48 10          	mov    %rcx,0x10(%rax)
    1d53:	48 89 48 18          	mov    %rcx,0x18(%rax)
    1d57:	48 89 48 20          	mov    %rcx,0x20(%rax)
    1d5b:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    1d62:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    1d66:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    1d6c:	4c 01 c7             	add    %r8,%rdi
    1d6f:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    1d73:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    1d7a:	b8 01 00 00 00       	mov    $0x1,%eax
    1d7f:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    1d86:	31 c0                	xor    %eax,%eax
    1d88:	48 89 85 08 fb ff ff 	mov    %rax,-0x4f8(%rbp)
    1d8f:	e9 a7 01 00 00       	jmp    0x1f3b
    1d94:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    1d9b:	48 8b 70 10          	mov    0x10(%rax),%rsi
    1d9f:	48 8b 48 18          	mov    0x18(%rax),%rcx
    1da3:	48 89 ca             	mov    %rcx,%rdx
    1da6:	f3 48 0f b8 d2       	popcnt %rdx,%rdx
    1dab:	bf 40 00 00 00       	mov    $0x40,%edi
    1db0:	48 29 d7             	sub    %rdx,%rdi
    1db3:	48 89 8d 00 fb ff ff 	mov    %rcx,-0x500(%rbp)
    1dba:	4c 8b 85 b0 fb ff ff 	mov    -0x450(%rbp),%r8
    1dc1:	48 89 f9             	mov    %rdi,%rcx
    1dc4:	4d 89 c1             	mov    %r8,%r9
    1dc7:	49 d3 e9             	shr    %cl,%r9
    1dca:	31 c9                	xor    %ecx,%ecx
    1dcc:	48 39 ca             	cmp    %rcx,%rdx
    1dcf:	ba 00 00 00 00       	mov    $0x0,%edx
    1dd4:	0f 94 c2             	sete   %dl
    1dd7:	48 85 d2             	test   %rdx,%rdx
    1dda:	49 0f 44 c9          	cmove  %r9,%rcx
    1dde:	ba 01 00 00 00       	mov    $0x1,%edx
    1de3:	48 89 cf             	mov    %rcx,%rdi
    1de6:	48 01 d7             	add    %rdx,%rdi
    1de9:	4c 8b 95 00 fb ff ff 	mov    -0x500(%rbp),%r10
    1df0:	49 89 f9             	mov    %rdi,%r9
    1df3:	4d 21 d1             	and    %r10,%r9
    1df6:	bf 28 00 00 00       	mov    $0x28,%edi
    1dfb:	48 0f af cf          	imul   %rdi,%rcx
    1dff:	48 8d 3c 0e          	lea    (%rsi,%rcx,1),%rdi
    1e03:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    1e07:	48 85 c9             	test   %rcx,%rcx
    1e0a:	0f 84 b2 00 00 00    	je     0x1ec2
    1e10:	48 8b 0f             	mov    (%rdi),%rcx
    1e13:	4c 8b 57 08          	mov    0x8(%rdi),%r10
    1e17:	4c 8b 9d c0 fb ff ff 	mov    -0x440(%rbp),%r11
    1e1e:	49 39 cb             	cmp    %rcx,%r11
    1e21:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1e27:	41 0f 94 c0          	sete   %r8b
    1e2b:	48 8b 8d b8 fb ff ff 	mov    -0x448(%rbp),%rcx
    1e32:	4c 39 d1             	cmp    %r10,%rcx
    1e35:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    1e3b:	41 0f 94 c3          	sete   %r11b
    1e3f:	4d 21 d8             	and    %r11,%r8
    1e42:	4d 85 c0             	test   %r8,%r8
    1e45:	0f 84 0c 00 00 00    	je     0x1e57
    1e4b:	48 89 bd 10 fb ff ff 	mov    %rdi,-0x4f0(%rbp)
    1e52:	e9 54 00 00 00       	jmp    0x1eab
    1e57:	bf 28 00 00 00       	mov    $0x28,%edi
    1e5c:	4c 0f af cf          	imul   %rdi,%r9
    1e60:	4a 8d 3c 0e          	lea    (%rsi,%r9,1),%rdi
    1e64:	48 8b 77 10          	mov    0x10(%rdi),%rsi
    1e68:	48 85 f6             	test   %rsi,%rsi
    1e6b:	0f 84 51 00 00 00    	je     0x1ec2
    1e71:	48 8b 37             	mov    (%rdi),%rsi
    1e74:	4c 8b 47 08          	mov    0x8(%rdi),%r8
    1e78:	4c 8b 8d c0 fb ff ff 	mov    -0x440(%rbp),%r9
    1e7f:	49 39 f1             	cmp    %rsi,%r9
    1e82:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    1e88:	41 0f 94 c2          	sete   %r10b
    1e8c:	4c 39 c1             	cmp    %r8,%rcx
    1e8f:	be 00 00 00 00       	mov    $0x0,%esi
    1e94:	40 0f 94 c6          	sete   %sil
    1e98:	49 21 f2             	and    %rsi,%r10
    1e9b:	4d 85 d2             	test   %r10,%r10
    1e9e:	0f 84 1e 00 00 00    	je     0x1ec2
    1ea4:	48 89 bd 10 fb ff ff 	mov    %rdi,-0x4f0(%rbp)
    1eab:	31 c0                	xor    %eax,%eax
    1ead:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    1eb4:	31 c0                	xor    %eax,%eax
    1eb6:	48 89 85 08 fb ff ff 	mov    %rax,-0x4f8(%rbp)
    1ebd:	e9 79 00 00 00       	jmp    0x1f3b
    1ec2:	48 8d 85 90 fe ff ff 	lea    -0x170(%rbp),%rax
    1ec9:	48 89 c1             	mov    %rax,%rcx
    1ecc:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    1ed3:	48 89 11             	mov    %rdx,(%rcx)
    1ed6:	48 8b b5 b8 fb ff ff 	mov    -0x448(%rbp),%rsi
    1edd:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    1ee1:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    1ee8:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    1eef:	48 89 ca             	mov    %rcx,%rdx
    1ef2:	e8 f9 e1 ff ff       	call   0xf0
    1ef7:	48 83 f8 00          	cmp    $0x0,%rax
    1efb:	0f 8d 08 00 00 00    	jge    0x1f09
    1f01:	49 89 c4             	mov    %rax,%r12
    1f04:	e9 1e 52 00 00       	jmp    0x7127
    1f09:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    1f10:	48 8b 11             	mov    (%rcx),%rdx
    1f13:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    1f17:	48 83 e6 01          	and    $0x1,%rsi
    1f1b:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    1f1f:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    1f26:	b8 01 00 00 00       	mov    $0x1,%eax
    1f2b:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    1f32:	31 c0                	xor    %eax,%eax
    1f34:	48 89 85 08 fb ff ff 	mov    %rax,-0x4f8(%rbp)
    1f3b:	48 8b 85 18 fb ff ff 	mov    -0x4e8(%rbp),%rax
    1f42:	48 85 c0             	test   %rax,%rax
    1f45:	0f 84 68 00 00 00    	je     0x1fb3
    1f4b:	48 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%rax
    1f52:	48 8b 8d a0 fb ff ff 	mov    -0x460(%rbp),%rcx
    1f59:	48 89 48 10          	mov    %rcx,0x10(%rax)
    1f5d:	31 d2                	xor    %edx,%edx
    1f5f:	48 39 d1             	cmp    %rdx,%rcx
    1f62:	be 00 00 00 00       	mov    $0x0,%esi
    1f67:	40 0f 95 c6          	setne  %sil
    1f6b:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    1f6f:	48 09 f7             	or     %rsi,%rdi
    1f72:	40 88 78 20          	mov    %dil,0x20(%rax)
    1f76:	48 8b b5 98 fb ff ff 	mov    -0x468(%rbp),%rsi
    1f7d:	48 89 70 18          	mov    %rsi,0x18(%rax)
    1f81:	48 8b bd 90 fb ff ff 	mov    -0x470(%rbp),%rdi
    1f88:	48 39 d7             	cmp    %rdx,%rdi
    1f8b:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1f91:	41 0f 95 c0          	setne  %r8b
    1f95:	44 0f b6 48 20       	movzbl 0x20(%rax),%r9d
    1f9a:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    1fa0:	4d 85 c0             	test   %r8,%r8
    1fa3:	4c 0f 44 d2          	cmove  %rdx,%r10
    1fa7:	4d 09 d1             	or     %r10,%r9
    1faa:	44 88 48 20          	mov    %r9b,0x20(%rax)
    1fae:	e9 8e 00 00 00       	jmp    0x2041
    1fb3:	48 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%rax
    1fba:	48 8b 48 10          	mov    0x10(%rax),%rcx
    1fbe:	48 8b 95 a0 fb ff ff 	mov    -0x460(%rbp),%rdx
    1fc5:	48 01 d1             	add    %rdx,%rcx
    1fc8:	48 89 48 10          	mov    %rcx,0x10(%rax)
    1fcc:	31 f6                	xor    %esi,%esi
    1fce:	48 39 f1             	cmp    %rsi,%rcx
    1fd1:	b9 00 00 00 00       	mov    $0x0,%ecx
    1fd6:	0f 95 c1             	setne  %cl
    1fd9:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    1fdd:	48 09 cf             	or     %rcx,%rdi
    1fe0:	40 88 78 20          	mov    %dil,0x20(%rax)
    1fe4:	48 8b 48 18          	mov    0x18(%rax),%rcx
    1fe8:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    1fec:	48 83 e7 02          	and    $0x2,%rdi
    1ff0:	48 39 f7             	cmp    %rsi,%rdi
    1ff3:	bf 00 00 00 00       	mov    $0x0,%edi
    1ff8:	40 0f 95 c7          	setne  %dil
    1ffc:	45 31 c0             	xor    %r8d,%r8d
    1fff:	48 85 ff             	test   %rdi,%rdi
    2002:	49 0f 44 c8          	cmove  %r8,%rcx
    2006:	4c 8b 85 90 fb ff ff 	mov    -0x470(%rbp),%r8
    200d:	4c 01 c7             	add    %r8,%rdi
    2010:	4c 8b 8d 98 fb ff ff 	mov    -0x468(%rbp),%r9
    2017:	4c 01 c9             	add    %r9,%rcx
    201a:	48 89 48 18          	mov    %rcx,0x18(%rax)
    201e:	48 39 f7             	cmp    %rsi,%rdi
    2021:	bf 00 00 00 00       	mov    $0x0,%edi
    2026:	40 0f 95 c7          	setne  %dil
    202a:	0f b6 48 20          	movzbl 0x20(%rax),%ecx
    202e:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    2034:	48 85 ff             	test   %rdi,%rdi
    2037:	4c 0f 44 d6          	cmove  %rsi,%r10
    203b:	4c 09 d1             	or     %r10,%rcx
    203e:	88 48 20             	mov    %cl,0x20(%rax)
    2041:	b8 01 00 00 00       	mov    $0x1,%eax
    2046:	48 8b 8d 30 fb ff ff 	mov    -0x4d0(%rbp),%rcx
    204d:	48 63 11             	movslq (%rcx),%rdx
    2050:	48 8b 8d 38 fb ff ff 	mov    -0x4c8(%rbp),%rcx
    2057:	48 31 c1             	xor    %rax,%rcx
    205a:	31 c0                	xor    %eax,%eax
    205c:	48 85 c9             	test   %rcx,%rcx
    205f:	48 0f 44 d0          	cmove  %rax,%rdx
    2063:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    206a:	79 37 9e 
    206d:	48 be 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%rsi
    2074:	79 37 9e 
    2077:	48 8b bd 28 fb ff ff 	mov    -0x4d8(%rbp),%rdi
    207e:	48 31 fe             	xor    %rdi,%rsi
    2081:	48 0f af f0          	imul   %rax,%rsi
    2085:	49 89 f0             	mov    %rsi,%r8
    2088:	49 c1 e8 1d          	shr    $0x1d,%r8
    208c:	4c 31 c6             	xor    %r8,%rsi
    208f:	4c 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%r8
    2096:	4c 31 c6             	xor    %r8,%rsi
    2099:	48 0f af f0          	imul   %rax,%rsi
    209d:	49 89 f1             	mov    %rsi,%r9
    20a0:	49 c1 e9 1d          	shr    $0x1d,%r9
    20a4:	4c 31 ce             	xor    %r9,%rsi
    20a7:	48 0f af f0          	imul   %rax,%rsi
    20ab:	48 89 bd c0 fb ff ff 	mov    %rdi,-0x440(%rbp)
    20b2:	4c 89 85 b8 fb ff ff 	mov    %r8,-0x448(%rbp)
    20b9:	48 89 b5 b0 fb ff ff 	mov    %rsi,-0x450(%rbp)
    20c0:	b8 01 00 00 00       	mov    $0x1,%eax
    20c5:	48 89 85 a0 fb ff ff 	mov    %rax,-0x460(%rbp)
    20cc:	48 89 95 98 fb ff ff 	mov    %rdx,-0x468(%rbp)
    20d3:	48 89 8d 90 fb ff ff 	mov    %rcx,-0x470(%rbp)
    20da:	48 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%rax
    20e1:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    20e8:	b8 01 00 00 00       	mov    $0x1,%eax
    20ed:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
    20f4:	48 8b 85 d0 fb ff ff 	mov    -0x430(%rbp),%rax
    20fb:	b9 01 00 00 00       	mov    $0x1,%ecx
    2100:	48 89 c2             	mov    %rax,%rdx
    2103:	48 01 ca             	add    %rcx,%rdx
    2106:	48 89 95 d0 fb ff ff 	mov    %rdx,-0x430(%rbp)
    210d:	e9 f1 f5 ff ff       	jmp    0x1703
    2112:	48 8b 85 08 fc ff ff 	mov    -0x3f8(%rbp),%rax
    2119:	48 89 85 d0 fb ff ff 	mov    %rax,-0x430(%rbp)
    2120:	31 c0                	xor    %eax,%eax
    2122:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    2129:	31 c0                	xor    %eax,%eax
    212b:	48 89 85 c0 fb ff ff 	mov    %rax,-0x440(%rbp)
    2132:	31 c0                	xor    %eax,%eax
    2134:	48 89 85 b8 fb ff ff 	mov    %rax,-0x448(%rbp)
    213b:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
    2142:	82 28 52 
    2145:	48 89 85 b0 fb ff ff 	mov    %rax,-0x450(%rbp)
    214c:	31 c0                	xor    %eax,%eax
    214e:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
    2155:	31 c0                	xor    %eax,%eax
    2157:	48 89 85 a0 fb ff ff 	mov    %rax,-0x460(%rbp)
    215e:	31 c0                	xor    %eax,%eax
    2160:	48 89 85 98 fb ff ff 	mov    %rax,-0x468(%rbp)
    2167:	31 c0                	xor    %eax,%eax
    2169:	48 89 85 90 fb ff ff 	mov    %rax,-0x470(%rbp)
    2170:	48 8b 85 d0 fb ff ff 	mov    -0x430(%rbp),%rax
    2177:	48 8b 8d f8 fb ff ff 	mov    -0x408(%rbp),%rcx
    217e:	48 39 c8             	cmp    %rcx,%rax
    2181:	0f 8c 75 00 00 00    	jl     0x21fc
    2187:	48 8b 95 c8 fb ff ff 	mov    -0x438(%rbp),%rdx
    218e:	48 89 95 80 fb ff ff 	mov    %rdx,-0x480(%rbp)
    2195:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    219c:	48 89 95 70 fb ff ff 	mov    %rdx,-0x490(%rbp)
    21a3:	48 8b 95 b8 fb ff ff 	mov    -0x448(%rbp),%rdx
    21aa:	48 89 95 68 fb ff ff 	mov    %rdx,-0x498(%rbp)
    21b1:	48 8b 95 b0 fb ff ff 	mov    -0x450(%rbp),%rdx
    21b8:	48 89 95 60 fb ff ff 	mov    %rdx,-0x4a0(%rbp)
    21bf:	48 8b 95 a8 fb ff ff 	mov    -0x458(%rbp),%rdx
    21c6:	48 89 95 88 fb ff ff 	mov    %rdx,-0x478(%rbp)
    21cd:	48 8b 95 a0 fb ff ff 	mov    -0x460(%rbp),%rdx
    21d4:	48 89 95 78 fb ff ff 	mov    %rdx,-0x488(%rbp)
    21db:	48 8b 95 98 fb ff ff 	mov    -0x468(%rbp),%rdx
    21e2:	48 89 95 58 fb ff ff 	mov    %rdx,-0x4a8(%rbp)
    21e9:	48 8b 95 90 fb ff ff 	mov    -0x470(%rbp),%rdx
    21f0:	48 89 95 50 fb ff ff 	mov    %rdx,-0x4b0(%rbp)
    21f7:	e9 4b 08 00 00       	jmp    0x2a47
    21fc:	48 8b 95 d8 fb ff ff 	mov    -0x428(%rbp),%rdx
    2203:	48 8d 34 82          	lea    (%rdx,%rax,4),%rsi
    2207:	48 8b bd e8 fb ff ff 	mov    -0x418(%rbp),%rdi
    220e:	4c 8d 04 87          	lea    (%rdi,%rax,4),%r8
    2212:	4c 63 0e             	movslq (%rsi),%r9
    2215:	4c 8b 95 50 fc ff ff 	mov    -0x3b0(%rbp),%r10
    221c:	4d 85 d2             	test   %r10,%r10
    221f:	4c 89 85 40 fb ff ff 	mov    %r8,-0x4c0(%rbp)
    2226:	4c 89 8d 20 fb ff ff 	mov    %r9,-0x4e0(%rbp)
    222d:	0f 84 38 01 00 00    	je     0x236b
    2233:	49 bb 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%r11
    223a:	79 37 9e 
    223d:	4d 89 c8             	mov    %r9,%r8
    2240:	49 c1 e8 2b          	shr    $0x2b,%r8
    2244:	4c 89 c8             	mov    %r9,%rax
    2247:	48 c1 e8 2c          	shr    $0x2c,%rax
    224b:	49 31 c0             	xor    %rax,%r8
    224e:	4c 89 c8             	mov    %r9,%rax
    2251:	4c 31 c0             	xor    %r8,%rax
    2254:	49 0f af c3          	imul   %r11,%rax
    2258:	49 89 c0             	mov    %rax,%r8
    225b:	49 c1 e8 1e          	shr    $0x1e,%r8
    225f:	49 89 c3             	mov    %rax,%r11
    2262:	4d 31 c3             	xor    %r8,%r11
    2265:	49 b8 b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%r8
    226c:	47 58 bf 
    226f:	4d 0f af d8          	imul   %r8,%r11
    2273:	4d 89 d8             	mov    %r11,%r8
    2276:	49 c1 e8 1b          	shr    $0x1b,%r8
    227a:	4d 31 c3             	xor    %r8,%r11
    227d:	49 b8 eb 11 31 13 bb 	movabs $0x94d049bb133111eb,%r8
    2284:	49 d0 94 
    2287:	4d 0f af d8          	imul   %r8,%r11
    228b:	4d 89 d8             	mov    %r11,%r8
    228e:	49 c1 e8 1f          	shr    $0x1f,%r8
    2292:	4d 31 c3             	xor    %r8,%r11
    2295:	41 b8 40 00 00 00    	mov    $0x40,%r8d
    229b:	4d 29 d0             	sub    %r10,%r8
    229e:	4c 89 c1             	mov    %r8,%rcx
    22a1:	49 d3 eb             	shr    %cl,%r11
    22a4:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
    22a8:	4c 89 d9             	mov    %r11,%rcx
    22ab:	4d 89 c1             	mov    %r8,%r9
    22ae:	49 d3 e9             	shr    %cl,%r9
    22b1:	b9 01 00 00 00       	mov    $0x1,%ecx
    22b6:	49 21 c9             	and    %rcx,%r9
    22b9:	4d 85 c9             	test   %r9,%r9
    22bc:	0f 84 a9 00 00 00    	je     0x236b
    22c2:	4c 8d 8d 00 ff ff ff 	lea    -0x100(%rbp),%r9
    22c9:	4c 89 ca             	mov    %r9,%rdx
    22cc:	4c 63 0e             	movslq (%rsi),%r9
    22cf:	31 f6                	xor    %esi,%esi
    22d1:	31 ff                	xor    %edi,%edi
    22d3:	48 89 32             	mov    %rsi,(%rdx)
    22d6:	4c 89 4a 08          	mov    %r9,0x8(%rdx)
    22da:	48 89 7a 10          	mov    %rdi,0x10(%rdx)
    22de:	48 8b b5 40 fb ff ff 	mov    -0x4c0(%rbp),%rsi
    22e5:	48 63 3e             	movslq (%rsi),%rdi
    22e8:	45 31 c9             	xor    %r9d,%r9d
    22eb:	31 f6                	xor    %esi,%esi
    22ed:	4c 89 4a 18          	mov    %r9,0x18(%rdx)
    22f1:	48 89 7a 20          	mov    %rdi,0x20(%rdx)
    22f5:	48 89 72 28          	mov    %rsi,0x28(%rdx)
    22f9:	be 01 00 00 00       	mov    $0x1,%esi
    22fe:	4c 89 d1             	mov    %r10,%rcx
    2301:	48 d3 e6             	shl    %cl,%rsi
    2304:	4c 01 de             	add    %r11,%rsi
    2307:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    230c:	bf 02 00 00 00       	mov    $0x2,%edi
    2311:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    2318:	48 89 b5 28 fb ff ff 	mov    %rsi,-0x4d8(%rbp)
    231f:	48 89 ce             	mov    %rcx,%rsi
    2322:	48 89 95 38 fb ff ff 	mov    %rdx,-0x4c8(%rbp)
    2329:	4c 89 d2             	mov    %r10,%rdx
    232c:	48 8b 8d 28 fb ff ff 	mov    -0x4d8(%rbp),%rcx
    2333:	49 89 c0             	mov    %rax,%r8
    2336:	4c 8b 8d 38 fb ff ff 	mov    -0x4c8(%rbp),%r9
    233d:	b8 02 00 00 00       	mov    $0x2,%eax
    2342:	48 89 04 24          	mov    %rax,(%rsp)
    2346:	e8 85 dd ff ff       	call   0xd0
    234b:	48 83 f8 00          	cmp    $0x0,%rax
    234f:	0f 8d 11 00 00 00    	jge    0x2366
    2355:	b8 80 00 00 00       	mov    $0x80,%eax
    235a:	48 89 85 48 fb ff ff 	mov    %rax,-0x4b8(%rbp)
    2361:	e9 a0 4d 00 00       	jmp    0x7106
    2366:	e9 be 06 00 00       	jmp    0x2a29
    236b:	49 83 fd 05          	cmp    $0x5,%r13
    236f:	0f 85 a7 00 00 00    	jne    0x241c
    2375:	48 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%rax
    237c:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    2383:	48 89 c2             	mov    %rax,%rdx
    2386:	48 29 ca             	sub    %rcx,%rdx
    2389:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    2390:	48 39 f2             	cmp    %rsi,%rdx
    2393:	bf 00 00 00 00       	mov    $0x0,%edi
    2398:	40 0f 92 c7          	setb   %dil
    239c:	45 31 c0             	xor    %r8d,%r8d
    239f:	48 85 ff             	test   %rdi,%rdi
    23a2:	49 0f 44 d0          	cmove  %r8,%rdx
    23a6:	49 89 d1             	mov    %rdx,%r9
    23a9:	49 c1 e9 06          	shr    $0x6,%r9
    23ad:	48 83 e2 3f          	and    $0x3f,%rdx
    23b1:	4c 8b 95 70 fc ff ff 	mov    -0x390(%rbp),%r10
    23b8:	4f 8d 1c ca          	lea    (%r10,%r9,8),%r11
    23bc:	49 8b 03             	mov    (%r11),%rax
    23bf:	48 89 d1             	mov    %rdx,%rcx
    23c2:	48 d3 e8             	shr    %cl,%rax
    23c5:	b9 01 00 00 00       	mov    $0x1,%ecx
    23ca:	48 21 c8             	and    %rcx,%rax
    23cd:	49 89 c3             	mov    %rax,%r11
    23d0:	49 21 fb             	and    %rdi,%r11
    23d3:	48 8b 85 48 fc ff ff 	mov    -0x3b8(%rbp),%rax
    23da:	4a 8d 3c c8          	lea    (%rax,%r9,8),%rdi
    23de:	48 8b 07             	mov    (%rdi),%rax
    23e1:	48 89 d1             	mov    %rdx,%rcx
    23e4:	48 d3 e8             	shr    %cl,%rax
    23e7:	b9 01 00 00 00       	mov    $0x1,%ecx
    23ec:	48 89 c7             	mov    %rax,%rdi
    23ef:	48 21 cf             	and    %rcx,%rdi
    23f2:	48 8b 85 58 fc ff ff 	mov    -0x3a8(%rbp),%rax
    23f9:	4a 8d 34 c8          	lea    (%rax,%r9,8),%rsi
    23fd:	4c 8b 0e             	mov    (%rsi),%r9
    2400:	48 89 d1             	mov    %rdx,%rcx
    2403:	49 d3 e9             	shr    %cl,%r9
    2406:	b9 01 00 00 00       	mov    $0x1,%ecx
    240b:	4c 89 ce             	mov    %r9,%rsi
    240e:	48 21 ce             	and    %rcx,%rsi
    2411:	49 89 f9             	mov    %rdi,%r9
    2414:	48 89 f7             	mov    %rsi,%rdi
    2417:	e9 96 00 00 00       	jmp    0x24b2
    241c:	48 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%rax
    2423:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    242a:	48 29 c8             	sub    %rcx,%rax
    242d:	48 8b 95 60 fc ff ff 	mov    -0x3a0(%rbp),%rdx
    2434:	48 39 d0             	cmp    %rdx,%rax
    2437:	be 00 00 00 00       	mov    $0x0,%esi
    243c:	40 0f 92 c6          	setb   %sil
    2440:	45 31 c0             	xor    %r8d,%r8d
    2443:	48 85 f6             	test   %rsi,%rsi
    2446:	49 0f 44 c0          	cmove  %r8,%rax
    244a:	49 89 c2             	mov    %rax,%r10
    244d:	49 c1 ea 06          	shr    $0x6,%r10
    2451:	48 89 c1             	mov    %rax,%rcx
    2454:	48 83 e1 3f          	and    $0x3f,%rcx
    2458:	48 8b 95 70 fc ff ff 	mov    -0x390(%rbp),%rdx
    245f:	4e 8d 04 d2          	lea    (%rdx,%r10,8),%r8
    2463:	4d 8b 10             	mov    (%r8),%r10
    2466:	48 89 8d 20 fb ff ff 	mov    %rcx,-0x4e0(%rbp)
    246d:	4c 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%r8
    2474:	4c 89 c1             	mov    %r8,%rcx
    2477:	49 d3 ea             	shr    %cl,%r10
    247a:	b9 01 00 00 00       	mov    $0x1,%ecx
    247f:	49 21 ca             	and    %rcx,%r10
    2482:	49 21 f2             	and    %rsi,%r10
    2485:	be 10 00 00 00       	mov    $0x10,%esi
    248a:	48 0f af c6          	imul   %rsi,%rax
    248e:	48 8b b5 80 fc ff ff 	mov    -0x380(%rbp),%rsi
    2495:	4c 8d 44 06 f8       	lea    -0x8(%rsi,%rax,1),%r8
    249a:	49 8b 40 08          	mov    0x8(%r8),%rax
    249e:	49 8b 70 10          	mov    0x10(%r8),%rsi
    24a2:	48 c1 e8 20          	shr    $0x20,%rax
    24a6:	48 21 c8             	and    %rcx,%rax
    24a9:	4d 89 d3             	mov    %r10,%r11
    24ac:	49 89 f1             	mov    %rsi,%r9
    24af:	48 89 c7             	mov    %rax,%rdi
    24b2:	4d 85 db             	test   %r11,%r11
    24b5:	0f 84 6e 05 00 00    	je     0x2a29
    24bb:	48 83 ff 00          	cmp    $0x0,%rdi
    24bf:	bf 00 00 00 00       	mov    $0x0,%edi
    24c4:	40 0f 95 c7          	setne  %dil
    24c8:	48 8b 85 c8 fb ff ff 	mov    -0x438(%rbp),%rax
    24cf:	48 89 c1             	mov    %rax,%rcx
    24d2:	48 83 c1 01          	add    $0x1,%rcx
    24d6:	4d 63 c9             	movslq %r9d,%r9
    24d9:	31 d2                	xor    %edx,%edx
    24db:	48 85 ff             	test   %rdi,%rdi
    24de:	49 0f 44 d1          	cmove  %r9,%rdx
    24e2:	48 8b b5 c0 fb ff ff 	mov    -0x440(%rbp),%rsi
    24e9:	48 39 d6             	cmp    %rdx,%rsi
    24ec:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    24f2:	41 0f 94 c0          	sete   %r8b
    24f6:	4c 8b 8d b8 fb ff ff 	mov    -0x448(%rbp),%r9
    24fd:	49 39 f9             	cmp    %rdi,%r9
    2500:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    2506:	41 0f 94 c2          	sete   %r10b
    250a:	4d 21 d0             	and    %r10,%r8
    250d:	4d 85 c0             	test   %r8,%r8
    2510:	48 89 8d 20 fb ff ff 	mov    %rcx,-0x4e0(%rbp)
    2517:	48 89 95 38 fb ff ff 	mov    %rdx,-0x4c8(%rbp)
    251e:	48 89 bd 28 fb ff ff 	mov    %rdi,-0x4d8(%rbp)
    2525:	0f 84 4d 00 00 00    	je     0x2578
    252b:	4c 8b 85 a0 fb ff ff 	mov    -0x460(%rbp),%r8
    2532:	4d 89 c2             	mov    %r8,%r10
    2535:	49 83 c2 01          	add    $0x1,%r10
    2539:	4c 8b 9d 40 fb ff ff 	mov    -0x4c0(%rbp),%r11
    2540:	49 63 13             	movslq (%r11),%rdx
    2543:	4c 8b 9d 90 fb ff ff 	mov    -0x470(%rbp),%r11
    254a:	4c 89 df             	mov    %r11,%rdi
    254d:	48 83 c7 01          	add    $0x1,%rdi
    2551:	48 8b 8d 98 fb ff ff 	mov    -0x468(%rbp),%rcx
    2558:	48 89 c8             	mov    %rcx,%rax
    255b:	48 01 d0             	add    %rdx,%rax
    255e:	4c 89 95 a0 fb ff ff 	mov    %r10,-0x460(%rbp)
    2565:	48 89 85 98 fb ff ff 	mov    %rax,-0x468(%rbp)
    256c:	48 89 bd 90 fb ff ff 	mov    %rdi,-0x470(%rbp)
    2573:	e9 97 04 00 00       	jmp    0x2a0f
    2578:	48 8b 85 a8 fb ff ff 	mov    -0x458(%rbp),%rax
    257f:	48 85 c0             	test   %rax,%rax
    2582:	0f 84 01 04 00 00    	je     0x2989
    2588:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    258f:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    2593:	48 85 d2             	test   %rdx,%rdx
    2596:	0f 84 40 01 00 00    	je     0x26dc
    259c:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    25a0:	be 40 00 00 00       	mov    $0x40,%esi
    25a5:	48 29 d6             	sub    %rdx,%rsi
    25a8:	48 8b bd b0 fb ff ff 	mov    -0x450(%rbp),%rdi
    25af:	48 89 f1             	mov    %rsi,%rcx
    25b2:	49 89 f8             	mov    %rdi,%r8
    25b5:	49 d3 e8             	shr    %cl,%r8
    25b8:	31 c9                	xor    %ecx,%ecx
    25ba:	48 39 ca             	cmp    %rcx,%rdx
    25bd:	ba 00 00 00 00       	mov    $0x0,%edx
    25c2:	0f 94 c2             	sete   %dl
    25c5:	48 85 d2             	test   %rdx,%rdx
    25c8:	49 0f 44 c8          	cmove  %r8,%rcx
    25cc:	48 8b 95 90 fc ff ff 	mov    -0x370(%rbp),%rdx
    25d3:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    25d7:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    25db:	49 8b 30             	mov    (%r8),%rsi
    25de:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    25e5:	00 28 00 
    25e8:	4c 39 ce             	cmp    %r9,%rsi
    25eb:	4c 89 85 30 fb ff ff 	mov    %r8,-0x4d0(%rbp)
    25f2:	0f 82 0c 00 00 00    	jb     0x2604
    25f8:	48 89 b5 10 fb ff ff 	mov    %rsi,-0x4f0(%rbp)
    25ff:	e9 4a 00 00 00       	jmp    0x264e
    2604:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    2608:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    260f:	48 89 b5 18 fb ff ff 	mov    %rsi,-0x4e8(%rbp)
    2616:	48 89 d6             	mov    %rdx,%rsi
    2619:	48 89 ca             	mov    %rcx,%rdx
    261c:	48 8b 8d 18 fb ff ff 	mov    -0x4e8(%rbp),%rcx
    2623:	e8 b8 da ff ff       	call   0xe0
    2628:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    262f:	31 d2                	xor    %edx,%edx
    2631:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    2635:	48 83 f8 00          	cmp    $0x0,%rax
    2639:	0f 8f 08 00 00 00    	jg     0x2647
    263f:	49 89 c4             	mov    %rax,%r12
    2642:	e9 e0 4a 00 00       	jmp    0x7127
    2647:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    264e:	48 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%rax
    2655:	48 89 c1             	mov    %rax,%rcx
    2658:	48 83 c1 28          	add    $0x28,%rcx
    265c:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    2663:	00 28 00 
    2666:	48 29 d1             	sub    %rdx,%rcx
    2669:	48 8b 95 30 fb ff ff 	mov    -0x4d0(%rbp),%rdx
    2670:	48 89 0a             	mov    %rcx,(%rdx)
    2673:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    267a:	ff 00 00 
    267d:	48 21 c8             	and    %rcx,%rax
    2680:	31 c9                	xor    %ecx,%ecx
    2682:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    2689:	48 89 10             	mov    %rdx,(%rax)
    268c:	48 8b b5 b8 fb ff ff 	mov    -0x448(%rbp),%rsi
    2693:	48 89 70 08          	mov    %rsi,0x8(%rax)
    2697:	48 89 48 10          	mov    %rcx,0x10(%rax)
    269b:	48 89 48 18          	mov    %rcx,0x18(%rax)
    269f:	48 89 48 20          	mov    %rcx,0x20(%rax)
    26a3:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    26aa:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    26ae:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    26b4:	4c 01 c7             	add    %r8,%rdi
    26b7:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    26bb:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    26c2:	b8 01 00 00 00       	mov    $0x1,%eax
    26c7:	48 89 85 30 fb ff ff 	mov    %rax,-0x4d0(%rbp)
    26ce:	31 c0                	xor    %eax,%eax
    26d0:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    26d7:	e9 a7 01 00 00       	jmp    0x2883
    26dc:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    26e3:	48 8b 70 10          	mov    0x10(%rax),%rsi
    26e7:	48 8b 48 18          	mov    0x18(%rax),%rcx
    26eb:	48 89 ca             	mov    %rcx,%rdx
    26ee:	f3 48 0f b8 d2       	popcnt %rdx,%rdx
    26f3:	bf 40 00 00 00       	mov    $0x40,%edi
    26f8:	48 29 d7             	sub    %rdx,%rdi
    26fb:	48 89 8d 08 fb ff ff 	mov    %rcx,-0x4f8(%rbp)
    2702:	4c 8b 85 b0 fb ff ff 	mov    -0x450(%rbp),%r8
    2709:	48 89 f9             	mov    %rdi,%rcx
    270c:	4d 89 c1             	mov    %r8,%r9
    270f:	49 d3 e9             	shr    %cl,%r9
    2712:	31 c9                	xor    %ecx,%ecx
    2714:	48 39 ca             	cmp    %rcx,%rdx
    2717:	ba 00 00 00 00       	mov    $0x0,%edx
    271c:	0f 94 c2             	sete   %dl
    271f:	48 85 d2             	test   %rdx,%rdx
    2722:	49 0f 44 c9          	cmove  %r9,%rcx
    2726:	ba 01 00 00 00       	mov    $0x1,%edx
    272b:	48 89 cf             	mov    %rcx,%rdi
    272e:	48 01 d7             	add    %rdx,%rdi
    2731:	4c 8b 95 08 fb ff ff 	mov    -0x4f8(%rbp),%r10
    2738:	49 89 f9             	mov    %rdi,%r9
    273b:	4d 21 d1             	and    %r10,%r9
    273e:	bf 28 00 00 00       	mov    $0x28,%edi
    2743:	48 0f af cf          	imul   %rdi,%rcx
    2747:	48 8d 3c 0e          	lea    (%rsi,%rcx,1),%rdi
    274b:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    274f:	48 85 c9             	test   %rcx,%rcx
    2752:	0f 84 b2 00 00 00    	je     0x280a
    2758:	48 8b 0f             	mov    (%rdi),%rcx
    275b:	4c 8b 57 08          	mov    0x8(%rdi),%r10
    275f:	4c 8b 9d c0 fb ff ff 	mov    -0x440(%rbp),%r11
    2766:	49 39 cb             	cmp    %rcx,%r11
    2769:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    276f:	41 0f 94 c0          	sete   %r8b
    2773:	48 8b 8d b8 fb ff ff 	mov    -0x448(%rbp),%rcx
    277a:	4c 39 d1             	cmp    %r10,%rcx
    277d:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    2783:	41 0f 94 c3          	sete   %r11b
    2787:	4d 21 d8             	and    %r11,%r8
    278a:	4d 85 c0             	test   %r8,%r8
    278d:	0f 84 0c 00 00 00    	je     0x279f
    2793:	48 89 bd 10 fb ff ff 	mov    %rdi,-0x4f0(%rbp)
    279a:	e9 54 00 00 00       	jmp    0x27f3
    279f:	bf 28 00 00 00       	mov    $0x28,%edi
    27a4:	4c 0f af cf          	imul   %rdi,%r9
    27a8:	4a 8d 3c 0e          	lea    (%rsi,%r9,1),%rdi
    27ac:	48 8b 77 10          	mov    0x10(%rdi),%rsi
    27b0:	48 85 f6             	test   %rsi,%rsi
    27b3:	0f 84 51 00 00 00    	je     0x280a
    27b9:	48 8b 37             	mov    (%rdi),%rsi
    27bc:	4c 8b 47 08          	mov    0x8(%rdi),%r8
    27c0:	4c 8b 8d c0 fb ff ff 	mov    -0x440(%rbp),%r9
    27c7:	49 39 f1             	cmp    %rsi,%r9
    27ca:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    27d0:	41 0f 94 c2          	sete   %r10b
    27d4:	4c 39 c1             	cmp    %r8,%rcx
    27d7:	be 00 00 00 00       	mov    $0x0,%esi
    27dc:	40 0f 94 c6          	sete   %sil
    27e0:	49 21 f2             	and    %rsi,%r10
    27e3:	4d 85 d2             	test   %r10,%r10
    27e6:	0f 84 1e 00 00 00    	je     0x280a
    27ec:	48 89 bd 10 fb ff ff 	mov    %rdi,-0x4f0(%rbp)
    27f3:	31 c0                	xor    %eax,%eax
    27f5:	48 89 85 30 fb ff ff 	mov    %rax,-0x4d0(%rbp)
    27fc:	31 c0                	xor    %eax,%eax
    27fe:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    2805:	e9 79 00 00 00       	jmp    0x2883
    280a:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
    2811:	48 89 c1             	mov    %rax,%rcx
    2814:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    281b:	48 89 11             	mov    %rdx,(%rcx)
    281e:	48 8b b5 b8 fb ff ff 	mov    -0x448(%rbp),%rsi
    2825:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    2829:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    2830:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    2837:	48 89 ca             	mov    %rcx,%rdx
    283a:	e8 b1 d8 ff ff       	call   0xf0
    283f:	48 83 f8 00          	cmp    $0x0,%rax
    2843:	0f 8d 08 00 00 00    	jge    0x2851
    2849:	49 89 c4             	mov    %rax,%r12
    284c:	e9 d6 48 00 00       	jmp    0x7127
    2851:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    2858:	48 8b 11             	mov    (%rcx),%rdx
    285b:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    285f:	48 83 e6 01          	and    $0x1,%rsi
    2863:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    2867:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    286e:	b8 01 00 00 00       	mov    $0x1,%eax
    2873:	48 89 85 30 fb ff ff 	mov    %rax,-0x4d0(%rbp)
    287a:	31 c0                	xor    %eax,%eax
    287c:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    2883:	48 8b 85 30 fb ff ff 	mov    -0x4d0(%rbp),%rax
    288a:	48 85 c0             	test   %rax,%rax
    288d:	0f 84 68 00 00 00    	je     0x28fb
    2893:	48 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%rax
    289a:	48 8b 8d a0 fb ff ff 	mov    -0x460(%rbp),%rcx
    28a1:	48 89 48 10          	mov    %rcx,0x10(%rax)
    28a5:	31 d2                	xor    %edx,%edx
    28a7:	48 39 d1             	cmp    %rdx,%rcx
    28aa:	be 00 00 00 00       	mov    $0x0,%esi
    28af:	40 0f 95 c6          	setne  %sil
    28b3:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    28b7:	48 09 f7             	or     %rsi,%rdi
    28ba:	40 88 78 20          	mov    %dil,0x20(%rax)
    28be:	48 8b b5 98 fb ff ff 	mov    -0x468(%rbp),%rsi
    28c5:	48 89 70 18          	mov    %rsi,0x18(%rax)
    28c9:	48 8b bd 90 fb ff ff 	mov    -0x470(%rbp),%rdi
    28d0:	48 39 d7             	cmp    %rdx,%rdi
    28d3:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    28d9:	41 0f 95 c0          	setne  %r8b
    28dd:	44 0f b6 48 20       	movzbl 0x20(%rax),%r9d
    28e2:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    28e8:	4d 85 c0             	test   %r8,%r8
    28eb:	4c 0f 44 d2          	cmove  %rdx,%r10
    28ef:	4d 09 d1             	or     %r10,%r9
    28f2:	44 88 48 20          	mov    %r9b,0x20(%rax)
    28f6:	e9 8e 00 00 00       	jmp    0x2989
    28fb:	48 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%rax
    2902:	48 8b 48 10          	mov    0x10(%rax),%rcx
    2906:	48 8b 95 a0 fb ff ff 	mov    -0x460(%rbp),%rdx
    290d:	48 01 d1             	add    %rdx,%rcx
    2910:	48 89 48 10          	mov    %rcx,0x10(%rax)
    2914:	31 f6                	xor    %esi,%esi
    2916:	48 39 f1             	cmp    %rsi,%rcx
    2919:	b9 00 00 00 00       	mov    $0x0,%ecx
    291e:	0f 95 c1             	setne  %cl
    2921:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    2925:	48 09 cf             	or     %rcx,%rdi
    2928:	40 88 78 20          	mov    %dil,0x20(%rax)
    292c:	48 8b 48 18          	mov    0x18(%rax),%rcx
    2930:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    2934:	48 83 e7 02          	and    $0x2,%rdi
    2938:	48 39 f7             	cmp    %rsi,%rdi
    293b:	bf 00 00 00 00       	mov    $0x0,%edi
    2940:	40 0f 95 c7          	setne  %dil
    2944:	45 31 c0             	xor    %r8d,%r8d
    2947:	48 85 ff             	test   %rdi,%rdi
    294a:	49 0f 44 c8          	cmove  %r8,%rcx
    294e:	4c 8b 85 90 fb ff ff 	mov    -0x470(%rbp),%r8
    2955:	4c 01 c7             	add    %r8,%rdi
    2958:	4c 8b 8d 98 fb ff ff 	mov    -0x468(%rbp),%r9
    295f:	4c 01 c9             	add    %r9,%rcx
    2962:	48 89 48 18          	mov    %rcx,0x18(%rax)
    2966:	48 39 f7             	cmp    %rsi,%rdi
    2969:	bf 00 00 00 00       	mov    $0x0,%edi
    296e:	40 0f 95 c7          	setne  %dil
    2972:	0f b6 48 20          	movzbl 0x20(%rax),%ecx
    2976:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    297c:	48 85 ff             	test   %rdi,%rdi
    297f:	4c 0f 44 d6          	cmove  %rsi,%r10
    2983:	4c 09 d1             	or     %r10,%rcx
    2986:	88 48 20             	mov    %cl,0x20(%rax)
    2989:	48 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%rax
    2990:	48 63 08             	movslq (%rax),%rcx
    2993:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    299a:	79 37 9e 
    299d:	48 ba 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%rdx
    29a4:	79 37 9e 
    29a7:	48 8b b5 38 fb ff ff 	mov    -0x4c8(%rbp),%rsi
    29ae:	48 31 f2             	xor    %rsi,%rdx
    29b1:	48 0f af d0          	imul   %rax,%rdx
    29b5:	48 89 d7             	mov    %rdx,%rdi
    29b8:	48 c1 ef 1d          	shr    $0x1d,%rdi
    29bc:	48 31 fa             	xor    %rdi,%rdx
    29bf:	48 8b bd 28 fb ff ff 	mov    -0x4d8(%rbp),%rdi
    29c6:	48 31 fa             	xor    %rdi,%rdx
    29c9:	48 0f af d0          	imul   %rax,%rdx
    29cd:	49 89 d0             	mov    %rdx,%r8
    29d0:	49 c1 e8 1d          	shr    $0x1d,%r8
    29d4:	4c 31 c2             	xor    %r8,%rdx
    29d7:	48 0f af d0          	imul   %rax,%rdx
    29db:	48 89 b5 c0 fb ff ff 	mov    %rsi,-0x440(%rbp)
    29e2:	48 89 bd b8 fb ff ff 	mov    %rdi,-0x448(%rbp)
    29e9:	48 89 95 b0 fb ff ff 	mov    %rdx,-0x450(%rbp)
    29f0:	b8 01 00 00 00       	mov    $0x1,%eax
    29f5:	48 89 85 a0 fb ff ff 	mov    %rax,-0x460(%rbp)
    29fc:	48 89 8d 98 fb ff ff 	mov    %rcx,-0x468(%rbp)
    2a03:	b8 01 00 00 00       	mov    $0x1,%eax
    2a08:	48 89 85 90 fb ff ff 	mov    %rax,-0x470(%rbp)
    2a0f:	48 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%rax
    2a16:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    2a1d:	b8 01 00 00 00       	mov    $0x1,%eax
    2a22:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
    2a29:	48 8b 85 d0 fb ff ff 	mov    -0x430(%rbp),%rax
    2a30:	b9 01 00 00 00       	mov    $0x1,%ecx
    2a35:	48 89 c2             	mov    %rax,%rdx
    2a38:	48 01 ca             	add    %rcx,%rdx
    2a3b:	48 89 95 d0 fb ff ff 	mov    %rdx,-0x430(%rbp)
    2a42:	e9 29 f7 ff ff       	jmp    0x2170
    2a47:	48 8b 85 88 fb ff ff 	mov    -0x478(%rbp),%rax
    2a4e:	48 85 c0             	test   %rax,%rax
    2a51:	0f 84 fe 03 00 00    	je     0x2e55
    2a57:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    2a5e:	48 8b 48 68          	mov    0x68(%rax),%rcx
    2a62:	48 85 c9             	test   %rcx,%rcx
    2a65:	0f 84 47 01 00 00    	je     0x2bb2
    2a6b:	48 8b 48 38          	mov    0x38(%rax),%rcx
    2a6f:	ba 40 00 00 00       	mov    $0x40,%edx
    2a74:	48 29 ca             	sub    %rcx,%rdx
    2a77:	48 89 8d 88 fb ff ff 	mov    %rcx,-0x478(%rbp)
    2a7e:	48 8b b5 60 fb ff ff 	mov    -0x4a0(%rbp),%rsi
    2a85:	48 89 d1             	mov    %rdx,%rcx
    2a88:	48 89 f7             	mov    %rsi,%rdi
    2a8b:	48 d3 ef             	shr    %cl,%rdi
    2a8e:	31 c9                	xor    %ecx,%ecx
    2a90:	48 8b 95 88 fb ff ff 	mov    -0x478(%rbp),%rdx
    2a97:	48 39 ca             	cmp    %rcx,%rdx
    2a9a:	ba 00 00 00 00       	mov    $0x0,%edx
    2a9f:	0f 94 c2             	sete   %dl
    2aa2:	48 85 d2             	test   %rdx,%rdx
    2aa5:	48 0f 44 cf          	cmove  %rdi,%rcx
    2aa9:	48 8b 50 08          	mov    0x8(%rax),%rdx
    2aad:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    2ab1:	48 8b 17             	mov    (%rdi),%rdx
    2ab4:	49 b8 00 00 00 00 00 	movabs $0x28000000000000,%r8
    2abb:	00 28 00 
    2abe:	4c 39 c2             	cmp    %r8,%rdx
    2ac1:	48 89 bd 88 fb ff ff 	mov    %rdi,-0x478(%rbp)
    2ac8:	0f 82 0c 00 00 00    	jb     0x2ada
    2ace:	48 89 95 d0 fb ff ff 	mov    %rdx,-0x430(%rbp)
    2ad5:	e9 4a 00 00 00       	jmp    0x2b24
    2ada:	48 8b 50 60          	mov    0x60(%rax),%rdx
    2ade:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    2ae5:	48 89 c6             	mov    %rax,%rsi
    2ae8:	48 89 95 c8 fb ff ff 	mov    %rdx,-0x438(%rbp)
    2aef:	48 89 ca             	mov    %rcx,%rdx
    2af2:	48 8b 8d c8 fb ff ff 	mov    -0x438(%rbp),%rcx
    2af9:	e8 e2 d5 ff ff       	call   0xe0
    2afe:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    2b05:	31 d2                	xor    %edx,%edx
    2b07:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    2b0b:	48 83 f8 00          	cmp    $0x0,%rax
    2b0f:	0f 8f 08 00 00 00    	jg     0x2b1d
    2b15:	49 89 c4             	mov    %rax,%r12
    2b18:	e9 0a 46 00 00       	jmp    0x7127
    2b1d:	48 89 85 d0 fb ff ff 	mov    %rax,-0x430(%rbp)
    2b24:	48 8b 85 d0 fb ff ff 	mov    -0x430(%rbp),%rax
    2b2b:	48 89 c1             	mov    %rax,%rcx
    2b2e:	48 83 c1 28          	add    $0x28,%rcx
    2b32:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    2b39:	00 28 00 
    2b3c:	48 29 d1             	sub    %rdx,%rcx
    2b3f:	48 8b 95 88 fb ff ff 	mov    -0x478(%rbp),%rdx
    2b46:	48 89 0a             	mov    %rcx,(%rdx)
    2b49:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    2b50:	ff 00 00 
    2b53:	48 21 c8             	and    %rcx,%rax
    2b56:	31 c9                	xor    %ecx,%ecx
    2b58:	48 8b 95 70 fb ff ff 	mov    -0x490(%rbp),%rdx
    2b5f:	48 89 10             	mov    %rdx,(%rax)
    2b62:	48 8b b5 68 fb ff ff 	mov    -0x498(%rbp),%rsi
    2b69:	48 89 70 08          	mov    %rsi,0x8(%rax)
    2b6d:	48 89 48 10          	mov    %rcx,0x10(%rax)
    2b71:	48 89 48 18          	mov    %rcx,0x18(%rax)
    2b75:	48 89 48 20          	mov    %rcx,0x20(%rax)
    2b79:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    2b80:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    2b84:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    2b8a:	4c 01 c7             	add    %r8,%rdi
    2b8d:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    2b91:	48 89 85 d0 fb ff ff 	mov    %rax,-0x430(%rbp)
    2b98:	b8 01 00 00 00       	mov    $0x1,%eax
    2b9d:	48 89 85 88 fb ff ff 	mov    %rax,-0x478(%rbp)
    2ba4:	31 c0                	xor    %eax,%eax
    2ba6:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    2bad:	e9 9f 01 00 00       	jmp    0x2d51
    2bb2:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    2bb9:	48 8b 48 10          	mov    0x10(%rax),%rcx
    2bbd:	48 8b 50 18          	mov    0x18(%rax),%rdx
    2bc1:	48 89 d6             	mov    %rdx,%rsi
    2bc4:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    2bc9:	bf 40 00 00 00       	mov    $0x40,%edi
    2bce:	48 29 f7             	sub    %rsi,%rdi
    2bd1:	48 89 8d c0 fb ff ff 	mov    %rcx,-0x440(%rbp)
    2bd8:	4c 8b 85 60 fb ff ff 	mov    -0x4a0(%rbp),%r8
    2bdf:	48 89 f9             	mov    %rdi,%rcx
    2be2:	49 d3 e8             	shr    %cl,%r8
    2be5:	31 c9                	xor    %ecx,%ecx
    2be7:	48 39 ce             	cmp    %rcx,%rsi
    2bea:	be 00 00 00 00       	mov    $0x0,%esi
    2bef:	40 0f 94 c6          	sete   %sil
    2bf3:	48 85 f6             	test   %rsi,%rsi
    2bf6:	49 0f 44 c8          	cmove  %r8,%rcx
    2bfa:	be 01 00 00 00       	mov    $0x1,%esi
    2bff:	48 89 cf             	mov    %rcx,%rdi
    2c02:	48 01 f7             	add    %rsi,%rdi
    2c05:	48 21 d7             	and    %rdx,%rdi
    2c08:	ba 28 00 00 00       	mov    $0x28,%edx
    2c0d:	48 0f af ca          	imul   %rdx,%rcx
    2c11:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    2c18:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
    2c1c:	49 8b 48 10          	mov    0x10(%r8),%rcx
    2c20:	48 85 c9             	test   %rcx,%rcx
    2c23:	0f 84 af 00 00 00    	je     0x2cd8
    2c29:	49 8b 08             	mov    (%r8),%rcx
    2c2c:	4d 8b 48 08          	mov    0x8(%r8),%r9
    2c30:	4c 8b 95 70 fb ff ff 	mov    -0x490(%rbp),%r10
    2c37:	49 39 ca             	cmp    %rcx,%r10
    2c3a:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    2c40:	41 0f 94 c3          	sete   %r11b
    2c44:	48 8b 8d 68 fb ff ff 	mov    -0x498(%rbp),%rcx
    2c4b:	4c 39 c9             	cmp    %r9,%rcx
    2c4e:	ba 00 00 00 00       	mov    $0x0,%edx
    2c53:	0f 94 c2             	sete   %dl
    2c56:	49 21 d3             	and    %rdx,%r11
    2c59:	4d 85 db             	test   %r11,%r11
    2c5c:	0f 84 0c 00 00 00    	je     0x2c6e
    2c62:	4c 89 85 d0 fb ff ff 	mov    %r8,-0x430(%rbp)
    2c69:	e9 53 00 00 00       	jmp    0x2cc1
    2c6e:	ba 28 00 00 00       	mov    $0x28,%edx
    2c73:	48 0f af fa          	imul   %rdx,%rdi
    2c77:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    2c7e:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    2c82:	49 8b 50 10          	mov    0x10(%r8),%rdx
    2c86:	48 85 d2             	test   %rdx,%rdx
    2c89:	0f 84 49 00 00 00    	je     0x2cd8
    2c8f:	49 8b 10             	mov    (%r8),%rdx
    2c92:	49 8b 78 08          	mov    0x8(%r8),%rdi
    2c96:	49 39 d2             	cmp    %rdx,%r10
    2c99:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    2c9f:	41 0f 94 c1          	sete   %r9b
    2ca3:	48 39 f9             	cmp    %rdi,%rcx
    2ca6:	ba 00 00 00 00       	mov    $0x0,%edx
    2cab:	0f 94 c2             	sete   %dl
    2cae:	49 21 d1             	and    %rdx,%r9
    2cb1:	4d 85 c9             	test   %r9,%r9
    2cb4:	0f 84 1e 00 00 00    	je     0x2cd8
    2cba:	4c 89 85 d0 fb ff ff 	mov    %r8,-0x430(%rbp)
    2cc1:	31 c0                	xor    %eax,%eax
    2cc3:	48 89 85 88 fb ff ff 	mov    %rax,-0x478(%rbp)
    2cca:	31 c0                	xor    %eax,%eax
    2ccc:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    2cd3:	e9 79 00 00 00       	jmp    0x2d51
    2cd8:	48 8d 85 80 fe ff ff 	lea    -0x180(%rbp),%rax
    2cdf:	48 89 c1             	mov    %rax,%rcx
    2ce2:	48 8b 95 70 fb ff ff 	mov    -0x490(%rbp),%rdx
    2ce9:	48 89 11             	mov    %rdx,(%rcx)
    2cec:	48 8b 95 68 fb ff ff 	mov    -0x498(%rbp),%rdx
    2cf3:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    2cf7:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    2cfe:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    2d05:	48 89 ca             	mov    %rcx,%rdx
    2d08:	e8 e3 d3 ff ff       	call   0xf0
    2d0d:	48 83 f8 00          	cmp    $0x0,%rax
    2d11:	0f 8d 08 00 00 00    	jge    0x2d1f
    2d17:	49 89 c4             	mov    %rax,%r12
    2d1a:	e9 08 44 00 00       	jmp    0x7127
    2d1f:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    2d26:	48 8b 11             	mov    (%rcx),%rdx
    2d29:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    2d2d:	48 83 e6 01          	and    $0x1,%rsi
    2d31:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    2d35:	48 89 85 d0 fb ff ff 	mov    %rax,-0x430(%rbp)
    2d3c:	b8 01 00 00 00       	mov    $0x1,%eax
    2d41:	48 89 85 88 fb ff ff 	mov    %rax,-0x478(%rbp)
    2d48:	31 c0                	xor    %eax,%eax
    2d4a:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    2d51:	48 8b 85 88 fb ff ff 	mov    -0x478(%rbp),%rax
    2d58:	48 85 c0             	test   %rax,%rax
    2d5b:	0f 84 68 00 00 00    	je     0x2dc9
    2d61:	48 8b 85 d0 fb ff ff 	mov    -0x430(%rbp),%rax
    2d68:	48 8b 8d 78 fb ff ff 	mov    -0x488(%rbp),%rcx
    2d6f:	48 89 48 10          	mov    %rcx,0x10(%rax)
    2d73:	31 d2                	xor    %edx,%edx
    2d75:	48 39 d1             	cmp    %rdx,%rcx
    2d78:	be 00 00 00 00       	mov    $0x0,%esi
    2d7d:	40 0f 95 c6          	setne  %sil
    2d81:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    2d85:	48 09 f7             	or     %rsi,%rdi
    2d88:	40 88 78 20          	mov    %dil,0x20(%rax)
    2d8c:	48 8b b5 58 fb ff ff 	mov    -0x4a8(%rbp),%rsi
    2d93:	48 89 70 18          	mov    %rsi,0x18(%rax)
    2d97:	48 8b bd 50 fb ff ff 	mov    -0x4b0(%rbp),%rdi
    2d9e:	48 39 d7             	cmp    %rdx,%rdi
    2da1:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    2da7:	41 0f 95 c0          	setne  %r8b
    2dab:	44 0f b6 48 20       	movzbl 0x20(%rax),%r9d
    2db0:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    2db6:	4d 85 c0             	test   %r8,%r8
    2db9:	4c 0f 44 d2          	cmove  %rdx,%r10
    2dbd:	4d 09 d1             	or     %r10,%r9
    2dc0:	44 88 48 20          	mov    %r9b,0x20(%rax)
    2dc4:	e9 8c 00 00 00       	jmp    0x2e55
    2dc9:	48 8b 85 d0 fb ff ff 	mov    -0x430(%rbp),%rax
    2dd0:	48 8b 48 10          	mov    0x10(%rax),%rcx
    2dd4:	48 8b 95 78 fb ff ff 	mov    -0x488(%rbp),%rdx
    2ddb:	48 01 d1             	add    %rdx,%rcx
    2dde:	48 89 48 10          	mov    %rcx,0x10(%rax)
    2de2:	31 d2                	xor    %edx,%edx
    2de4:	48 39 d1             	cmp    %rdx,%rcx
    2de7:	b9 00 00 00 00       	mov    $0x0,%ecx
    2dec:	0f 95 c1             	setne  %cl
    2def:	0f b6 70 20          	movzbl 0x20(%rax),%esi
    2df3:	48 09 ce             	or     %rcx,%rsi
    2df6:	40 88 70 20          	mov    %sil,0x20(%rax)
    2dfa:	48 8b 48 18          	mov    0x18(%rax),%rcx
    2dfe:	0f b6 70 20          	movzbl 0x20(%rax),%esi
    2e02:	48 83 e6 02          	and    $0x2,%rsi
    2e06:	48 39 d6             	cmp    %rdx,%rsi
    2e09:	be 00 00 00 00       	mov    $0x0,%esi
    2e0e:	40 0f 95 c6          	setne  %sil
    2e12:	31 ff                	xor    %edi,%edi
    2e14:	48 85 f6             	test   %rsi,%rsi
    2e17:	48 0f 44 cf          	cmove  %rdi,%rcx
    2e1b:	48 8b bd 50 fb ff ff 	mov    -0x4b0(%rbp),%rdi
    2e22:	48 01 fe             	add    %rdi,%rsi
    2e25:	48 8b bd 58 fb ff ff 	mov    -0x4a8(%rbp),%rdi
    2e2c:	48 01 f9             	add    %rdi,%rcx
    2e2f:	48 89 48 18          	mov    %rcx,0x18(%rax)
    2e33:	48 39 d6             	cmp    %rdx,%rsi
    2e36:	be 00 00 00 00       	mov    $0x0,%esi
    2e3b:	40 0f 95 c6          	setne  %sil
    2e3f:	0f b6 48 20          	movzbl 0x20(%rax),%ecx
    2e43:	bf 02 00 00 00       	mov    $0x2,%edi
    2e48:	48 85 f6             	test   %rsi,%rsi
    2e4b:	48 0f 44 fa          	cmove  %rdx,%rdi
    2e4f:	48 09 f9             	or     %rdi,%rcx
    2e52:	88 48 20             	mov    %cl,0x20(%rax)
    2e55:	48 8b 85 80 fb ff ff 	mov    -0x480(%rbp),%rax
    2e5c:	48 89 85 d0 fb ff ff 	mov    %rax,-0x430(%rbp)
    2e63:	e9 9d 41 00 00       	jmp    0x7005
    2e68:	48 8b 85 38 fc ff ff 	mov    -0x3c8(%rbp),%rax
    2e6f:	48 85 c0             	test   %rax,%rax
    2e72:	0f 84 02 23 00 00    	je     0x517a
    2e78:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
    2e7f:	82 28 52 
    2e82:	31 c9                	xor    %ecx,%ecx
    2e84:	48 8b 95 18 fc ff ff 	mov    -0x3e8(%rbp),%rdx
    2e8b:	48 8b b5 e0 fb ff ff 	mov    -0x420(%rbp),%rsi
    2e92:	48 89 d7             	mov    %rdx,%rdi
    2e95:	48 21 f7             	and    %rsi,%rdi
    2e98:	48 85 ff             	test   %rdi,%rdi
    2e9b:	0f 85 19 10 00 00    	jne    0x3eba
    2ea1:	48 8b bd 08 fc ff ff 	mov    -0x3f8(%rbp),%rdi
    2ea8:	48 89 bd 38 fc ff ff 	mov    %rdi,-0x3c8(%rbp)
    2eaf:	31 ff                	xor    %edi,%edi
    2eb1:	48 89 bd 80 fb ff ff 	mov    %rdi,-0x480(%rbp)
    2eb8:	31 ff                	xor    %edi,%edi
    2eba:	48 89 bd 58 fb ff ff 	mov    %rdi,-0x4a8(%rbp)
    2ec1:	48 89 85 50 fb ff ff 	mov    %rax,-0x4b0(%rbp)
    2ec8:	31 ff                	xor    %edi,%edi
    2eca:	48 89 bd 78 fb ff ff 	mov    %rdi,-0x488(%rbp)
    2ed1:	48 89 8d 88 fb ff ff 	mov    %rcx,-0x478(%rbp)
    2ed8:	31 ff                	xor    %edi,%edi
    2eda:	48 89 bd c8 fb ff ff 	mov    %rdi,-0x438(%rbp)
    2ee1:	31 ff                	xor    %edi,%edi
    2ee3:	48 89 bd 68 fb ff ff 	mov    %rdi,-0x498(%rbp)
    2eea:	31 ff                	xor    %edi,%edi
    2eec:	48 89 bd 70 fb ff ff 	mov    %rdi,-0x490(%rbp)
    2ef3:	48 8b 85 38 fc ff ff 	mov    -0x3c8(%rbp),%rax
    2efa:	48 8b 8d f8 fb ff ff 	mov    -0x408(%rbp),%rcx
    2f01:	48 39 c8             	cmp    %rcx,%rax
    2f04:	0f 8c 75 00 00 00    	jl     0x2f7f
    2f0a:	48 8b 95 70 fb ff ff 	mov    -0x490(%rbp),%rdx
    2f11:	48 89 95 c0 fb ff ff 	mov    %rdx,-0x440(%rbp)
    2f18:	48 8b 95 68 fb ff ff 	mov    -0x498(%rbp),%rdx
    2f1f:	48 89 95 60 fb ff ff 	mov    %rdx,-0x4a0(%rbp)
    2f26:	48 8b 95 78 fb ff ff 	mov    -0x488(%rbp),%rdx
    2f2d:	48 89 95 b8 fb ff ff 	mov    %rdx,-0x448(%rbp)
    2f34:	48 8b 95 80 fb ff ff 	mov    -0x480(%rbp),%rdx
    2f3b:	48 89 95 b0 fb ff ff 	mov    %rdx,-0x450(%rbp)
    2f42:	48 8b 95 58 fb ff ff 	mov    -0x4a8(%rbp),%rdx
    2f49:	48 89 95 a8 fb ff ff 	mov    %rdx,-0x458(%rbp)
    2f50:	48 8b 95 50 fb ff ff 	mov    -0x4b0(%rbp),%rdx
    2f57:	48 89 95 a0 fb ff ff 	mov    %rdx,-0x460(%rbp)
    2f5e:	48 8b 95 88 fb ff ff 	mov    -0x478(%rbp),%rdx
    2f65:	48 89 95 98 fb ff ff 	mov    %rdx,-0x468(%rbp)
    2f6c:	48 8b 95 c8 fb ff ff 	mov    -0x438(%rbp),%rdx
    2f73:	48 89 95 90 fb ff ff 	mov    %rdx,-0x470(%rbp)
    2f7a:	e9 18 1e 00 00       	jmp    0x4d97
    2f7f:	48 8b 95 e0 fb ff ff 	mov    -0x420(%rbp),%rdx
    2f86:	48 85 d2             	test   %rdx,%rdx
    2f89:	0f 84 08 00 00 00    	je     0x2f97
    2f8f:	48 89 c6             	mov    %rax,%rsi
    2f92:	e9 11 00 00 00       	jmp    0x2fa8
    2f97:	48 8b bd 30 fc ff ff 	mov    -0x3d0(%rbp),%rdi
    2f9e:	4c 8d 04 87          	lea    (%rdi,%rax,4),%r8
    2fa2:	45 8b 08             	mov    (%r8),%r9d
    2fa5:	4c 89 ce             	mov    %r9,%rsi
    2fa8:	48 8b 85 d8 fb ff ff 	mov    -0x428(%rbp),%rax
    2faf:	48 8d 0c b0          	lea    (%rax,%rsi,4),%rcx
    2fb3:	48 89 f2             	mov    %rsi,%rdx
    2fb6:	48 c1 ea 06          	shr    $0x6,%rdx
    2fba:	48 8b bd 20 fc ff ff 	mov    -0x3e0(%rbp),%rdi
    2fc1:	4c 8d 04 d7          	lea    (%rdi,%rdx,8),%r8
    2fc5:	48 8b 95 10 fc ff ff 	mov    -0x3f0(%rbp),%rdx
    2fcc:	4c 8b 8d 98 fc ff ff 	mov    -0x368(%rbp),%r9
    2fd3:	4d 89 ca             	mov    %r9,%r10
    2fd6:	48 85 d2             	test   %rdx,%rdx
    2fd9:	4d 0f 44 d0          	cmove  %r8,%r10
    2fdd:	4d 8b 02             	mov    (%r10),%r8
    2fe0:	49 89 f2             	mov    %rsi,%r10
    2fe3:	49 83 e2 3f          	and    $0x3f,%r10
    2fe7:	48 89 8d 20 fb ff ff 	mov    %rcx,-0x4e0(%rbp)
    2fee:	4c 89 d1             	mov    %r10,%rcx
    2ff1:	49 d3 e8             	shr    %cl,%r8
    2ff4:	b9 01 00 00 00       	mov    $0x1,%ecx
    2ff9:	49 21 c8             	and    %rcx,%r8
    2ffc:	45 31 d2             	xor    %r10d,%r10d
    2fff:	4d 39 d0             	cmp    %r10,%r8
    3002:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    3008:	41 0f 94 c0          	sete   %r8b
    300c:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    3012:	48 89 d7             	mov    %rdx,%rdi
    3015:	4c 31 df             	xor    %r11,%rdi
    3018:	49 21 f8             	and    %rdi,%r8
    301b:	48 8b bd e8 fb ff ff 	mov    -0x418(%rbp),%rdi
    3022:	4c 8d 1c b7          	lea    (%rdi,%rsi,4),%r11
    3026:	48 89 f2             	mov    %rsi,%rdx
    3029:	48 c1 ea 06          	shr    $0x6,%rdx
    302d:	48 8b 85 00 fc ff ff 	mov    -0x400(%rbp),%rax
    3034:	48 8d 3c d0          	lea    (%rax,%rdx,8),%rdi
    3038:	48 8b 95 f0 fb ff ff 	mov    -0x410(%rbp),%rdx
    303f:	4c 89 c8             	mov    %r9,%rax
    3042:	48 85 d2             	test   %rdx,%rdx
    3045:	48 0f 44 c7          	cmove  %rdi,%rax
    3049:	48 8b 38             	mov    (%rax),%rdi
    304c:	48 83 e6 3f          	and    $0x3f,%rsi
    3050:	48 89 f1             	mov    %rsi,%rcx
    3053:	48 d3 ef             	shr    %cl,%rdi
    3056:	b8 01 00 00 00       	mov    $0x1,%eax
    305b:	48 21 c7             	and    %rax,%rdi
    305e:	4c 39 d7             	cmp    %r10,%rdi
    3061:	bf 00 00 00 00       	mov    $0x0,%edi
    3066:	40 0f 94 c7          	sete   %dil
    306a:	b9 01 00 00 00       	mov    $0x1,%ecx
    306f:	48 89 d6             	mov    %rdx,%rsi
    3072:	48 31 ce             	xor    %rcx,%rsi
    3075:	48 21 f7             	and    %rsi,%rdi
    3078:	4d 85 c0             	test   %r8,%r8
    307b:	48 89 bd 28 fb ff ff 	mov    %rdi,-0x4d8(%rbp)
    3082:	4c 89 9d 38 fb ff ff 	mov    %r11,-0x4c8(%rbp)
    3089:	0f 85 f3 0d 00 00    	jne    0x3e82
    308f:	48 8b 8d 20 fb ff ff 	mov    -0x4e0(%rbp),%rcx
    3096:	48 63 31             	movslq (%rcx),%rsi
    3099:	48 8b 8d 50 fc ff ff 	mov    -0x3b0(%rbp),%rcx
    30a0:	48 85 c9             	test   %rcx,%rcx
    30a3:	48 89 b5 40 fb ff ff 	mov    %rsi,-0x4c0(%rbp)
    30aa:	0f 84 47 01 00 00    	je     0x31f7
    30b0:	48 be 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rsi
    30b7:	79 37 9e 
    30ba:	48 8b bd 40 fb ff ff 	mov    -0x4c0(%rbp),%rdi
    30c1:	49 89 fb             	mov    %rdi,%r11
    30c4:	49 c1 eb 2b          	shr    $0x2b,%r11
    30c8:	48 89 fa             	mov    %rdi,%rdx
    30cb:	48 c1 ea 2c          	shr    $0x2c,%rdx
    30cf:	49 31 d3             	xor    %rdx,%r11
    30d2:	48 89 fa             	mov    %rdi,%rdx
    30d5:	4c 31 da             	xor    %r11,%rdx
    30d8:	48 0f af d6          	imul   %rsi,%rdx
    30dc:	48 89 d6             	mov    %rdx,%rsi
    30df:	48 c1 ee 1e          	shr    $0x1e,%rsi
    30e3:	49 89 d3             	mov    %rdx,%r11
    30e6:	49 31 f3             	xor    %rsi,%r11
    30e9:	48 be b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rsi
    30f0:	47 58 bf 
    30f3:	4c 0f af de          	imul   %rsi,%r11
    30f7:	4c 89 de             	mov    %r11,%rsi
    30fa:	48 c1 ee 1b          	shr    $0x1b,%rsi
    30fe:	49 31 f3             	xor    %rsi,%r11
    3101:	48 be eb 11 31 13 bb 	movabs $0x94d049bb133111eb,%rsi
    3108:	49 d0 94 
    310b:	4c 0f af de          	imul   %rsi,%r11
    310f:	4c 89 de             	mov    %r11,%rsi
    3112:	48 c1 ee 1f          	shr    $0x1f,%rsi
    3116:	49 31 f3             	xor    %rsi,%r11
    3119:	be 40 00 00 00       	mov    $0x40,%esi
    311e:	48 29 ce             	sub    %rcx,%rsi
    3121:	48 89 f1             	mov    %rsi,%rcx
    3124:	49 d3 eb             	shr    %cl,%r11
    3127:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
    312b:	4c 89 d9             	mov    %r11,%rcx
    312e:	48 89 f7             	mov    %rsi,%rdi
    3131:	48 d3 ef             	shr    %cl,%rdi
    3134:	48 21 c7             	and    %rax,%rdi
    3137:	48 85 ff             	test   %rdi,%rdi
    313a:	0f 84 b7 00 00 00    	je     0x31f7
    3140:	48 8d 8d e0 fd ff ff 	lea    -0x220(%rbp),%rcx
    3147:	48 89 cf             	mov    %rcx,%rdi
    314a:	48 8b 8d 20 fb ff ff 	mov    -0x4e0(%rbp),%rcx
    3151:	48 63 31             	movslq (%rcx),%rsi
    3154:	31 c9                	xor    %ecx,%ecx
    3156:	48 89 0f             	mov    %rcx,(%rdi)
    3159:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    315d:	4c 89 47 10          	mov    %r8,0x10(%rdi)
    3161:	48 8b 8d 38 fb ff ff 	mov    -0x4c8(%rbp),%rcx
    3168:	48 63 31             	movslq (%rcx),%rsi
    316b:	45 31 c0             	xor    %r8d,%r8d
    316e:	4c 89 47 18          	mov    %r8,0x18(%rdi)
    3172:	48 89 77 20          	mov    %rsi,0x20(%rdi)
    3176:	48 8b b5 28 fb ff ff 	mov    -0x4d8(%rbp),%rsi
    317d:	48 89 77 28          	mov    %rsi,0x28(%rdi)
    3181:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    3187:	48 8b b5 50 fc ff ff 	mov    -0x3b0(%rbp),%rsi
    318e:	48 89 f1             	mov    %rsi,%rcx
    3191:	49 d3 e0             	shl    %cl,%r8
    3194:	4d 01 d8             	add    %r11,%r8
    3197:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    319c:	41 bb 02 00 00 00    	mov    $0x2,%r11d
    31a2:	48 89 bd 20 fb ff ff 	mov    %rdi,-0x4e0(%rbp)
    31a9:	4c 89 cf             	mov    %r9,%rdi
    31ac:	48 89 ce             	mov    %rcx,%rsi
    31af:	48 89 95 10 fb ff ff 	mov    %rdx,-0x4f0(%rbp)
    31b6:	48 8b 95 50 fc ff ff 	mov    -0x3b0(%rbp),%rdx
    31bd:	4c 89 c1             	mov    %r8,%rcx
    31c0:	4c 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%r8
    31c7:	4c 8b 8d 20 fb ff ff 	mov    -0x4e0(%rbp),%r9
    31ce:	4c 89 1c 24          	mov    %r11,(%rsp)
    31d2:	e8 f9 ce ff ff       	call   0xd0
    31d7:	48 83 f8 00          	cmp    $0x0,%rax
    31db:	0f 8d 11 00 00 00    	jge    0x31f2
    31e1:	b8 80 00 00 00       	mov    $0x80,%eax
    31e6:	48 89 85 48 fb ff ff 	mov    %rax,-0x4b8(%rbp)
    31ed:	e9 14 3f 00 00       	jmp    0x7106
    31f2:	e9 8b 0c 00 00       	jmp    0x3e82
    31f7:	49 83 fd 05          	cmp    $0x5,%r13
    31fb:	0f 85 d1 00 00 00    	jne    0x32d2
    3201:	48 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%rax
    3208:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    320f:	48 89 c2             	mov    %rax,%rdx
    3212:	48 29 ca             	sub    %rcx,%rdx
    3215:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    321c:	48 39 f2             	cmp    %rsi,%rdx
    321f:	bf 00 00 00 00       	mov    $0x0,%edi
    3224:	40 0f 92 c7          	setb   %dil
    3228:	45 31 c0             	xor    %r8d,%r8d
    322b:	48 85 ff             	test   %rdi,%rdi
    322e:	49 0f 44 d0          	cmove  %r8,%rdx
    3232:	49 89 d1             	mov    %rdx,%r9
    3235:	49 c1 e9 06          	shr    $0x6,%r9
    3239:	48 83 e2 3f          	and    $0x3f,%rdx
    323d:	4c 8b 95 70 fc ff ff 	mov    -0x390(%rbp),%r10
    3244:	4f 8d 1c ca          	lea    (%r10,%r9,8),%r11
    3248:	49 8b 03             	mov    (%r11),%rax
    324b:	48 89 d1             	mov    %rdx,%rcx
    324e:	48 d3 e8             	shr    %cl,%rax
    3251:	b9 01 00 00 00       	mov    $0x1,%ecx
    3256:	48 21 c8             	and    %rcx,%rax
    3259:	48 21 f8             	and    %rdi,%rax
    325c:	48 8b bd 48 fc ff ff 	mov    -0x3b8(%rbp),%rdi
    3263:	4e 8d 1c cf          	lea    (%rdi,%r9,8),%r11
    3267:	49 8b 3b             	mov    (%r11),%rdi
    326a:	48 89 d1             	mov    %rdx,%rcx
    326d:	48 d3 ef             	shr    %cl,%rdi
    3270:	b9 01 00 00 00       	mov    $0x1,%ecx
    3275:	48 21 cf             	and    %rcx,%rdi
    3278:	4c 8b 9d 58 fc ff ff 	mov    -0x3a8(%rbp),%r11
    327f:	4b 8d 34 cb          	lea    (%r11,%r9,8),%rsi
    3283:	4c 8b 0e             	mov    (%rsi),%r9
    3286:	48 89 d1             	mov    %rdx,%rcx
    3289:	49 d3 e9             	shr    %cl,%r9
    328c:	b9 01 00 00 00       	mov    $0x1,%ecx
    3291:	49 21 c9             	and    %rcx,%r9
    3294:	48 8d 95 c0 fd ff ff 	lea    -0x240(%rbp),%rdx
    329b:	48 89 d6             	mov    %rdx,%rsi
    329e:	49 c1 e1 20          	shl    $0x20,%r9
    32a2:	48 8b 95 40 fb ff ff 	mov    -0x4c0(%rbp),%rdx
    32a9:	48 89 16             	mov    %rdx,(%rsi)
    32ac:	4c 89 4e 08          	mov    %r9,0x8(%rsi)
    32b0:	48 89 7e 10          	mov    %rdi,0x10(%rsi)
    32b4:	4c 39 c0             	cmp    %r8,%rax
    32b7:	b8 00 00 00 00       	mov    $0x0,%eax
    32bc:	0f 95 c0             	setne  %al
    32bf:	48 85 c0             	test   %rax,%rax
    32c2:	49 0f 44 f0          	cmove  %r8,%rsi
    32c6:	48 89 b5 20 fb ff ff 	mov    %rsi,-0x4e0(%rbp)
    32cd:	e9 0c 04 00 00       	jmp    0x36de
    32d2:	49 83 fd 01          	cmp    $0x1,%r13
    32d6:	0f 85 09 03 00 00    	jne    0x35e5
    32dc:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    32e3:	79 37 9e 
    32e6:	48 8b 8d 40 fb ff ff 	mov    -0x4c0(%rbp),%rcx
    32ed:	48 89 ca             	mov    %rcx,%rdx
    32f0:	48 c1 ea 2b          	shr    $0x2b,%rdx
    32f4:	48 89 ce             	mov    %rcx,%rsi
    32f7:	48 c1 ee 2c          	shr    $0x2c,%rsi
    32fb:	48 31 f2             	xor    %rsi,%rdx
    32fe:	48 89 ce             	mov    %rcx,%rsi
    3301:	48 31 d6             	xor    %rdx,%rsi
    3304:	48 0f af f0          	imul   %rax,%rsi
    3308:	48 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%rax
    330f:	48 85 c0             	test   %rax,%rax
    3312:	48 89 b5 10 fb ff ff 	mov    %rsi,-0x4f0(%rbp)
    3319:	0f 84 10 01 00 00    	je     0x342f
    331f:	ba 40 00 00 00       	mov    $0x40,%edx
    3324:	48 8b bd 88 fc ff ff 	mov    -0x378(%rbp),%rdi
    332b:	48 29 fa             	sub    %rdi,%rdx
    332e:	48 89 d1             	mov    %rdx,%rcx
    3331:	49 89 f0             	mov    %rsi,%r8
    3334:	49 d3 e8             	shr    %cl,%r8
    3337:	31 c9                	xor    %ecx,%ecx
    3339:	48 39 cf             	cmp    %rcx,%rdi
    333c:	ba 00 00 00 00       	mov    $0x0,%edx
    3341:	0f 94 c2             	sete   %dl
    3344:	48 85 d2             	test   %rdx,%rdx
    3347:	49 0f 44 c8          	cmove  %r8,%rcx
    334b:	49 8d 14 cf          	lea    (%r15,%rcx,8),%rdx
    334f:	48 8b 0a             	mov    (%rdx),%rcx
    3352:	48 89 f2             	mov    %rsi,%rdx
    3355:	48 c1 ea 20          	shr    $0x20,%rdx
    3359:	49 89 f0             	mov    %rsi,%r8
    335c:	49 31 d0             	xor    %rdx,%r8
    335f:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    3364:	49 21 d0             	and    %rdx,%r8
    3367:	4c 89 c2             	mov    %r8,%rdx
    336a:	48 83 e2 3f          	and    $0x3f,%rdx
    336e:	48 89 8d 30 fb ff ff 	mov    %rcx,-0x4d0(%rbp)
    3375:	41 b9 01 00 00 00    	mov    $0x1,%r9d
    337b:	48 89 d1             	mov    %rdx,%rcx
    337e:	4d 89 ca             	mov    %r9,%r10
    3381:	49 d3 e2             	shl    %cl,%r10
    3384:	4c 89 c1             	mov    %r8,%rcx
    3387:	48 c1 e9 06          	shr    $0x6,%rcx
    338b:	48 83 e1 3f          	and    $0x3f,%rcx
    338f:	48 89 8d 18 fb ff ff 	mov    %rcx,-0x4e8(%rbp)
    3396:	48 8b 95 18 fb ff ff 	mov    -0x4e8(%rbp),%rdx
    339d:	48 89 d1             	mov    %rdx,%rcx
    33a0:	4d 89 cb             	mov    %r9,%r11
    33a3:	49 d3 e3             	shl    %cl,%r11
    33a6:	4d 09 da             	or     %r11,%r10
    33a9:	4c 89 c1             	mov    %r8,%rcx
    33ac:	48 c1 e9 0c          	shr    $0xc,%rcx
    33b0:	48 83 e1 3f          	and    $0x3f,%rcx
    33b4:	48 89 8d 18 fb ff ff 	mov    %rcx,-0x4e8(%rbp)
    33bb:	48 8b 95 18 fb ff ff 	mov    -0x4e8(%rbp),%rdx
    33c2:	48 89 d1             	mov    %rdx,%rcx
    33c5:	4d 89 cb             	mov    %r9,%r11
    33c8:	49 d3 e3             	shl    %cl,%r11
    33cb:	4d 09 da             	or     %r11,%r10
    33ce:	49 c1 e8 12          	shr    $0x12,%r8
    33d2:	49 83 e0 3f          	and    $0x3f,%r8
    33d6:	4c 89 c1             	mov    %r8,%rcx
    33d9:	4c 89 ca             	mov    %r9,%rdx
    33dc:	48 d3 e2             	shl    %cl,%rdx
    33df:	49 09 d2             	or     %rdx,%r10
    33e2:	48 8b 8d 30 fb ff ff 	mov    -0x4d0(%rbp),%rcx
    33e9:	4c 21 d1             	and    %r10,%rcx
    33ec:	4c 39 d1             	cmp    %r10,%rcx
    33ef:	b9 00 00 00 00       	mov    $0x0,%ecx
    33f4:	0f 94 c1             	sete   %cl
    33f7:	ba 01 00 00 00       	mov    $0x1,%edx
    33fc:	49 b8 00 00 00 00 01 	movabs $0x100000000,%r8
    3403:	00 00 00 
    3406:	48 85 c9             	test   %rcx,%rcx
    3409:	49 0f 44 d0          	cmove  %r8,%rdx
    340d:	4c 8b 43 08          	mov    0x8(%rbx),%r8
    3411:	49 01 d0             	add    %rdx,%r8
    3414:	4c 89 43 08          	mov    %r8,0x8(%rbx)
    3418:	48 85 c9             	test   %rcx,%rcx
    341b:	0f 85 f3 00 00 00    	jne    0x3514
    3421:	31 c9                	xor    %ecx,%ecx
    3423:	48 89 8d 20 fb ff ff 	mov    %rcx,-0x4e0(%rbp)
    342a:	e9 b1 01 00 00       	jmp    0x35e0
    342f:	b8 40 00 00 00       	mov    $0x40,%eax
    3434:	48 8b 8d 88 fc ff ff 	mov    -0x378(%rbp),%rcx
    343b:	48 29 c8             	sub    %rcx,%rax
    343e:	48 8b 95 10 fb ff ff 	mov    -0x4f0(%rbp),%rdx
    3445:	48 89 c1             	mov    %rax,%rcx
    3448:	48 89 d6             	mov    %rdx,%rsi
    344b:	48 d3 ee             	shr    %cl,%rsi
    344e:	31 c0                	xor    %eax,%eax
    3450:	48 8b 8d 88 fc ff ff 	mov    -0x378(%rbp),%rcx
    3457:	48 39 c1             	cmp    %rax,%rcx
    345a:	bf 00 00 00 00       	mov    $0x0,%edi
    345f:	40 0f 94 c7          	sete   %dil
    3463:	48 85 ff             	test   %rdi,%rdi
    3466:	48 0f 44 c6          	cmove  %rsi,%rax
    346a:	49 8d 34 c7          	lea    (%r15,%rax,8),%rsi
    346e:	48 8b 06             	mov    (%rsi),%rax
    3471:	48 89 d6             	mov    %rdx,%rsi
    3474:	48 c1 ee 20          	shr    $0x20,%rsi
    3478:	48 89 d7             	mov    %rdx,%rdi
    347b:	48 31 f7             	xor    %rsi,%rdi
    347e:	be ff ff ff ff       	mov    $0xffffffff,%esi
    3483:	48 21 f7             	and    %rsi,%rdi
    3486:	48 89 fe             	mov    %rdi,%rsi
    3489:	48 83 e6 3f          	and    $0x3f,%rsi
    348d:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    3493:	48 89 f1             	mov    %rsi,%rcx
    3496:	4d 89 c1             	mov    %r8,%r9
    3499:	49 d3 e1             	shl    %cl,%r9
    349c:	48 89 f9             	mov    %rdi,%rcx
    349f:	48 c1 e9 06          	shr    $0x6,%rcx
    34a3:	48 83 e1 3f          	and    $0x3f,%rcx
    34a7:	48 89 8d 30 fb ff ff 	mov    %rcx,-0x4d0(%rbp)
    34ae:	48 8b b5 30 fb ff ff 	mov    -0x4d0(%rbp),%rsi
    34b5:	48 89 f1             	mov    %rsi,%rcx
    34b8:	4d 89 c2             	mov    %r8,%r10
    34bb:	49 d3 e2             	shl    %cl,%r10
    34be:	4d 09 d1             	or     %r10,%r9
    34c1:	48 89 f9             	mov    %rdi,%rcx
    34c4:	48 c1 e9 0c          	shr    $0xc,%rcx
    34c8:	48 83 e1 3f          	and    $0x3f,%rcx
    34cc:	48 89 8d 30 fb ff ff 	mov    %rcx,-0x4d0(%rbp)
    34d3:	48 8b b5 30 fb ff ff 	mov    -0x4d0(%rbp),%rsi
    34da:	48 89 f1             	mov    %rsi,%rcx
    34dd:	4d 89 c2             	mov    %r8,%r10
    34e0:	49 d3 e2             	shl    %cl,%r10
    34e3:	4d 09 d1             	or     %r10,%r9
    34e6:	48 c1 ef 12          	shr    $0x12,%rdi
    34ea:	48 83 e7 3f          	and    $0x3f,%rdi
    34ee:	48 89 f9             	mov    %rdi,%rcx
    34f1:	4c 89 c6             	mov    %r8,%rsi
    34f4:	48 d3 e6             	shl    %cl,%rsi
    34f7:	49 09 f1             	or     %rsi,%r9
    34fa:	4c 21 c8             	and    %r9,%rax
    34fd:	4c 39 c8             	cmp    %r9,%rax
    3500:	0f 84 0e 00 00 00    	je     0x3514
    3506:	31 c0                	xor    %eax,%eax
    3508:	48 89 85 20 fb ff ff 	mov    %rax,-0x4e0(%rbp)
    350f:	e9 cc 00 00 00       	jmp    0x35e0
    3514:	b8 40 00 00 00       	mov    $0x40,%eax
    3519:	48 8b 8d 78 fc ff ff 	mov    -0x388(%rbp),%rcx
    3520:	48 29 c8             	sub    %rcx,%rax
    3523:	48 8b 95 10 fb ff ff 	mov    -0x4f0(%rbp),%rdx
    352a:	48 89 c1             	mov    %rax,%rcx
    352d:	48 89 d6             	mov    %rdx,%rsi
    3530:	48 d3 ee             	shr    %cl,%rsi
    3533:	31 c0                	xor    %eax,%eax
    3535:	48 8b 8d 78 fc ff ff 	mov    -0x388(%rbp),%rcx
    353c:	48 39 c1             	cmp    %rax,%rcx
    353f:	bf 00 00 00 00       	mov    $0x0,%edi
    3544:	40 0f 94 c7          	sete   %dil
    3548:	48 85 ff             	test   %rdi,%rdi
    354b:	48 0f 44 c6          	cmove  %rsi,%rax
    354f:	48 8b b5 70 fc ff ff 	mov    -0x390(%rbp),%rsi
    3556:	48 8d 3c c6          	lea    (%rsi,%rax,8),%rdi
    355a:	48 8b 07             	mov    (%rdi),%rax
    355d:	48 bf ff ff ff ff ff 	movabs $0xffffffffffff,%rdi
    3564:	ff 00 00 
    3567:	49 89 c0             	mov    %rax,%r8
    356a:	49 21 f8             	and    %rdi,%r8
    356d:	31 ff                	xor    %edi,%edi
    356f:	49 39 f8             	cmp    %rdi,%r8
    3572:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    3578:	41 0f 94 c1          	sete   %r9b
    357c:	49 89 d2             	mov    %rdx,%r10
    357f:	49 c1 ea 20          	shr    $0x20,%r10
    3583:	4c 31 d2             	xor    %r10,%rdx
    3586:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
    358c:	4c 21 d2             	and    %r10,%rdx
    358f:	48 83 e2 0f          	and    $0xf,%rdx
    3593:	48 83 c2 30          	add    $0x30,%rdx
    3597:	48 89 d1             	mov    %rdx,%rcx
    359a:	48 d3 e8             	shr    %cl,%rax
    359d:	48 83 e0 01          	and    $0x1,%rax
    35a1:	48 83 f8 00          	cmp    $0x0,%rax
    35a5:	b8 00 00 00 00       	mov    $0x0,%eax
    35aa:	0f 95 c0             	setne  %al
    35ad:	b9 01 00 00 00       	mov    $0x1,%ecx
    35b2:	48 31 c8             	xor    %rcx,%rax
    35b5:	49 09 c1             	or     %rax,%r9
    35b8:	b8 01 00 00 00       	mov    $0x1,%eax
    35bd:	49 29 c0             	sub    %rax,%r8
    35c0:	b9 18 00 00 00       	mov    $0x18,%ecx
    35c5:	4c 0f af c1          	imul   %rcx,%r8
    35c9:	4c 89 f1             	mov    %r14,%rcx
    35cc:	4c 01 c1             	add    %r8,%rcx
    35cf:	48 89 fa             	mov    %rdi,%rdx
    35d2:	4d 85 c9             	test   %r9,%r9
    35d5:	48 0f 44 d1          	cmove  %rcx,%rdx
    35d9:	48 89 95 20 fb ff ff 	mov    %rdx,-0x4e0(%rbp)
    35e0:	e9 f9 00 00 00       	jmp    0x36de
    35e5:	48 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%rax
    35ec:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    35f3:	48 89 c2             	mov    %rax,%rdx
    35f6:	48 29 ca             	sub    %rcx,%rdx
    35f9:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    3600:	48 39 f2             	cmp    %rsi,%rdx
    3603:	0f 82 0e 00 00 00    	jb     0x3617
    3609:	31 ff                	xor    %edi,%edi
    360b:	48 89 bd 20 fb ff ff 	mov    %rdi,-0x4e0(%rbp)
    3612:	e9 c7 00 00 00       	jmp    0x36de
    3617:	49 83 fd 02          	cmp    $0x2,%r13
    361b:	48 89 95 10 fb ff ff 	mov    %rdx,-0x4f0(%rbp)
    3622:	0f 85 6a 00 00 00    	jne    0x3692
    3628:	48 89 d7             	mov    %rdx,%rdi
    362b:	48 c1 ef 06          	shr    $0x6,%rdi
    362f:	4c 8b 85 70 fc ff ff 	mov    -0x390(%rbp),%r8
    3636:	4d 8d 0c f8          	lea    (%r8,%rdi,8),%r9
    363a:	49 8b 39             	mov    (%r9),%rdi
    363d:	49 89 d1             	mov    %rdx,%r9
    3640:	49 83 e1 3f          	and    $0x3f,%r9
    3644:	4c 89 c9             	mov    %r9,%rcx
    3647:	48 d3 ef             	shr    %cl,%rdi
    364a:	b9 01 00 00 00       	mov    $0x1,%ecx
    364f:	48 21 cf             	and    %rcx,%rdi
    3652:	45 31 c9             	xor    %r9d,%r9d
    3655:	4c 39 cf             	cmp    %r9,%rdi
    3658:	bf 00 00 00 00       	mov    $0x0,%edi
    365d:	40 0f 95 c7          	setne  %dil
    3661:	41 ba 10 00 00 00    	mov    $0x10,%r10d
    3667:	49 89 d3             	mov    %rdx,%r11
    366a:	4d 0f af da          	imul   %r10,%r11
    366e:	4c 8b 95 80 fc ff ff 	mov    -0x380(%rbp),%r10
    3675:	4c 89 d2             	mov    %r10,%rdx
    3678:	4c 01 da             	add    %r11,%rdx
    367b:	48 83 ea 08          	sub    $0x8,%rdx
    367f:	48 85 ff             	test   %rdi,%rdi
    3682:	49 0f 44 d1          	cmove  %r9,%rdx
    3686:	48 89 95 20 fb ff ff 	mov    %rdx,-0x4e0(%rbp)
    368d:	e9 4c 00 00 00       	jmp    0x36de
    3692:	48 8b 85 70 fc ff ff 	mov    -0x390(%rbp),%rax
    3699:	48 8b 8d 10 fb ff ff 	mov    -0x4f0(%rbp),%rcx
    36a0:	48 8d 14 88          	lea    (%rax,%rcx,4),%rdx
    36a4:	8b 0a                	mov    (%rdx),%ecx
    36a6:	ba 01 00 00 00       	mov    $0x1,%edx
    36ab:	48 89 ce             	mov    %rcx,%rsi
    36ae:	48 29 d6             	sub    %rdx,%rsi
    36b1:	bf 18 00 00 00       	mov    $0x18,%edi
    36b6:	48 0f af f7          	imul   %rdi,%rsi
    36ba:	4c 89 f7             	mov    %r14,%rdi
    36bd:	48 01 f7             	add    %rsi,%rdi
    36c0:	31 f6                	xor    %esi,%esi
    36c2:	48 39 f1             	cmp    %rsi,%rcx
    36c5:	b9 00 00 00 00       	mov    $0x0,%ecx
    36ca:	0f 94 c1             	sete   %cl
    36cd:	49 89 f0             	mov    %rsi,%r8
    36d0:	48 85 c9             	test   %rcx,%rcx
    36d3:	4c 0f 44 c7          	cmove  %rdi,%r8
    36d7:	4c 89 85 20 fb ff ff 	mov    %r8,-0x4e0(%rbp)
    36de:	49 83 fd 01          	cmp    $0x1,%r13
    36e2:	be 00 00 00 00       	mov    $0x0,%esi
    36e7:	40 0f 95 c6          	setne  %sil
    36eb:	31 ff                	xor    %edi,%edi
    36ed:	48 8b 85 68 fb ff ff 	mov    -0x498(%rbp),%rax
    36f4:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    36fb:	48 8b 85 80 fb ff ff 	mov    -0x480(%rbp),%rax
    3702:	48 89 85 30 fb ff ff 	mov    %rax,-0x4d0(%rbp)
    3709:	48 8b 85 58 fb ff ff 	mov    -0x4a8(%rbp),%rax
    3710:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    3717:	48 8b 85 50 fb ff ff 	mov    -0x4b0(%rbp),%rax
    371e:	48 89 85 08 fb ff ff 	mov    %rax,-0x4f8(%rbp)
    3725:	48 8b 85 70 fb ff ff 	mov    -0x490(%rbp),%rax
    372c:	48 89 85 00 fb ff ff 	mov    %rax,-0x500(%rbp)
    3733:	48 8b 85 78 fb ff ff 	mov    -0x488(%rbp),%rax
    373a:	48 89 85 f8 fa ff ff 	mov    %rax,-0x508(%rbp)
    3741:	48 8b 85 88 fb ff ff 	mov    -0x478(%rbp),%rax
    3748:	48 89 85 f0 fa ff ff 	mov    %rax,-0x510(%rbp)
    374f:	48 8b 85 c8 fb ff ff 	mov    -0x438(%rbp),%rax
    3756:	48 89 85 e8 fa ff ff 	mov    %rax,-0x518(%rbp)
    375d:	48 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%rax
    3764:	48 85 c0             	test   %rax,%rax
    3767:	0f 85 75 00 00 00    	jne    0x37e2
    376d:	48 8b 8d 10 fb ff ff 	mov    -0x4f0(%rbp),%rcx
    3774:	48 89 8d 68 fb ff ff 	mov    %rcx,-0x498(%rbp)
    377b:	48 8b 8d 30 fb ff ff 	mov    -0x4d0(%rbp),%rcx
    3782:	48 89 8d 80 fb ff ff 	mov    %rcx,-0x480(%rbp)
    3789:	48 8b 8d 18 fb ff ff 	mov    -0x4e8(%rbp),%rcx
    3790:	48 89 8d 58 fb ff ff 	mov    %rcx,-0x4a8(%rbp)
    3797:	48 8b 8d 08 fb ff ff 	mov    -0x4f8(%rbp),%rcx
    379e:	48 89 8d 50 fb ff ff 	mov    %rcx,-0x4b0(%rbp)
    37a5:	48 8b 8d 00 fb ff ff 	mov    -0x500(%rbp),%rcx
    37ac:	48 89 8d 70 fb ff ff 	mov    %rcx,-0x490(%rbp)
    37b3:	48 8b 8d f8 fa ff ff 	mov    -0x508(%rbp),%rcx
    37ba:	48 89 8d 78 fb ff ff 	mov    %rcx,-0x488(%rbp)
    37c1:	48 8b 8d f0 fa ff ff 	mov    -0x510(%rbp),%rcx
    37c8:	48 89 8d 88 fb ff ff 	mov    %rcx,-0x478(%rbp)
    37cf:	48 8b 8d e8 fa ff ff 	mov    -0x518(%rbp),%rcx
    37d6:	48 89 8d c8 fb ff ff 	mov    %rcx,-0x438(%rbp)
    37dd:	e9 9b 06 00 00       	jmp    0x3e7d
    37e2:	48 8b 48 08          	mov    0x8(%rax),%rcx
    37e6:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    37eb:	49 89 c8             	mov    %rcx,%r8
    37ee:	49 21 d0             	and    %rdx,%r8
    37f1:	ba 01 00 00 00       	mov    $0x1,%edx
    37f6:	4d 89 c1             	mov    %r8,%r9
    37f9:	49 29 d1             	sub    %rdx,%r9
    37fc:	41 ba 18 00 00 00    	mov    $0x18,%r10d
    3802:	4d 0f af ca          	imul   %r10,%r9
    3806:	4d 89 f2             	mov    %r14,%r10
    3809:	4d 01 ca             	add    %r9,%r10
    380c:	45 31 c9             	xor    %r9d,%r9d
    380f:	4d 39 c8             	cmp    %r9,%r8
    3812:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    3818:	41 0f 94 c0          	sete   %r8b
    381c:	4d 89 cb             	mov    %r9,%r11
    381f:	4d 85 c0             	test   %r8,%r8
    3822:	4d 0f 44 da          	cmove  %r10,%r11
    3826:	4c 8b 00             	mov    (%rax),%r8
    3829:	4c 8b 95 40 fb ff ff 	mov    -0x4c0(%rbp),%r10
    3830:	4d 39 c2             	cmp    %r8,%r10
    3833:	b8 00 00 00 00       	mov    $0x0,%eax
    3838:	0f 94 c0             	sete   %al
    383b:	48 09 f0             	or     %rsi,%rax
    383e:	49 89 f8             	mov    %rdi,%r8
    3841:	49 01 d0             	add    %rdx,%r8
    3844:	48 85 c0             	test   %rax,%rax
    3847:	0f 85 0c 00 00 00    	jne    0x3859
    384d:	4c 89 9d 20 fb ff ff 	mov    %r11,-0x4e0(%rbp)
    3854:	e9 04 ff ff ff       	jmp    0x375d
    3859:	48 8b 03             	mov    (%rbx),%rax
    385c:	48 39 c7             	cmp    %rax,%rdi
    385f:	0f 8d 0f 00 00 00    	jge    0x3874
    3865:	4c 89 9d 20 fb ff ff 	mov    %r11,-0x4e0(%rbp)
    386c:	4c 89 c7             	mov    %r8,%rdi
    386f:	e9 e9 fe ff ff       	jmp    0x375d
    3874:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    387b:	48 8b 70 18          	mov    0x18(%rax),%rsi
    387f:	48 85 f6             	test   %rsi,%rsi
    3882:	48 89 8d 40 fb ff ff 	mov    %rcx,-0x4c0(%rbp)
    3889:	4c 89 85 e0 fa ff ff 	mov    %r8,-0x520(%rbp)
    3890:	0f 84 0c 00 00 00    	je     0x38a2
    3896:	0f b6 3e             	movzbl (%rsi),%edi
    3899:	48 85 ff             	test   %rdi,%rdi
    389c:	0f 85 fe 05 00 00    	jne    0x3ea0
    38a2:	48 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%rax
    38a9:	48 8b 48 10          	mov    0x10(%rax),%rcx
    38ad:	48 8b 95 40 fb ff ff 	mov    -0x4c0(%rbp),%rdx
    38b4:	48 89 d6             	mov    %rdx,%rsi
    38b7:	48 c1 ee 20          	shr    $0x20,%rsi
    38bb:	48 83 e6 01          	and    $0x1,%rsi
    38bf:	48 83 fe 00          	cmp    $0x0,%rsi
    38c3:	be 00 00 00 00       	mov    $0x0,%esi
    38c8:	40 0f 95 c6          	setne  %sil
    38cc:	48 8b bd e0 fa ff ff 	mov    -0x520(%rbp),%rdi
    38d3:	48 89 3b             	mov    %rdi,(%rbx)
    38d6:	4c 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%r8
    38dd:	4d 89 c1             	mov    %r8,%r9
    38e0:	49 83 c1 01          	add    $0x1,%r9
    38e4:	48 63 c9             	movslq %ecx,%rcx
    38e7:	45 31 d2             	xor    %r10d,%r10d
    38ea:	48 85 f6             	test   %rsi,%rsi
    38ed:	4c 0f 44 d1          	cmove  %rcx,%r10
    38f1:	48 8b 8d 30 fb ff ff 	mov    -0x4d0(%rbp),%rcx
    38f8:	4c 39 d1             	cmp    %r10,%rcx
    38fb:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    3901:	41 0f 94 c3          	sete   %r11b
    3905:	48 8b 85 18 fb ff ff 	mov    -0x4e8(%rbp),%rax
    390c:	48 39 f0             	cmp    %rsi,%rax
    390f:	ba 00 00 00 00       	mov    $0x0,%edx
    3914:	0f 94 c2             	sete   %dl
    3917:	49 21 d3             	and    %rdx,%r11
    391a:	4d 85 db             	test   %r11,%r11
    391d:	48 89 b5 d8 fa ff ff 	mov    %rsi,-0x528(%rbp)
    3924:	4c 89 8d d0 fa ff ff 	mov    %r9,-0x530(%rbp)
    392b:	4c 89 95 c8 fa ff ff 	mov    %r10,-0x538(%rbp)
    3932:	0f 84 83 00 00 00    	je     0x39bb
    3938:	48 8b 95 f8 fa ff ff 	mov    -0x508(%rbp),%rdx
    393f:	49 89 d3             	mov    %rdx,%r11
    3942:	49 83 c3 01          	add    $0x1,%r11
    3946:	be 01 00 00 00       	mov    $0x1,%esi
    394b:	4c 8b 95 38 fb ff ff 	mov    -0x4c8(%rbp),%r10
    3952:	4d 63 0a             	movslq (%r10),%r9
    3955:	4c 8b 95 28 fb ff ff 	mov    -0x4d8(%rbp),%r10
    395c:	4c 89 d2             	mov    %r10,%rdx
    395f:	48 31 f2             	xor    %rsi,%rdx
    3962:	31 f6                	xor    %esi,%esi
    3964:	48 85 d2             	test   %rdx,%rdx
    3967:	4c 0f 44 ce          	cmove  %rsi,%r9
    396b:	48 8b b5 e8 fa ff ff 	mov    -0x518(%rbp),%rsi
    3972:	49 89 f2             	mov    %rsi,%r10
    3975:	49 01 d2             	add    %rdx,%r10
    3978:	48 8b 95 f0 fa ff ff 	mov    -0x510(%rbp),%rdx
    397f:	48 89 d6             	mov    %rdx,%rsi
    3982:	4c 01 ce             	add    %r9,%rsi
    3985:	48 89 8d 80 fb ff ff 	mov    %rcx,-0x480(%rbp)
    398c:	48 89 85 58 fb ff ff 	mov    %rax,-0x4a8(%rbp)
    3993:	4c 8b 8d 08 fb ff ff 	mov    -0x4f8(%rbp),%r9
    399a:	4c 89 8d 50 fb ff ff 	mov    %r9,-0x4b0(%rbp)
    39a1:	4c 89 9d 78 fb ff ff 	mov    %r11,-0x488(%rbp)
    39a8:	48 89 b5 88 fb ff ff 	mov    %rsi,-0x478(%rbp)
    39af:	4c 89 95 c8 fb ff ff 	mov    %r10,-0x438(%rbp)
    39b6:	e9 a8 04 00 00       	jmp    0x3e63
    39bb:	48 8b 85 00 fb ff ff 	mov    -0x500(%rbp),%rax
    39c2:	48 85 c0             	test   %rax,%rax
    39c5:	0f 84 fc 03 00 00    	je     0x3dc7
    39cb:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    39d2:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    39d6:	48 85 d2             	test   %rdx,%rdx
    39d9:	0f 84 40 01 00 00    	je     0x3b1f
    39df:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    39e3:	be 40 00 00 00       	mov    $0x40,%esi
    39e8:	48 29 d6             	sub    %rdx,%rsi
    39eb:	48 8b bd 08 fb ff ff 	mov    -0x4f8(%rbp),%rdi
    39f2:	48 89 f1             	mov    %rsi,%rcx
    39f5:	49 89 f8             	mov    %rdi,%r8
    39f8:	49 d3 e8             	shr    %cl,%r8
    39fb:	31 c9                	xor    %ecx,%ecx
    39fd:	48 39 ca             	cmp    %rcx,%rdx
    3a00:	ba 00 00 00 00       	mov    $0x0,%edx
    3a05:	0f 94 c2             	sete   %dl
    3a08:	48 85 d2             	test   %rdx,%rdx
    3a0b:	49 0f 44 c8          	cmove  %r8,%rcx
    3a0f:	48 8b 95 90 fc ff ff 	mov    -0x370(%rbp),%rdx
    3a16:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    3a1a:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    3a1e:	49 8b 30             	mov    (%r8),%rsi
    3a21:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    3a28:	00 28 00 
    3a2b:	4c 39 ce             	cmp    %r9,%rsi
    3a2e:	4c 89 85 c0 fa ff ff 	mov    %r8,-0x540(%rbp)
    3a35:	0f 82 0c 00 00 00    	jb     0x3a47
    3a3b:	48 89 b5 b8 fa ff ff 	mov    %rsi,-0x548(%rbp)
    3a42:	e9 4a 00 00 00       	jmp    0x3a91
    3a47:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    3a4b:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    3a52:	48 89 b5 b0 fa ff ff 	mov    %rsi,-0x550(%rbp)
    3a59:	48 89 d6             	mov    %rdx,%rsi
    3a5c:	48 89 ca             	mov    %rcx,%rdx
    3a5f:	48 8b 8d b0 fa ff ff 	mov    -0x550(%rbp),%rcx
    3a66:	e8 75 c6 ff ff       	call   0xe0
    3a6b:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    3a72:	31 d2                	xor    %edx,%edx
    3a74:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    3a78:	48 83 f8 00          	cmp    $0x0,%rax
    3a7c:	0f 8f 08 00 00 00    	jg     0x3a8a
    3a82:	49 89 c4             	mov    %rax,%r12
    3a85:	e9 9d 36 00 00       	jmp    0x7127
    3a8a:	48 89 85 b8 fa ff ff 	mov    %rax,-0x548(%rbp)
    3a91:	48 8b 85 b8 fa ff ff 	mov    -0x548(%rbp),%rax
    3a98:	48 89 c1             	mov    %rax,%rcx
    3a9b:	48 83 c1 28          	add    $0x28,%rcx
    3a9f:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    3aa6:	00 28 00 
    3aa9:	48 29 d1             	sub    %rdx,%rcx
    3aac:	48 8b 95 c0 fa ff ff 	mov    -0x540(%rbp),%rdx
    3ab3:	48 89 0a             	mov    %rcx,(%rdx)
    3ab6:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    3abd:	ff 00 00 
    3ac0:	48 21 c8             	and    %rcx,%rax
    3ac3:	31 c9                	xor    %ecx,%ecx
    3ac5:	48 8b 95 30 fb ff ff 	mov    -0x4d0(%rbp),%rdx
    3acc:	48 89 10             	mov    %rdx,(%rax)
    3acf:	48 8b b5 18 fb ff ff 	mov    -0x4e8(%rbp),%rsi
    3ad6:	48 89 70 08          	mov    %rsi,0x8(%rax)
    3ada:	48 89 48 10          	mov    %rcx,0x10(%rax)
    3ade:	48 89 48 18          	mov    %rcx,0x18(%rax)
    3ae2:	48 89 48 20          	mov    %rcx,0x20(%rax)
    3ae6:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    3aed:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    3af1:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    3af7:	4c 01 c7             	add    %r8,%rdi
    3afa:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    3afe:	48 89 85 b8 fa ff ff 	mov    %rax,-0x548(%rbp)
    3b05:	b8 01 00 00 00       	mov    $0x1,%eax
    3b0a:	48 89 85 c0 fa ff ff 	mov    %rax,-0x540(%rbp)
    3b11:	31 c0                	xor    %eax,%eax
    3b13:	48 89 85 b0 fa ff ff 	mov    %rax,-0x550(%rbp)
    3b1a:	e9 a2 01 00 00       	jmp    0x3cc1
    3b1f:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    3b26:	48 8b 48 10          	mov    0x10(%rax),%rcx
    3b2a:	48 8b 50 18          	mov    0x18(%rax),%rdx
    3b2e:	48 89 d6             	mov    %rdx,%rsi
    3b31:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    3b36:	bf 40 00 00 00       	mov    $0x40,%edi
    3b3b:	48 29 f7             	sub    %rsi,%rdi
    3b3e:	48 89 8d a8 fa ff ff 	mov    %rcx,-0x558(%rbp)
    3b45:	4c 8b 85 08 fb ff ff 	mov    -0x4f8(%rbp),%r8
    3b4c:	48 89 f9             	mov    %rdi,%rcx
    3b4f:	4d 89 c1             	mov    %r8,%r9
    3b52:	49 d3 e9             	shr    %cl,%r9
    3b55:	31 c9                	xor    %ecx,%ecx
    3b57:	48 39 ce             	cmp    %rcx,%rsi
    3b5a:	be 00 00 00 00       	mov    $0x0,%esi
    3b5f:	40 0f 94 c6          	sete   %sil
    3b63:	48 85 f6             	test   %rsi,%rsi
    3b66:	49 0f 44 c9          	cmove  %r9,%rcx
    3b6a:	be 01 00 00 00       	mov    $0x1,%esi
    3b6f:	48 89 cf             	mov    %rcx,%rdi
    3b72:	48 01 f7             	add    %rsi,%rdi
    3b75:	48 21 d7             	and    %rdx,%rdi
    3b78:	ba 28 00 00 00       	mov    $0x28,%edx
    3b7d:	48 0f af ca          	imul   %rdx,%rcx
    3b81:	48 8b 95 a8 fa ff ff 	mov    -0x558(%rbp),%rdx
    3b88:	4c 8d 0c 0a          	lea    (%rdx,%rcx,1),%r9
    3b8c:	49 8b 49 10          	mov    0x10(%r9),%rcx
    3b90:	48 85 c9             	test   %rcx,%rcx
    3b93:	0f 84 af 00 00 00    	je     0x3c48
    3b99:	49 8b 09             	mov    (%r9),%rcx
    3b9c:	4d 8b 51 08          	mov    0x8(%r9),%r10
    3ba0:	4c 8b 9d 30 fb ff ff 	mov    -0x4d0(%rbp),%r11
    3ba7:	49 39 cb             	cmp    %rcx,%r11
    3baa:	ba 00 00 00 00       	mov    $0x0,%edx
    3baf:	0f 94 c2             	sete   %dl
    3bb2:	48 8b 8d 18 fb ff ff 	mov    -0x4e8(%rbp),%rcx
    3bb9:	4c 39 d1             	cmp    %r10,%rcx
    3bbc:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    3bc2:	41 0f 94 c0          	sete   %r8b
    3bc6:	4c 21 c2             	and    %r8,%rdx
    3bc9:	48 85 d2             	test   %rdx,%rdx
    3bcc:	0f 84 0c 00 00 00    	je     0x3bde
    3bd2:	4c 89 8d b8 fa ff ff 	mov    %r9,-0x548(%rbp)
    3bd9:	e9 53 00 00 00       	jmp    0x3c31
    3bde:	ba 28 00 00 00       	mov    $0x28,%edx
    3be3:	48 0f af fa          	imul   %rdx,%rdi
    3be7:	48 8b 95 a8 fa ff ff 	mov    -0x558(%rbp),%rdx
    3bee:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    3bf2:	49 8b 50 10          	mov    0x10(%r8),%rdx
    3bf6:	48 85 d2             	test   %rdx,%rdx
    3bf9:	0f 84 49 00 00 00    	je     0x3c48
    3bff:	49 8b 10             	mov    (%r8),%rdx
    3c02:	49 8b 78 08          	mov    0x8(%r8),%rdi
    3c06:	49 39 d3             	cmp    %rdx,%r11
    3c09:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    3c0f:	41 0f 94 c1          	sete   %r9b
    3c13:	48 39 f9             	cmp    %rdi,%rcx
    3c16:	ba 00 00 00 00       	mov    $0x0,%edx
    3c1b:	0f 94 c2             	sete   %dl
    3c1e:	49 21 d1             	and    %rdx,%r9
    3c21:	4d 85 c9             	test   %r9,%r9
    3c24:	0f 84 1e 00 00 00    	je     0x3c48
    3c2a:	4c 89 85 b8 fa ff ff 	mov    %r8,-0x548(%rbp)
    3c31:	31 c0                	xor    %eax,%eax
    3c33:	48 89 85 c0 fa ff ff 	mov    %rax,-0x540(%rbp)
    3c3a:	31 c0                	xor    %eax,%eax
    3c3c:	48 89 85 b0 fa ff ff 	mov    %rax,-0x550(%rbp)
    3c43:	e9 79 00 00 00       	jmp    0x3cc1
    3c48:	48 8d 85 a0 fd ff ff 	lea    -0x260(%rbp),%rax
    3c4f:	48 89 c1             	mov    %rax,%rcx
    3c52:	48 8b 95 30 fb ff ff 	mov    -0x4d0(%rbp),%rdx
    3c59:	48 89 11             	mov    %rdx,(%rcx)
    3c5c:	48 8b b5 18 fb ff ff 	mov    -0x4e8(%rbp),%rsi
    3c63:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    3c67:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    3c6e:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    3c75:	48 89 ca             	mov    %rcx,%rdx
    3c78:	e8 73 c4 ff ff       	call   0xf0
    3c7d:	48 83 f8 00          	cmp    $0x0,%rax
    3c81:	0f 8d 08 00 00 00    	jge    0x3c8f
    3c87:	49 89 c4             	mov    %rax,%r12
    3c8a:	e9 98 34 00 00       	jmp    0x7127
    3c8f:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    3c96:	48 8b 11             	mov    (%rcx),%rdx
    3c99:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    3c9d:	48 83 e6 01          	and    $0x1,%rsi
    3ca1:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    3ca5:	48 89 85 b8 fa ff ff 	mov    %rax,-0x548(%rbp)
    3cac:	b8 01 00 00 00       	mov    $0x1,%eax
    3cb1:	48 89 85 c0 fa ff ff 	mov    %rax,-0x540(%rbp)
    3cb8:	31 c0                	xor    %eax,%eax
    3cba:	48 89 85 b0 fa ff ff 	mov    %rax,-0x550(%rbp)
    3cc1:	48 8b 85 c0 fa ff ff 	mov    -0x540(%rbp),%rax
    3cc8:	48 85 c0             	test   %rax,%rax
    3ccb:	0f 84 68 00 00 00    	je     0x3d39
    3cd1:	48 8b 85 b8 fa ff ff 	mov    -0x548(%rbp),%rax
    3cd8:	48 8b 8d f8 fa ff ff 	mov    -0x508(%rbp),%rcx
    3cdf:	48 89 48 10          	mov    %rcx,0x10(%rax)
    3ce3:	31 d2                	xor    %edx,%edx
    3ce5:	48 39 d1             	cmp    %rdx,%rcx
    3ce8:	be 00 00 00 00       	mov    $0x0,%esi
    3ced:	40 0f 95 c6          	setne  %sil
    3cf1:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    3cf5:	48 09 f7             	or     %rsi,%rdi
    3cf8:	40 88 78 20          	mov    %dil,0x20(%rax)
    3cfc:	48 8b b5 f0 fa ff ff 	mov    -0x510(%rbp),%rsi
    3d03:	48 89 70 18          	mov    %rsi,0x18(%rax)
    3d07:	48 8b bd e8 fa ff ff 	mov    -0x518(%rbp),%rdi
    3d0e:	48 39 d7             	cmp    %rdx,%rdi
    3d11:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    3d17:	41 0f 95 c0          	setne  %r8b
    3d1b:	44 0f b6 48 20       	movzbl 0x20(%rax),%r9d
    3d20:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    3d26:	4d 85 c0             	test   %r8,%r8
    3d29:	4c 0f 44 d2          	cmove  %rdx,%r10
    3d2d:	4d 09 d1             	or     %r10,%r9
    3d30:	44 88 48 20          	mov    %r9b,0x20(%rax)
    3d34:	e9 8e 00 00 00       	jmp    0x3dc7
    3d39:	48 8b 85 b8 fa ff ff 	mov    -0x548(%rbp),%rax
    3d40:	48 8b 48 10          	mov    0x10(%rax),%rcx
    3d44:	48 8b 95 f8 fa ff ff 	mov    -0x508(%rbp),%rdx
    3d4b:	48 01 d1             	add    %rdx,%rcx
    3d4e:	48 89 48 10          	mov    %rcx,0x10(%rax)
    3d52:	31 f6                	xor    %esi,%esi
    3d54:	48 39 f1             	cmp    %rsi,%rcx
    3d57:	b9 00 00 00 00       	mov    $0x0,%ecx
    3d5c:	0f 95 c1             	setne  %cl
    3d5f:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    3d63:	48 09 cf             	or     %rcx,%rdi
    3d66:	40 88 78 20          	mov    %dil,0x20(%rax)
    3d6a:	48 8b 48 18          	mov    0x18(%rax),%rcx
    3d6e:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    3d72:	48 83 e7 02          	and    $0x2,%rdi
    3d76:	48 39 f7             	cmp    %rsi,%rdi
    3d79:	bf 00 00 00 00       	mov    $0x0,%edi
    3d7e:	40 0f 95 c7          	setne  %dil
    3d82:	45 31 c0             	xor    %r8d,%r8d
    3d85:	48 85 ff             	test   %rdi,%rdi
    3d88:	49 0f 44 c8          	cmove  %r8,%rcx
    3d8c:	4c 8b 85 e8 fa ff ff 	mov    -0x518(%rbp),%r8
    3d93:	4c 01 c7             	add    %r8,%rdi
    3d96:	4c 8b 8d f0 fa ff ff 	mov    -0x510(%rbp),%r9
    3d9d:	4c 01 c9             	add    %r9,%rcx
    3da0:	48 89 48 18          	mov    %rcx,0x18(%rax)
    3da4:	48 39 f7             	cmp    %rsi,%rdi
    3da7:	bf 00 00 00 00       	mov    $0x0,%edi
    3dac:	40 0f 95 c7          	setne  %dil
    3db0:	0f b6 48 20          	movzbl 0x20(%rax),%ecx
    3db4:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    3dba:	48 85 ff             	test   %rdi,%rdi
    3dbd:	4c 0f 44 d6          	cmove  %rsi,%r10
    3dc1:	4c 09 d1             	or     %r10,%rcx
    3dc4:	88 48 20             	mov    %cl,0x20(%rax)
    3dc7:	b8 01 00 00 00       	mov    $0x1,%eax
    3dcc:	48 8b 8d 38 fb ff ff 	mov    -0x4c8(%rbp),%rcx
    3dd3:	48 63 11             	movslq (%rcx),%rdx
    3dd6:	48 8b b5 28 fb ff ff 	mov    -0x4d8(%rbp),%rsi
    3ddd:	48 89 f7             	mov    %rsi,%rdi
    3de0:	48 31 c7             	xor    %rax,%rdi
    3de3:	31 c0                	xor    %eax,%eax
    3de5:	48 85 ff             	test   %rdi,%rdi
    3de8:	48 0f 44 d0          	cmove  %rax,%rdx
    3dec:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    3df3:	79 37 9e 
    3df6:	49 b8 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%r8
    3dfd:	79 37 9e 
    3e00:	4c 8b 8d c8 fa ff ff 	mov    -0x538(%rbp),%r9
    3e07:	4d 31 c8             	xor    %r9,%r8
    3e0a:	4c 0f af c0          	imul   %rax,%r8
    3e0e:	4d 89 c2             	mov    %r8,%r10
    3e11:	49 c1 ea 1d          	shr    $0x1d,%r10
    3e15:	4d 31 d0             	xor    %r10,%r8
    3e18:	4c 8b 95 d8 fa ff ff 	mov    -0x528(%rbp),%r10
    3e1f:	4d 31 d0             	xor    %r10,%r8
    3e22:	4c 0f af c0          	imul   %rax,%r8
    3e26:	4d 89 c3             	mov    %r8,%r11
    3e29:	49 c1 eb 1d          	shr    $0x1d,%r11
    3e2d:	4d 31 d8             	xor    %r11,%r8
    3e30:	4c 0f af c0          	imul   %rax,%r8
    3e34:	4c 89 8d 80 fb ff ff 	mov    %r9,-0x480(%rbp)
    3e3b:	4c 89 95 58 fb ff ff 	mov    %r10,-0x4a8(%rbp)
    3e42:	4c 89 85 50 fb ff ff 	mov    %r8,-0x4b0(%rbp)
    3e49:	b8 01 00 00 00       	mov    $0x1,%eax
    3e4e:	48 89 85 78 fb ff ff 	mov    %rax,-0x488(%rbp)
    3e55:	48 89 95 88 fb ff ff 	mov    %rdx,-0x478(%rbp)
    3e5c:	48 89 bd c8 fb ff ff 	mov    %rdi,-0x438(%rbp)
    3e63:	48 8b 85 d0 fa ff ff 	mov    -0x530(%rbp),%rax
    3e6a:	48 89 85 68 fb ff ff 	mov    %rax,-0x498(%rbp)
    3e71:	b8 01 00 00 00       	mov    $0x1,%eax
    3e76:	48 89 85 70 fb ff ff 	mov    %rax,-0x490(%rbp)
    3e7d:	31 c0                	xor    %eax,%eax
    3e7f:	48 89 03             	mov    %rax,(%rbx)
    3e82:	48 8b 85 38 fc ff ff 	mov    -0x3c8(%rbp),%rax
    3e89:	b9 01 00 00 00       	mov    $0x1,%ecx
    3e8e:	48 89 c2             	mov    %rax,%rdx
    3e91:	48 01 ca             	add    %rcx,%rdx
    3e94:	48 89 95 38 fc ff ff 	mov    %rdx,-0x3c8(%rbp)
    3e9b:	e9 53 f0 ff ff       	jmp    0x2ef3
    3ea0:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    3ea7:	e8 94 c1 ff ff       	call   0x40
    3eac:	48 85 c0             	test   %rax,%rax
    3eaf:	0f 84 ed f9 ff ff    	je     0x38a2
    3eb5:	e9 66 32 00 00       	jmp    0x7120
    3eba:	48 8b 85 08 fc ff ff 	mov    -0x3f8(%rbp),%rax
    3ec1:	48 89 85 20 fb ff ff 	mov    %rax,-0x4e0(%rbp)
    3ec8:	31 c0                	xor    %eax,%eax
    3eca:	48 89 85 40 fb ff ff 	mov    %rax,-0x4c0(%rbp)
    3ed1:	31 c0                	xor    %eax,%eax
    3ed3:	48 89 85 e0 fa ff ff 	mov    %rax,-0x520(%rbp)
    3eda:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
    3ee1:	82 28 52 
    3ee4:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    3eeb:	31 c0                	xor    %eax,%eax
    3eed:	48 89 85 00 fb ff ff 	mov    %rax,-0x500(%rbp)
    3ef4:	31 c0                	xor    %eax,%eax
    3ef6:	48 89 85 08 fb ff ff 	mov    %rax,-0x4f8(%rbp)
    3efd:	31 c0                	xor    %eax,%eax
    3eff:	48 89 85 30 fb ff ff 	mov    %rax,-0x4d0(%rbp)
    3f06:	31 c0                	xor    %eax,%eax
    3f08:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    3f0f:	31 c0                	xor    %eax,%eax
    3f11:	48 89 85 f8 fa ff ff 	mov    %rax,-0x508(%rbp)
    3f18:	48 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%rax
    3f1f:	48 8b 8d f8 fb ff ff 	mov    -0x408(%rbp),%rcx
    3f26:	48 39 c8             	cmp    %rcx,%rax
    3f29:	0f 8c 75 00 00 00    	jl     0x3fa4
    3f2f:	48 8b 95 18 fb ff ff 	mov    -0x4e8(%rbp),%rdx
    3f36:	48 89 95 60 fb ff ff 	mov    %rdx,-0x4a0(%rbp)
    3f3d:	48 8b 95 40 fb ff ff 	mov    -0x4c0(%rbp),%rdx
    3f44:	48 89 95 b0 fb ff ff 	mov    %rdx,-0x450(%rbp)
    3f4b:	48 8b 95 e0 fa ff ff 	mov    -0x520(%rbp),%rdx
    3f52:	48 89 95 a8 fb ff ff 	mov    %rdx,-0x458(%rbp)
    3f59:	48 8b 95 10 fb ff ff 	mov    -0x4f0(%rbp),%rdx
    3f60:	48 89 95 a0 fb ff ff 	mov    %rdx,-0x460(%rbp)
    3f67:	48 8b 95 f8 fa ff ff 	mov    -0x508(%rbp),%rdx
    3f6e:	48 89 95 c0 fb ff ff 	mov    %rdx,-0x440(%rbp)
    3f75:	48 8b 95 00 fb ff ff 	mov    -0x500(%rbp),%rdx
    3f7c:	48 89 95 b8 fb ff ff 	mov    %rdx,-0x448(%rbp)
    3f83:	48 8b 95 08 fb ff ff 	mov    -0x4f8(%rbp),%rdx
    3f8a:	48 89 95 98 fb ff ff 	mov    %rdx,-0x468(%rbp)
    3f91:	48 8b 95 30 fb ff ff 	mov    -0x4d0(%rbp),%rdx
    3f98:	48 89 95 90 fb ff ff 	mov    %rdx,-0x470(%rbp)
    3f9f:	e9 f3 0d 00 00       	jmp    0x4d97
    3fa4:	48 8b 95 d8 fb ff ff 	mov    -0x428(%rbp),%rdx
    3fab:	48 8d 34 82          	lea    (%rdx,%rax,4),%rsi
    3faf:	48 8b bd e8 fb ff ff 	mov    -0x418(%rbp),%rdi
    3fb6:	4c 8d 04 87          	lea    (%rdi,%rax,4),%r8
    3fba:	4c 63 0e             	movslq (%rsi),%r9
    3fbd:	4c 8b 95 50 fc ff ff 	mov    -0x3b0(%rbp),%r10
    3fc4:	4d 85 d2             	test   %r10,%r10
    3fc7:	4c 89 85 e8 fa ff ff 	mov    %r8,-0x518(%rbp)
    3fce:	4c 89 8d f0 fa ff ff 	mov    %r9,-0x510(%rbp)
    3fd5:	0f 84 29 01 00 00    	je     0x4104
    3fdb:	49 bb 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%r11
    3fe2:	79 37 9e 
    3fe5:	4c 89 c8             	mov    %r9,%rax
    3fe8:	48 c1 e8 2b          	shr    $0x2b,%rax
    3fec:	4d 89 c8             	mov    %r9,%r8
    3fef:	49 c1 e8 2c          	shr    $0x2c,%r8
    3ff3:	4c 31 c0             	xor    %r8,%rax
    3ff6:	4d 89 c8             	mov    %r9,%r8
    3ff9:	49 31 c0             	xor    %rax,%r8
    3ffc:	4d 0f af c3          	imul   %r11,%r8
    4000:	4c 89 c0             	mov    %r8,%rax
    4003:	48 c1 e8 1e          	shr    $0x1e,%rax
    4007:	4d 89 c3             	mov    %r8,%r11
    400a:	49 31 c3             	xor    %rax,%r11
    400d:	48 b8 b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rax
    4014:	47 58 bf 
    4017:	4c 0f af d8          	imul   %rax,%r11
    401b:	4c 89 d8             	mov    %r11,%rax
    401e:	48 c1 e8 1b          	shr    $0x1b,%rax
    4022:	49 31 c3             	xor    %rax,%r11
    4025:	48 b8 eb 11 31 13 bb 	movabs $0x94d049bb133111eb,%rax
    402c:	49 d0 94 
    402f:	4c 0f af d8          	imul   %rax,%r11
    4033:	4c 89 d8             	mov    %r11,%rax
    4036:	48 c1 e8 1f          	shr    $0x1f,%rax
    403a:	49 31 c3             	xor    %rax,%r11
    403d:	b8 40 00 00 00       	mov    $0x40,%eax
    4042:	4c 29 d0             	sub    %r10,%rax
    4045:	48 89 c1             	mov    %rax,%rcx
    4048:	49 d3 eb             	shr    %cl,%r11
    404b:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
    404f:	4c 89 d9             	mov    %r11,%rcx
    4052:	49 89 c1             	mov    %rax,%r9
    4055:	49 d3 e9             	shr    %cl,%r9
    4058:	b9 01 00 00 00       	mov    $0x1,%ecx
    405d:	49 21 c9             	and    %rcx,%r9
    4060:	4d 85 c9             	test   %r9,%r9
    4063:	0f 84 9b 00 00 00    	je     0x4104
    4069:	4c 8d 8d 50 fe ff ff 	lea    -0x1b0(%rbp),%r9
    4070:	4c 89 c8             	mov    %r9,%rax
    4073:	4c 63 0e             	movslq (%rsi),%r9
    4076:	31 f6                	xor    %esi,%esi
    4078:	31 d2                	xor    %edx,%edx
    407a:	48 89 30             	mov    %rsi,(%rax)
    407d:	4c 89 48 08          	mov    %r9,0x8(%rax)
    4081:	48 89 50 10          	mov    %rdx,0x10(%rax)
    4085:	48 8b 95 e8 fa ff ff 	mov    -0x518(%rbp),%rdx
    408c:	48 63 32             	movslq (%rdx),%rsi
    408f:	45 31 c9             	xor    %r9d,%r9d
    4092:	31 d2                	xor    %edx,%edx
    4094:	4c 89 48 18          	mov    %r9,0x18(%rax)
    4098:	48 89 70 20          	mov    %rsi,0x20(%rax)
    409c:	48 89 50 28          	mov    %rdx,0x28(%rax)
    40a0:	ba 01 00 00 00       	mov    $0x1,%edx
    40a5:	4c 89 d1             	mov    %r10,%rcx
    40a8:	48 d3 e2             	shl    %cl,%rdx
    40ab:	4c 01 da             	add    %r11,%rdx
    40ae:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    40b3:	be 02 00 00 00       	mov    $0x2,%esi
    40b8:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    40bf:	48 89 ce             	mov    %rcx,%rsi
    40c2:	48 89 95 38 fb ff ff 	mov    %rdx,-0x4c8(%rbp)
    40c9:	4c 89 d2             	mov    %r10,%rdx
    40cc:	48 8b 8d 38 fb ff ff 	mov    -0x4c8(%rbp),%rcx
    40d3:	49 89 c1             	mov    %rax,%r9
    40d6:	b8 02 00 00 00       	mov    $0x2,%eax
    40db:	48 89 04 24          	mov    %rax,(%rsp)
    40df:	e8 ec bf ff ff       	call   0xd0
    40e4:	48 83 f8 00          	cmp    $0x0,%rax
    40e8:	0f 8d 11 00 00 00    	jge    0x40ff
    40ee:	b8 80 00 00 00       	mov    $0x80,%eax
    40f3:	48 89 85 48 fb ff ff 	mov    %rax,-0x4b8(%rbp)
    40fa:	e9 07 30 00 00       	jmp    0x7106
    40ff:	e9 5b 0c 00 00       	jmp    0x4d5f
    4104:	49 83 fd 05          	cmp    $0x5,%r13
    4108:	0f 85 d1 00 00 00    	jne    0x41df
    410e:	48 8b 85 f0 fa ff ff 	mov    -0x510(%rbp),%rax
    4115:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    411c:	48 89 c2             	mov    %rax,%rdx
    411f:	48 29 ca             	sub    %rcx,%rdx
    4122:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    4129:	48 39 f2             	cmp    %rsi,%rdx
    412c:	bf 00 00 00 00       	mov    $0x0,%edi
    4131:	40 0f 92 c7          	setb   %dil
    4135:	45 31 c0             	xor    %r8d,%r8d
    4138:	48 85 ff             	test   %rdi,%rdi
    413b:	49 0f 44 d0          	cmove  %r8,%rdx
    413f:	49 89 d1             	mov    %rdx,%r9
    4142:	49 c1 e9 06          	shr    $0x6,%r9
    4146:	48 83 e2 3f          	and    $0x3f,%rdx
    414a:	4c 8b 95 70 fc ff ff 	mov    -0x390(%rbp),%r10
    4151:	4f 8d 1c ca          	lea    (%r10,%r9,8),%r11
    4155:	49 8b 03             	mov    (%r11),%rax
    4158:	48 89 d1             	mov    %rdx,%rcx
    415b:	48 d3 e8             	shr    %cl,%rax
    415e:	b9 01 00 00 00       	mov    $0x1,%ecx
    4163:	48 21 c8             	and    %rcx,%rax
    4166:	48 21 f8             	and    %rdi,%rax
    4169:	48 8b bd 48 fc ff ff 	mov    -0x3b8(%rbp),%rdi
    4170:	4e 8d 1c cf          	lea    (%rdi,%r9,8),%r11
    4174:	49 8b 3b             	mov    (%r11),%rdi
    4177:	48 89 d1             	mov    %rdx,%rcx
    417a:	48 d3 ef             	shr    %cl,%rdi
    417d:	b9 01 00 00 00       	mov    $0x1,%ecx
    4182:	48 21 cf             	and    %rcx,%rdi
    4185:	4c 8b 9d 58 fc ff ff 	mov    -0x3a8(%rbp),%r11
    418c:	4b 8d 34 cb          	lea    (%r11,%r9,8),%rsi
    4190:	4c 8b 0e             	mov    (%rsi),%r9
    4193:	48 89 d1             	mov    %rdx,%rcx
    4196:	49 d3 e9             	shr    %cl,%r9
    4199:	b9 01 00 00 00       	mov    $0x1,%ecx
    419e:	49 21 c9             	and    %rcx,%r9
    41a1:	48 8d 95 30 fe ff ff 	lea    -0x1d0(%rbp),%rdx
    41a8:	48 89 d6             	mov    %rdx,%rsi
    41ab:	49 c1 e1 20          	shl    $0x20,%r9
    41af:	48 8b 95 f0 fa ff ff 	mov    -0x510(%rbp),%rdx
    41b6:	48 89 16             	mov    %rdx,(%rsi)
    41b9:	4c 89 4e 08          	mov    %r9,0x8(%rsi)
    41bd:	48 89 7e 10          	mov    %rdi,0x10(%rsi)
    41c1:	4c 39 c0             	cmp    %r8,%rax
    41c4:	b8 00 00 00 00       	mov    $0x0,%eax
    41c9:	0f 95 c0             	setne  %al
    41cc:	48 85 c0             	test   %rax,%rax
    41cf:	49 0f 44 f0          	cmove  %r8,%rsi
    41d3:	48 89 b5 38 fb ff ff 	mov    %rsi,-0x4c8(%rbp)
    41da:	e9 0c 04 00 00       	jmp    0x45eb
    41df:	49 83 fd 01          	cmp    $0x1,%r13
    41e3:	0f 85 09 03 00 00    	jne    0x44f2
    41e9:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    41f0:	79 37 9e 
    41f3:	48 8b 8d f0 fa ff ff 	mov    -0x510(%rbp),%rcx
    41fa:	48 89 ca             	mov    %rcx,%rdx
    41fd:	48 c1 ea 2b          	shr    $0x2b,%rdx
    4201:	48 89 ce             	mov    %rcx,%rsi
    4204:	48 c1 ee 2c          	shr    $0x2c,%rsi
    4208:	48 31 f2             	xor    %rsi,%rdx
    420b:	48 89 ce             	mov    %rcx,%rsi
    420e:	48 31 d6             	xor    %rdx,%rsi
    4211:	48 0f af f0          	imul   %rax,%rsi
    4215:	48 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%rax
    421c:	48 85 c0             	test   %rax,%rax
    421f:	48 89 b5 28 fb ff ff 	mov    %rsi,-0x4d8(%rbp)
    4226:	0f 84 10 01 00 00    	je     0x433c
    422c:	ba 40 00 00 00       	mov    $0x40,%edx
    4231:	48 8b bd 88 fc ff ff 	mov    -0x378(%rbp),%rdi
    4238:	48 29 fa             	sub    %rdi,%rdx
    423b:	48 89 d1             	mov    %rdx,%rcx
    423e:	49 89 f0             	mov    %rsi,%r8
    4241:	49 d3 e8             	shr    %cl,%r8
    4244:	31 c9                	xor    %ecx,%ecx
    4246:	48 39 cf             	cmp    %rcx,%rdi
    4249:	ba 00 00 00 00       	mov    $0x0,%edx
    424e:	0f 94 c2             	sete   %dl
    4251:	48 85 d2             	test   %rdx,%rdx
    4254:	49 0f 44 c8          	cmove  %r8,%rcx
    4258:	49 8d 14 cf          	lea    (%r15,%rcx,8),%rdx
    425c:	48 8b 0a             	mov    (%rdx),%rcx
    425f:	48 89 f2             	mov    %rsi,%rdx
    4262:	48 c1 ea 20          	shr    $0x20,%rdx
    4266:	49 89 f0             	mov    %rsi,%r8
    4269:	49 31 d0             	xor    %rdx,%r8
    426c:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    4271:	49 21 d0             	and    %rdx,%r8
    4274:	4c 89 c2             	mov    %r8,%rdx
    4277:	48 83 e2 3f          	and    $0x3f,%rdx
    427b:	48 89 8d 38 fc ff ff 	mov    %rcx,-0x3c8(%rbp)
    4282:	41 b9 01 00 00 00    	mov    $0x1,%r9d
    4288:	48 89 d1             	mov    %rdx,%rcx
    428b:	4d 89 ca             	mov    %r9,%r10
    428e:	49 d3 e2             	shl    %cl,%r10
    4291:	4c 89 c1             	mov    %r8,%rcx
    4294:	48 c1 e9 06          	shr    $0x6,%rcx
    4298:	48 83 e1 3f          	and    $0x3f,%rcx
    429c:	48 89 8d 68 fb ff ff 	mov    %rcx,-0x498(%rbp)
    42a3:	48 8b 95 68 fb ff ff 	mov    -0x498(%rbp),%rdx
    42aa:	48 89 d1             	mov    %rdx,%rcx
    42ad:	4d 89 cb             	mov    %r9,%r11
    42b0:	49 d3 e3             	shl    %cl,%r11
    42b3:	4d 09 da             	or     %r11,%r10
    42b6:	4c 89 c1             	mov    %r8,%rcx
    42b9:	48 c1 e9 0c          	shr    $0xc,%rcx
    42bd:	48 83 e1 3f          	and    $0x3f,%rcx
    42c1:	48 89 8d 68 fb ff ff 	mov    %rcx,-0x498(%rbp)
    42c8:	48 8b 95 68 fb ff ff 	mov    -0x498(%rbp),%rdx
    42cf:	48 89 d1             	mov    %rdx,%rcx
    42d2:	4d 89 cb             	mov    %r9,%r11
    42d5:	49 d3 e3             	shl    %cl,%r11
    42d8:	4d 09 da             	or     %r11,%r10
    42db:	49 c1 e8 12          	shr    $0x12,%r8
    42df:	49 83 e0 3f          	and    $0x3f,%r8
    42e3:	4c 89 c1             	mov    %r8,%rcx
    42e6:	4c 89 ca             	mov    %r9,%rdx
    42e9:	48 d3 e2             	shl    %cl,%rdx
    42ec:	49 09 d2             	or     %rdx,%r10
    42ef:	48 8b 8d 38 fc ff ff 	mov    -0x3c8(%rbp),%rcx
    42f6:	4c 21 d1             	and    %r10,%rcx
    42f9:	4c 39 d1             	cmp    %r10,%rcx
    42fc:	b9 00 00 00 00       	mov    $0x0,%ecx
    4301:	0f 94 c1             	sete   %cl
    4304:	ba 01 00 00 00       	mov    $0x1,%edx
    4309:	49 b8 00 00 00 00 01 	movabs $0x100000000,%r8
    4310:	00 00 00 
    4313:	48 85 c9             	test   %rcx,%rcx
    4316:	49 0f 44 d0          	cmove  %r8,%rdx
    431a:	4c 8b 43 08          	mov    0x8(%rbx),%r8
    431e:	49 01 d0             	add    %rdx,%r8
    4321:	4c 89 43 08          	mov    %r8,0x8(%rbx)
    4325:	48 85 c9             	test   %rcx,%rcx
    4328:	0f 85 f3 00 00 00    	jne    0x4421
    432e:	31 c9                	xor    %ecx,%ecx
    4330:	48 89 8d 38 fb ff ff 	mov    %rcx,-0x4c8(%rbp)
    4337:	e9 b1 01 00 00       	jmp    0x44ed
    433c:	b8 40 00 00 00       	mov    $0x40,%eax
    4341:	48 8b 8d 88 fc ff ff 	mov    -0x378(%rbp),%rcx
    4348:	48 29 c8             	sub    %rcx,%rax
    434b:	48 8b 95 28 fb ff ff 	mov    -0x4d8(%rbp),%rdx
    4352:	48 89 c1             	mov    %rax,%rcx
    4355:	48 89 d6             	mov    %rdx,%rsi
    4358:	48 d3 ee             	shr    %cl,%rsi
    435b:	31 c0                	xor    %eax,%eax
    435d:	48 8b 8d 88 fc ff ff 	mov    -0x378(%rbp),%rcx
    4364:	48 39 c1             	cmp    %rax,%rcx
    4367:	bf 00 00 00 00       	mov    $0x0,%edi
    436c:	40 0f 94 c7          	sete   %dil
    4370:	48 85 ff             	test   %rdi,%rdi
    4373:	48 0f 44 c6          	cmove  %rsi,%rax
    4377:	49 8d 34 c7          	lea    (%r15,%rax,8),%rsi
    437b:	48 8b 06             	mov    (%rsi),%rax
    437e:	48 89 d6             	mov    %rdx,%rsi
    4381:	48 c1 ee 20          	shr    $0x20,%rsi
    4385:	48 89 d7             	mov    %rdx,%rdi
    4388:	48 31 f7             	xor    %rsi,%rdi
    438b:	be ff ff ff ff       	mov    $0xffffffff,%esi
    4390:	48 21 f7             	and    %rsi,%rdi
    4393:	48 89 fe             	mov    %rdi,%rsi
    4396:	48 83 e6 3f          	and    $0x3f,%rsi
    439a:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    43a0:	48 89 f1             	mov    %rsi,%rcx
    43a3:	4d 89 c1             	mov    %r8,%r9
    43a6:	49 d3 e1             	shl    %cl,%r9
    43a9:	48 89 f9             	mov    %rdi,%rcx
    43ac:	48 c1 e9 06          	shr    $0x6,%rcx
    43b0:	48 83 e1 3f          	and    $0x3f,%rcx
    43b4:	48 89 8d 38 fc ff ff 	mov    %rcx,-0x3c8(%rbp)
    43bb:	48 8b b5 38 fc ff ff 	mov    -0x3c8(%rbp),%rsi
    43c2:	48 89 f1             	mov    %rsi,%rcx
    43c5:	4d 89 c2             	mov    %r8,%r10
    43c8:	49 d3 e2             	shl    %cl,%r10
    43cb:	4d 09 d1             	or     %r10,%r9
    43ce:	48 89 f9             	mov    %rdi,%rcx
    43d1:	48 c1 e9 0c          	shr    $0xc,%rcx
    43d5:	48 83 e1 3f          	and    $0x3f,%rcx
    43d9:	48 89 8d 38 fc ff ff 	mov    %rcx,-0x3c8(%rbp)
    43e0:	48 8b b5 38 fc ff ff 	mov    -0x3c8(%rbp),%rsi
    43e7:	48 89 f1             	mov    %rsi,%rcx
    43ea:	4d 89 c2             	mov    %r8,%r10
    43ed:	49 d3 e2             	shl    %cl,%r10
    43f0:	4d 09 d1             	or     %r10,%r9
    43f3:	48 c1 ef 12          	shr    $0x12,%rdi
    43f7:	48 83 e7 3f          	and    $0x3f,%rdi
    43fb:	48 89 f9             	mov    %rdi,%rcx
    43fe:	4c 89 c6             	mov    %r8,%rsi
    4401:	48 d3 e6             	shl    %cl,%rsi
    4404:	49 09 f1             	or     %rsi,%r9
    4407:	4c 21 c8             	and    %r9,%rax
    440a:	4c 39 c8             	cmp    %r9,%rax
    440d:	0f 84 0e 00 00 00    	je     0x4421
    4413:	31 c0                	xor    %eax,%eax
    4415:	48 89 85 38 fb ff ff 	mov    %rax,-0x4c8(%rbp)
    441c:	e9 cc 00 00 00       	jmp    0x44ed
    4421:	b8 40 00 00 00       	mov    $0x40,%eax
    4426:	48 8b 8d 78 fc ff ff 	mov    -0x388(%rbp),%rcx
    442d:	48 29 c8             	sub    %rcx,%rax
    4430:	48 8b 95 28 fb ff ff 	mov    -0x4d8(%rbp),%rdx
    4437:	48 89 c1             	mov    %rax,%rcx
    443a:	48 89 d6             	mov    %rdx,%rsi
    443d:	48 d3 ee             	shr    %cl,%rsi
    4440:	31 c0                	xor    %eax,%eax
    4442:	48 8b 8d 78 fc ff ff 	mov    -0x388(%rbp),%rcx
    4449:	48 39 c1             	cmp    %rax,%rcx
    444c:	bf 00 00 00 00       	mov    $0x0,%edi
    4451:	40 0f 94 c7          	sete   %dil
    4455:	48 85 ff             	test   %rdi,%rdi
    4458:	48 0f 44 c6          	cmove  %rsi,%rax
    445c:	48 8b b5 70 fc ff ff 	mov    -0x390(%rbp),%rsi
    4463:	48 8d 3c c6          	lea    (%rsi,%rax,8),%rdi
    4467:	48 8b 07             	mov    (%rdi),%rax
    446a:	48 bf ff ff ff ff ff 	movabs $0xffffffffffff,%rdi
    4471:	ff 00 00 
    4474:	49 89 c0             	mov    %rax,%r8
    4477:	49 21 f8             	and    %rdi,%r8
    447a:	31 ff                	xor    %edi,%edi
    447c:	49 39 f8             	cmp    %rdi,%r8
    447f:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    4485:	41 0f 94 c1          	sete   %r9b
    4489:	49 89 d2             	mov    %rdx,%r10
    448c:	49 c1 ea 20          	shr    $0x20,%r10
    4490:	4c 31 d2             	xor    %r10,%rdx
    4493:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
    4499:	4c 21 d2             	and    %r10,%rdx
    449c:	48 83 e2 0f          	and    $0xf,%rdx
    44a0:	48 83 c2 30          	add    $0x30,%rdx
    44a4:	48 89 d1             	mov    %rdx,%rcx
    44a7:	48 d3 e8             	shr    %cl,%rax
    44aa:	48 83 e0 01          	and    $0x1,%rax
    44ae:	48 83 f8 00          	cmp    $0x0,%rax
    44b2:	b8 00 00 00 00       	mov    $0x0,%eax
    44b7:	0f 95 c0             	setne  %al
    44ba:	b9 01 00 00 00       	mov    $0x1,%ecx
    44bf:	48 31 c8             	xor    %rcx,%rax
    44c2:	49 09 c1             	or     %rax,%r9
    44c5:	b8 01 00 00 00       	mov    $0x1,%eax
    44ca:	49 29 c0             	sub    %rax,%r8
    44cd:	b9 18 00 00 00       	mov    $0x18,%ecx
    44d2:	4c 0f af c1          	imul   %rcx,%r8
    44d6:	4c 89 f1             	mov    %r14,%rcx
    44d9:	4c 01 c1             	add    %r8,%rcx
    44dc:	48 89 fa             	mov    %rdi,%rdx
    44df:	4d 85 c9             	test   %r9,%r9
    44e2:	48 0f 44 d1          	cmove  %rcx,%rdx
    44e6:	48 89 95 38 fb ff ff 	mov    %rdx,-0x4c8(%rbp)
    44ed:	e9 f9 00 00 00       	jmp    0x45eb
    44f2:	48 8b 85 f0 fa ff ff 	mov    -0x510(%rbp),%rax
    44f9:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    4500:	48 89 c2             	mov    %rax,%rdx
    4503:	48 29 ca             	sub    %rcx,%rdx
    4506:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    450d:	48 39 f2             	cmp    %rsi,%rdx
    4510:	0f 82 0e 00 00 00    	jb     0x4524
    4516:	31 ff                	xor    %edi,%edi
    4518:	48 89 bd 38 fb ff ff 	mov    %rdi,-0x4c8(%rbp)
    451f:	e9 c7 00 00 00       	jmp    0x45eb
    4524:	49 83 fd 02          	cmp    $0x2,%r13
    4528:	48 89 95 28 fb ff ff 	mov    %rdx,-0x4d8(%rbp)
    452f:	0f 85 6a 00 00 00    	jne    0x459f
    4535:	48 89 d7             	mov    %rdx,%rdi
    4538:	48 c1 ef 06          	shr    $0x6,%rdi
    453c:	4c 8b 85 70 fc ff ff 	mov    -0x390(%rbp),%r8
    4543:	4d 8d 0c f8          	lea    (%r8,%rdi,8),%r9
    4547:	49 8b 39             	mov    (%r9),%rdi
    454a:	49 89 d1             	mov    %rdx,%r9
    454d:	49 83 e1 3f          	and    $0x3f,%r9
    4551:	4c 89 c9             	mov    %r9,%rcx
    4554:	48 d3 ef             	shr    %cl,%rdi
    4557:	b9 01 00 00 00       	mov    $0x1,%ecx
    455c:	48 21 cf             	and    %rcx,%rdi
    455f:	45 31 c9             	xor    %r9d,%r9d
    4562:	4c 39 cf             	cmp    %r9,%rdi
    4565:	bf 00 00 00 00       	mov    $0x0,%edi
    456a:	40 0f 95 c7          	setne  %dil
    456e:	41 ba 10 00 00 00    	mov    $0x10,%r10d
    4574:	49 89 d3             	mov    %rdx,%r11
    4577:	4d 0f af da          	imul   %r10,%r11
    457b:	4c 8b 95 80 fc ff ff 	mov    -0x380(%rbp),%r10
    4582:	4c 89 d2             	mov    %r10,%rdx
    4585:	4c 01 da             	add    %r11,%rdx
    4588:	48 83 ea 08          	sub    $0x8,%rdx
    458c:	48 85 ff             	test   %rdi,%rdi
    458f:	49 0f 44 d1          	cmove  %r9,%rdx
    4593:	48 89 95 38 fb ff ff 	mov    %rdx,-0x4c8(%rbp)
    459a:	e9 4c 00 00 00       	jmp    0x45eb
    459f:	48 8b 85 70 fc ff ff 	mov    -0x390(%rbp),%rax
    45a6:	48 8b 8d 28 fb ff ff 	mov    -0x4d8(%rbp),%rcx
    45ad:	48 8d 14 88          	lea    (%rax,%rcx,4),%rdx
    45b1:	8b 0a                	mov    (%rdx),%ecx
    45b3:	ba 01 00 00 00       	mov    $0x1,%edx
    45b8:	48 89 ce             	mov    %rcx,%rsi
    45bb:	48 29 d6             	sub    %rdx,%rsi
    45be:	bf 18 00 00 00       	mov    $0x18,%edi
    45c3:	48 0f af f7          	imul   %rdi,%rsi
    45c7:	4c 89 f7             	mov    %r14,%rdi
    45ca:	48 01 f7             	add    %rsi,%rdi
    45cd:	31 f6                	xor    %esi,%esi
    45cf:	48 39 f1             	cmp    %rsi,%rcx
    45d2:	b9 00 00 00 00       	mov    $0x0,%ecx
    45d7:	0f 94 c1             	sete   %cl
    45da:	49 89 f0             	mov    %rsi,%r8
    45dd:	48 85 c9             	test   %rcx,%rcx
    45e0:	4c 0f 44 c7          	cmove  %rdi,%r8
    45e4:	4c 89 85 38 fb ff ff 	mov    %r8,-0x4c8(%rbp)
    45eb:	49 83 fd 01          	cmp    $0x1,%r13
    45ef:	be 00 00 00 00       	mov    $0x0,%esi
    45f4:	40 0f 95 c6          	setne  %sil
    45f8:	31 ff                	xor    %edi,%edi
    45fa:	48 8b 85 18 fb ff ff 	mov    -0x4e8(%rbp),%rax
    4601:	48 89 85 28 fb ff ff 	mov    %rax,-0x4d8(%rbp)
    4608:	48 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%rax
    460f:	48 89 85 38 fc ff ff 	mov    %rax,-0x3c8(%rbp)
    4616:	48 8b 85 e0 fa ff ff 	mov    -0x520(%rbp),%rax
    461d:	48 89 85 68 fb ff ff 	mov    %rax,-0x498(%rbp)
    4624:	48 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%rax
    462b:	48 89 85 80 fb ff ff 	mov    %rax,-0x480(%rbp)
    4632:	48 8b 85 f8 fa ff ff 	mov    -0x508(%rbp),%rax
    4639:	48 89 85 58 fb ff ff 	mov    %rax,-0x4a8(%rbp)
    4640:	48 8b 85 00 fb ff ff 	mov    -0x500(%rbp),%rax
    4647:	48 89 85 50 fb ff ff 	mov    %rax,-0x4b0(%rbp)
    464e:	48 8b 85 08 fb ff ff 	mov    -0x4f8(%rbp),%rax
    4655:	48 89 85 70 fb ff ff 	mov    %rax,-0x490(%rbp)
    465c:	48 8b 85 30 fb ff ff 	mov    -0x4d0(%rbp),%rax
    4663:	48 89 85 78 fb ff ff 	mov    %rax,-0x488(%rbp)
    466a:	48 8b 85 38 fb ff ff 	mov    -0x4c8(%rbp),%rax
    4671:	48 85 c0             	test   %rax,%rax
    4674:	0f 85 75 00 00 00    	jne    0x46ef
    467a:	48 8b 8d 28 fb ff ff 	mov    -0x4d8(%rbp),%rcx
    4681:	48 89 8d 18 fb ff ff 	mov    %rcx,-0x4e8(%rbp)
    4688:	48 8b 8d 38 fc ff ff 	mov    -0x3c8(%rbp),%rcx
    468f:	48 89 8d 40 fb ff ff 	mov    %rcx,-0x4c0(%rbp)
    4696:	48 8b 8d 68 fb ff ff 	mov    -0x498(%rbp),%rcx
    469d:	48 89 8d e0 fa ff ff 	mov    %rcx,-0x520(%rbp)
    46a4:	48 8b 8d 80 fb ff ff 	mov    -0x480(%rbp),%rcx
    46ab:	48 89 8d 10 fb ff ff 	mov    %rcx,-0x4f0(%rbp)
    46b2:	48 8b 8d 58 fb ff ff 	mov    -0x4a8(%rbp),%rcx
    46b9:	48 89 8d f8 fa ff ff 	mov    %rcx,-0x508(%rbp)
    46c0:	48 8b 8d 50 fb ff ff 	mov    -0x4b0(%rbp),%rcx
    46c7:	48 89 8d 00 fb ff ff 	mov    %rcx,-0x500(%rbp)
    46ce:	48 8b 8d 70 fb ff ff 	mov    -0x490(%rbp),%rcx
    46d5:	48 89 8d 08 fb ff ff 	mov    %rcx,-0x4f8(%rbp)
    46dc:	48 8b 8d 78 fb ff ff 	mov    -0x488(%rbp),%rcx
    46e3:	48 89 8d 30 fb ff ff 	mov    %rcx,-0x4d0(%rbp)
    46ea:	e9 6b 06 00 00       	jmp    0x4d5a
    46ef:	48 8b 48 08          	mov    0x8(%rax),%rcx
    46f3:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    46f8:	49 89 c8             	mov    %rcx,%r8
    46fb:	49 21 d0             	and    %rdx,%r8
    46fe:	ba 01 00 00 00       	mov    $0x1,%edx
    4703:	4d 89 c1             	mov    %r8,%r9
    4706:	49 29 d1             	sub    %rdx,%r9
    4709:	41 ba 18 00 00 00    	mov    $0x18,%r10d
    470f:	4d 0f af ca          	imul   %r10,%r9
    4713:	4d 89 f2             	mov    %r14,%r10
    4716:	4d 01 ca             	add    %r9,%r10
    4719:	45 31 c9             	xor    %r9d,%r9d
    471c:	4d 39 c8             	cmp    %r9,%r8
    471f:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    4725:	41 0f 94 c0          	sete   %r8b
    4729:	4d 89 cb             	mov    %r9,%r11
    472c:	4d 85 c0             	test   %r8,%r8
    472f:	4d 0f 44 da          	cmove  %r10,%r11
    4733:	4c 8b 00             	mov    (%rax),%r8
    4736:	4c 8b 95 f0 fa ff ff 	mov    -0x510(%rbp),%r10
    473d:	4d 39 c2             	cmp    %r8,%r10
    4740:	b8 00 00 00 00       	mov    $0x0,%eax
    4745:	0f 94 c0             	sete   %al
    4748:	48 09 f0             	or     %rsi,%rax
    474b:	49 89 f8             	mov    %rdi,%r8
    474e:	49 01 d0             	add    %rdx,%r8
    4751:	48 85 c0             	test   %rax,%rax
    4754:	0f 85 0c 00 00 00    	jne    0x4766
    475a:	4c 89 9d 38 fb ff ff 	mov    %r11,-0x4c8(%rbp)
    4761:	e9 04 ff ff ff       	jmp    0x466a
    4766:	48 8b 03             	mov    (%rbx),%rax
    4769:	48 39 c7             	cmp    %rax,%rdi
    476c:	0f 8d 0f 00 00 00    	jge    0x4781
    4772:	4c 89 9d 38 fb ff ff 	mov    %r11,-0x4c8(%rbp)
    4779:	4c 89 c7             	mov    %r8,%rdi
    477c:	e9 e9 fe ff ff       	jmp    0x466a
    4781:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    4788:	48 8b 70 18          	mov    0x18(%rax),%rsi
    478c:	48 85 f6             	test   %rsi,%rsi
    478f:	48 89 8d f0 fa ff ff 	mov    %rcx,-0x510(%rbp)
    4796:	4c 89 85 88 fb ff ff 	mov    %r8,-0x478(%rbp)
    479d:	0f 84 0c 00 00 00    	je     0x47af
    47a3:	0f b6 3e             	movzbl (%rsi),%edi
    47a6:	48 85 ff             	test   %rdi,%rdi
    47a9:	0f 85 ce 05 00 00    	jne    0x4d7d
    47af:	48 8b 85 38 fb ff ff 	mov    -0x4c8(%rbp),%rax
    47b6:	48 8b 48 10          	mov    0x10(%rax),%rcx
    47ba:	48 8b 95 f0 fa ff ff 	mov    -0x510(%rbp),%rdx
    47c1:	48 89 d6             	mov    %rdx,%rsi
    47c4:	48 c1 ee 20          	shr    $0x20,%rsi
    47c8:	48 83 e6 01          	and    $0x1,%rsi
    47cc:	48 83 fe 00          	cmp    $0x0,%rsi
    47d0:	be 00 00 00 00       	mov    $0x0,%esi
    47d5:	40 0f 95 c6          	setne  %sil
    47d9:	48 8b bd 88 fb ff ff 	mov    -0x478(%rbp),%rdi
    47e0:	48 89 3b             	mov    %rdi,(%rbx)
    47e3:	4c 8b 85 28 fb ff ff 	mov    -0x4d8(%rbp),%r8
    47ea:	4d 89 c1             	mov    %r8,%r9
    47ed:	49 83 c1 01          	add    $0x1,%r9
    47f1:	48 63 c9             	movslq %ecx,%rcx
    47f4:	45 31 d2             	xor    %r10d,%r10d
    47f7:	48 85 f6             	test   %rsi,%rsi
    47fa:	4c 0f 44 d1          	cmove  %rcx,%r10
    47fe:	48 8b 8d 38 fc ff ff 	mov    -0x3c8(%rbp),%rcx
    4805:	4c 39 d1             	cmp    %r10,%rcx
    4808:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    480e:	41 0f 94 c3          	sete   %r11b
    4812:	48 8b 85 68 fb ff ff 	mov    -0x498(%rbp),%rax
    4819:	48 39 f0             	cmp    %rsi,%rax
    481c:	ba 00 00 00 00       	mov    $0x0,%edx
    4821:	0f 94 c2             	sete   %dl
    4824:	49 21 d3             	and    %rdx,%r11
    4827:	4d 85 db             	test   %r11,%r11
    482a:	48 89 b5 c8 fb ff ff 	mov    %rsi,-0x438(%rbp)
    4831:	4c 89 8d d0 fa ff ff 	mov    %r9,-0x530(%rbp)
    4838:	4c 89 95 d8 fa ff ff 	mov    %r10,-0x528(%rbp)
    483f:	0f 84 69 00 00 00    	je     0x48ae
    4845:	48 8b 95 50 fb ff ff 	mov    -0x4b0(%rbp),%rdx
    484c:	49 89 d3             	mov    %rdx,%r11
    484f:	49 83 c3 01          	add    $0x1,%r11
    4853:	48 8b b5 e8 fa ff ff 	mov    -0x518(%rbp),%rsi
    485a:	4c 63 16             	movslq (%rsi),%r10
    485d:	4c 8b 8d 78 fb ff ff 	mov    -0x488(%rbp),%r9
    4864:	4c 89 ce             	mov    %r9,%rsi
    4867:	48 83 c6 01          	add    $0x1,%rsi
    486b:	4c 8b 8d 70 fb ff ff 	mov    -0x490(%rbp),%r9
    4872:	4c 89 ca             	mov    %r9,%rdx
    4875:	4c 01 d2             	add    %r10,%rdx
    4878:	48 89 8d 40 fb ff ff 	mov    %rcx,-0x4c0(%rbp)
    487f:	48 89 85 e0 fa ff ff 	mov    %rax,-0x520(%rbp)
    4886:	4c 8b 95 80 fb ff ff 	mov    -0x480(%rbp),%r10
    488d:	4c 89 95 10 fb ff ff 	mov    %r10,-0x4f0(%rbp)
    4894:	4c 89 9d 00 fb ff ff 	mov    %r11,-0x500(%rbp)
    489b:	48 89 95 08 fb ff ff 	mov    %rdx,-0x4f8(%rbp)
    48a2:	48 89 b5 30 fb ff ff 	mov    %rsi,-0x4d0(%rbp)
    48a9:	e9 92 04 00 00       	jmp    0x4d40
    48ae:	48 8b 85 58 fb ff ff 	mov    -0x4a8(%rbp),%rax
    48b5:	48 85 c0             	test   %rax,%rax
    48b8:	0f 84 fc 03 00 00    	je     0x4cba
    48be:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    48c5:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    48c9:	48 85 d2             	test   %rdx,%rdx
    48cc:	0f 84 40 01 00 00    	je     0x4a12
    48d2:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    48d6:	be 40 00 00 00       	mov    $0x40,%esi
    48db:	48 29 d6             	sub    %rdx,%rsi
    48de:	48 8b bd 80 fb ff ff 	mov    -0x480(%rbp),%rdi
    48e5:	48 89 f1             	mov    %rsi,%rcx
    48e8:	49 89 f8             	mov    %rdi,%r8
    48eb:	49 d3 e8             	shr    %cl,%r8
    48ee:	31 c9                	xor    %ecx,%ecx
    48f0:	48 39 ca             	cmp    %rcx,%rdx
    48f3:	ba 00 00 00 00       	mov    $0x0,%edx
    48f8:	0f 94 c2             	sete   %dl
    48fb:	48 85 d2             	test   %rdx,%rdx
    48fe:	49 0f 44 c8          	cmove  %r8,%rcx
    4902:	48 8b 95 90 fc ff ff 	mov    -0x370(%rbp),%rdx
    4909:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    490d:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    4911:	49 8b 30             	mov    (%r8),%rsi
    4914:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    491b:	00 28 00 
    491e:	4c 39 ce             	cmp    %r9,%rsi
    4921:	4c 89 85 c8 fa ff ff 	mov    %r8,-0x538(%rbp)
    4928:	0f 82 0c 00 00 00    	jb     0x493a
    492e:	48 89 b5 b8 fa ff ff 	mov    %rsi,-0x548(%rbp)
    4935:	e9 4a 00 00 00       	jmp    0x4984
    493a:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    493e:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    4945:	48 89 b5 c0 fa ff ff 	mov    %rsi,-0x540(%rbp)
    494c:	48 89 d6             	mov    %rdx,%rsi
    494f:	48 89 ca             	mov    %rcx,%rdx
    4952:	48 8b 8d c0 fa ff ff 	mov    -0x540(%rbp),%rcx
    4959:	e8 82 b7 ff ff       	call   0xe0
    495e:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    4965:	31 d2                	xor    %edx,%edx
    4967:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    496b:	48 83 f8 00          	cmp    $0x0,%rax
    496f:	0f 8f 08 00 00 00    	jg     0x497d
    4975:	49 89 c4             	mov    %rax,%r12
    4978:	e9 aa 27 00 00       	jmp    0x7127
    497d:	48 89 85 b8 fa ff ff 	mov    %rax,-0x548(%rbp)
    4984:	48 8b 85 b8 fa ff ff 	mov    -0x548(%rbp),%rax
    498b:	48 89 c1             	mov    %rax,%rcx
    498e:	48 83 c1 28          	add    $0x28,%rcx
    4992:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    4999:	00 28 00 
    499c:	48 29 d1             	sub    %rdx,%rcx
    499f:	48 8b 95 c8 fa ff ff 	mov    -0x538(%rbp),%rdx
    49a6:	48 89 0a             	mov    %rcx,(%rdx)
    49a9:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    49b0:	ff 00 00 
    49b3:	48 21 c8             	and    %rcx,%rax
    49b6:	31 c9                	xor    %ecx,%ecx
    49b8:	48 8b 95 38 fc ff ff 	mov    -0x3c8(%rbp),%rdx
    49bf:	48 89 10             	mov    %rdx,(%rax)
    49c2:	48 8b b5 68 fb ff ff 	mov    -0x498(%rbp),%rsi
    49c9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    49cd:	48 89 48 10          	mov    %rcx,0x10(%rax)
    49d1:	48 89 48 18          	mov    %rcx,0x18(%rax)
    49d5:	48 89 48 20          	mov    %rcx,0x20(%rax)
    49d9:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    49e0:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    49e4:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    49ea:	4c 01 c7             	add    %r8,%rdi
    49ed:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    49f1:	48 89 85 b8 fa ff ff 	mov    %rax,-0x548(%rbp)
    49f8:	b8 01 00 00 00       	mov    $0x1,%eax
    49fd:	48 89 85 c8 fa ff ff 	mov    %rax,-0x538(%rbp)
    4a04:	31 c0                	xor    %eax,%eax
    4a06:	48 89 85 c0 fa ff ff 	mov    %rax,-0x540(%rbp)
    4a0d:	e9 a2 01 00 00       	jmp    0x4bb4
    4a12:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    4a19:	48 8b 48 10          	mov    0x10(%rax),%rcx
    4a1d:	48 8b 50 18          	mov    0x18(%rax),%rdx
    4a21:	48 89 d6             	mov    %rdx,%rsi
    4a24:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    4a29:	bf 40 00 00 00       	mov    $0x40,%edi
    4a2e:	48 29 f7             	sub    %rsi,%rdi
    4a31:	48 89 8d b0 fa ff ff 	mov    %rcx,-0x550(%rbp)
    4a38:	4c 8b 85 80 fb ff ff 	mov    -0x480(%rbp),%r8
    4a3f:	48 89 f9             	mov    %rdi,%rcx
    4a42:	4d 89 c1             	mov    %r8,%r9
    4a45:	49 d3 e9             	shr    %cl,%r9
    4a48:	31 c9                	xor    %ecx,%ecx
    4a4a:	48 39 ce             	cmp    %rcx,%rsi
    4a4d:	be 00 00 00 00       	mov    $0x0,%esi
    4a52:	40 0f 94 c6          	sete   %sil
    4a56:	48 85 f6             	test   %rsi,%rsi
    4a59:	49 0f 44 c9          	cmove  %r9,%rcx
    4a5d:	be 01 00 00 00       	mov    $0x1,%esi
    4a62:	48 89 cf             	mov    %rcx,%rdi
    4a65:	48 01 f7             	add    %rsi,%rdi
    4a68:	48 21 d7             	and    %rdx,%rdi
    4a6b:	ba 28 00 00 00       	mov    $0x28,%edx
    4a70:	48 0f af ca          	imul   %rdx,%rcx
    4a74:	48 8b 95 b0 fa ff ff 	mov    -0x550(%rbp),%rdx
    4a7b:	4c 8d 0c 0a          	lea    (%rdx,%rcx,1),%r9
    4a7f:	49 8b 49 10          	mov    0x10(%r9),%rcx
    4a83:	48 85 c9             	test   %rcx,%rcx
    4a86:	0f 84 af 00 00 00    	je     0x4b3b
    4a8c:	49 8b 09             	mov    (%r9),%rcx
    4a8f:	4d 8b 51 08          	mov    0x8(%r9),%r10
    4a93:	4c 8b 9d 38 fc ff ff 	mov    -0x3c8(%rbp),%r11
    4a9a:	49 39 cb             	cmp    %rcx,%r11
    4a9d:	ba 00 00 00 00       	mov    $0x0,%edx
    4aa2:	0f 94 c2             	sete   %dl
    4aa5:	48 8b 8d 68 fb ff ff 	mov    -0x498(%rbp),%rcx
    4aac:	4c 39 d1             	cmp    %r10,%rcx
    4aaf:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    4ab5:	41 0f 94 c0          	sete   %r8b
    4ab9:	4c 21 c2             	and    %r8,%rdx
    4abc:	48 85 d2             	test   %rdx,%rdx
    4abf:	0f 84 0c 00 00 00    	je     0x4ad1
    4ac5:	4c 89 8d b8 fa ff ff 	mov    %r9,-0x548(%rbp)
    4acc:	e9 53 00 00 00       	jmp    0x4b24
    4ad1:	ba 28 00 00 00       	mov    $0x28,%edx
    4ad6:	48 0f af fa          	imul   %rdx,%rdi
    4ada:	48 8b 95 b0 fa ff ff 	mov    -0x550(%rbp),%rdx
    4ae1:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    4ae5:	49 8b 50 10          	mov    0x10(%r8),%rdx
    4ae9:	48 85 d2             	test   %rdx,%rdx
    4aec:	0f 84 49 00 00 00    	je     0x4b3b
    4af2:	49 8b 10             	mov    (%r8),%rdx
    4af5:	49 8b 78 08          	mov    0x8(%r8),%rdi
    4af9:	49 39 d3             	cmp    %rdx,%r11
    4afc:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    4b02:	41 0f 94 c1          	sete   %r9b
    4b06:	48 39 f9             	cmp    %rdi,%rcx
    4b09:	ba 00 00 00 00       	mov    $0x0,%edx
    4b0e:	0f 94 c2             	sete   %dl
    4b11:	49 21 d1             	and    %rdx,%r9
    4b14:	4d 85 c9             	test   %r9,%r9
    4b17:	0f 84 1e 00 00 00    	je     0x4b3b
    4b1d:	4c 89 85 b8 fa ff ff 	mov    %r8,-0x548(%rbp)
    4b24:	31 c0                	xor    %eax,%eax
    4b26:	48 89 85 c8 fa ff ff 	mov    %rax,-0x538(%rbp)
    4b2d:	31 c0                	xor    %eax,%eax
    4b2f:	48 89 85 c0 fa ff ff 	mov    %rax,-0x540(%rbp)
    4b36:	e9 79 00 00 00       	jmp    0x4bb4
    4b3b:	48 8d 85 10 fe ff ff 	lea    -0x1f0(%rbp),%rax
    4b42:	48 89 c1             	mov    %rax,%rcx
    4b45:	48 8b 95 38 fc ff ff 	mov    -0x3c8(%rbp),%rdx
    4b4c:	48 89 11             	mov    %rdx,(%rcx)
    4b4f:	48 8b b5 68 fb ff ff 	mov    -0x498(%rbp),%rsi
    4b56:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    4b5a:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    4b61:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    4b68:	48 89 ca             	mov    %rcx,%rdx
    4b6b:	e8 80 b5 ff ff       	call   0xf0
    4b70:	48 83 f8 00          	cmp    $0x0,%rax
    4b74:	0f 8d 08 00 00 00    	jge    0x4b82
    4b7a:	49 89 c4             	mov    %rax,%r12
    4b7d:	e9 a5 25 00 00       	jmp    0x7127
    4b82:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    4b89:	48 8b 11             	mov    (%rcx),%rdx
    4b8c:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    4b90:	48 83 e6 01          	and    $0x1,%rsi
    4b94:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    4b98:	48 89 85 b8 fa ff ff 	mov    %rax,-0x548(%rbp)
    4b9f:	b8 01 00 00 00       	mov    $0x1,%eax
    4ba4:	48 89 85 c8 fa ff ff 	mov    %rax,-0x538(%rbp)
    4bab:	31 c0                	xor    %eax,%eax
    4bad:	48 89 85 c0 fa ff ff 	mov    %rax,-0x540(%rbp)
    4bb4:	48 8b 85 c8 fa ff ff 	mov    -0x538(%rbp),%rax
    4bbb:	48 85 c0             	test   %rax,%rax
    4bbe:	0f 84 68 00 00 00    	je     0x4c2c
    4bc4:	48 8b 85 b8 fa ff ff 	mov    -0x548(%rbp),%rax
    4bcb:	48 8b 8d 50 fb ff ff 	mov    -0x4b0(%rbp),%rcx
    4bd2:	48 89 48 10          	mov    %rcx,0x10(%rax)
    4bd6:	31 d2                	xor    %edx,%edx
    4bd8:	48 39 d1             	cmp    %rdx,%rcx
    4bdb:	be 00 00 00 00       	mov    $0x0,%esi
    4be0:	40 0f 95 c6          	setne  %sil
    4be4:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    4be8:	48 09 f7             	or     %rsi,%rdi
    4beb:	40 88 78 20          	mov    %dil,0x20(%rax)
    4bef:	48 8b b5 70 fb ff ff 	mov    -0x490(%rbp),%rsi
    4bf6:	48 89 70 18          	mov    %rsi,0x18(%rax)
    4bfa:	48 8b bd 78 fb ff ff 	mov    -0x488(%rbp),%rdi
    4c01:	48 39 d7             	cmp    %rdx,%rdi
    4c04:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    4c0a:	41 0f 95 c0          	setne  %r8b
    4c0e:	44 0f b6 48 20       	movzbl 0x20(%rax),%r9d
    4c13:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    4c19:	4d 85 c0             	test   %r8,%r8
    4c1c:	4c 0f 44 d2          	cmove  %rdx,%r10
    4c20:	4d 09 d1             	or     %r10,%r9
    4c23:	44 88 48 20          	mov    %r9b,0x20(%rax)
    4c27:	e9 8e 00 00 00       	jmp    0x4cba
    4c2c:	48 8b 85 b8 fa ff ff 	mov    -0x548(%rbp),%rax
    4c33:	48 8b 48 10          	mov    0x10(%rax),%rcx
    4c37:	48 8b 95 50 fb ff ff 	mov    -0x4b0(%rbp),%rdx
    4c3e:	48 01 d1             	add    %rdx,%rcx
    4c41:	48 89 48 10          	mov    %rcx,0x10(%rax)
    4c45:	31 f6                	xor    %esi,%esi
    4c47:	48 39 f1             	cmp    %rsi,%rcx
    4c4a:	b9 00 00 00 00       	mov    $0x0,%ecx
    4c4f:	0f 95 c1             	setne  %cl
    4c52:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    4c56:	48 09 cf             	or     %rcx,%rdi
    4c59:	40 88 78 20          	mov    %dil,0x20(%rax)
    4c5d:	48 8b 48 18          	mov    0x18(%rax),%rcx
    4c61:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    4c65:	48 83 e7 02          	and    $0x2,%rdi
    4c69:	48 39 f7             	cmp    %rsi,%rdi
    4c6c:	bf 00 00 00 00       	mov    $0x0,%edi
    4c71:	40 0f 95 c7          	setne  %dil
    4c75:	45 31 c0             	xor    %r8d,%r8d
    4c78:	48 85 ff             	test   %rdi,%rdi
    4c7b:	49 0f 44 c8          	cmove  %r8,%rcx
    4c7f:	4c 8b 85 78 fb ff ff 	mov    -0x488(%rbp),%r8
    4c86:	4c 01 c7             	add    %r8,%rdi
    4c89:	4c 8b 8d 70 fb ff ff 	mov    -0x490(%rbp),%r9
    4c90:	4c 01 c9             	add    %r9,%rcx
    4c93:	48 89 48 18          	mov    %rcx,0x18(%rax)
    4c97:	48 39 f7             	cmp    %rsi,%rdi
    4c9a:	bf 00 00 00 00       	mov    $0x0,%edi
    4c9f:	40 0f 95 c7          	setne  %dil
    4ca3:	0f b6 48 20          	movzbl 0x20(%rax),%ecx
    4ca7:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    4cad:	48 85 ff             	test   %rdi,%rdi
    4cb0:	4c 0f 44 d6          	cmove  %rsi,%r10
    4cb4:	4c 09 d1             	or     %r10,%rcx
    4cb7:	88 48 20             	mov    %cl,0x20(%rax)
    4cba:	48 8b 85 e8 fa ff ff 	mov    -0x518(%rbp),%rax
    4cc1:	48 63 08             	movslq (%rax),%rcx
    4cc4:	48 ba 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rdx
    4ccb:	79 37 9e 
    4cce:	48 be 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%rsi
    4cd5:	79 37 9e 
    4cd8:	48 8b bd d8 fa ff ff 	mov    -0x528(%rbp),%rdi
    4cdf:	48 31 fe             	xor    %rdi,%rsi
    4ce2:	48 0f af f2          	imul   %rdx,%rsi
    4ce6:	49 89 f0             	mov    %rsi,%r8
    4ce9:	49 c1 e8 1d          	shr    $0x1d,%r8
    4ced:	4c 31 c6             	xor    %r8,%rsi
    4cf0:	4c 8b 85 c8 fb ff ff 	mov    -0x438(%rbp),%r8
    4cf7:	4c 31 c6             	xor    %r8,%rsi
    4cfa:	48 0f af f2          	imul   %rdx,%rsi
    4cfe:	49 89 f1             	mov    %rsi,%r9
    4d01:	49 c1 e9 1d          	shr    $0x1d,%r9
    4d05:	4c 31 ce             	xor    %r9,%rsi
    4d08:	48 0f af f2          	imul   %rdx,%rsi
    4d0c:	48 89 bd 40 fb ff ff 	mov    %rdi,-0x4c0(%rbp)
    4d13:	4c 89 85 e0 fa ff ff 	mov    %r8,-0x520(%rbp)
    4d1a:	48 89 b5 10 fb ff ff 	mov    %rsi,-0x4f0(%rbp)
    4d21:	ba 01 00 00 00       	mov    $0x1,%edx
    4d26:	48 89 95 00 fb ff ff 	mov    %rdx,-0x500(%rbp)
    4d2d:	48 89 8d 08 fb ff ff 	mov    %rcx,-0x4f8(%rbp)
    4d34:	ba 01 00 00 00       	mov    $0x1,%edx
    4d39:	48 89 95 30 fb ff ff 	mov    %rdx,-0x4d0(%rbp)
    4d40:	48 8b 85 d0 fa ff ff 	mov    -0x530(%rbp),%rax
    4d47:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    4d4e:	b8 01 00 00 00       	mov    $0x1,%eax
    4d53:	48 89 85 f8 fa ff ff 	mov    %rax,-0x508(%rbp)
    4d5a:	31 c0                	xor    %eax,%eax
    4d5c:	48 89 03             	mov    %rax,(%rbx)
    4d5f:	48 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%rax
    4d66:	b9 01 00 00 00       	mov    $0x1,%ecx
    4d6b:	48 89 c2             	mov    %rax,%rdx
    4d6e:	48 01 ca             	add    %rcx,%rdx
    4d71:	48 89 95 20 fb ff ff 	mov    %rdx,-0x4e0(%rbp)
    4d78:	e9 9b f1 ff ff       	jmp    0x3f18
    4d7d:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    4d84:	e8 b7 b2 ff ff       	call   0x40
    4d89:	48 85 c0             	test   %rax,%rax
    4d8c:	0f 84 1d fa ff ff    	je     0x47af
    4d92:	e9 89 23 00 00       	jmp    0x7120
    4d97:	48 8b 85 c0 fb ff ff 	mov    -0x440(%rbp),%rax
    4d9e:	48 85 c0             	test   %rax,%rax
    4da1:	0f 84 c0 03 00 00    	je     0x5167
    4da7:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    4dae:	48 8b 48 68          	mov    0x68(%rax),%rcx
    4db2:	48 85 c9             	test   %rcx,%rcx
    4db5:	0f 84 22 01 00 00    	je     0x4edd
    4dbb:	48 8b 48 38          	mov    0x38(%rax),%rcx
    4dbf:	ba 40 00 00 00       	mov    $0x40,%edx
    4dc4:	48 29 ca             	sub    %rcx,%rdx
    4dc7:	48 89 8d c0 fb ff ff 	mov    %rcx,-0x440(%rbp)
    4dce:	48 8b b5 a0 fb ff ff 	mov    -0x460(%rbp),%rsi
    4dd5:	48 89 d1             	mov    %rdx,%rcx
    4dd8:	48 89 f7             	mov    %rsi,%rdi
    4ddb:	48 d3 ef             	shr    %cl,%rdi
    4dde:	31 c9                	xor    %ecx,%ecx
    4de0:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    4de7:	48 39 ca             	cmp    %rcx,%rdx
    4dea:	ba 00 00 00 00       	mov    $0x0,%edx
    4def:	0f 94 c2             	sete   %dl
    4df2:	48 85 d2             	test   %rdx,%rdx
    4df5:	48 0f 44 cf          	cmove  %rdi,%rcx
    4df9:	48 8b 50 08          	mov    0x8(%rax),%rdx
    4dfd:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    4e01:	4c 8b 3f             	mov    (%rdi),%r15
    4e04:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    4e0b:	00 28 00 
    4e0e:	49 39 d7             	cmp    %rdx,%r15
    4e11:	48 89 bd c0 fb ff ff 	mov    %rdi,-0x440(%rbp)
    4e18:	0f 82 05 00 00 00    	jb     0x4e23
    4e1e:	e9 3b 00 00 00       	jmp    0x4e5e
    4e23:	4c 8b 40 60          	mov    0x60(%rax),%r8
    4e27:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    4e2e:	48 89 c6             	mov    %rax,%rsi
    4e31:	48 89 ca             	mov    %rcx,%rdx
    4e34:	4c 89 c1             	mov    %r8,%rcx
    4e37:	e8 a4 b2 ff ff       	call   0xe0
    4e3c:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    4e43:	31 d2                	xor    %edx,%edx
    4e45:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    4e49:	48 83 f8 00          	cmp    $0x0,%rax
    4e4d:	0f 8f 08 00 00 00    	jg     0x4e5b
    4e53:	49 89 c4             	mov    %rax,%r12
    4e56:	e9 cc 22 00 00       	jmp    0x7127
    4e5b:	49 89 c7             	mov    %rax,%r15
    4e5e:	4c 89 f8             	mov    %r15,%rax
    4e61:	48 83 c0 28          	add    $0x28,%rax
    4e65:	48 b9 00 00 00 00 00 	movabs $0x28000000000000,%rcx
    4e6c:	00 28 00 
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 8b 8d c0 fb ff ff 	mov    -0x440(%rbp),%rcx
    4e79:	48 89 01             	mov    %rax,(%rcx)
    4e7c:	48 b8 ff ff ff ff ff 	movabs $0xffffffffffff,%rax
    4e83:	ff 00 00 
    4e86:	49 21 c7             	and    %rax,%r15
    4e89:	31 c0                	xor    %eax,%eax
    4e8b:	48 8b 8d b0 fb ff ff 	mov    -0x450(%rbp),%rcx
    4e92:	49 89 0f             	mov    %rcx,(%r15)
    4e95:	48 8b 95 a8 fb ff ff 	mov    -0x458(%rbp),%rdx
    4e9c:	49 89 57 08          	mov    %rdx,0x8(%r15)
    4ea0:	49 89 47 10          	mov    %rax,0x10(%r15)
    4ea4:	49 89 47 18          	mov    %rax,0x18(%r15)
    4ea8:	49 89 47 20          	mov    %rax,0x20(%r15)
    4eac:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    4eb3:	48 8b 70 60          	mov    0x60(%rax),%rsi
    4eb7:	bf 01 00 00 00       	mov    $0x1,%edi
    4ebc:	48 01 fe             	add    %rdi,%rsi
    4ebf:	48 89 70 60          	mov    %rsi,0x60(%rax)
    4ec3:	be 01 00 00 00       	mov    $0x1,%esi
    4ec8:	48 89 b5 c0 fb ff ff 	mov    %rsi,-0x440(%rbp)
    4ecf:	31 f6                	xor    %esi,%esi
    4ed1:	48 89 b5 40 fc ff ff 	mov    %rsi,-0x3c0(%rbp)
    4ed8:	e9 93 01 00 00       	jmp    0x5070
    4edd:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    4ee4:	48 8b 48 10          	mov    0x10(%rax),%rcx
    4ee8:	48 8b 50 18          	mov    0x18(%rax),%rdx
    4eec:	48 89 d6             	mov    %rdx,%rsi
    4eef:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    4ef4:	bf 40 00 00 00       	mov    $0x40,%edi
    4ef9:	48 29 f7             	sub    %rsi,%rdi
    4efc:	48 89 8d 88 fc ff ff 	mov    %rcx,-0x378(%rbp)
    4f03:	4c 8b 85 a0 fb ff ff 	mov    -0x460(%rbp),%r8
    4f0a:	48 89 f9             	mov    %rdi,%rcx
    4f0d:	49 d3 e8             	shr    %cl,%r8
    4f10:	31 c9                	xor    %ecx,%ecx
    4f12:	48 39 ce             	cmp    %rcx,%rsi
    4f15:	be 00 00 00 00       	mov    $0x0,%esi
    4f1a:	40 0f 94 c6          	sete   %sil
    4f1e:	48 85 f6             	test   %rsi,%rsi
    4f21:	49 0f 44 c8          	cmove  %r8,%rcx
    4f25:	be 01 00 00 00       	mov    $0x1,%esi
    4f2a:	48 89 cf             	mov    %rcx,%rdi
    4f2d:	48 01 f7             	add    %rsi,%rdi
    4f30:	48 21 d7             	and    %rdx,%rdi
    4f33:	ba 28 00 00 00       	mov    $0x28,%edx
    4f38:	48 0f af ca          	imul   %rdx,%rcx
    4f3c:	48 8b 95 88 fc ff ff 	mov    -0x378(%rbp),%rdx
    4f43:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
    4f47:	49 8b 48 10          	mov    0x10(%r8),%rcx
    4f4b:	48 85 c9             	test   %rcx,%rcx
    4f4e:	0f 84 a7 00 00 00    	je     0x4ffb
    4f54:	49 8b 08             	mov    (%r8),%rcx
    4f57:	4d 8b 48 08          	mov    0x8(%r8),%r9
    4f5b:	4c 8b 95 b0 fb ff ff 	mov    -0x450(%rbp),%r10
    4f62:	49 39 ca             	cmp    %rcx,%r10
    4f65:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    4f6b:	41 0f 94 c3          	sete   %r11b
    4f6f:	48 8b 8d a8 fb ff ff 	mov    -0x458(%rbp),%rcx
    4f76:	4c 39 c9             	cmp    %r9,%rcx
    4f79:	ba 00 00 00 00       	mov    $0x0,%edx
    4f7e:	0f 94 c2             	sete   %dl
    4f81:	49 21 d3             	and    %rdx,%r11
    4f84:	4d 85 db             	test   %r11,%r11
    4f87:	0f 84 08 00 00 00    	je     0x4f95
    4f8d:	4d 89 c7             	mov    %r8,%r15
    4f90:	e9 4f 00 00 00       	jmp    0x4fe4
    4f95:	ba 28 00 00 00       	mov    $0x28,%edx
    4f9a:	48 0f af fa          	imul   %rdx,%rdi
    4f9e:	48 8b 95 88 fc ff ff 	mov    -0x378(%rbp),%rdx
    4fa5:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    4fa9:	49 8b 50 10          	mov    0x10(%r8),%rdx
    4fad:	48 85 d2             	test   %rdx,%rdx
    4fb0:	0f 84 45 00 00 00    	je     0x4ffb
    4fb6:	49 8b 10             	mov    (%r8),%rdx
    4fb9:	49 8b 78 08          	mov    0x8(%r8),%rdi
    4fbd:	49 39 d2             	cmp    %rdx,%r10
    4fc0:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    4fc6:	41 0f 94 c1          	sete   %r9b
    4fca:	48 39 f9             	cmp    %rdi,%rcx
    4fcd:	ba 00 00 00 00       	mov    $0x0,%edx
    4fd2:	0f 94 c2             	sete   %dl
    4fd5:	49 21 d1             	and    %rdx,%r9
    4fd8:	4d 85 c9             	test   %r9,%r9
    4fdb:	0f 84 1a 00 00 00    	je     0x4ffb
    4fe1:	4d 89 c7             	mov    %r8,%r15
    4fe4:	31 c0                	xor    %eax,%eax
    4fe6:	48 89 85 c0 fb ff ff 	mov    %rax,-0x440(%rbp)
    4fed:	31 c0                	xor    %eax,%eax
    4fef:	48 89 85 40 fc ff ff 	mov    %rax,-0x3c0(%rbp)
    4ff6:	e9 75 00 00 00       	jmp    0x5070
    4ffb:	48 8d 85 90 fd ff ff 	lea    -0x270(%rbp),%rax
    5002:	48 89 c1             	mov    %rax,%rcx
    5005:	48 8b 95 b0 fb ff ff 	mov    -0x450(%rbp),%rdx
    500c:	48 89 11             	mov    %rdx,(%rcx)
    500f:	48 8b 95 a8 fb ff ff 	mov    -0x458(%rbp),%rdx
    5016:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    501a:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    5021:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    5028:	48 89 ca             	mov    %rcx,%rdx
    502b:	e8 c0 b0 ff ff       	call   0xf0
    5030:	48 83 f8 00          	cmp    $0x0,%rax
    5034:	0f 8d 08 00 00 00    	jge    0x5042
    503a:	49 89 c4             	mov    %rax,%r12
    503d:	e9 e5 20 00 00       	jmp    0x7127
    5042:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    5049:	48 8b 11             	mov    (%rcx),%rdx
    504c:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    5050:	48 83 e6 01          	and    $0x1,%rsi
    5054:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    5058:	49 89 c7             	mov    %rax,%r15
    505b:	b8 01 00 00 00       	mov    $0x1,%eax
    5060:	48 89 85 c0 fb ff ff 	mov    %rax,-0x440(%rbp)
    5067:	31 c0                	xor    %eax,%eax
    5069:	48 89 85 40 fc ff ff 	mov    %rax,-0x3c0(%rbp)
    5070:	48 8b 85 c0 fb ff ff 	mov    -0x440(%rbp),%rax
    5077:	48 85 c0             	test   %rax,%rax
    507a:	0f 84 60 00 00 00    	je     0x50e0
    5080:	48 8b 85 b8 fb ff ff 	mov    -0x448(%rbp),%rax
    5087:	49 89 47 10          	mov    %rax,0x10(%r15)
    508b:	31 c9                	xor    %ecx,%ecx
    508d:	48 39 c8             	cmp    %rcx,%rax
    5090:	ba 00 00 00 00       	mov    $0x0,%edx
    5095:	0f 95 c2             	setne  %dl
    5098:	41 0f b6 77 20       	movzbl 0x20(%r15),%esi
    509d:	48 09 d6             	or     %rdx,%rsi
    50a0:	41 88 77 20          	mov    %sil,0x20(%r15)
    50a4:	48 8b 95 98 fb ff ff 	mov    -0x468(%rbp),%rdx
    50ab:	49 89 57 18          	mov    %rdx,0x18(%r15)
    50af:	48 8b b5 90 fb ff ff 	mov    -0x470(%rbp),%rsi
    50b6:	48 39 ce             	cmp    %rcx,%rsi
    50b9:	bf 00 00 00 00       	mov    $0x0,%edi
    50be:	40 0f 95 c7          	setne  %dil
    50c2:	45 0f b6 47 20       	movzbl 0x20(%r15),%r8d
    50c7:	41 b9 02 00 00 00    	mov    $0x2,%r9d
    50cd:	48 85 ff             	test   %rdi,%rdi
    50d0:	4c 0f 44 c9          	cmove  %rcx,%r9
    50d4:	4d 09 c8             	or     %r9,%r8
    50d7:	45 88 47 20          	mov    %r8b,0x20(%r15)
    50db:	e9 87 00 00 00       	jmp    0x5167
    50e0:	49 8b 47 10          	mov    0x10(%r15),%rax
    50e4:	48 8b 8d b8 fb ff ff 	mov    -0x448(%rbp),%rcx
    50eb:	48 01 c8             	add    %rcx,%rax
    50ee:	49 89 47 10          	mov    %rax,0x10(%r15)
    50f2:	31 c9                	xor    %ecx,%ecx
    50f4:	48 39 c8             	cmp    %rcx,%rax
    50f7:	b8 00 00 00 00       	mov    $0x0,%eax
    50fc:	0f 95 c0             	setne  %al
    50ff:	41 0f b6 57 20       	movzbl 0x20(%r15),%edx
    5104:	48 09 c2             	or     %rax,%rdx
    5107:	41 88 57 20          	mov    %dl,0x20(%r15)
    510b:	49 8b 47 18          	mov    0x18(%r15),%rax
    510f:	41 0f b6 57 20       	movzbl 0x20(%r15),%edx
    5114:	48 83 e2 02          	and    $0x2,%rdx
    5118:	48 39 ca             	cmp    %rcx,%rdx
    511b:	ba 00 00 00 00       	mov    $0x0,%edx
    5120:	0f 95 c2             	setne  %dl
    5123:	31 f6                	xor    %esi,%esi
    5125:	48 85 d2             	test   %rdx,%rdx
    5128:	48 0f 44 c6          	cmove  %rsi,%rax
    512c:	48 8b b5 90 fb ff ff 	mov    -0x470(%rbp),%rsi
    5133:	48 01 f2             	add    %rsi,%rdx
    5136:	48 8b b5 98 fb ff ff 	mov    -0x468(%rbp),%rsi
    513d:	48 01 f0             	add    %rsi,%rax
    5140:	49 89 47 18          	mov    %rax,0x18(%r15)
    5144:	48 39 ca             	cmp    %rcx,%rdx
    5147:	ba 00 00 00 00       	mov    $0x0,%edx
    514c:	0f 95 c2             	setne  %dl
    514f:	41 0f b6 47 20       	movzbl 0x20(%r15),%eax
    5154:	be 02 00 00 00       	mov    $0x2,%esi
    5159:	48 85 d2             	test   %rdx,%rdx
    515c:	48 0f 44 f1          	cmove  %rcx,%rsi
    5160:	48 09 f0             	or     %rsi,%rax
    5163:	41 88 47 20          	mov    %al,0x20(%r15)
    5167:	48 8b 85 60 fb ff ff 	mov    -0x4a0(%rbp),%rax
    516e:	48 89 85 d0 fb ff ff 	mov    %rax,-0x430(%rbp)
    5175:	e9 8b 1e 00 00       	jmp    0x7005
    517a:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
    5181:	82 28 52 
    5184:	31 c9                	xor    %ecx,%ecx
    5186:	48 8b 95 18 fc ff ff 	mov    -0x3e8(%rbp),%rdx
    518d:	48 8b b5 e0 fb ff ff 	mov    -0x420(%rbp),%rsi
    5194:	48 21 f2             	and    %rsi,%rdx
    5197:	48 85 d2             	test   %rdx,%rdx
    519a:	0f 85 df 0d 00 00    	jne    0x5f7f
    51a0:	4c 8b bd 08 fc ff ff 	mov    -0x3f8(%rbp),%r15
    51a7:	31 d2                	xor    %edx,%edx
    51a9:	48 89 95 18 fc ff ff 	mov    %rdx,-0x3e8(%rbp)
    51b0:	31 d2                	xor    %edx,%edx
    51b2:	48 89 95 60 fb ff ff 	mov    %rdx,-0x4a0(%rbp)
    51b9:	48 89 85 98 fb ff ff 	mov    %rax,-0x468(%rbp)
    51c0:	31 d2                	xor    %edx,%edx
    51c2:	48 89 95 90 fb ff ff 	mov    %rdx,-0x470(%rbp)
    51c9:	48 89 8d b8 fb ff ff 	mov    %rcx,-0x448(%rbp)
    51d0:	31 d2                	xor    %edx,%edx
    51d2:	48 89 95 c0 fb ff ff 	mov    %rdx,-0x440(%rbp)
    51d9:	31 d2                	xor    %edx,%edx
    51db:	48 89 95 40 fc ff ff 	mov    %rdx,-0x3c0(%rbp)
    51e2:	31 d2                	xor    %edx,%edx
    51e4:	48 89 95 a8 fb ff ff 	mov    %rdx,-0x458(%rbp)
    51eb:	48 8b 85 f8 fb ff ff 	mov    -0x408(%rbp),%rax
    51f2:	49 39 c7             	cmp    %rax,%r15
    51f5:	0f 8c 75 00 00 00    	jl     0x5270
    51fb:	48 8b 8d a8 fb ff ff 	mov    -0x458(%rbp),%rcx
    5202:	48 89 8d b0 fb ff ff 	mov    %rcx,-0x450(%rbp)
    5209:	48 8b 8d 40 fc ff ff 	mov    -0x3c0(%rbp),%rcx
    5210:	48 89 8d 88 fc ff ff 	mov    %rcx,-0x378(%rbp)
    5217:	48 8b 8d 90 fb ff ff 	mov    -0x470(%rbp),%rcx
    521e:	48 89 8d a0 fb ff ff 	mov    %rcx,-0x460(%rbp)
    5225:	48 8b 8d 18 fc ff ff 	mov    -0x3e8(%rbp),%rcx
    522c:	48 89 8d 38 fb ff ff 	mov    %rcx,-0x4c8(%rbp)
    5233:	48 8b 8d 60 fb ff ff 	mov    -0x4a0(%rbp),%rcx
    523a:	48 89 8d f0 fa ff ff 	mov    %rcx,-0x510(%rbp)
    5241:	48 8b 8d 98 fb ff ff 	mov    -0x468(%rbp),%rcx
    5248:	48 89 8d 88 fb ff ff 	mov    %rcx,-0x478(%rbp)
    524f:	48 8b 8d b8 fb ff ff 	mov    -0x448(%rbp),%rcx
    5256:	48 89 8d 28 fb ff ff 	mov    %rcx,-0x4d8(%rbp)
    525d:	48 8b 8d c0 fb ff ff 	mov    -0x440(%rbp),%rcx
    5264:	48 89 8d 58 fb ff ff 	mov    %rcx,-0x4a8(%rbp)
    526b:	e9 d1 19 00 00       	jmp    0x6c41
    5270:	48 8b 8d e0 fb ff ff 	mov    -0x420(%rbp),%rcx
    5277:	48 85 c9             	test   %rcx,%rcx
    527a:	0f 84 08 00 00 00    	je     0x5288
    5280:	4c 89 fe             	mov    %r15,%rsi
    5283:	e9 11 00 00 00       	jmp    0x5299
    5288:	48 8b 95 30 fc ff ff 	mov    -0x3d0(%rbp),%rdx
    528f:	4a 8d 3c ba          	lea    (%rdx,%r15,4),%rdi
    5293:	44 8b 07             	mov    (%rdi),%r8d
    5296:	4c 89 c6             	mov    %r8,%rsi
    5299:	48 8b 85 d8 fb ff ff 	mov    -0x428(%rbp),%rax
    52a0:	48 8d 0c b0          	lea    (%rax,%rsi,4),%rcx
    52a4:	48 89 f2             	mov    %rsi,%rdx
    52a7:	48 c1 ea 06          	shr    $0x6,%rdx
    52ab:	48 8b bd 20 fc ff ff 	mov    -0x3e0(%rbp),%rdi
    52b2:	4c 8d 04 d7          	lea    (%rdi,%rdx,8),%r8
    52b6:	48 8b 95 10 fc ff ff 	mov    -0x3f0(%rbp),%rdx
    52bd:	4c 8b 8d 98 fc ff ff 	mov    -0x368(%rbp),%r9
    52c4:	4d 89 ca             	mov    %r9,%r10
    52c7:	48 85 d2             	test   %rdx,%rdx
    52ca:	4d 0f 44 d0          	cmove  %r8,%r10
    52ce:	4d 8b 02             	mov    (%r10),%r8
    52d1:	49 89 f2             	mov    %rsi,%r10
    52d4:	49 83 e2 3f          	and    $0x3f,%r10
    52d8:	48 89 8d 80 fb ff ff 	mov    %rcx,-0x480(%rbp)
    52df:	4c 89 d1             	mov    %r10,%rcx
    52e2:	49 d3 e8             	shr    %cl,%r8
    52e5:	b9 01 00 00 00       	mov    $0x1,%ecx
    52ea:	49 21 c8             	and    %rcx,%r8
    52ed:	45 31 d2             	xor    %r10d,%r10d
    52f0:	4d 39 d0             	cmp    %r10,%r8
    52f3:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    52f9:	41 0f 94 c0          	sete   %r8b
    52fd:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5303:	48 89 d7             	mov    %rdx,%rdi
    5306:	4c 31 df             	xor    %r11,%rdi
    5309:	49 21 f8             	and    %rdi,%r8
    530c:	48 8b bd e8 fb ff ff 	mov    -0x418(%rbp),%rdi
    5313:	4c 8d 1c b7          	lea    (%rdi,%rsi,4),%r11
    5317:	48 89 f2             	mov    %rsi,%rdx
    531a:	48 c1 ea 06          	shr    $0x6,%rdx
    531e:	48 8b 85 00 fc ff ff 	mov    -0x400(%rbp),%rax
    5325:	48 8d 3c d0          	lea    (%rax,%rdx,8),%rdi
    5329:	48 8b 95 f0 fb ff ff 	mov    -0x410(%rbp),%rdx
    5330:	4c 89 c8             	mov    %r9,%rax
    5333:	48 85 d2             	test   %rdx,%rdx
    5336:	48 0f 44 c7          	cmove  %rdi,%rax
    533a:	48 8b 38             	mov    (%rax),%rdi
    533d:	48 83 e6 3f          	and    $0x3f,%rsi
    5341:	48 89 f1             	mov    %rsi,%rcx
    5344:	48 d3 ef             	shr    %cl,%rdi
    5347:	b8 01 00 00 00       	mov    $0x1,%eax
    534c:	48 21 c7             	and    %rax,%rdi
    534f:	4c 39 d7             	cmp    %r10,%rdi
    5352:	bf 00 00 00 00       	mov    $0x0,%edi
    5357:	40 0f 94 c7          	sete   %dil
    535b:	b9 01 00 00 00       	mov    $0x1,%ecx
    5360:	48 89 d6             	mov    %rdx,%rsi
    5363:	48 31 ce             	xor    %rcx,%rsi
    5366:	48 21 f7             	and    %rsi,%rdi
    5369:	4d 85 c0             	test   %r8,%r8
    536c:	48 89 bd 38 fc ff ff 	mov    %rdi,-0x3c8(%rbp)
    5373:	4c 89 9d 68 fb ff ff 	mov    %r11,-0x498(%rbp)
    537a:	0f 85 d2 0b 00 00    	jne    0x5f52
    5380:	48 8b 8d 80 fb ff ff 	mov    -0x480(%rbp),%rcx
    5387:	48 63 31             	movslq (%rcx),%rsi
    538a:	48 8b 8d 50 fc ff ff 	mov    -0x3b0(%rbp),%rcx
    5391:	48 85 c9             	test   %rcx,%rcx
    5394:	48 89 b5 50 fb ff ff 	mov    %rsi,-0x4b0(%rbp)
    539b:	0f 84 41 01 00 00    	je     0x54e2
    53a1:	48 be 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rsi
    53a8:	79 37 9e 
    53ab:	48 8b 95 50 fb ff ff 	mov    -0x4b0(%rbp),%rdx
    53b2:	48 89 d7             	mov    %rdx,%rdi
    53b5:	48 c1 ef 2b          	shr    $0x2b,%rdi
    53b9:	49 89 d3             	mov    %rdx,%r11
    53bc:	49 c1 eb 2c          	shr    $0x2c,%r11
    53c0:	4c 31 df             	xor    %r11,%rdi
    53c3:	49 89 d3             	mov    %rdx,%r11
    53c6:	49 31 fb             	xor    %rdi,%r11
    53c9:	4c 0f af de          	imul   %rsi,%r11
    53cd:	4c 89 de             	mov    %r11,%rsi
    53d0:	48 c1 ee 1e          	shr    $0x1e,%rsi
    53d4:	4c 89 df             	mov    %r11,%rdi
    53d7:	48 31 f7             	xor    %rsi,%rdi
    53da:	48 be b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rsi
    53e1:	47 58 bf 
    53e4:	48 0f af fe          	imul   %rsi,%rdi
    53e8:	48 89 fe             	mov    %rdi,%rsi
    53eb:	48 c1 ee 1b          	shr    $0x1b,%rsi
    53ef:	48 31 f7             	xor    %rsi,%rdi
    53f2:	48 be eb 11 31 13 bb 	movabs $0x94d049bb133111eb,%rsi
    53f9:	49 d0 94 
    53fc:	48 0f af fe          	imul   %rsi,%rdi
    5400:	48 89 fe             	mov    %rdi,%rsi
    5403:	48 c1 ee 1f          	shr    $0x1f,%rsi
    5407:	48 31 f7             	xor    %rsi,%rdi
    540a:	be 40 00 00 00       	mov    $0x40,%esi
    540f:	48 29 ce             	sub    %rcx,%rsi
    5412:	48 89 f1             	mov    %rsi,%rcx
    5415:	48 d3 ef             	shr    %cl,%rdi
    5418:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
    541c:	48 89 f9             	mov    %rdi,%rcx
    541f:	48 89 f2             	mov    %rsi,%rdx
    5422:	48 d3 ea             	shr    %cl,%rdx
    5425:	48 21 c2             	and    %rax,%rdx
    5428:	48 85 d2             	test   %rdx,%rdx
    542b:	0f 84 b1 00 00 00    	je     0x54e2
    5431:	48 8d 8d f0 fc ff ff 	lea    -0x310(%rbp),%rcx
    5438:	48 89 ca             	mov    %rcx,%rdx
    543b:	48 8b 8d 80 fb ff ff 	mov    -0x480(%rbp),%rcx
    5442:	48 63 31             	movslq (%rcx),%rsi
    5445:	31 c9                	xor    %ecx,%ecx
    5447:	48 89 0a             	mov    %rcx,(%rdx)
    544a:	48 89 72 08          	mov    %rsi,0x8(%rdx)
    544e:	4c 89 42 10          	mov    %r8,0x10(%rdx)
    5452:	48 8b 8d 68 fb ff ff 	mov    -0x498(%rbp),%rcx
    5459:	48 63 31             	movslq (%rcx),%rsi
    545c:	45 31 c0             	xor    %r8d,%r8d
    545f:	4c 89 42 18          	mov    %r8,0x18(%rdx)
    5463:	48 89 72 20          	mov    %rsi,0x20(%rdx)
    5467:	48 8b b5 38 fc ff ff 	mov    -0x3c8(%rbp),%rsi
    546e:	48 89 72 28          	mov    %rsi,0x28(%rdx)
    5472:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    5478:	48 8b b5 50 fc ff ff 	mov    -0x3b0(%rbp),%rsi
    547f:	48 89 f1             	mov    %rsi,%rcx
    5482:	49 d3 e0             	shl    %cl,%r8
    5485:	49 01 f8             	add    %rdi,%r8
    5488:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    548d:	bf 02 00 00 00       	mov    $0x2,%edi
    5492:	4c 89 cf             	mov    %r9,%rdi
    5495:	48 89 ce             	mov    %rcx,%rsi
    5498:	48 89 95 80 fb ff ff 	mov    %rdx,-0x480(%rbp)
    549f:	48 8b 95 50 fc ff ff 	mov    -0x3b0(%rbp),%rdx
    54a6:	4c 89 c1             	mov    %r8,%rcx
    54a9:	4d 89 d8             	mov    %r11,%r8
    54ac:	4c 8b 8d 80 fb ff ff 	mov    -0x480(%rbp),%r9
    54b3:	41 bb 02 00 00 00    	mov    $0x2,%r11d
    54b9:	4c 89 1c 24          	mov    %r11,(%rsp)
    54bd:	e8 0e ac ff ff       	call   0xd0
    54c2:	48 83 f8 00          	cmp    $0x0,%rax
    54c6:	0f 8d 11 00 00 00    	jge    0x54dd
    54cc:	b8 80 00 00 00       	mov    $0x80,%eax
    54d1:	48 89 85 48 fb ff ff 	mov    %rax,-0x4b8(%rbp)
    54d8:	e9 29 1c 00 00       	jmp    0x7106
    54dd:	e9 70 0a 00 00       	jmp    0x5f52
    54e2:	49 83 fd 05          	cmp    $0x5,%r13
    54e6:	0f 85 d1 00 00 00    	jne    0x55bd
    54ec:	48 8b 85 50 fb ff ff 	mov    -0x4b0(%rbp),%rax
    54f3:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    54fa:	48 89 c2             	mov    %rax,%rdx
    54fd:	48 29 ca             	sub    %rcx,%rdx
    5500:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    5507:	48 39 f2             	cmp    %rsi,%rdx
    550a:	bf 00 00 00 00       	mov    $0x0,%edi
    550f:	40 0f 92 c7          	setb   %dil
    5513:	45 31 c0             	xor    %r8d,%r8d
    5516:	48 85 ff             	test   %rdi,%rdi
    5519:	49 0f 44 d0          	cmove  %r8,%rdx
    551d:	49 89 d1             	mov    %rdx,%r9
    5520:	49 c1 e9 06          	shr    $0x6,%r9
    5524:	48 83 e2 3f          	and    $0x3f,%rdx
    5528:	4c 8b 95 70 fc ff ff 	mov    -0x390(%rbp),%r10
    552f:	4f 8d 1c ca          	lea    (%r10,%r9,8),%r11
    5533:	49 8b 03             	mov    (%r11),%rax
    5536:	48 89 d1             	mov    %rdx,%rcx
    5539:	48 d3 e8             	shr    %cl,%rax
    553c:	b9 01 00 00 00       	mov    $0x1,%ecx
    5541:	48 21 c8             	and    %rcx,%rax
    5544:	48 21 f8             	and    %rdi,%rax
    5547:	48 8b bd 48 fc ff ff 	mov    -0x3b8(%rbp),%rdi
    554e:	4e 8d 1c cf          	lea    (%rdi,%r9,8),%r11
    5552:	49 8b 3b             	mov    (%r11),%rdi
    5555:	48 89 d1             	mov    %rdx,%rcx
    5558:	48 d3 ef             	shr    %cl,%rdi
    555b:	b9 01 00 00 00       	mov    $0x1,%ecx
    5560:	48 21 cf             	and    %rcx,%rdi
    5563:	4c 8b 9d 58 fc ff ff 	mov    -0x3a8(%rbp),%r11
    556a:	4b 8d 34 cb          	lea    (%r11,%r9,8),%rsi
    556e:	4c 8b 0e             	mov    (%rsi),%r9
    5571:	48 89 d1             	mov    %rdx,%rcx
    5574:	49 d3 e9             	shr    %cl,%r9
    5577:	b9 01 00 00 00       	mov    $0x1,%ecx
    557c:	49 21 c9             	and    %rcx,%r9
    557f:	48 8d 95 d0 fc ff ff 	lea    -0x330(%rbp),%rdx
    5586:	48 89 d6             	mov    %rdx,%rsi
    5589:	49 c1 e1 20          	shl    $0x20,%r9
    558d:	48 8b 95 50 fb ff ff 	mov    -0x4b0(%rbp),%rdx
    5594:	48 89 16             	mov    %rdx,(%rsi)
    5597:	4c 89 4e 08          	mov    %r9,0x8(%rsi)
    559b:	48 89 7e 10          	mov    %rdi,0x10(%rsi)
    559f:	4c 39 c0             	cmp    %r8,%rax
    55a2:	b8 00 00 00 00       	mov    $0x0,%eax
    55a7:	0f 95 c0             	setne  %al
    55aa:	48 85 c0             	test   %rax,%rax
    55ad:	49 0f 44 f0          	cmove  %r8,%rsi
    55b1:	48 89 b5 80 fb ff ff 	mov    %rsi,-0x480(%rbp)
    55b8:	e9 f1 01 00 00       	jmp    0x57ae
    55bd:	49 83 fd 01          	cmp    $0x1,%r13
    55c1:	0f 85 ee 00 00 00    	jne    0x56b5
    55c7:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    55ce:	79 37 9e 
    55d1:	48 8b 8d 50 fb ff ff 	mov    -0x4b0(%rbp),%rcx
    55d8:	48 89 ca             	mov    %rcx,%rdx
    55db:	48 c1 ea 2b          	shr    $0x2b,%rdx
    55df:	48 89 ce             	mov    %rcx,%rsi
    55e2:	48 c1 ee 2c          	shr    $0x2c,%rsi
    55e6:	48 31 f2             	xor    %rsi,%rdx
    55e9:	48 89 ce             	mov    %rcx,%rsi
    55ec:	48 31 d6             	xor    %rdx,%rsi
    55ef:	48 0f af f0          	imul   %rax,%rsi
    55f3:	b8 40 00 00 00       	mov    $0x40,%eax
    55f8:	48 8b 95 78 fc ff ff 	mov    -0x388(%rbp),%rdx
    55ff:	48 29 d0             	sub    %rdx,%rax
    5602:	48 89 c1             	mov    %rax,%rcx
    5605:	48 89 f7             	mov    %rsi,%rdi
    5608:	48 d3 ef             	shr    %cl,%rdi
    560b:	31 c0                	xor    %eax,%eax
    560d:	48 39 c2             	cmp    %rax,%rdx
    5610:	b9 00 00 00 00       	mov    $0x0,%ecx
    5615:	0f 94 c1             	sete   %cl
    5618:	48 85 c9             	test   %rcx,%rcx
    561b:	48 0f 44 c7          	cmove  %rdi,%rax
    561f:	48 8b 8d 70 fc ff ff 	mov    -0x390(%rbp),%rcx
    5626:	48 8d 3c c1          	lea    (%rcx,%rax,8),%rdi
    562a:	48 8b 07             	mov    (%rdi),%rax
    562d:	48 bf ff ff ff ff ff 	movabs $0xffffffffffff,%rdi
    5634:	ff 00 00 
    5637:	49 89 c0             	mov    %rax,%r8
    563a:	49 21 f8             	and    %rdi,%r8
    563d:	31 ff                	xor    %edi,%edi
    563f:	49 39 f8             	cmp    %rdi,%r8
    5642:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    5648:	41 0f 94 c1          	sete   %r9b
    564c:	49 89 f2             	mov    %rsi,%r10
    564f:	49 c1 ea 20          	shr    $0x20,%r10
    5653:	4c 31 d6             	xor    %r10,%rsi
    5656:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
    565c:	4c 21 d6             	and    %r10,%rsi
    565f:	48 83 e6 0f          	and    $0xf,%rsi
    5663:	48 83 c6 30          	add    $0x30,%rsi
    5667:	48 89 f1             	mov    %rsi,%rcx
    566a:	48 d3 e8             	shr    %cl,%rax
    566d:	48 83 e0 01          	and    $0x1,%rax
    5671:	48 83 f8 00          	cmp    $0x0,%rax
    5675:	b8 00 00 00 00       	mov    $0x0,%eax
    567a:	0f 95 c0             	setne  %al
    567d:	b9 01 00 00 00       	mov    $0x1,%ecx
    5682:	48 31 c8             	xor    %rcx,%rax
    5685:	49 09 c1             	or     %rax,%r9
    5688:	b8 01 00 00 00       	mov    $0x1,%eax
    568d:	49 29 c0             	sub    %rax,%r8
    5690:	b9 18 00 00 00       	mov    $0x18,%ecx
    5695:	4c 0f af c1          	imul   %rcx,%r8
    5699:	4c 89 f1             	mov    %r14,%rcx
    569c:	4c 01 c1             	add    %r8,%rcx
    569f:	48 89 fe             	mov    %rdi,%rsi
    56a2:	4d 85 c9             	test   %r9,%r9
    56a5:	48 0f 44 f1          	cmove  %rcx,%rsi
    56a9:	48 89 b5 80 fb ff ff 	mov    %rsi,-0x480(%rbp)
    56b0:	e9 f9 00 00 00       	jmp    0x57ae
    56b5:	48 8b 85 50 fb ff ff 	mov    -0x4b0(%rbp),%rax
    56bc:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    56c3:	48 89 c2             	mov    %rax,%rdx
    56c6:	48 29 ca             	sub    %rcx,%rdx
    56c9:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    56d0:	48 39 f2             	cmp    %rsi,%rdx
    56d3:	0f 82 0e 00 00 00    	jb     0x56e7
    56d9:	31 ff                	xor    %edi,%edi
    56db:	48 89 bd 80 fb ff ff 	mov    %rdi,-0x480(%rbp)
    56e2:	e9 c7 00 00 00       	jmp    0x57ae
    56e7:	49 83 fd 02          	cmp    $0x2,%r13
    56eb:	48 89 95 78 fb ff ff 	mov    %rdx,-0x488(%rbp)
    56f2:	0f 85 6a 00 00 00    	jne    0x5762
    56f8:	48 89 d7             	mov    %rdx,%rdi
    56fb:	48 c1 ef 06          	shr    $0x6,%rdi
    56ff:	4c 8b 85 70 fc ff ff 	mov    -0x390(%rbp),%r8
    5706:	4d 8d 0c f8          	lea    (%r8,%rdi,8),%r9
    570a:	49 8b 39             	mov    (%r9),%rdi
    570d:	49 89 d1             	mov    %rdx,%r9
    5710:	49 83 e1 3f          	and    $0x3f,%r9
    5714:	4c 89 c9             	mov    %r9,%rcx
    5717:	48 d3 ef             	shr    %cl,%rdi
    571a:	b9 01 00 00 00       	mov    $0x1,%ecx
    571f:	48 21 cf             	and    %rcx,%rdi
    5722:	45 31 c9             	xor    %r9d,%r9d
    5725:	4c 39 cf             	cmp    %r9,%rdi
    5728:	bf 00 00 00 00       	mov    $0x0,%edi
    572d:	40 0f 95 c7          	setne  %dil
    5731:	41 ba 10 00 00 00    	mov    $0x10,%r10d
    5737:	49 89 d3             	mov    %rdx,%r11
    573a:	4d 0f af da          	imul   %r10,%r11
    573e:	4c 8b 95 80 fc ff ff 	mov    -0x380(%rbp),%r10
    5745:	4c 89 d2             	mov    %r10,%rdx
    5748:	4c 01 da             	add    %r11,%rdx
    574b:	48 83 ea 08          	sub    $0x8,%rdx
    574f:	48 85 ff             	test   %rdi,%rdi
    5752:	49 0f 44 d1          	cmove  %r9,%rdx
    5756:	48 89 95 80 fb ff ff 	mov    %rdx,-0x480(%rbp)
    575d:	e9 4c 00 00 00       	jmp    0x57ae
    5762:	48 8b 85 70 fc ff ff 	mov    -0x390(%rbp),%rax
    5769:	48 8b 8d 78 fb ff ff 	mov    -0x488(%rbp),%rcx
    5770:	48 8d 14 88          	lea    (%rax,%rcx,4),%rdx
    5774:	8b 0a                	mov    (%rdx),%ecx
    5776:	ba 01 00 00 00       	mov    $0x1,%edx
    577b:	48 89 ce             	mov    %rcx,%rsi
    577e:	48 29 d6             	sub    %rdx,%rsi
    5781:	bf 18 00 00 00       	mov    $0x18,%edi
    5786:	48 0f af f7          	imul   %rdi,%rsi
    578a:	4c 89 f7             	mov    %r14,%rdi
    578d:	48 01 f7             	add    %rsi,%rdi
    5790:	31 f6                	xor    %esi,%esi
    5792:	48 39 f1             	cmp    %rsi,%rcx
    5795:	b9 00 00 00 00       	mov    $0x0,%ecx
    579a:	0f 94 c1             	sete   %cl
    579d:	49 89 f0             	mov    %rsi,%r8
    57a0:	48 85 c9             	test   %rcx,%rcx
    57a3:	4c 0f 44 c7          	cmove  %rdi,%r8
    57a7:	4c 89 85 80 fb ff ff 	mov    %r8,-0x480(%rbp)
    57ae:	49 83 fd 01          	cmp    $0x1,%r13
    57b2:	be 00 00 00 00       	mov    $0x0,%esi
    57b7:	40 0f 95 c6          	setne  %sil
    57bb:	31 ff                	xor    %edi,%edi
    57bd:	48 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%rax
    57c4:	48 89 85 78 fb ff ff 	mov    %rax,-0x488(%rbp)
    57cb:	48 8b 85 18 fc ff ff 	mov    -0x3e8(%rbp),%rax
    57d2:	48 89 85 70 fb ff ff 	mov    %rax,-0x490(%rbp)
    57d9:	48 8b 85 60 fb ff ff 	mov    -0x4a0(%rbp),%rax
    57e0:	48 89 85 e8 fa ff ff 	mov    %rax,-0x518(%rbp)
    57e7:	48 8b 85 98 fb ff ff 	mov    -0x468(%rbp),%rax
    57ee:	48 89 85 20 fb ff ff 	mov    %rax,-0x4e0(%rbp)
    57f5:	48 8b 85 a8 fb ff ff 	mov    -0x458(%rbp),%rax
    57fc:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    5803:	48 8b 85 90 fb ff ff 	mov    -0x470(%rbp),%rax
    580a:	48 89 85 40 fb ff ff 	mov    %rax,-0x4c0(%rbp)
    5811:	48 8b 85 b8 fb ff ff 	mov    -0x448(%rbp),%rax
    5818:	48 89 85 e0 fa ff ff 	mov    %rax,-0x520(%rbp)
    581f:	48 8b 85 c0 fb ff ff 	mov    -0x440(%rbp),%rax
    5826:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    582d:	48 8b 85 80 fb ff ff 	mov    -0x480(%rbp),%rax
    5834:	48 85 c0             	test   %rax,%rax
    5837:	0f 85 75 00 00 00    	jne    0x58b2
    583d:	48 8b 8d 78 fb ff ff 	mov    -0x488(%rbp),%rcx
    5844:	48 89 8d 40 fc ff ff 	mov    %rcx,-0x3c0(%rbp)
    584b:	48 8b 8d 70 fb ff ff 	mov    -0x490(%rbp),%rcx
    5852:	48 89 8d 18 fc ff ff 	mov    %rcx,-0x3e8(%rbp)
    5859:	48 8b 8d e8 fa ff ff 	mov    -0x518(%rbp),%rcx
    5860:	48 89 8d 60 fb ff ff 	mov    %rcx,-0x4a0(%rbp)
    5867:	48 8b 8d 20 fb ff ff 	mov    -0x4e0(%rbp),%rcx
    586e:	48 89 8d 98 fb ff ff 	mov    %rcx,-0x468(%rbp)
    5875:	48 8b 8d 18 fb ff ff 	mov    -0x4e8(%rbp),%rcx
    587c:	48 89 8d a8 fb ff ff 	mov    %rcx,-0x458(%rbp)
    5883:	48 8b 8d 40 fb ff ff 	mov    -0x4c0(%rbp),%rcx
    588a:	48 89 8d 90 fb ff ff 	mov    %rcx,-0x470(%rbp)
    5891:	48 8b 8d e0 fa ff ff 	mov    -0x520(%rbp),%rcx
    5898:	48 89 8d b8 fb ff ff 	mov    %rcx,-0x448(%rbp)
    589f:	48 8b 8d 10 fb ff ff 	mov    -0x4f0(%rbp),%rcx
    58a6:	48 89 8d c0 fb ff ff 	mov    %rcx,-0x440(%rbp)
    58ad:	e9 9b 06 00 00       	jmp    0x5f4d
    58b2:	48 8b 48 08          	mov    0x8(%rax),%rcx
    58b6:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    58bb:	49 89 c8             	mov    %rcx,%r8
    58be:	49 21 d0             	and    %rdx,%r8
    58c1:	ba 01 00 00 00       	mov    $0x1,%edx
    58c6:	4d 89 c1             	mov    %r8,%r9
    58c9:	49 29 d1             	sub    %rdx,%r9
    58cc:	41 ba 18 00 00 00    	mov    $0x18,%r10d
    58d2:	4d 0f af ca          	imul   %r10,%r9
    58d6:	4d 89 f2             	mov    %r14,%r10
    58d9:	4d 01 ca             	add    %r9,%r10
    58dc:	45 31 c9             	xor    %r9d,%r9d
    58df:	4d 39 c8             	cmp    %r9,%r8
    58e2:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    58e8:	41 0f 94 c0          	sete   %r8b
    58ec:	4d 89 cb             	mov    %r9,%r11
    58ef:	4d 85 c0             	test   %r8,%r8
    58f2:	4d 0f 44 da          	cmove  %r10,%r11
    58f6:	4c 8b 00             	mov    (%rax),%r8
    58f9:	4c 8b 95 50 fb ff ff 	mov    -0x4b0(%rbp),%r10
    5900:	4d 39 c2             	cmp    %r8,%r10
    5903:	b8 00 00 00 00       	mov    $0x0,%eax
    5908:	0f 94 c0             	sete   %al
    590b:	48 09 f0             	or     %rsi,%rax
    590e:	49 89 f8             	mov    %rdi,%r8
    5911:	49 01 d0             	add    %rdx,%r8
    5914:	48 85 c0             	test   %rax,%rax
    5917:	0f 85 0c 00 00 00    	jne    0x5929
    591d:	4c 89 9d 80 fb ff ff 	mov    %r11,-0x480(%rbp)
    5924:	e9 04 ff ff ff       	jmp    0x582d
    5929:	48 8b 03             	mov    (%rbx),%rax
    592c:	48 39 c7             	cmp    %rax,%rdi
    592f:	0f 8d 0f 00 00 00    	jge    0x5944
    5935:	4c 89 9d 80 fb ff ff 	mov    %r11,-0x480(%rbp)
    593c:	4c 89 c7             	mov    %r8,%rdi
    593f:	e9 e9 fe ff ff       	jmp    0x582d
    5944:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    594b:	48 8b 70 18          	mov    0x18(%rax),%rsi
    594f:	48 85 f6             	test   %rsi,%rsi
    5952:	48 89 8d 50 fb ff ff 	mov    %rcx,-0x4b0(%rbp)
    5959:	4c 89 85 f8 fa ff ff 	mov    %r8,-0x508(%rbp)
    5960:	0f 84 0c 00 00 00    	je     0x5972
    5966:	0f b6 3e             	movzbl (%rsi),%edi
    5969:	48 85 ff             	test   %rdi,%rdi
    596c:	0f 85 f3 05 00 00    	jne    0x5f65
    5972:	48 8b 85 80 fb ff ff 	mov    -0x480(%rbp),%rax
    5979:	48 8b 48 10          	mov    0x10(%rax),%rcx
    597d:	48 8b 95 50 fb ff ff 	mov    -0x4b0(%rbp),%rdx
    5984:	48 89 d6             	mov    %rdx,%rsi
    5987:	48 c1 ee 20          	shr    $0x20,%rsi
    598b:	48 83 e6 01          	and    $0x1,%rsi
    598f:	48 83 fe 00          	cmp    $0x0,%rsi
    5993:	be 00 00 00 00       	mov    $0x0,%esi
    5998:	40 0f 95 c6          	setne  %sil
    599c:	48 8b bd f8 fa ff ff 	mov    -0x508(%rbp),%rdi
    59a3:	48 89 3b             	mov    %rdi,(%rbx)
    59a6:	4c 8b 85 78 fb ff ff 	mov    -0x488(%rbp),%r8
    59ad:	4d 89 c1             	mov    %r8,%r9
    59b0:	49 83 c1 01          	add    $0x1,%r9
    59b4:	48 63 c9             	movslq %ecx,%rcx
    59b7:	45 31 d2             	xor    %r10d,%r10d
    59ba:	48 85 f6             	test   %rsi,%rsi
    59bd:	4c 0f 44 d1          	cmove  %rcx,%r10
    59c1:	48 8b 8d 70 fb ff ff 	mov    -0x490(%rbp),%rcx
    59c8:	4c 39 d1             	cmp    %r10,%rcx
    59cb:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    59d1:	41 0f 94 c3          	sete   %r11b
    59d5:	48 8b 85 e8 fa ff ff 	mov    -0x518(%rbp),%rax
    59dc:	48 39 f0             	cmp    %rsi,%rax
    59df:	ba 00 00 00 00       	mov    $0x0,%edx
    59e4:	0f 94 c2             	sete   %dl
    59e7:	49 21 d3             	and    %rdx,%r11
    59ea:	4d 85 db             	test   %r11,%r11
    59ed:	48 89 b5 00 fb ff ff 	mov    %rsi,-0x500(%rbp)
    59f4:	4c 89 8d 08 fb ff ff 	mov    %r9,-0x4f8(%rbp)
    59fb:	4c 89 95 30 fb ff ff 	mov    %r10,-0x4d0(%rbp)
    5a02:	0f 84 83 00 00 00    	je     0x5a8b
    5a08:	48 8b 95 40 fb ff ff 	mov    -0x4c0(%rbp),%rdx
    5a0f:	49 89 d3             	mov    %rdx,%r11
    5a12:	49 83 c3 01          	add    $0x1,%r11
    5a16:	be 01 00 00 00       	mov    $0x1,%esi
    5a1b:	4c 8b 95 68 fb ff ff 	mov    -0x498(%rbp),%r10
    5a22:	4d 63 0a             	movslq (%r10),%r9
    5a25:	4c 8b 95 38 fc ff ff 	mov    -0x3c8(%rbp),%r10
    5a2c:	4c 89 d2             	mov    %r10,%rdx
    5a2f:	48 31 f2             	xor    %rsi,%rdx
    5a32:	31 f6                	xor    %esi,%esi
    5a34:	48 85 d2             	test   %rdx,%rdx
    5a37:	4c 0f 44 ce          	cmove  %rsi,%r9
    5a3b:	48 8b b5 10 fb ff ff 	mov    -0x4f0(%rbp),%rsi
    5a42:	49 89 f2             	mov    %rsi,%r10
    5a45:	49 01 d2             	add    %rdx,%r10
    5a48:	48 8b 95 e0 fa ff ff 	mov    -0x520(%rbp),%rdx
    5a4f:	48 89 d6             	mov    %rdx,%rsi
    5a52:	4c 01 ce             	add    %r9,%rsi
    5a55:	48 89 8d 18 fc ff ff 	mov    %rcx,-0x3e8(%rbp)
    5a5c:	48 89 85 60 fb ff ff 	mov    %rax,-0x4a0(%rbp)
    5a63:	4c 8b 8d 20 fb ff ff 	mov    -0x4e0(%rbp),%r9
    5a6a:	4c 89 8d 98 fb ff ff 	mov    %r9,-0x468(%rbp)
    5a71:	4c 89 9d 90 fb ff ff 	mov    %r11,-0x470(%rbp)
    5a78:	48 89 b5 b8 fb ff ff 	mov    %rsi,-0x448(%rbp)
    5a7f:	4c 89 95 c0 fb ff ff 	mov    %r10,-0x440(%rbp)
    5a86:	e9 a8 04 00 00       	jmp    0x5f33
    5a8b:	48 8b 85 18 fb ff ff 	mov    -0x4e8(%rbp),%rax
    5a92:	48 85 c0             	test   %rax,%rax
    5a95:	0f 84 fc 03 00 00    	je     0x5e97
    5a9b:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    5aa2:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    5aa6:	48 85 d2             	test   %rdx,%rdx
    5aa9:	0f 84 40 01 00 00    	je     0x5bef
    5aaf:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    5ab3:	be 40 00 00 00       	mov    $0x40,%esi
    5ab8:	48 29 d6             	sub    %rdx,%rsi
    5abb:	48 8b bd 20 fb ff ff 	mov    -0x4e0(%rbp),%rdi
    5ac2:	48 89 f1             	mov    %rsi,%rcx
    5ac5:	49 89 f8             	mov    %rdi,%r8
    5ac8:	49 d3 e8             	shr    %cl,%r8
    5acb:	31 c9                	xor    %ecx,%ecx
    5acd:	48 39 ca             	cmp    %rcx,%rdx
    5ad0:	ba 00 00 00 00       	mov    $0x0,%edx
    5ad5:	0f 94 c2             	sete   %dl
    5ad8:	48 85 d2             	test   %rdx,%rdx
    5adb:	49 0f 44 c8          	cmove  %r8,%rcx
    5adf:	48 8b 95 90 fc ff ff 	mov    -0x370(%rbp),%rdx
    5ae6:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    5aea:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    5aee:	49 8b 30             	mov    (%r8),%rsi
    5af1:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    5af8:	00 28 00 
    5afb:	4c 39 ce             	cmp    %r9,%rsi
    5afe:	4c 89 85 d0 fa ff ff 	mov    %r8,-0x530(%rbp)
    5b05:	0f 82 0c 00 00 00    	jb     0x5b17
    5b0b:	48 89 b5 c8 fb ff ff 	mov    %rsi,-0x438(%rbp)
    5b12:	e9 4a 00 00 00       	jmp    0x5b61
    5b17:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    5b1b:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    5b22:	48 89 b5 d8 fa ff ff 	mov    %rsi,-0x528(%rbp)
    5b29:	48 89 d6             	mov    %rdx,%rsi
    5b2c:	48 89 ca             	mov    %rcx,%rdx
    5b2f:	48 8b 8d d8 fa ff ff 	mov    -0x528(%rbp),%rcx
    5b36:	e8 a5 a5 ff ff       	call   0xe0
    5b3b:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    5b42:	31 d2                	xor    %edx,%edx
    5b44:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    5b48:	48 83 f8 00          	cmp    $0x0,%rax
    5b4c:	0f 8f 08 00 00 00    	jg     0x5b5a
    5b52:	49 89 c4             	mov    %rax,%r12
    5b55:	e9 cd 15 00 00       	jmp    0x7127
    5b5a:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    5b61:	48 8b 85 c8 fb ff ff 	mov    -0x438(%rbp),%rax
    5b68:	48 89 c1             	mov    %rax,%rcx
    5b6b:	48 83 c1 28          	add    $0x28,%rcx
    5b6f:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    5b76:	00 28 00 
    5b79:	48 29 d1             	sub    %rdx,%rcx
    5b7c:	48 8b 95 d0 fa ff ff 	mov    -0x530(%rbp),%rdx
    5b83:	48 89 0a             	mov    %rcx,(%rdx)
    5b86:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    5b8d:	ff 00 00 
    5b90:	48 21 c8             	and    %rcx,%rax
    5b93:	31 c9                	xor    %ecx,%ecx
    5b95:	48 8b 95 70 fb ff ff 	mov    -0x490(%rbp),%rdx
    5b9c:	48 89 10             	mov    %rdx,(%rax)
    5b9f:	48 8b b5 e8 fa ff ff 	mov    -0x518(%rbp),%rsi
    5ba6:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5baa:	48 89 48 10          	mov    %rcx,0x10(%rax)
    5bae:	48 89 48 18          	mov    %rcx,0x18(%rax)
    5bb2:	48 89 48 20          	mov    %rcx,0x20(%rax)
    5bb6:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    5bbd:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    5bc1:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    5bc7:	4c 01 c7             	add    %r8,%rdi
    5bca:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    5bce:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    5bd5:	b8 01 00 00 00       	mov    $0x1,%eax
    5bda:	48 89 85 d0 fa ff ff 	mov    %rax,-0x530(%rbp)
    5be1:	31 c0                	xor    %eax,%eax
    5be3:	48 89 85 d8 fa ff ff 	mov    %rax,-0x528(%rbp)
    5bea:	e9 a2 01 00 00       	jmp    0x5d91
    5bef:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    5bf6:	48 8b 48 10          	mov    0x10(%rax),%rcx
    5bfa:	48 8b 50 18          	mov    0x18(%rax),%rdx
    5bfe:	48 89 d6             	mov    %rdx,%rsi
    5c01:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    5c06:	bf 40 00 00 00       	mov    $0x40,%edi
    5c0b:	48 29 f7             	sub    %rsi,%rdi
    5c0e:	48 89 8d b8 fa ff ff 	mov    %rcx,-0x548(%rbp)
    5c15:	4c 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%r8
    5c1c:	48 89 f9             	mov    %rdi,%rcx
    5c1f:	4d 89 c1             	mov    %r8,%r9
    5c22:	49 d3 e9             	shr    %cl,%r9
    5c25:	31 c9                	xor    %ecx,%ecx
    5c27:	48 39 ce             	cmp    %rcx,%rsi
    5c2a:	be 00 00 00 00       	mov    $0x0,%esi
    5c2f:	40 0f 94 c6          	sete   %sil
    5c33:	48 85 f6             	test   %rsi,%rsi
    5c36:	49 0f 44 c9          	cmove  %r9,%rcx
    5c3a:	be 01 00 00 00       	mov    $0x1,%esi
    5c3f:	48 89 cf             	mov    %rcx,%rdi
    5c42:	48 01 f7             	add    %rsi,%rdi
    5c45:	48 21 d7             	and    %rdx,%rdi
    5c48:	ba 28 00 00 00       	mov    $0x28,%edx
    5c4d:	48 0f af ca          	imul   %rdx,%rcx
    5c51:	48 8b 95 b8 fa ff ff 	mov    -0x548(%rbp),%rdx
    5c58:	4c 8d 0c 0a          	lea    (%rdx,%rcx,1),%r9
    5c5c:	49 8b 49 10          	mov    0x10(%r9),%rcx
    5c60:	48 85 c9             	test   %rcx,%rcx
    5c63:	0f 84 af 00 00 00    	je     0x5d18
    5c69:	49 8b 09             	mov    (%r9),%rcx
    5c6c:	4d 8b 51 08          	mov    0x8(%r9),%r10
    5c70:	4c 8b 9d 70 fb ff ff 	mov    -0x490(%rbp),%r11
    5c77:	49 39 cb             	cmp    %rcx,%r11
    5c7a:	ba 00 00 00 00       	mov    $0x0,%edx
    5c7f:	0f 94 c2             	sete   %dl
    5c82:	48 8b 8d e8 fa ff ff 	mov    -0x518(%rbp),%rcx
    5c89:	4c 39 d1             	cmp    %r10,%rcx
    5c8c:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    5c92:	41 0f 94 c0          	sete   %r8b
    5c96:	4c 21 c2             	and    %r8,%rdx
    5c99:	48 85 d2             	test   %rdx,%rdx
    5c9c:	0f 84 0c 00 00 00    	je     0x5cae
    5ca2:	4c 89 8d c8 fb ff ff 	mov    %r9,-0x438(%rbp)
    5ca9:	e9 53 00 00 00       	jmp    0x5d01
    5cae:	ba 28 00 00 00       	mov    $0x28,%edx
    5cb3:	48 0f af fa          	imul   %rdx,%rdi
    5cb7:	48 8b 95 b8 fa ff ff 	mov    -0x548(%rbp),%rdx
    5cbe:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    5cc2:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5cc6:	48 85 d2             	test   %rdx,%rdx
    5cc9:	0f 84 49 00 00 00    	je     0x5d18
    5ccf:	49 8b 10             	mov    (%r8),%rdx
    5cd2:	49 8b 78 08          	mov    0x8(%r8),%rdi
    5cd6:	49 39 d3             	cmp    %rdx,%r11
    5cd9:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    5cdf:	41 0f 94 c1          	sete   %r9b
    5ce3:	48 39 f9             	cmp    %rdi,%rcx
    5ce6:	ba 00 00 00 00       	mov    $0x0,%edx
    5ceb:	0f 94 c2             	sete   %dl
    5cee:	49 21 d1             	and    %rdx,%r9
    5cf1:	4d 85 c9             	test   %r9,%r9
    5cf4:	0f 84 1e 00 00 00    	je     0x5d18
    5cfa:	4c 89 85 c8 fb ff ff 	mov    %r8,-0x438(%rbp)
    5d01:	31 c0                	xor    %eax,%eax
    5d03:	48 89 85 d0 fa ff ff 	mov    %rax,-0x530(%rbp)
    5d0a:	31 c0                	xor    %eax,%eax
    5d0c:	48 89 85 d8 fa ff ff 	mov    %rax,-0x528(%rbp)
    5d13:	e9 79 00 00 00       	jmp    0x5d91
    5d18:	48 8d 85 b0 fc ff ff 	lea    -0x350(%rbp),%rax
    5d1f:	48 89 c1             	mov    %rax,%rcx
    5d22:	48 8b 95 70 fb ff ff 	mov    -0x490(%rbp),%rdx
    5d29:	48 89 11             	mov    %rdx,(%rcx)
    5d2c:	48 8b b5 e8 fa ff ff 	mov    -0x518(%rbp),%rsi
    5d33:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    5d37:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    5d3e:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    5d45:	48 89 ca             	mov    %rcx,%rdx
    5d48:	e8 a3 a3 ff ff       	call   0xf0
    5d4d:	48 83 f8 00          	cmp    $0x0,%rax
    5d51:	0f 8d 08 00 00 00    	jge    0x5d5f
    5d57:	49 89 c4             	mov    %rax,%r12
    5d5a:	e9 c8 13 00 00       	jmp    0x7127
    5d5f:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    5d66:	48 8b 11             	mov    (%rcx),%rdx
    5d69:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    5d6d:	48 83 e6 01          	and    $0x1,%rsi
    5d71:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    5d75:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    5d7c:	b8 01 00 00 00       	mov    $0x1,%eax
    5d81:	48 89 85 d0 fa ff ff 	mov    %rax,-0x530(%rbp)
    5d88:	31 c0                	xor    %eax,%eax
    5d8a:	48 89 85 d8 fa ff ff 	mov    %rax,-0x528(%rbp)
    5d91:	48 8b 85 d0 fa ff ff 	mov    -0x530(%rbp),%rax
    5d98:	48 85 c0             	test   %rax,%rax
    5d9b:	0f 84 68 00 00 00    	je     0x5e09
    5da1:	48 8b 85 c8 fb ff ff 	mov    -0x438(%rbp),%rax
    5da8:	48 8b 8d 40 fb ff ff 	mov    -0x4c0(%rbp),%rcx
    5daf:	48 89 48 10          	mov    %rcx,0x10(%rax)
    5db3:	31 d2                	xor    %edx,%edx
    5db5:	48 39 d1             	cmp    %rdx,%rcx
    5db8:	be 00 00 00 00       	mov    $0x0,%esi
    5dbd:	40 0f 95 c6          	setne  %sil
    5dc1:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    5dc5:	48 09 f7             	or     %rsi,%rdi
    5dc8:	40 88 78 20          	mov    %dil,0x20(%rax)
    5dcc:	48 8b b5 e0 fa ff ff 	mov    -0x520(%rbp),%rsi
    5dd3:	48 89 70 18          	mov    %rsi,0x18(%rax)
    5dd7:	48 8b bd 10 fb ff ff 	mov    -0x4f0(%rbp),%rdi
    5dde:	48 39 d7             	cmp    %rdx,%rdi
    5de1:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    5de7:	41 0f 95 c0          	setne  %r8b
    5deb:	44 0f b6 48 20       	movzbl 0x20(%rax),%r9d
    5df0:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    5df6:	4d 85 c0             	test   %r8,%r8
    5df9:	4c 0f 44 d2          	cmove  %rdx,%r10
    5dfd:	4d 09 d1             	or     %r10,%r9
    5e00:	44 88 48 20          	mov    %r9b,0x20(%rax)
    5e04:	e9 8e 00 00 00       	jmp    0x5e97
    5e09:	48 8b 85 c8 fb ff ff 	mov    -0x438(%rbp),%rax
    5e10:	48 8b 48 10          	mov    0x10(%rax),%rcx
    5e14:	48 8b 95 40 fb ff ff 	mov    -0x4c0(%rbp),%rdx
    5e1b:	48 01 d1             	add    %rdx,%rcx
    5e1e:	48 89 48 10          	mov    %rcx,0x10(%rax)
    5e22:	31 f6                	xor    %esi,%esi
    5e24:	48 39 f1             	cmp    %rsi,%rcx
    5e27:	b9 00 00 00 00       	mov    $0x0,%ecx
    5e2c:	0f 95 c1             	setne  %cl
    5e2f:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    5e33:	48 09 cf             	or     %rcx,%rdi
    5e36:	40 88 78 20          	mov    %dil,0x20(%rax)
    5e3a:	48 8b 48 18          	mov    0x18(%rax),%rcx
    5e3e:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    5e42:	48 83 e7 02          	and    $0x2,%rdi
    5e46:	48 39 f7             	cmp    %rsi,%rdi
    5e49:	bf 00 00 00 00       	mov    $0x0,%edi
    5e4e:	40 0f 95 c7          	setne  %dil
    5e52:	45 31 c0             	xor    %r8d,%r8d
    5e55:	48 85 ff             	test   %rdi,%rdi
    5e58:	49 0f 44 c8          	cmove  %r8,%rcx
    5e5c:	4c 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%r8
    5e63:	4c 01 c7             	add    %r8,%rdi
    5e66:	4c 8b 8d e0 fa ff ff 	mov    -0x520(%rbp),%r9
    5e6d:	4c 01 c9             	add    %r9,%rcx
    5e70:	48 89 48 18          	mov    %rcx,0x18(%rax)
    5e74:	48 39 f7             	cmp    %rsi,%rdi
    5e77:	bf 00 00 00 00       	mov    $0x0,%edi
    5e7c:	40 0f 95 c7          	setne  %dil
    5e80:	0f b6 48 20          	movzbl 0x20(%rax),%ecx
    5e84:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    5e8a:	48 85 ff             	test   %rdi,%rdi
    5e8d:	4c 0f 44 d6          	cmove  %rsi,%r10
    5e91:	4c 09 d1             	or     %r10,%rcx
    5e94:	88 48 20             	mov    %cl,0x20(%rax)
    5e97:	b8 01 00 00 00       	mov    $0x1,%eax
    5e9c:	48 8b 8d 68 fb ff ff 	mov    -0x498(%rbp),%rcx
    5ea3:	48 63 11             	movslq (%rcx),%rdx
    5ea6:	48 8b b5 38 fc ff ff 	mov    -0x3c8(%rbp),%rsi
    5ead:	48 89 f7             	mov    %rsi,%rdi
    5eb0:	48 31 c7             	xor    %rax,%rdi
    5eb3:	31 c0                	xor    %eax,%eax
    5eb5:	48 85 ff             	test   %rdi,%rdi
    5eb8:	48 0f 44 d0          	cmove  %rax,%rdx
    5ebc:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    5ec3:	79 37 9e 
    5ec6:	49 b8 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%r8
    5ecd:	79 37 9e 
    5ed0:	4c 8b 8d 30 fb ff ff 	mov    -0x4d0(%rbp),%r9
    5ed7:	4d 31 c8             	xor    %r9,%r8
    5eda:	4c 0f af c0          	imul   %rax,%r8
    5ede:	4d 89 c2             	mov    %r8,%r10
    5ee1:	49 c1 ea 1d          	shr    $0x1d,%r10
    5ee5:	4d 31 d0             	xor    %r10,%r8
    5ee8:	4c 8b 95 00 fb ff ff 	mov    -0x500(%rbp),%r10
    5eef:	4d 31 d0             	xor    %r10,%r8
    5ef2:	4c 0f af c0          	imul   %rax,%r8
    5ef6:	4d 89 c3             	mov    %r8,%r11
    5ef9:	49 c1 eb 1d          	shr    $0x1d,%r11
    5efd:	4d 31 d8             	xor    %r11,%r8
    5f00:	4c 0f af c0          	imul   %rax,%r8
    5f04:	4c 89 8d 18 fc ff ff 	mov    %r9,-0x3e8(%rbp)
    5f0b:	4c 89 95 60 fb ff ff 	mov    %r10,-0x4a0(%rbp)
    5f12:	4c 89 85 98 fb ff ff 	mov    %r8,-0x468(%rbp)
    5f19:	b8 01 00 00 00       	mov    $0x1,%eax
    5f1e:	48 89 85 90 fb ff ff 	mov    %rax,-0x470(%rbp)
    5f25:	48 89 95 b8 fb ff ff 	mov    %rdx,-0x448(%rbp)
    5f2c:	48 89 bd c0 fb ff ff 	mov    %rdi,-0x440(%rbp)
    5f33:	48 8b 85 08 fb ff ff 	mov    -0x4f8(%rbp),%rax
    5f3a:	48 89 85 40 fc ff ff 	mov    %rax,-0x3c0(%rbp)
    5f41:	b8 01 00 00 00       	mov    $0x1,%eax
    5f46:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
    5f4d:	31 c0                	xor    %eax,%eax
    5f4f:	48 89 03             	mov    %rax,(%rbx)
    5f52:	b8 01 00 00 00       	mov    $0x1,%eax
    5f57:	4c 89 f9             	mov    %r15,%rcx
    5f5a:	48 01 c1             	add    %rax,%rcx
    5f5d:	49 89 cf             	mov    %rcx,%r15
    5f60:	e9 86 f2 ff ff       	jmp    0x51eb
    5f65:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    5f6c:	e8 cf a0 ff ff       	call   0x40
    5f71:	48 85 c0             	test   %rax,%rax
    5f74:	0f 84 f8 f9 ff ff    	je     0x5972
    5f7a:	e9 a1 11 00 00       	jmp    0x7120
    5f7f:	4c 8b bd 08 fc ff ff 	mov    -0x3f8(%rbp),%r15
    5f86:	31 c0                	xor    %eax,%eax
    5f88:	48 89 85 08 fc ff ff 	mov    %rax,-0x3f8(%rbp)
    5f8f:	31 c0                	xor    %eax,%eax
    5f91:	48 89 85 e0 fb ff ff 	mov    %rax,-0x420(%rbp)
    5f98:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
    5f9f:	82 28 52 
    5fa2:	48 89 85 30 fc ff ff 	mov    %rax,-0x3d0(%rbp)
    5fa9:	31 c0                	xor    %eax,%eax
    5fab:	48 89 85 20 fc ff ff 	mov    %rax,-0x3e0(%rbp)
    5fb2:	31 c0                	xor    %eax,%eax
    5fb4:	48 89 85 10 fc ff ff 	mov    %rax,-0x3f0(%rbp)
    5fbb:	31 c0                	xor    %eax,%eax
    5fbd:	48 89 85 00 fc ff ff 	mov    %rax,-0x400(%rbp)
    5fc4:	31 c0                	xor    %eax,%eax
    5fc6:	48 89 85 f0 fb ff ff 	mov    %rax,-0x410(%rbp)
    5fcd:	31 c0                	xor    %eax,%eax
    5fcf:	48 89 85 80 fb ff ff 	mov    %rax,-0x480(%rbp)
    5fd6:	48 8b 85 f8 fb ff ff 	mov    -0x408(%rbp),%rax
    5fdd:	49 39 c7             	cmp    %rax,%r15
    5fe0:	0f 8c 75 00 00 00    	jl     0x605b
    5fe6:	48 8b 8d f0 fb ff ff 	mov    -0x410(%rbp),%rcx
    5fed:	48 89 8d 88 fc ff ff 	mov    %rcx,-0x378(%rbp)
    5ff4:	48 8b 8d 08 fc ff ff 	mov    -0x3f8(%rbp),%rcx
    5ffb:	48 89 8d 38 fb ff ff 	mov    %rcx,-0x4c8(%rbp)
    6002:	48 8b 8d e0 fb ff ff 	mov    -0x420(%rbp),%rcx
    6009:	48 89 8d f0 fa ff ff 	mov    %rcx,-0x510(%rbp)
    6010:	48 8b 8d 30 fc ff ff 	mov    -0x3d0(%rbp),%rcx
    6017:	48 89 8d 88 fb ff ff 	mov    %rcx,-0x478(%rbp)
    601e:	48 8b 8d 80 fb ff ff 	mov    -0x480(%rbp),%rcx
    6025:	48 89 8d b0 fb ff ff 	mov    %rcx,-0x450(%rbp)
    602c:	48 8b 8d 20 fc ff ff 	mov    -0x3e0(%rbp),%rcx
    6033:	48 89 8d a0 fb ff ff 	mov    %rcx,-0x460(%rbp)
    603a:	48 8b 8d 10 fc ff ff 	mov    -0x3f0(%rbp),%rcx
    6041:	48 89 8d 28 fb ff ff 	mov    %rcx,-0x4d8(%rbp)
    6048:	48 8b 8d 00 fc ff ff 	mov    -0x400(%rbp),%rcx
    604f:	48 89 8d 58 fb ff ff 	mov    %rcx,-0x4a8(%rbp)
    6056:	e9 e6 0b 00 00       	jmp    0x6c41
    605b:	48 8b 8d d8 fb ff ff 	mov    -0x428(%rbp),%rcx
    6062:	4a 8d 14 b9          	lea    (%rcx,%r15,4),%rdx
    6066:	48 8b b5 e8 fb ff ff 	mov    -0x418(%rbp),%rsi
    606d:	4a 8d 3c be          	lea    (%rsi,%r15,4),%rdi
    6071:	4c 63 02             	movslq (%rdx),%r8
    6074:	4c 8b 8d 50 fc ff ff 	mov    -0x3b0(%rbp),%r9
    607b:	4d 85 c9             	test   %r9,%r9
    607e:	48 89 bd 50 fb ff ff 	mov    %rdi,-0x4b0(%rbp)
    6085:	4c 89 85 f8 fa ff ff 	mov    %r8,-0x508(%rbp)
    608c:	0f 84 42 01 00 00    	je     0x61d4
    6092:	49 ba 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%r10
    6099:	79 37 9e 
    609c:	4d 89 c3             	mov    %r8,%r11
    609f:	49 c1 eb 2b          	shr    $0x2b,%r11
    60a3:	4c 89 c1             	mov    %r8,%rcx
    60a6:	48 c1 e9 2c          	shr    $0x2c,%rcx
    60aa:	49 31 cb             	xor    %rcx,%r11
    60ad:	4c 89 c1             	mov    %r8,%rcx
    60b0:	4c 31 d9             	xor    %r11,%rcx
    60b3:	49 0f af ca          	imul   %r10,%rcx
    60b7:	49 89 ca             	mov    %rcx,%r10
    60ba:	49 c1 ea 1e          	shr    $0x1e,%r10
    60be:	49 89 cb             	mov    %rcx,%r11
    60c1:	4d 31 d3             	xor    %r10,%r11
    60c4:	49 ba b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%r10
    60cb:	47 58 bf 
    60ce:	4d 0f af da          	imul   %r10,%r11
    60d2:	4d 89 da             	mov    %r11,%r10
    60d5:	49 c1 ea 1b          	shr    $0x1b,%r10
    60d9:	4d 31 d3             	xor    %r10,%r11
    60dc:	49 ba eb 11 31 13 bb 	movabs $0x94d049bb133111eb,%r10
    60e3:	49 d0 94 
    60e6:	4d 0f af da          	imul   %r10,%r11
    60ea:	4d 89 da             	mov    %r11,%r10
    60ed:	49 c1 ea 1f          	shr    $0x1f,%r10
    60f1:	4d 31 d3             	xor    %r10,%r11
    60f4:	41 ba 40 00 00 00    	mov    $0x40,%r10d
    60fa:	4d 29 ca             	sub    %r9,%r10
    60fd:	48 89 8d 78 fb ff ff 	mov    %rcx,-0x488(%rbp)
    6104:	4c 89 d1             	mov    %r10,%rcx
    6107:	49 d3 eb             	shr    %cl,%r11
    610a:	4c 8b 55 d0          	mov    -0x30(%rbp),%r10
    610e:	4c 89 d9             	mov    %r11,%rcx
    6111:	4d 89 d0             	mov    %r10,%r8
    6114:	49 d3 e8             	shr    %cl,%r8
    6117:	b9 01 00 00 00       	mov    $0x1,%ecx
    611c:	49 21 c8             	and    %rcx,%r8
    611f:	4d 85 c0             	test   %r8,%r8
    6122:	0f 84 ac 00 00 00    	je     0x61d4
    6128:	4c 8d 85 60 fd ff ff 	lea    -0x2a0(%rbp),%r8
    612f:	4d 89 c1             	mov    %r8,%r9
    6132:	4c 63 02             	movslq (%rdx),%r8
    6135:	31 d2                	xor    %edx,%edx
    6137:	31 ff                	xor    %edi,%edi
    6139:	49 89 11             	mov    %rdx,(%r9)
    613c:	4d 89 41 08          	mov    %r8,0x8(%r9)
    6140:	49 89 79 10          	mov    %rdi,0x10(%r9)
    6144:	48 8b 95 50 fb ff ff 	mov    -0x4b0(%rbp),%rdx
    614b:	48 63 3a             	movslq (%rdx),%rdi
    614e:	45 31 c0             	xor    %r8d,%r8d
    6151:	31 d2                	xor    %edx,%edx
    6153:	4d 89 41 18          	mov    %r8,0x18(%r9)
    6157:	49 89 79 20          	mov    %rdi,0x20(%r9)
    615b:	49 89 51 28          	mov    %rdx,0x28(%r9)
    615f:	ba 01 00 00 00       	mov    $0x1,%edx
    6164:	48 8b bd 50 fc ff ff 	mov    -0x3b0(%rbp),%rdi
    616b:	48 89 f9             	mov    %rdi,%rcx
    616e:	48 d3 e2             	shl    %cl,%rdx
    6171:	4c 01 da             	add    %r11,%rdx
    6174:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    6179:	41 b8 02 00 00 00    	mov    $0x2,%r8d
    617f:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    6186:	48 89 ce             	mov    %rcx,%rsi
    6189:	48 89 95 18 fb ff ff 	mov    %rdx,-0x4e8(%rbp)
    6190:	48 8b 95 50 fc ff ff 	mov    -0x3b0(%rbp),%rdx
    6197:	48 8b 8d 18 fb ff ff 	mov    -0x4e8(%rbp),%rcx
    619e:	4c 8b 85 78 fb ff ff 	mov    -0x488(%rbp),%r8
    61a5:	41 bb 02 00 00 00    	mov    $0x2,%r11d
    61ab:	4c 89 1c 24          	mov    %r11,(%rsp)
    61af:	e8 1c 9f ff ff       	call   0xd0
    61b4:	48 83 f8 00          	cmp    $0x0,%rax
    61b8:	0f 8d 11 00 00 00    	jge    0x61cf
    61be:	b8 80 00 00 00       	mov    $0x80,%eax
    61c3:	48 89 85 48 fb ff ff 	mov    %rax,-0x4b8(%rbp)
    61ca:	e9 37 0f 00 00       	jmp    0x7106
    61cf:	e9 40 0a 00 00       	jmp    0x6c14
    61d4:	49 83 fd 05          	cmp    $0x5,%r13
    61d8:	0f 85 d1 00 00 00    	jne    0x62af
    61de:	48 8b 85 f8 fa ff ff 	mov    -0x508(%rbp),%rax
    61e5:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    61ec:	48 89 c2             	mov    %rax,%rdx
    61ef:	48 29 ca             	sub    %rcx,%rdx
    61f2:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    61f9:	48 39 f2             	cmp    %rsi,%rdx
    61fc:	bf 00 00 00 00       	mov    $0x0,%edi
    6201:	40 0f 92 c7          	setb   %dil
    6205:	45 31 c0             	xor    %r8d,%r8d
    6208:	48 85 ff             	test   %rdi,%rdi
    620b:	49 0f 44 d0          	cmove  %r8,%rdx
    620f:	49 89 d1             	mov    %rdx,%r9
    6212:	49 c1 e9 06          	shr    $0x6,%r9
    6216:	48 83 e2 3f          	and    $0x3f,%rdx
    621a:	4c 8b 95 70 fc ff ff 	mov    -0x390(%rbp),%r10
    6221:	4f 8d 1c ca          	lea    (%r10,%r9,8),%r11
    6225:	49 8b 03             	mov    (%r11),%rax
    6228:	48 89 d1             	mov    %rdx,%rcx
    622b:	48 d3 e8             	shr    %cl,%rax
    622e:	b9 01 00 00 00       	mov    $0x1,%ecx
    6233:	48 21 c8             	and    %rcx,%rax
    6236:	48 21 f8             	and    %rdi,%rax
    6239:	48 8b bd 48 fc ff ff 	mov    -0x3b8(%rbp),%rdi
    6240:	4e 8d 1c cf          	lea    (%rdi,%r9,8),%r11
    6244:	49 8b 3b             	mov    (%r11),%rdi
    6247:	48 89 d1             	mov    %rdx,%rcx
    624a:	48 d3 ef             	shr    %cl,%rdi
    624d:	b9 01 00 00 00       	mov    $0x1,%ecx
    6252:	48 21 cf             	and    %rcx,%rdi
    6255:	4c 8b 9d 58 fc ff ff 	mov    -0x3a8(%rbp),%r11
    625c:	4b 8d 34 cb          	lea    (%r11,%r9,8),%rsi
    6260:	4c 8b 0e             	mov    (%rsi),%r9
    6263:	48 89 d1             	mov    %rdx,%rcx
    6266:	49 d3 e9             	shr    %cl,%r9
    6269:	b9 01 00 00 00       	mov    $0x1,%ecx
    626e:	49 21 c9             	and    %rcx,%r9
    6271:	48 8d 95 40 fd ff ff 	lea    -0x2c0(%rbp),%rdx
    6278:	48 89 d6             	mov    %rdx,%rsi
    627b:	49 c1 e1 20          	shl    $0x20,%r9
    627f:	48 8b 95 f8 fa ff ff 	mov    -0x508(%rbp),%rdx
    6286:	48 89 16             	mov    %rdx,(%rsi)
    6289:	4c 89 4e 08          	mov    %r9,0x8(%rsi)
    628d:	48 89 7e 10          	mov    %rdi,0x10(%rsi)
    6291:	4c 39 c0             	cmp    %r8,%rax
    6294:	b8 00 00 00 00       	mov    $0x0,%eax
    6299:	0f 95 c0             	setne  %al
    629c:	48 85 c0             	test   %rax,%rax
    629f:	49 0f 44 f0          	cmove  %r8,%rsi
    62a3:	48 89 b5 78 fb ff ff 	mov    %rsi,-0x488(%rbp)
    62aa:	e9 f1 01 00 00       	jmp    0x64a0
    62af:	49 83 fd 01          	cmp    $0x1,%r13
    62b3:	0f 85 ee 00 00 00    	jne    0x63a7
    62b9:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    62c0:	79 37 9e 
    62c3:	48 8b 8d f8 fa ff ff 	mov    -0x508(%rbp),%rcx
    62ca:	48 89 ca             	mov    %rcx,%rdx
    62cd:	48 c1 ea 2b          	shr    $0x2b,%rdx
    62d1:	48 89 ce             	mov    %rcx,%rsi
    62d4:	48 c1 ee 2c          	shr    $0x2c,%rsi
    62d8:	48 31 f2             	xor    %rsi,%rdx
    62db:	48 89 ce             	mov    %rcx,%rsi
    62de:	48 31 d6             	xor    %rdx,%rsi
    62e1:	48 0f af f0          	imul   %rax,%rsi
    62e5:	b8 40 00 00 00       	mov    $0x40,%eax
    62ea:	48 8b 95 78 fc ff ff 	mov    -0x388(%rbp),%rdx
    62f1:	48 29 d0             	sub    %rdx,%rax
    62f4:	48 89 c1             	mov    %rax,%rcx
    62f7:	48 89 f7             	mov    %rsi,%rdi
    62fa:	48 d3 ef             	shr    %cl,%rdi
    62fd:	31 c0                	xor    %eax,%eax
    62ff:	48 39 c2             	cmp    %rax,%rdx
    6302:	b9 00 00 00 00       	mov    $0x0,%ecx
    6307:	0f 94 c1             	sete   %cl
    630a:	48 85 c9             	test   %rcx,%rcx
    630d:	48 0f 44 c7          	cmove  %rdi,%rax
    6311:	48 8b 8d 70 fc ff ff 	mov    -0x390(%rbp),%rcx
    6318:	48 8d 3c c1          	lea    (%rcx,%rax,8),%rdi
    631c:	48 8b 07             	mov    (%rdi),%rax
    631f:	48 bf ff ff ff ff ff 	movabs $0xffffffffffff,%rdi
    6326:	ff 00 00 
    6329:	49 89 c0             	mov    %rax,%r8
    632c:	49 21 f8             	and    %rdi,%r8
    632f:	31 ff                	xor    %edi,%edi
    6331:	49 39 f8             	cmp    %rdi,%r8
    6334:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    633a:	41 0f 94 c1          	sete   %r9b
    633e:	49 89 f2             	mov    %rsi,%r10
    6341:	49 c1 ea 20          	shr    $0x20,%r10
    6345:	4c 31 d6             	xor    %r10,%rsi
    6348:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
    634e:	4c 21 d6             	and    %r10,%rsi
    6351:	48 83 e6 0f          	and    $0xf,%rsi
    6355:	48 83 c6 30          	add    $0x30,%rsi
    6359:	48 89 f1             	mov    %rsi,%rcx
    635c:	48 d3 e8             	shr    %cl,%rax
    635f:	48 83 e0 01          	and    $0x1,%rax
    6363:	48 83 f8 00          	cmp    $0x0,%rax
    6367:	b8 00 00 00 00       	mov    $0x0,%eax
    636c:	0f 95 c0             	setne  %al
    636f:	b9 01 00 00 00       	mov    $0x1,%ecx
    6374:	48 31 c8             	xor    %rcx,%rax
    6377:	49 09 c1             	or     %rax,%r9
    637a:	b8 01 00 00 00       	mov    $0x1,%eax
    637f:	49 29 c0             	sub    %rax,%r8
    6382:	b9 18 00 00 00       	mov    $0x18,%ecx
    6387:	4c 0f af c1          	imul   %rcx,%r8
    638b:	4c 89 f1             	mov    %r14,%rcx
    638e:	4c 01 c1             	add    %r8,%rcx
    6391:	48 89 fe             	mov    %rdi,%rsi
    6394:	4d 85 c9             	test   %r9,%r9
    6397:	48 0f 44 f1          	cmove  %rcx,%rsi
    639b:	48 89 b5 78 fb ff ff 	mov    %rsi,-0x488(%rbp)
    63a2:	e9 f9 00 00 00       	jmp    0x64a0
    63a7:	48 8b 85 f8 fa ff ff 	mov    -0x508(%rbp),%rax
    63ae:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    63b5:	48 89 c2             	mov    %rax,%rdx
    63b8:	48 29 ca             	sub    %rcx,%rdx
    63bb:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    63c2:	48 39 f2             	cmp    %rsi,%rdx
    63c5:	0f 82 0e 00 00 00    	jb     0x63d9
    63cb:	31 ff                	xor    %edi,%edi
    63cd:	48 89 bd 78 fb ff ff 	mov    %rdi,-0x488(%rbp)
    63d4:	e9 c7 00 00 00       	jmp    0x64a0
    63d9:	49 83 fd 02          	cmp    $0x2,%r13
    63dd:	48 89 95 18 fb ff ff 	mov    %rdx,-0x4e8(%rbp)
    63e4:	0f 85 6a 00 00 00    	jne    0x6454
    63ea:	48 89 d7             	mov    %rdx,%rdi
    63ed:	48 c1 ef 06          	shr    $0x6,%rdi
    63f1:	4c 8b 85 70 fc ff ff 	mov    -0x390(%rbp),%r8
    63f8:	4d 8d 0c f8          	lea    (%r8,%rdi,8),%r9
    63fc:	49 8b 39             	mov    (%r9),%rdi
    63ff:	49 89 d1             	mov    %rdx,%r9
    6402:	49 83 e1 3f          	and    $0x3f,%r9
    6406:	4c 89 c9             	mov    %r9,%rcx
    6409:	48 d3 ef             	shr    %cl,%rdi
    640c:	b9 01 00 00 00       	mov    $0x1,%ecx
    6411:	48 21 cf             	and    %rcx,%rdi
    6414:	45 31 c9             	xor    %r9d,%r9d
    6417:	4c 39 cf             	cmp    %r9,%rdi
    641a:	bf 00 00 00 00       	mov    $0x0,%edi
    641f:	40 0f 95 c7          	setne  %dil
    6423:	41 ba 10 00 00 00    	mov    $0x10,%r10d
    6429:	49 89 d3             	mov    %rdx,%r11
    642c:	4d 0f af da          	imul   %r10,%r11
    6430:	4c 8b 95 80 fc ff ff 	mov    -0x380(%rbp),%r10
    6437:	4c 89 d2             	mov    %r10,%rdx
    643a:	4c 01 da             	add    %r11,%rdx
    643d:	48 83 ea 08          	sub    $0x8,%rdx
    6441:	48 85 ff             	test   %rdi,%rdi
    6444:	49 0f 44 d1          	cmove  %r9,%rdx
    6448:	48 89 95 78 fb ff ff 	mov    %rdx,-0x488(%rbp)
    644f:	e9 4c 00 00 00       	jmp    0x64a0
    6454:	48 8b 85 70 fc ff ff 	mov    -0x390(%rbp),%rax
    645b:	48 8b 8d 18 fb ff ff 	mov    -0x4e8(%rbp),%rcx
    6462:	48 8d 14 88          	lea    (%rax,%rcx,4),%rdx
    6466:	8b 0a                	mov    (%rdx),%ecx
    6468:	ba 01 00 00 00       	mov    $0x1,%edx
    646d:	48 89 ce             	mov    %rcx,%rsi
    6470:	48 29 d6             	sub    %rdx,%rsi
    6473:	bf 18 00 00 00       	mov    $0x18,%edi
    6478:	48 0f af f7          	imul   %rdi,%rsi
    647c:	4c 89 f7             	mov    %r14,%rdi
    647f:	48 01 f7             	add    %rsi,%rdi
    6482:	31 f6                	xor    %esi,%esi
    6484:	48 39 f1             	cmp    %rsi,%rcx
    6487:	b9 00 00 00 00       	mov    $0x0,%ecx
    648c:	0f 94 c1             	sete   %cl
    648f:	49 89 f0             	mov    %rsi,%r8
    6492:	48 85 c9             	test   %rcx,%rcx
    6495:	4c 0f 44 c7          	cmove  %rdi,%r8
    6499:	4c 89 85 78 fb ff ff 	mov    %r8,-0x488(%rbp)
    64a0:	49 83 fd 01          	cmp    $0x1,%r13
    64a4:	be 00 00 00 00       	mov    $0x0,%esi
    64a9:	40 0f 95 c6          	setne  %sil
    64ad:	31 ff                	xor    %edi,%edi
    64af:	48 8b 85 f0 fb ff ff 	mov    -0x410(%rbp),%rax
    64b6:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    64bd:	48 8b 85 08 fc ff ff 	mov    -0x3f8(%rbp),%rax
    64c4:	48 89 85 20 fb ff ff 	mov    %rax,-0x4e0(%rbp)
    64cb:	48 8b 85 e0 fb ff ff 	mov    -0x420(%rbp),%rax
    64d2:	48 89 85 70 fb ff ff 	mov    %rax,-0x490(%rbp)
    64d9:	48 8b 85 30 fc ff ff 	mov    -0x3d0(%rbp),%rax
    64e0:	48 89 85 e8 fa ff ff 	mov    %rax,-0x518(%rbp)
    64e7:	48 8b 85 80 fb ff ff 	mov    -0x480(%rbp),%rax
    64ee:	48 89 85 40 fb ff ff 	mov    %rax,-0x4c0(%rbp)
    64f5:	48 8b 85 20 fc ff ff 	mov    -0x3e0(%rbp),%rax
    64fc:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    6503:	48 8b 85 10 fc ff ff 	mov    -0x3f0(%rbp),%rax
    650a:	48 89 85 e0 fa ff ff 	mov    %rax,-0x520(%rbp)
    6511:	48 8b 85 00 fc ff ff 	mov    -0x400(%rbp),%rax
    6518:	48 89 85 68 fb ff ff 	mov    %rax,-0x498(%rbp)
    651f:	48 8b 85 78 fb ff ff 	mov    -0x488(%rbp),%rax
    6526:	48 85 c0             	test   %rax,%rax
    6529:	0f 85 75 00 00 00    	jne    0x65a4
    652f:	48 8b 8d 18 fb ff ff 	mov    -0x4e8(%rbp),%rcx
    6536:	48 89 8d f0 fb ff ff 	mov    %rcx,-0x410(%rbp)
    653d:	48 8b 8d 20 fb ff ff 	mov    -0x4e0(%rbp),%rcx
    6544:	48 89 8d 08 fc ff ff 	mov    %rcx,-0x3f8(%rbp)
    654b:	48 8b 8d 70 fb ff ff 	mov    -0x490(%rbp),%rcx
    6552:	48 89 8d e0 fb ff ff 	mov    %rcx,-0x420(%rbp)
    6559:	48 8b 8d e8 fa ff ff 	mov    -0x518(%rbp),%rcx
    6560:	48 89 8d 30 fc ff ff 	mov    %rcx,-0x3d0(%rbp)
    6567:	48 8b 8d 40 fb ff ff 	mov    -0x4c0(%rbp),%rcx
    656e:	48 89 8d 80 fb ff ff 	mov    %rcx,-0x480(%rbp)
    6575:	48 8b 8d 10 fb ff ff 	mov    -0x4f0(%rbp),%rcx
    657c:	48 89 8d 20 fc ff ff 	mov    %rcx,-0x3e0(%rbp)
    6583:	48 8b 8d e0 fa ff ff 	mov    -0x520(%rbp),%rcx
    658a:	48 89 8d 10 fc ff ff 	mov    %rcx,-0x3f0(%rbp)
    6591:	48 8b 8d 68 fb ff ff 	mov    -0x498(%rbp),%rcx
    6598:	48 89 8d 00 fc ff ff 	mov    %rcx,-0x400(%rbp)
    659f:	e9 6b 06 00 00       	jmp    0x6c0f
    65a4:	48 8b 48 08          	mov    0x8(%rax),%rcx
    65a8:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    65ad:	49 89 c8             	mov    %rcx,%r8
    65b0:	49 21 d0             	and    %rdx,%r8
    65b3:	ba 01 00 00 00       	mov    $0x1,%edx
    65b8:	4d 89 c1             	mov    %r8,%r9
    65bb:	49 29 d1             	sub    %rdx,%r9
    65be:	41 ba 18 00 00 00    	mov    $0x18,%r10d
    65c4:	4d 0f af ca          	imul   %r10,%r9
    65c8:	4d 89 f2             	mov    %r14,%r10
    65cb:	4d 01 ca             	add    %r9,%r10
    65ce:	45 31 c9             	xor    %r9d,%r9d
    65d1:	4d 39 c8             	cmp    %r9,%r8
    65d4:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    65da:	41 0f 94 c0          	sete   %r8b
    65de:	4d 89 cb             	mov    %r9,%r11
    65e1:	4d 85 c0             	test   %r8,%r8
    65e4:	4d 0f 44 da          	cmove  %r10,%r11
    65e8:	4c 8b 00             	mov    (%rax),%r8
    65eb:	4c 8b 95 f8 fa ff ff 	mov    -0x508(%rbp),%r10
    65f2:	4d 39 c2             	cmp    %r8,%r10
    65f5:	b8 00 00 00 00       	mov    $0x0,%eax
    65fa:	0f 94 c0             	sete   %al
    65fd:	48 09 f0             	or     %rsi,%rax
    6600:	49 89 f8             	mov    %rdi,%r8
    6603:	49 01 d0             	add    %rdx,%r8
    6606:	48 85 c0             	test   %rax,%rax
    6609:	0f 85 0c 00 00 00    	jne    0x661b
    660f:	4c 89 9d 78 fb ff ff 	mov    %r11,-0x488(%rbp)
    6616:	e9 04 ff ff ff       	jmp    0x651f
    661b:	48 8b 03             	mov    (%rbx),%rax
    661e:	48 39 c7             	cmp    %rax,%rdi
    6621:	0f 8d 0f 00 00 00    	jge    0x6636
    6627:	4c 89 9d 78 fb ff ff 	mov    %r11,-0x488(%rbp)
    662e:	4c 89 c7             	mov    %r8,%rdi
    6631:	e9 e9 fe ff ff       	jmp    0x651f
    6636:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    663d:	48 8b 70 18          	mov    0x18(%rax),%rsi
    6641:	48 85 f6             	test   %rsi,%rsi
    6644:	48 89 8d f8 fa ff ff 	mov    %rcx,-0x508(%rbp)
    664b:	4c 89 85 38 fc ff ff 	mov    %r8,-0x3c8(%rbp)
    6652:	0f 84 0c 00 00 00    	je     0x6664
    6658:	0f b6 3e             	movzbl (%rsi),%edi
    665b:	48 85 ff             	test   %rdi,%rdi
    665e:	0f 85 c3 05 00 00    	jne    0x6c27
    6664:	48 8b 85 78 fb ff ff 	mov    -0x488(%rbp),%rax
    666b:	48 8b 48 10          	mov    0x10(%rax),%rcx
    666f:	48 8b 95 f8 fa ff ff 	mov    -0x508(%rbp),%rdx
    6676:	48 89 d6             	mov    %rdx,%rsi
    6679:	48 c1 ee 20          	shr    $0x20,%rsi
    667d:	48 83 e6 01          	and    $0x1,%rsi
    6681:	48 83 fe 00          	cmp    $0x0,%rsi
    6685:	be 00 00 00 00       	mov    $0x0,%esi
    668a:	40 0f 95 c6          	setne  %sil
    668e:	48 8b bd 38 fc ff ff 	mov    -0x3c8(%rbp),%rdi
    6695:	48 89 3b             	mov    %rdi,(%rbx)
    6698:	4c 8b 85 18 fb ff ff 	mov    -0x4e8(%rbp),%r8
    669f:	4d 89 c1             	mov    %r8,%r9
    66a2:	49 83 c1 01          	add    $0x1,%r9
    66a6:	48 63 c9             	movslq %ecx,%rcx
    66a9:	45 31 d2             	xor    %r10d,%r10d
    66ac:	48 85 f6             	test   %rsi,%rsi
    66af:	4c 0f 44 d1          	cmove  %rcx,%r10
    66b3:	48 8b 8d 20 fb ff ff 	mov    -0x4e0(%rbp),%rcx
    66ba:	4c 39 d1             	cmp    %r10,%rcx
    66bd:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    66c3:	41 0f 94 c3          	sete   %r11b
    66c7:	48 8b 85 70 fb ff ff 	mov    -0x490(%rbp),%rax
    66ce:	48 39 f0             	cmp    %rsi,%rax
    66d1:	ba 00 00 00 00       	mov    $0x0,%edx
    66d6:	0f 94 c2             	sete   %dl
    66d9:	49 21 d3             	and    %rdx,%r11
    66dc:	4d 85 db             	test   %r11,%r11
    66df:	48 89 b5 40 fc ff ff 	mov    %rsi,-0x3c0(%rbp)
    66e6:	4c 89 8d 18 fc ff ff 	mov    %r9,-0x3e8(%rbp)
    66ed:	4c 89 95 60 fb ff ff 	mov    %r10,-0x4a0(%rbp)
    66f4:	0f 84 69 00 00 00    	je     0x6763
    66fa:	48 8b 95 10 fb ff ff 	mov    -0x4f0(%rbp),%rdx
    6701:	49 89 d3             	mov    %rdx,%r11
    6704:	49 83 c3 01          	add    $0x1,%r11
    6708:	48 8b b5 50 fb ff ff 	mov    -0x4b0(%rbp),%rsi
    670f:	4c 63 16             	movslq (%rsi),%r10
    6712:	4c 8b 8d 68 fb ff ff 	mov    -0x498(%rbp),%r9
    6719:	4c 89 ce             	mov    %r9,%rsi
    671c:	48 83 c6 01          	add    $0x1,%rsi
    6720:	4c 8b 8d e0 fa ff ff 	mov    -0x520(%rbp),%r9
    6727:	4c 89 ca             	mov    %r9,%rdx
    672a:	4c 01 d2             	add    %r10,%rdx
    672d:	48 89 8d 08 fc ff ff 	mov    %rcx,-0x3f8(%rbp)
    6734:	48 89 85 e0 fb ff ff 	mov    %rax,-0x420(%rbp)
    673b:	4c 8b 95 e8 fa ff ff 	mov    -0x518(%rbp),%r10
    6742:	4c 89 95 30 fc ff ff 	mov    %r10,-0x3d0(%rbp)
    6749:	4c 89 9d 20 fc ff ff 	mov    %r11,-0x3e0(%rbp)
    6750:	48 89 95 10 fc ff ff 	mov    %rdx,-0x3f0(%rbp)
    6757:	48 89 b5 00 fc ff ff 	mov    %rsi,-0x400(%rbp)
    675e:	e9 92 04 00 00       	jmp    0x6bf5
    6763:	48 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%rax
    676a:	48 85 c0             	test   %rax,%rax
    676d:	0f 84 fc 03 00 00    	je     0x6b6f
    6773:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    677a:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    677e:	48 85 d2             	test   %rdx,%rdx
    6781:	0f 84 40 01 00 00    	je     0x68c7
    6787:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    678b:	be 40 00 00 00       	mov    $0x40,%esi
    6790:	48 29 d6             	sub    %rdx,%rsi
    6793:	48 8b bd e8 fa ff ff 	mov    -0x518(%rbp),%rdi
    679a:	48 89 f1             	mov    %rsi,%rcx
    679d:	49 89 f8             	mov    %rdi,%r8
    67a0:	49 d3 e8             	shr    %cl,%r8
    67a3:	31 c9                	xor    %ecx,%ecx
    67a5:	48 39 ca             	cmp    %rcx,%rdx
    67a8:	ba 00 00 00 00       	mov    $0x0,%edx
    67ad:	0f 94 c2             	sete   %dl
    67b0:	48 85 d2             	test   %rdx,%rdx
    67b3:	49 0f 44 c8          	cmove  %r8,%rcx
    67b7:	48 8b 95 90 fc ff ff 	mov    -0x370(%rbp),%rdx
    67be:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    67c2:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    67c6:	49 8b 30             	mov    (%r8),%rsi
    67c9:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    67d0:	00 28 00 
    67d3:	4c 39 ce             	cmp    %r9,%rsi
    67d6:	4c 89 85 98 fb ff ff 	mov    %r8,-0x468(%rbp)
    67dd:	0f 82 0c 00 00 00    	jb     0x67ef
    67e3:	48 89 b5 a8 fb ff ff 	mov    %rsi,-0x458(%rbp)
    67ea:	e9 4a 00 00 00       	jmp    0x6839
    67ef:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    67f3:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    67fa:	48 89 b5 90 fb ff ff 	mov    %rsi,-0x470(%rbp)
    6801:	48 89 d6             	mov    %rdx,%rsi
    6804:	48 89 ca             	mov    %rcx,%rdx
    6807:	48 8b 8d 90 fb ff ff 	mov    -0x470(%rbp),%rcx
    680e:	e8 cd 98 ff ff       	call   0xe0
    6813:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    681a:	31 d2                	xor    %edx,%edx
    681c:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    6820:	48 83 f8 00          	cmp    $0x0,%rax
    6824:	0f 8f 08 00 00 00    	jg     0x6832
    682a:	49 89 c4             	mov    %rax,%r12
    682d:	e9 f5 08 00 00       	jmp    0x7127
    6832:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
    6839:	48 8b 85 a8 fb ff ff 	mov    -0x458(%rbp),%rax
    6840:	48 89 c1             	mov    %rax,%rcx
    6843:	48 83 c1 28          	add    $0x28,%rcx
    6847:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    684e:	00 28 00 
    6851:	48 29 d1             	sub    %rdx,%rcx
    6854:	48 8b 95 98 fb ff ff 	mov    -0x468(%rbp),%rdx
    685b:	48 89 0a             	mov    %rcx,(%rdx)
    685e:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    6865:	ff 00 00 
    6868:	48 21 c8             	and    %rcx,%rax
    686b:	31 c9                	xor    %ecx,%ecx
    686d:	48 8b 95 20 fb ff ff 	mov    -0x4e0(%rbp),%rdx
    6874:	48 89 10             	mov    %rdx,(%rax)
    6877:	48 8b b5 70 fb ff ff 	mov    -0x490(%rbp),%rsi
    687e:	48 89 70 08          	mov    %rsi,0x8(%rax)
    6882:	48 89 48 10          	mov    %rcx,0x10(%rax)
    6886:	48 89 48 18          	mov    %rcx,0x18(%rax)
    688a:	48 89 48 20          	mov    %rcx,0x20(%rax)
    688e:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    6895:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    6899:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    689f:	4c 01 c7             	add    %r8,%rdi
    68a2:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    68a6:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
    68ad:	b8 01 00 00 00       	mov    $0x1,%eax
    68b2:	48 89 85 98 fb ff ff 	mov    %rax,-0x468(%rbp)
    68b9:	31 c0                	xor    %eax,%eax
    68bb:	48 89 85 90 fb ff ff 	mov    %rax,-0x470(%rbp)
    68c2:	e9 a2 01 00 00       	jmp    0x6a69
    68c7:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    68ce:	48 8b 48 10          	mov    0x10(%rax),%rcx
    68d2:	48 8b 50 18          	mov    0x18(%rax),%rdx
    68d6:	48 89 d6             	mov    %rdx,%rsi
    68d9:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    68de:	bf 40 00 00 00       	mov    $0x40,%edi
    68e3:	48 29 f7             	sub    %rsi,%rdi
    68e6:	48 89 8d b8 fb ff ff 	mov    %rcx,-0x448(%rbp)
    68ed:	4c 8b 85 e8 fa ff ff 	mov    -0x518(%rbp),%r8
    68f4:	48 89 f9             	mov    %rdi,%rcx
    68f7:	4d 89 c1             	mov    %r8,%r9
    68fa:	49 d3 e9             	shr    %cl,%r9
    68fd:	31 c9                	xor    %ecx,%ecx
    68ff:	48 39 ce             	cmp    %rcx,%rsi
    6902:	be 00 00 00 00       	mov    $0x0,%esi
    6907:	40 0f 94 c6          	sete   %sil
    690b:	48 85 f6             	test   %rsi,%rsi
    690e:	49 0f 44 c9          	cmove  %r9,%rcx
    6912:	be 01 00 00 00       	mov    $0x1,%esi
    6917:	48 89 cf             	mov    %rcx,%rdi
    691a:	48 01 f7             	add    %rsi,%rdi
    691d:	48 21 d7             	and    %rdx,%rdi
    6920:	ba 28 00 00 00       	mov    $0x28,%edx
    6925:	48 0f af ca          	imul   %rdx,%rcx
    6929:	48 8b 95 b8 fb ff ff 	mov    -0x448(%rbp),%rdx
    6930:	4c 8d 0c 0a          	lea    (%rdx,%rcx,1),%r9
    6934:	49 8b 49 10          	mov    0x10(%r9),%rcx
    6938:	48 85 c9             	test   %rcx,%rcx
    693b:	0f 84 af 00 00 00    	je     0x69f0
    6941:	49 8b 09             	mov    (%r9),%rcx
    6944:	4d 8b 51 08          	mov    0x8(%r9),%r10
    6948:	4c 8b 9d 20 fb ff ff 	mov    -0x4e0(%rbp),%r11
    694f:	49 39 cb             	cmp    %rcx,%r11
    6952:	ba 00 00 00 00       	mov    $0x0,%edx
    6957:	0f 94 c2             	sete   %dl
    695a:	48 8b 8d 70 fb ff ff 	mov    -0x490(%rbp),%rcx
    6961:	4c 39 d1             	cmp    %r10,%rcx
    6964:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    696a:	41 0f 94 c0          	sete   %r8b
    696e:	4c 21 c2             	and    %r8,%rdx
    6971:	48 85 d2             	test   %rdx,%rdx
    6974:	0f 84 0c 00 00 00    	je     0x6986
    697a:	4c 89 8d a8 fb ff ff 	mov    %r9,-0x458(%rbp)
    6981:	e9 53 00 00 00       	jmp    0x69d9
    6986:	ba 28 00 00 00       	mov    $0x28,%edx
    698b:	48 0f af fa          	imul   %rdx,%rdi
    698f:	48 8b 95 b8 fb ff ff 	mov    -0x448(%rbp),%rdx
    6996:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    699a:	49 8b 50 10          	mov    0x10(%r8),%rdx
    699e:	48 85 d2             	test   %rdx,%rdx
    69a1:	0f 84 49 00 00 00    	je     0x69f0
    69a7:	49 8b 10             	mov    (%r8),%rdx
    69aa:	49 8b 78 08          	mov    0x8(%r8),%rdi
    69ae:	49 39 d3             	cmp    %rdx,%r11
    69b1:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    69b7:	41 0f 94 c1          	sete   %r9b
    69bb:	48 39 f9             	cmp    %rdi,%rcx
    69be:	ba 00 00 00 00       	mov    $0x0,%edx
    69c3:	0f 94 c2             	sete   %dl
    69c6:	49 21 d1             	and    %rdx,%r9
    69c9:	4d 85 c9             	test   %r9,%r9
    69cc:	0f 84 1e 00 00 00    	je     0x69f0
    69d2:	4c 89 85 a8 fb ff ff 	mov    %r8,-0x458(%rbp)
    69d9:	31 c0                	xor    %eax,%eax
    69db:	48 89 85 98 fb ff ff 	mov    %rax,-0x468(%rbp)
    69e2:	31 c0                	xor    %eax,%eax
    69e4:	48 89 85 90 fb ff ff 	mov    %rax,-0x470(%rbp)
    69eb:	e9 79 00 00 00       	jmp    0x6a69
    69f0:	48 8d 85 20 fd ff ff 	lea    -0x2e0(%rbp),%rax
    69f7:	48 89 c1             	mov    %rax,%rcx
    69fa:	48 8b 95 20 fb ff ff 	mov    -0x4e0(%rbp),%rdx
    6a01:	48 89 11             	mov    %rdx,(%rcx)
    6a04:	48 8b b5 70 fb ff ff 	mov    -0x490(%rbp),%rsi
    6a0b:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    6a0f:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    6a16:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    6a1d:	48 89 ca             	mov    %rcx,%rdx
    6a20:	e8 cb 96 ff ff       	call   0xf0
    6a25:	48 83 f8 00          	cmp    $0x0,%rax
    6a29:	0f 8d 08 00 00 00    	jge    0x6a37
    6a2f:	49 89 c4             	mov    %rax,%r12
    6a32:	e9 f0 06 00 00       	jmp    0x7127
    6a37:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    6a3e:	48 8b 11             	mov    (%rcx),%rdx
    6a41:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    6a45:	48 83 e6 01          	and    $0x1,%rsi
    6a49:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    6a4d:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
    6a54:	b8 01 00 00 00       	mov    $0x1,%eax
    6a59:	48 89 85 98 fb ff ff 	mov    %rax,-0x468(%rbp)
    6a60:	31 c0                	xor    %eax,%eax
    6a62:	48 89 85 90 fb ff ff 	mov    %rax,-0x470(%rbp)
    6a69:	48 8b 85 98 fb ff ff 	mov    -0x468(%rbp),%rax
    6a70:	48 85 c0             	test   %rax,%rax
    6a73:	0f 84 68 00 00 00    	je     0x6ae1
    6a79:	48 8b 85 a8 fb ff ff 	mov    -0x458(%rbp),%rax
    6a80:	48 8b 8d 10 fb ff ff 	mov    -0x4f0(%rbp),%rcx
    6a87:	48 89 48 10          	mov    %rcx,0x10(%rax)
    6a8b:	31 d2                	xor    %edx,%edx
    6a8d:	48 39 d1             	cmp    %rdx,%rcx
    6a90:	be 00 00 00 00       	mov    $0x0,%esi
    6a95:	40 0f 95 c6          	setne  %sil
    6a99:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    6a9d:	48 09 f7             	or     %rsi,%rdi
    6aa0:	40 88 78 20          	mov    %dil,0x20(%rax)
    6aa4:	48 8b b5 e0 fa ff ff 	mov    -0x520(%rbp),%rsi
    6aab:	48 89 70 18          	mov    %rsi,0x18(%rax)
    6aaf:	48 8b bd 68 fb ff ff 	mov    -0x498(%rbp),%rdi
    6ab6:	48 39 d7             	cmp    %rdx,%rdi
    6ab9:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    6abf:	41 0f 95 c0          	setne  %r8b
    6ac3:	44 0f b6 48 20       	movzbl 0x20(%rax),%r9d
    6ac8:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    6ace:	4d 85 c0             	test   %r8,%r8
    6ad1:	4c 0f 44 d2          	cmove  %rdx,%r10
    6ad5:	4d 09 d1             	or     %r10,%r9
    6ad8:	44 88 48 20          	mov    %r9b,0x20(%rax)
    6adc:	e9 8e 00 00 00       	jmp    0x6b6f
    6ae1:	48 8b 85 a8 fb ff ff 	mov    -0x458(%rbp),%rax
    6ae8:	48 8b 48 10          	mov    0x10(%rax),%rcx
    6aec:	48 8b 95 10 fb ff ff 	mov    -0x4f0(%rbp),%rdx
    6af3:	48 01 d1             	add    %rdx,%rcx
    6af6:	48 89 48 10          	mov    %rcx,0x10(%rax)
    6afa:	31 f6                	xor    %esi,%esi
    6afc:	48 39 f1             	cmp    %rsi,%rcx
    6aff:	b9 00 00 00 00       	mov    $0x0,%ecx
    6b04:	0f 95 c1             	setne  %cl
    6b07:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    6b0b:	48 09 cf             	or     %rcx,%rdi
    6b0e:	40 88 78 20          	mov    %dil,0x20(%rax)
    6b12:	48 8b 48 18          	mov    0x18(%rax),%rcx
    6b16:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    6b1a:	48 83 e7 02          	and    $0x2,%rdi
    6b1e:	48 39 f7             	cmp    %rsi,%rdi
    6b21:	bf 00 00 00 00       	mov    $0x0,%edi
    6b26:	40 0f 95 c7          	setne  %dil
    6b2a:	45 31 c0             	xor    %r8d,%r8d
    6b2d:	48 85 ff             	test   %rdi,%rdi
    6b30:	49 0f 44 c8          	cmove  %r8,%rcx
    6b34:	4c 8b 85 68 fb ff ff 	mov    -0x498(%rbp),%r8
    6b3b:	4c 01 c7             	add    %r8,%rdi
    6b3e:	4c 8b 8d e0 fa ff ff 	mov    -0x520(%rbp),%r9
    6b45:	4c 01 c9             	add    %r9,%rcx
    6b48:	48 89 48 18          	mov    %rcx,0x18(%rax)
    6b4c:	48 39 f7             	cmp    %rsi,%rdi
    6b4f:	bf 00 00 00 00       	mov    $0x0,%edi
    6b54:	40 0f 95 c7          	setne  %dil
    6b58:	0f b6 48 20          	movzbl 0x20(%rax),%ecx
    6b5c:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    6b62:	48 85 ff             	test   %rdi,%rdi
    6b65:	4c 0f 44 d6          	cmove  %rsi,%r10
    6b69:	4c 09 d1             	or     %r10,%rcx
    6b6c:	88 48 20             	mov    %cl,0x20(%rax)
    6b6f:	48 8b 85 50 fb ff ff 	mov    -0x4b0(%rbp),%rax
    6b76:	48 63 08             	movslq (%rax),%rcx
    6b79:	48 ba 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rdx
    6b80:	79 37 9e 
    6b83:	48 be 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%rsi
    6b8a:	79 37 9e 
    6b8d:	48 8b bd 60 fb ff ff 	mov    -0x4a0(%rbp),%rdi
    6b94:	48 31 fe             	xor    %rdi,%rsi
    6b97:	48 0f af f2          	imul   %rdx,%rsi
    6b9b:	49 89 f0             	mov    %rsi,%r8
    6b9e:	49 c1 e8 1d          	shr    $0x1d,%r8
    6ba2:	4c 31 c6             	xor    %r8,%rsi
    6ba5:	4c 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%r8
    6bac:	4c 31 c6             	xor    %r8,%rsi
    6baf:	48 0f af f2          	imul   %rdx,%rsi
    6bb3:	49 89 f1             	mov    %rsi,%r9
    6bb6:	49 c1 e9 1d          	shr    $0x1d,%r9
    6bba:	4c 31 ce             	xor    %r9,%rsi
    6bbd:	48 0f af f2          	imul   %rdx,%rsi
    6bc1:	48 89 bd 08 fc ff ff 	mov    %rdi,-0x3f8(%rbp)
    6bc8:	4c 89 85 e0 fb ff ff 	mov    %r8,-0x420(%rbp)
    6bcf:	48 89 b5 30 fc ff ff 	mov    %rsi,-0x3d0(%rbp)
    6bd6:	ba 01 00 00 00       	mov    $0x1,%edx
    6bdb:	48 89 95 20 fc ff ff 	mov    %rdx,-0x3e0(%rbp)
    6be2:	48 89 8d 10 fc ff ff 	mov    %rcx,-0x3f0(%rbp)
    6be9:	ba 01 00 00 00       	mov    $0x1,%edx
    6bee:	48 89 95 00 fc ff ff 	mov    %rdx,-0x400(%rbp)
    6bf5:	48 8b 85 18 fc ff ff 	mov    -0x3e8(%rbp),%rax
    6bfc:	48 89 85 f0 fb ff ff 	mov    %rax,-0x410(%rbp)
    6c03:	b8 01 00 00 00       	mov    $0x1,%eax
    6c08:	48 89 85 80 fb ff ff 	mov    %rax,-0x480(%rbp)
    6c0f:	31 c0                	xor    %eax,%eax
    6c11:	48 89 03             	mov    %rax,(%rbx)
    6c14:	b8 01 00 00 00       	mov    $0x1,%eax
    6c19:	4c 89 f9             	mov    %r15,%rcx
    6c1c:	48 01 c1             	add    %rax,%rcx
    6c1f:	49 89 cf             	mov    %rcx,%r15
    6c22:	e9 af f3 ff ff       	jmp    0x5fd6
    6c27:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    6c2e:	e8 0d 94 ff ff       	call   0x40
    6c33:	48 85 c0             	test   %rax,%rax
    6c36:	0f 84 28 fa ff ff    	je     0x6664
    6c3c:	e9 df 04 00 00       	jmp    0x7120
    6c41:	48 8b 85 b0 fb ff ff 	mov    -0x450(%rbp),%rax
    6c48:	48 85 c0             	test   %rax,%rax
    6c4b:	0f 84 a6 03 00 00    	je     0x6ff7
    6c51:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    6c58:	48 8b 48 68          	mov    0x68(%rax),%rcx
    6c5c:	48 85 c9             	test   %rcx,%rcx
    6c5f:	0f 84 1f 01 00 00    	je     0x6d84
    6c65:	48 8b 48 38          	mov    0x38(%rax),%rcx
    6c69:	ba 40 00 00 00       	mov    $0x40,%edx
    6c6e:	48 29 ca             	sub    %rcx,%rdx
    6c71:	48 89 8d b0 fb ff ff 	mov    %rcx,-0x450(%rbp)
    6c78:	48 8b b5 88 fb ff ff 	mov    -0x478(%rbp),%rsi
    6c7f:	48 89 d1             	mov    %rdx,%rcx
    6c82:	48 89 f7             	mov    %rsi,%rdi
    6c85:	48 d3 ef             	shr    %cl,%rdi
    6c88:	31 c9                	xor    %ecx,%ecx
    6c8a:	48 8b 95 b0 fb ff ff 	mov    -0x450(%rbp),%rdx
    6c91:	48 39 ca             	cmp    %rcx,%rdx
    6c94:	ba 00 00 00 00       	mov    $0x0,%edx
    6c99:	0f 94 c2             	sete   %dl
    6c9c:	48 85 d2             	test   %rdx,%rdx
    6c9f:	48 0f 44 cf          	cmove  %rdi,%rcx
    6ca3:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6ca7:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    6cab:	4c 8b 2f             	mov    (%rdi),%r13
    6cae:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    6cb5:	00 28 00 
    6cb8:	49 39 d5             	cmp    %rdx,%r13
    6cbb:	48 89 bd b0 fb ff ff 	mov    %rdi,-0x450(%rbp)
    6cc2:	0f 82 05 00 00 00    	jb     0x6ccd
    6cc8:	e9 3b 00 00 00       	jmp    0x6d08
    6ccd:	4c 8b 40 60          	mov    0x60(%rax),%r8
    6cd1:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    6cd8:	48 89 c6             	mov    %rax,%rsi
    6cdb:	48 89 ca             	mov    %rcx,%rdx
    6cde:	4c 89 c1             	mov    %r8,%rcx
    6ce1:	e8 fa 93 ff ff       	call   0xe0
    6ce6:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    6ced:	31 d2                	xor    %edx,%edx
    6cef:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    6cf3:	48 83 f8 00          	cmp    $0x0,%rax
    6cf7:	0f 8f 08 00 00 00    	jg     0x6d05
    6cfd:	49 89 c4             	mov    %rax,%r12
    6d00:	e9 22 04 00 00       	jmp    0x7127
    6d05:	49 89 c5             	mov    %rax,%r13
    6d08:	4c 89 e8             	mov    %r13,%rax
    6d0b:	48 83 c0 28          	add    $0x28,%rax
    6d0f:	48 b9 00 00 00 00 00 	movabs $0x28000000000000,%rcx
    6d16:	00 28 00 
    6d19:	48 29 c8             	sub    %rcx,%rax
    6d1c:	48 8b 8d b0 fb ff ff 	mov    -0x450(%rbp),%rcx
    6d23:	48 89 01             	mov    %rax,(%rcx)
    6d26:	48 b8 ff ff ff ff ff 	movabs $0xffffffffffff,%rax
    6d2d:	ff 00 00 
    6d30:	4d 89 ee             	mov    %r13,%r14
    6d33:	49 21 c6             	and    %rax,%r14
    6d36:	31 c0                	xor    %eax,%eax
    6d38:	48 8b 8d 38 fb ff ff 	mov    -0x4c8(%rbp),%rcx
    6d3f:	49 89 0e             	mov    %rcx,(%r14)
    6d42:	48 8b 95 f0 fa ff ff 	mov    -0x510(%rbp),%rdx
    6d49:	49 89 56 08          	mov    %rdx,0x8(%r14)
    6d4d:	49 89 46 10          	mov    %rax,0x10(%r14)
    6d51:	49 89 46 18          	mov    %rax,0x18(%r14)
    6d55:	49 89 46 20          	mov    %rax,0x20(%r14)
    6d59:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    6d60:	48 8b 70 60          	mov    0x60(%rax),%rsi
    6d64:	bf 01 00 00 00       	mov    $0x1,%edi
    6d69:	48 01 fe             	add    %rdi,%rsi
    6d6c:	48 89 70 60          	mov    %rsi,0x60(%rax)
    6d70:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    6d76:	31 f6                	xor    %esi,%esi
    6d78:	48 89 b5 b0 fb ff ff 	mov    %rsi,-0x450(%rbp)
    6d7f:	e9 83 01 00 00       	jmp    0x6f07
    6d84:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    6d8b:	48 8b 48 10          	mov    0x10(%rax),%rcx
    6d8f:	48 8b 50 18          	mov    0x18(%rax),%rdx
    6d93:	48 89 d6             	mov    %rdx,%rsi
    6d96:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    6d9b:	bf 40 00 00 00       	mov    $0x40,%edi
    6da0:	48 29 f7             	sub    %rsi,%rdi
    6da3:	48 89 8d d8 fb ff ff 	mov    %rcx,-0x428(%rbp)
    6daa:	4c 8b 85 88 fb ff ff 	mov    -0x478(%rbp),%r8
    6db1:	48 89 f9             	mov    %rdi,%rcx
    6db4:	49 d3 e8             	shr    %cl,%r8
    6db7:	31 c9                	xor    %ecx,%ecx
    6db9:	48 39 ce             	cmp    %rcx,%rsi
    6dbc:	be 00 00 00 00       	mov    $0x0,%esi
    6dc1:	40 0f 94 c6          	sete   %sil
    6dc5:	48 85 f6             	test   %rsi,%rsi
    6dc8:	49 0f 44 c8          	cmove  %r8,%rcx
    6dcc:	be 01 00 00 00       	mov    $0x1,%esi
    6dd1:	48 89 cf             	mov    %rcx,%rdi
    6dd4:	48 01 f7             	add    %rsi,%rdi
    6dd7:	48 21 d7             	and    %rdx,%rdi
    6dda:	ba 28 00 00 00       	mov    $0x28,%edx
    6ddf:	48 0f af ca          	imul   %rdx,%rcx
    6de3:	48 8b 95 d8 fb ff ff 	mov    -0x428(%rbp),%rdx
    6dea:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
    6dee:	49 8b 48 10          	mov    0x10(%r8),%rcx
    6df2:	48 85 c9             	test   %rcx,%rcx
    6df5:	0f 84 9d 00 00 00    	je     0x6e98
    6dfb:	49 8b 08             	mov    (%r8),%rcx
    6dfe:	4d 8b 48 08          	mov    0x8(%r8),%r9
    6e02:	4c 8b 95 38 fb ff ff 	mov    -0x4c8(%rbp),%r10
    6e09:	49 39 ca             	cmp    %rcx,%r10
    6e0c:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    6e12:	41 0f 94 c3          	sete   %r11b
    6e16:	48 8b 8d f0 fa ff ff 	mov    -0x510(%rbp),%rcx
    6e1d:	4c 39 c9             	cmp    %r9,%rcx
    6e20:	41 bf 00 00 00 00    	mov    $0x0,%r15d
    6e26:	41 0f 94 c7          	sete   %r15b
    6e2a:	4d 21 fb             	and    %r15,%r11
    6e2d:	4d 85 db             	test   %r11,%r11
    6e30:	0f 84 08 00 00 00    	je     0x6e3e
    6e36:	4d 89 c6             	mov    %r8,%r14
    6e39:	e9 49 00 00 00       	jmp    0x6e87
    6e3e:	41 b8 28 00 00 00    	mov    $0x28,%r8d
    6e44:	49 0f af f8          	imul   %r8,%rdi
    6e48:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    6e4c:	49 8b 50 10          	mov    0x10(%r8),%rdx
    6e50:	48 85 d2             	test   %rdx,%rdx
    6e53:	0f 84 3f 00 00 00    	je     0x6e98
    6e59:	49 8b 10             	mov    (%r8),%rdx
    6e5c:	49 8b 78 08          	mov    0x8(%r8),%rdi
    6e60:	49 39 d2             	cmp    %rdx,%r10
    6e63:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    6e69:	41 0f 94 c1          	sete   %r9b
    6e6d:	48 39 f9             	cmp    %rdi,%rcx
    6e70:	ba 00 00 00 00       	mov    $0x0,%edx
    6e75:	0f 94 c2             	sete   %dl
    6e78:	49 21 d1             	and    %rdx,%r9
    6e7b:	4d 85 c9             	test   %r9,%r9
    6e7e:	0f 84 14 00 00 00    	je     0x6e98
    6e84:	4d 89 c6             	mov    %r8,%r14
    6e87:	45 31 ed             	xor    %r13d,%r13d
    6e8a:	31 c0                	xor    %eax,%eax
    6e8c:	48 89 85 b0 fb ff ff 	mov    %rax,-0x450(%rbp)
    6e93:	e9 6f 00 00 00       	jmp    0x6f07
    6e98:	48 8d 85 a0 fc ff ff 	lea    -0x360(%rbp),%rax
    6e9f:	48 89 c1             	mov    %rax,%rcx
    6ea2:	48 8b 95 38 fb ff ff 	mov    -0x4c8(%rbp),%rdx
    6ea9:	48 89 11             	mov    %rdx,(%rcx)
    6eac:	48 8b 95 f0 fa ff ff 	mov    -0x510(%rbp),%rdx
    6eb3:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    6eb7:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    6ebe:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    6ec5:	48 89 ca             	mov    %rcx,%rdx
    6ec8:	e8 23 92 ff ff       	call   0xf0
    6ecd:	48 83 f8 00          	cmp    $0x0,%rax
    6ed1:	0f 8d 08 00 00 00    	jge    0x6edf
    6ed7:	49 89 c4             	mov    %rax,%r12
    6eda:	e9 48 02 00 00       	jmp    0x7127
    6edf:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    6ee6:	48 8b 11             	mov    (%rcx),%rdx
    6ee9:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    6eed:	48 83 e6 01          	and    $0x1,%rsi
    6ef1:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    6ef5:	49 89 c6             	mov    %rax,%r14
    6ef8:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    6efe:	31 c0                	xor    %eax,%eax
    6f00:	48 89 85 b0 fb ff ff 	mov    %rax,-0x450(%rbp)
    6f07:	4d 85 ed             	test   %r13,%r13
    6f0a:	0f 84 60 00 00 00    	je     0x6f70
    6f10:	48 8b 85 a0 fb ff ff 	mov    -0x460(%rbp),%rax
    6f17:	49 89 46 10          	mov    %rax,0x10(%r14)
    6f1b:	31 c9                	xor    %ecx,%ecx
    6f1d:	48 39 c8             	cmp    %rcx,%rax
    6f20:	ba 00 00 00 00       	mov    $0x0,%edx
    6f25:	0f 95 c2             	setne  %dl
    6f28:	41 0f b6 76 20       	movzbl 0x20(%r14),%esi
    6f2d:	48 09 d6             	or     %rdx,%rsi
    6f30:	41 88 76 20          	mov    %sil,0x20(%r14)
    6f34:	48 8b 95 28 fb ff ff 	mov    -0x4d8(%rbp),%rdx
    6f3b:	49 89 56 18          	mov    %rdx,0x18(%r14)
    6f3f:	48 8b b5 58 fb ff ff 	mov    -0x4a8(%rbp),%rsi
    6f46:	48 39 ce             	cmp    %rcx,%rsi
    6f49:	bf 00 00 00 00       	mov    $0x0,%edi
    6f4e:	40 0f 95 c7          	setne  %dil
    6f52:	45 0f b6 46 20       	movzbl 0x20(%r14),%r8d
    6f57:	41 b9 02 00 00 00    	mov    $0x2,%r9d
    6f5d:	48 85 ff             	test   %rdi,%rdi
    6f60:	4c 0f 44 c9          	cmove  %rcx,%r9
    6f64:	4d 09 c8             	or     %r9,%r8
    6f67:	45 88 46 20          	mov    %r8b,0x20(%r14)
    6f6b:	e9 87 00 00 00       	jmp    0x6ff7
    6f70:	49 8b 46 10          	mov    0x10(%r14),%rax
    6f74:	48 8b 8d a0 fb ff ff 	mov    -0x460(%rbp),%rcx
    6f7b:	48 01 c8             	add    %rcx,%rax
    6f7e:	49 89 46 10          	mov    %rax,0x10(%r14)
    6f82:	31 c9                	xor    %ecx,%ecx
    6f84:	48 39 c8             	cmp    %rcx,%rax
    6f87:	b8 00 00 00 00       	mov    $0x0,%eax
    6f8c:	0f 95 c0             	setne  %al
    6f8f:	41 0f b6 56 20       	movzbl 0x20(%r14),%edx
    6f94:	48 09 c2             	or     %rax,%rdx
    6f97:	41 88 56 20          	mov    %dl,0x20(%r14)
    6f9b:	49 8b 46 18          	mov    0x18(%r14),%rax
    6f9f:	41 0f b6 56 20       	movzbl 0x20(%r14),%edx
    6fa4:	48 83 e2 02          	and    $0x2,%rdx
    6fa8:	48 39 ca             	cmp    %rcx,%rdx
    6fab:	ba 00 00 00 00       	mov    $0x0,%edx
    6fb0:	0f 95 c2             	setne  %dl
    6fb3:	31 f6                	xor    %esi,%esi
    6fb5:	48 85 d2             	test   %rdx,%rdx
    6fb8:	48 0f 44 c6          	cmove  %rsi,%rax
    6fbc:	48 8b b5 58 fb ff ff 	mov    -0x4a8(%rbp),%rsi
    6fc3:	48 01 f2             	add    %rsi,%rdx
    6fc6:	48 8b b5 28 fb ff ff 	mov    -0x4d8(%rbp),%rsi
    6fcd:	48 01 f0             	add    %rsi,%rax
    6fd0:	49 89 46 18          	mov    %rax,0x18(%r14)
    6fd4:	48 39 ca             	cmp    %rcx,%rdx
    6fd7:	ba 00 00 00 00       	mov    $0x0,%edx
    6fdc:	0f 95 c2             	setne  %dl
    6fdf:	41 0f b6 46 20       	movzbl 0x20(%r14),%eax
    6fe4:	be 02 00 00 00       	mov    $0x2,%esi
    6fe9:	48 85 d2             	test   %rdx,%rdx
    6fec:	48 0f 44 f1          	cmove  %rcx,%rsi
    6ff0:	48 09 f0             	or     %rsi,%rax
    6ff3:	41 88 46 20          	mov    %al,0x20(%r14)
    6ff7:	48 8b 85 88 fc ff ff 	mov    -0x378(%rbp),%rax
    6ffe:	48 89 85 d0 fb ff ff 	mov    %rax,-0x430(%rbp)
    7005:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    700c:	48 8b 88 a8 01 00 00 	mov    0x1a8(%rax),%rcx
    7013:	48 8b 95 d0 fb ff ff 	mov    -0x430(%rbp),%rdx
    701a:	48 01 d1             	add    %rdx,%rcx
    701d:	48 89 88 a8 01 00 00 	mov    %rcx,0x1a8(%rax)
    7024:	48 8b 8d f8 fb ff ff 	mov    -0x408(%rbp),%rcx
    702b:	89 88 c0 01 00 00    	mov    %ecx,0x1c0(%rax)
    7031:	e9 8d a2 ff ff       	jmp    0x12c3
    7036:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    703d:	e8 fe 8f ff ff       	call   0x40
    7042:	48 85 c0             	test   %rax,%rax
    7045:	0f 84 98 a2 ff ff    	je     0x12e3
    704b:	e9 d0 00 00 00       	jmp    0x7120
    7050:	48 8b 85 28 fc ff ff 	mov    -0x3d8(%rbp),%rax
    7057:	48 85 c0             	test   %rax,%rax
    705a:	0f 84 08 00 00 00    	je     0x7068
    7060:	49 89 c4             	mov    %rax,%r12
    7063:	e9 bf 00 00 00       	jmp    0x7127
    7068:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    706f:	48 8b 08             	mov    (%rax),%rcx
    7072:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    7076:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
    707a:	0f b6 51 70          	movzbl 0x70(%rcx),%edx
    707e:	48 85 d2             	test   %rdx,%rdx
    7081:	0f 84 2b 00 00 00    	je     0x70b2
    7087:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    708c:	48 89 c7             	mov    %rax,%rdi
    708f:	48 89 ce             	mov    %rcx,%rsi
    7092:	e8 c9 8f ff ff       	call   0x60
    7097:	48 83 f8 00          	cmp    $0x0,%rax
    709b:	0f 8d 11 00 00 00    	jge    0x70b2
    70a1:	b8 80 00 00 00       	mov    $0x80,%eax
    70a6:	48 89 85 48 fb ff ff 	mov    %rax,-0x4b8(%rbp)
    70ad:	e9 54 00 00 00       	jmp    0x7106
    70b2:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    70b9:	48 8b 08             	mov    (%rax),%rcx
    70bc:	48 8b 50 60          	mov    0x60(%rax),%rdx
    70c0:	48 8b 59 58          	mov    0x58(%rcx),%rbx
    70c4:	48 01 d3             	add    %rdx,%rbx
    70c7:	48 89 59 58          	mov    %rbx,0x58(%rcx)
    70cb:	31 c9                	xor    %ecx,%ecx
    70cd:	48 89 48 60          	mov    %rcx,0x60(%rax)
    70d1:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    70d8:	48 89 c6             	mov    %rax,%rsi
    70db:	e8 20 90 ff ff       	call   0x100
    70e0:	48 83 f8 00          	cmp    $0x0,%rax
    70e4:	0f 8d 08 00 00 00    	jge    0x70f2
    70ea:	49 89 c4             	mov    %rax,%r12
    70ed:	e9 35 00 00 00       	jmp    0x7127
    70f2:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    70f9:	e8 72 8f ff ff       	call   0x70
    70fe:	49 89 c4             	mov    %rax,%r12
    7101:	e9 21 00 00 00       	jmp    0x7127
    7106:	48 8b 85 48 fb ff ff 	mov    -0x4b8(%rbp),%rax
    710d:	48 c1 e0 08          	shl    $0x8,%rax
    7111:	48 83 c8 03          	or     $0x3,%rax
    7115:	48 f7 d8             	neg    %rax
    7118:	49 89 c4             	mov    %rax,%r12
    711b:	e9 07 00 00 00       	jmp    0x7127
    7120:	49 c7 c4 fe ff ff ff 	mov    $0xfffffffffffffffe,%r12
    7127:	4c 89 e0             	mov    %r12,%rax
    712a:	48 81 c4 38 05 00 00 	add    $0x538,%rsp
    7131:	41 5f                	pop    %r15
    7133:	41 5e                	pop    %r14
    7135:	41 5d                	pop    %r13
    7137:	41 5c                	pop    %r12
    7139:	5b                   	pop    %rbx
    713a:	5d                   	pop    %rbp
    713b:	c3                   	ret
    713c:	0f 1f 40 00          	nopl   0x0(%rax)
    7140:	55                   	push   %rbp
    7141:	48 89 e5             	mov    %rsp,%rbp
    7144:	53                   	push   %rbx
    7145:	41 54                	push   %r12
    7147:	41 55                	push   %r13
    7149:	41 56                	push   %r14
    714b:	41 57                	push   %r15
    714d:	48 81 ec e8 02 00 00 	sub    $0x2e8,%rsp
    7154:	31 c0                	xor    %eax,%eax
    7156:	b9 01 00 00 00       	mov    $0x1,%ecx
    715b:	48 8b 57 58          	mov    0x58(%rdi),%rdx
    715f:	48 8b 9f 10 02 00 00 	mov    0x210(%rdi),%rbx
    7166:	48 8d b5 60 ff ff ff 	lea    -0xa0(%rbp),%rsi
    716d:	49 89 f0             	mov    %rsi,%r8
    7170:	4c 8b 4f 50          	mov    0x50(%rdi),%r9
    7174:	4d 85 c9             	test   %r9,%r9
    7177:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
    717b:	4c 89 85 58 fe ff ff 	mov    %r8,-0x1a8(%rbp)
    7182:	0f 85 c1 01 00 00    	jne    0x7349
    7188:	49 b9 01 00 00 00 00 	movabs $0x4000000000001,%r9
    718f:	00 04 00 
    7192:	4c 89 4f 50          	mov    %r9,0x50(%rdi)
    7196:	45 31 c9             	xor    %r9d,%r9d
    7199:	4c 89 4b 18          	mov    %r9,0x18(%rbx)
    719d:	41 b9 99 19 00 00    	mov    $0x1999,%r9d
    71a3:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    71a7:	49 39 c2             	cmp    %rax,%r10
    71aa:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    71b0:	41 0f 94 c3          	sete   %r11b
    71b4:	4d 85 db             	test   %r11,%r11
    71b7:	4d 0f 44 ca          	cmove  %r10,%r9
    71bb:	41 bc 99 19 00 00    	mov    $0x1999,%r12d
    71c1:	4d 85 db             	test   %r11,%r11
    71c4:	4d 0f 44 e2          	cmove  %r10,%r12
    71c8:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
    71ce:	4d 39 e1             	cmp    %r12,%r9
    71d1:	4d 0f 47 cc          	cmova  %r12,%r9
    71d5:	4d 39 d1             	cmp    %r10,%r9
    71d8:	4d 0f 47 ca          	cmova  %r10,%r9
    71dc:	4c 8d 95 30 ff ff ff 	lea    -0xd0(%rbp),%r10
    71e3:	4d 89 d3             	mov    %r10,%r11
    71e6:	41 bc 02 02 01 01    	mov    $0x1010202,%r12d
    71ec:	4d 89 23             	mov    %r12,(%r11)
    71ef:	41 bc 00 00 00 01    	mov    $0x1000000,%r12d
    71f5:	4d 89 63 08          	mov    %r12,0x8(%r11)
    71f9:	41 bc 00 00 10 18    	mov    $0x18100000,%r12d
    71ff:	4d 89 63 10          	mov    %r12,0x10(%r11)
    7203:	49 bc 00 00 28 01 10 	movabs $0x201001280000,%r12
    720a:	20 00 00 
    720d:	4d 89 63 18          	mov    %r12,0x18(%r11)
    7211:	45 31 e4             	xor    %r12d,%r12d
    7214:	4d 89 63 20          	mov    %r12,0x20(%r11)
    7218:	41 bc 99 19 00 00    	mov    $0x1999,%r12d
    721e:	4c 8b 6a 08          	mov    0x8(%rdx),%r13
    7222:	49 39 c5             	cmp    %rax,%r13
    7225:	ba 00 00 00 00       	mov    $0x0,%edx
    722a:	0f 94 c2             	sete   %dl
    722d:	48 85 d2             	test   %rdx,%rdx
    7230:	4d 0f 44 e5          	cmove  %r13,%r12
    7234:	ba cd cc cc 00       	mov    $0xcccccd,%edx
    7239:	49 39 d4             	cmp    %rdx,%r12
    723c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    7242:	41 0f 97 c5          	seta   %r13b
    7246:	4d 85 ed             	test   %r13,%r13
    7249:	49 0f 44 d4          	cmove  %r12,%rdx
    724d:	41 bc 28 00 00 00    	mov    $0x28,%r12d
    7253:	49 0f af d4          	imul   %r12,%rdx
    7257:	48 81 c2 ff ff 03 00 	add    $0x3ffff,%rdx
    725e:	48 c1 ea 12          	shr    $0x12,%rdx
    7262:	48 83 fa 01          	cmp    $0x1,%rdx
    7266:	41 bc 00 00 00 00    	mov    $0x0,%r12d
    726c:	41 0f 97 c4          	seta   %r12b
    7270:	48 83 ea 01          	sub    $0x1,%rdx
    7274:	4c 0f bd ea          	bsr    %rdx,%r13
    7278:	ba 7f 00 00 00       	mov    $0x7f,%edx
    727d:	49 0f 45 d5          	cmovne %r13,%rdx
    7281:	83 f2 3f             	xor    $0x3f,%edx
    7284:	41 bd 40 00 00 00    	mov    $0x40,%r13d
    728a:	49 29 d5             	sub    %rdx,%r13
    728d:	ba 0b 00 00 00       	mov    $0xb,%edx
    7292:	49 39 d5             	cmp    %rdx,%r13
    7295:	41 be 00 00 00 00    	mov    $0x0,%r14d
    729b:	41 0f 97 c6          	seta   %r14b
    729f:	4d 85 f6             	test   %r14,%r14
    72a2:	49 0f 44 d5          	cmove  %r13,%rdx
    72a6:	45 31 ed             	xor    %r13d,%r13d
    72a9:	4d 85 e4             	test   %r12,%r12
    72ac:	49 0f 44 d5          	cmove  %r13,%rdx
    72b0:	4c 89 c6             	mov    %r8,%rsi
    72b3:	48 89 95 50 fe ff ff 	mov    %rdx,-0x1b0(%rbp)
    72ba:	4c 89 da             	mov    %r11,%rdx
    72bd:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
    72c4:	4d 89 c8             	mov    %r9,%r8
    72c7:	e8 b4 8d ff ff       	call   0x80
    72cc:	48 83 f8 00          	cmp    $0x0,%rax
    72d0:	0f 8d 08 00 00 00    	jge    0x72de
    72d6:	49 89 c4             	mov    %rax,%r12
    72d9:	e9 6c 31 00 00       	jmp    0xa44a
    72de:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    72e5:	48 8b 08             	mov    (%rax),%rcx
    72e8:	31 d2                	xor    %edx,%edx
    72ea:	48 8d 74 11 10       	lea    0x10(%rcx,%rdx,1),%rsi
    72ef:	48 89 70 40          	mov    %rsi,0x40(%rax)
    72f3:	48 89 50 60          	mov    %rdx,0x60(%rax)
    72f7:	48 8b 08             	mov    (%rax),%rcx
    72fa:	0f b6 71 0d          	movzbl 0xd(%rcx),%esi
    72fe:	48 83 e6 01          	and    $0x1,%rsi
    7302:	48 89 70 68          	mov    %rsi,0x68(%rax)
    7306:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    730b:	31 f6                	xor    %esi,%esi
    730d:	bf 06 00 00 00       	mov    $0x6,%edi
    7312:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    7318:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    731c:	48 89 ce             	mov    %rcx,%rsi
    731f:	31 d2                	xor    %edx,%edx
    7321:	b9 06 00 00 00       	mov    $0x6,%ecx
    7326:	e8 e5 8d ff ff       	call   0x110
    732b:	48 83 f8 00          	cmp    $0x0,%rax
    732f:	0f 8d 0b 00 00 00    	jge    0x7340
    7335:	41 bd 80 00 00 00    	mov    $0x80,%r13d
    733b:	e9 8f 30 00 00       	jmp    0xa3cf
    7340:	48 85 c0             	test   %rax,%rax
    7343:	0f 85 ac 30 00 00    	jne    0xa3f5
    7349:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
    734d:	48 8b 48 18          	mov    0x18(%rax),%rcx
    7351:	48 85 c9             	test   %rcx,%rcx
    7354:	0f 84 0c 00 00 00    	je     0x7366
    735a:	0f b6 11             	movzbl (%rcx),%edx
    735d:	48 85 d2             	test   %rdx,%rdx
    7360:	0f 85 52 30 00 00    	jne    0xa3b8
    7366:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
    736a:	48 8b 08             	mov    (%rax),%rcx
    736d:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    7371:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
    7375:	44 0f b6 71 0c       	movzbl 0xc(%rcx),%r14d
    737a:	4d 85 f6             	test   %r14,%r14
    737d:	0f 84 72 30 00 00    	je     0xa3f5
    7383:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    7387:	4c 8d 3c 11          	lea    (%rcx,%rdx,1),%r15
    738b:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    738f:	48 8d 34 11          	lea    (%rcx,%rdx,1),%rsi
    7393:	8b 51 30             	mov    0x30(%rcx),%edx
    7396:	48 8b 79 18          	mov    0x18(%rcx),%rdi
    739a:	4c 8b 41 20          	mov    0x20(%rcx),%r8
    739e:	49 29 f8             	sub    %rdi,%r8
    73a1:	41 b9 01 00 00 00    	mov    $0x1,%r9d
    73a7:	4d 01 c8             	add    %r9,%r8
    73aa:	49 89 ca             	mov    %rcx,%r10
    73ad:	49 81 c2 c0 00 00 00 	add    $0xc0,%r10
    73b4:	49 89 f3             	mov    %rsi,%r11
    73b7:	4d 29 fb             	sub    %r15,%r11
    73ba:	4f 8d 0c 1f          	lea    (%r15,%r11,1),%r9
    73be:	4b 8d 04 5f          	lea    (%r15,%r11,2),%rax
    73c2:	44 0f b6 59 72       	movzbl 0x72(%rcx),%r11d
    73c7:	49 83 fe 01          	cmp    $0x1,%r14
    73cb:	b9 00 00 00 00       	mov    $0x0,%ecx
    73d0:	0f 94 c1             	sete   %cl
    73d3:	48 89 8d 50 fe ff ff 	mov    %rcx,-0x1b0(%rbp)
    73da:	31 c9                	xor    %ecx,%ecx
    73dc:	48 89 85 48 fe ff ff 	mov    %rax,-0x1b8(%rbp)
    73e3:	49 39 cb             	cmp    %rcx,%r11
    73e6:	b8 00 00 00 00       	mov    $0x0,%eax
    73eb:	0f 95 c0             	setne  %al
    73ee:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
    73f5:	48 21 c1             	and    %rax,%rcx
    73f8:	48 85 c9             	test   %rcx,%rcx
    73fb:	48 89 95 50 fe ff ff 	mov    %rdx,-0x1b0(%rbp)
    7402:	48 89 b5 40 fe ff ff 	mov    %rsi,-0x1c0(%rbp)
    7409:	48 89 bd 38 fe ff ff 	mov    %rdi,-0x1c8(%rbp)
    7410:	4c 89 85 30 fe ff ff 	mov    %r8,-0x1d0(%rbp)
    7417:	4c 89 8d 28 fe ff ff 	mov    %r9,-0x1d8(%rbp)
    741e:	4c 89 95 20 fe ff ff 	mov    %r10,-0x1e0(%rbp)
    7425:	4c 89 9d 18 fe ff ff 	mov    %r11,-0x1e8(%rbp)
    742c:	0f 85 20 00 00 00    	jne    0x7452
    7432:	31 c0                	xor    %eax,%eax
    7434:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
    743b:	31 c0                	xor    %eax,%eax
    743d:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
    7444:	31 c0                	xor    %eax,%eax
    7446:	48 89 85 00 fe ff ff 	mov    %rax,-0x200(%rbp)
    744d:	e9 96 01 00 00       	jmp    0x75e8
    7452:	b8 08 00 00 00       	mov    $0x8,%eax
    7457:	48 89 d1             	mov    %rdx,%rcx
    745a:	48 d3 e0             	shl    %cl,%rax
    745d:	49 8d 0c 07          	lea    (%r15,%rax,1),%rcx
    7461:	45 31 db             	xor    %r11d,%r11d
    7464:	4a 8d 74 19 40       	lea    0x40(%rcx,%r11,1),%rsi
    7469:	48 3d 00 00 10 00    	cmp    $0x100000,%rax
    746f:	0f 87 1e 00 00 00    	ja     0x7493
    7475:	31 c0                	xor    %eax,%eax
    7477:	48 89 85 00 fe ff ff 	mov    %rax,-0x200(%rbp)
    747e:	48 89 b5 10 fe ff ff 	mov    %rsi,-0x1f0(%rbp)
    7485:	31 c0                	xor    %eax,%eax
    7487:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
    748e:	e9 55 01 00 00       	jmp    0x75e8
    7493:	48 8b 43 20          	mov    0x20(%rbx),%rax
    7497:	4c 8b 4b 28          	mov    0x28(%rbx),%r9
    749b:	ba 01 00 00 00       	mov    $0x1,%edx
    74a0:	49 01 d1             	add    %rdx,%r9
    74a3:	4c 89 4b 28          	mov    %r9,0x28(%rbx)
    74a7:	48 8b 79 10          	mov    0x10(%rcx),%rdi
    74ab:	48 85 c0             	test   %rax,%rax
    74ae:	48 89 b5 f8 fd ff ff 	mov    %rsi,-0x208(%rbp)
    74b5:	4c 89 8d f0 fd ff ff 	mov    %r9,-0x210(%rbp)
    74bc:	0f 85 0c 00 00 00    	jne    0x74ce
    74c2:	48 89 bd e8 fd ff ff 	mov    %rdi,-0x218(%rbp)
    74c9:	e9 b3 00 00 00       	jmp    0x7581
    74ce:	4c 89 5b 20          	mov    %r11,0x20(%rbx)
    74d2:	be ff ff ff ff       	mov    $0xffffffff,%esi
    74d7:	49 89 c1             	mov    %rax,%r9
    74da:	49 21 f1             	and    %rsi,%r9
    74dd:	48 c1 e8 20          	shr    $0x20,%rax
    74e1:	4c 89 ce             	mov    %r9,%rsi
    74e4:	48 01 c6             	add    %rax,%rsi
    74e7:	48 8b 01             	mov    (%rcx),%rax
    74ea:	48 01 f0             	add    %rsi,%rax
    74ed:	48 89 01             	mov    %rax,(%rcx)
    74f0:	48 8b 71 08          	mov    0x8(%rcx),%rsi
    74f4:	4c 01 ce             	add    %r9,%rsi
    74f7:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    74fb:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    7501:	0f 83 0c 00 00 00    	jae    0x7513
    7507:	48 89 bd e8 fd ff ff 	mov    %rdi,-0x218(%rbp)
    750e:	e9 6e 00 00 00       	jmp    0x7581
    7513:	41 b9 17 00 00 00    	mov    $0x17,%r9d
    7519:	41 b8 08 00 00 00    	mov    $0x8,%r8d
    751f:	49 89 c2             	mov    %rax,%r10
    7522:	49 29 f2             	sub    %rsi,%r10
    7525:	4d 0f af d1          	imul   %r9,%r10
    7529:	49 0f af c0          	imul   %r8,%rax
    752d:	49 39 c2             	cmp    %rax,%r10
    7530:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    7536:	41 0f 96 c2          	setbe  %r10b
    753a:	49 83 ca 02          	or     $0x2,%r10
    753e:	4c 89 51 10          	mov    %r10,0x10(%rcx)
    7542:	4c 89 19             	mov    %r11,(%rcx)
    7545:	4c 89 59 08          	mov    %r11,0x8(%rcx)
    7549:	4c 31 d7             	xor    %r10,%rdi
    754c:	48 21 d7             	and    %rdx,%rdi
    754f:	48 85 ff             	test   %rdi,%rdi
    7552:	0f 85 0c 00 00 00    	jne    0x7564
    7558:	4c 89 95 e8 fd ff ff 	mov    %r10,-0x218(%rbp)
    755f:	e9 1d 00 00 00       	jmp    0x7581
    7564:	4c 89 d7             	mov    %r10,%rdi
    7567:	4c 89 95 e0 fd ff ff 	mov    %r10,-0x220(%rbp)
    756e:	e8 3d 8b ff ff       	call   0xb0
    7573:	48 8b 85 e0 fd ff ff 	mov    -0x220(%rbp),%rax
    757a:	48 89 85 e8 fd ff ff 	mov    %rax,-0x218(%rbp)
    7581:	48 8b 85 f0 fd ff ff 	mov    -0x210(%rbp),%rax
    7588:	48 83 e0 1f          	and    $0x1f,%rax
    758c:	31 c9                	xor    %ecx,%ecx
    758e:	48 39 c8             	cmp    %rcx,%rax
    7591:	b8 00 00 00 00       	mov    $0x0,%eax
    7596:	0f 94 c0             	sete   %al
    7599:	48 8b 95 e8 fd ff ff 	mov    -0x218(%rbp),%rdx
    75a0:	48 89 d6             	mov    %rdx,%rsi
    75a3:	48 83 e6 02          	and    $0x2,%rsi
    75a7:	48 39 ce             	cmp    %rcx,%rsi
    75aa:	be 00 00 00 00       	mov    $0x0,%esi
    75af:	40 0f 94 c6          	sete   %sil
    75b3:	48 09 c6             	or     %rax,%rsi
    75b6:	b8 01 00 00 00       	mov    $0x1,%eax
    75bb:	48 21 c2             	and    %rax,%rdx
    75be:	48 39 ca             	cmp    %rcx,%rdx
    75c1:	ba 00 00 00 00       	mov    $0x0,%edx
    75c6:	0f 94 c2             	sete   %dl
    75c9:	48 09 f2             	or     %rsi,%rdx
    75cc:	48 89 95 00 fe ff ff 	mov    %rdx,-0x200(%rbp)
    75d3:	48 8b 95 f8 fd ff ff 	mov    -0x208(%rbp),%rdx
    75da:	48 89 95 10 fe ff ff 	mov    %rdx,-0x1f0(%rbp)
    75e1:	48 89 b5 08 fe ff ff 	mov    %rsi,-0x1f8(%rbp)
    75e8:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
    75ec:	48 8b 08             	mov    (%rax),%rcx
    75ef:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    75f3:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
    75f7:	31 d2                	xor    %edx,%edx
    75f9:	48 8d b4 11 40 fd ff 	lea    -0x2c0(%rcx,%rdx,1),%rsi
    7600:	ff 
    7601:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7605:	48 8b 70 50          	mov    0x50(%rax),%rsi
    7609:	48 bf 01 00 00 00 00 	movabs $0x4000000000001,%rdi
    7610:	00 04 00 
    7613:	48 29 fe             	sub    %rdi,%rsi
    7616:	48 39 ce             	cmp    %rcx,%rsi
    7619:	0f 8d 13 00 00 00    	jge    0x7632
    761f:	48 89 b5 f8 fd ff ff 	mov    %rsi,-0x208(%rbp)
    7626:	48 89 8d e8 fd ff ff 	mov    %rcx,-0x218(%rbp)
    762d:	e9 54 00 00 00       	jmp    0x7686
    7632:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    7637:	31 f6                	xor    %esi,%esi
    7639:	bf 06 00 00 00       	mov    $0x6,%edi
    763e:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    7644:	48 89 c7             	mov    %rax,%rdi
    7647:	48 89 ce             	mov    %rcx,%rsi
    764a:	31 d2                	xor    %edx,%edx
    764c:	b9 06 00 00 00       	mov    $0x6,%ecx
    7651:	e8 ca 8a ff ff       	call   0x120
    7656:	48 83 f8 00          	cmp    $0x0,%rax
    765a:	0f 8d 0b 00 00 00    	jge    0x766b
    7660:	41 bd 80 00 00 00    	mov    $0x80,%r13d
    7666:	e9 64 2d 00 00       	jmp    0xa3cf
    766b:	48 85 c0             	test   %rax,%rax
    766e:	0f 84 6e 2d 00 00    	je     0xa3e2
    7674:	31 c0                	xor    %eax,%eax
    7676:	48 89 85 f8 fd ff ff 	mov    %rax,-0x208(%rbp)
    767d:	31 c0                	xor    %eax,%eax
    767f:	48 89 85 e8 fd ff ff 	mov    %rax,-0x218(%rbp)
    7686:	48 8b 85 f8 fd ff ff 	mov    -0x208(%rbp),%rax
    768d:	48 89 c1             	mov    %rax,%rcx
    7690:	48 81 c1 00 01 00 00 	add    $0x100,%rcx
    7697:	48 8b 95 e8 fd ff ff 	mov    -0x218(%rbp),%rdx
    769e:	48 39 d1             	cmp    %rdx,%rcx
    76a1:	be 00 00 00 00       	mov    $0x0,%esi
    76a6:	40 0f 9c c6          	setl   %sil
    76aa:	48 85 f6             	test   %rsi,%rsi
    76ad:	48 0f 44 ca          	cmove  %rdx,%rcx
    76b1:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
    76b5:	48 8b 32             	mov    (%rdx),%rsi
    76b8:	48 8b 7e 28          	mov    0x28(%rsi),%rdi
    76bc:	48 8b 77 08          	mov    0x8(%rdi),%rsi
    76c0:	31 ff                	xor    %edi,%edi
    76c2:	4c 8d 84 3e 40 fd ff 	lea    -0x2c0(%rsi,%rdi,1),%r8
    76c9:	ff 
    76ca:	49 8b 70 10          	mov    0x10(%r8),%rsi
    76ce:	4d 8b 48 18          	mov    0x18(%r8),%r9
    76d2:	49 83 fe 05          	cmp    $0x5,%r14
    76d6:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    76dc:	41 0f 94 c0          	sete   %r8b
    76e0:	49 83 fe 02          	cmp    $0x2,%r14
    76e4:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    76ea:	41 0f 94 c2          	sete   %r10b
    76ee:	4d 09 d0             	or     %r10,%r8
    76f1:	4d 85 c0             	test   %r8,%r8
    76f4:	48 89 8d e8 fd ff ff 	mov    %rcx,-0x218(%rbp)
    76fb:	48 89 b5 f0 fd ff ff 	mov    %rsi,-0x210(%rbp)
    7702:	4c 89 8d e0 fd ff ff 	mov    %r9,-0x220(%rbp)
    7709:	0f 84 b0 0b 00 00    	je     0x82bf
    770f:	49 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%r8
    7716:	82 28 52 
    7719:	45 31 d2             	xor    %r10d,%r10d
    771c:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
    7723:	48 89 bd d0 fd ff ff 	mov    %rdi,-0x230(%rbp)
    772a:	48 89 bd c8 fd ff ff 	mov    %rdi,-0x238(%rbp)
    7731:	48 89 bd c0 fd ff ff 	mov    %rdi,-0x240(%rbp)
    7738:	4c 89 85 b8 fd ff ff 	mov    %r8,-0x248(%rbp)
    773f:	48 89 bd b0 fd ff ff 	mov    %rdi,-0x250(%rbp)
    7746:	48 89 bd a8 fd ff ff 	mov    %rdi,-0x258(%rbp)
    774d:	4c 89 95 a0 fd ff ff 	mov    %r10,-0x260(%rbp)
    7754:	48 89 bd 98 fd ff ff 	mov    %rdi,-0x268(%rbp)
    775b:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
    7762:	48 8b 8d e8 fd ff ff 	mov    -0x218(%rbp),%rcx
    7769:	48 39 c8             	cmp    %rcx,%rax
    776c:	0f 8d 32 07 00 00    	jge    0x7ea4
    7772:	48 8b 95 e0 fd ff ff 	mov    -0x220(%rbp),%rdx
    7779:	48 8d 34 c2          	lea    (%rdx,%rax,8),%rsi
    777d:	48 8b 3e             	mov    (%rsi),%rdi
    7780:	48 8b b5 f0 fd ff ff 	mov    -0x210(%rbp),%rsi
    7787:	49 89 f0             	mov    %rsi,%r8
    778a:	49 01 f8             	add    %rdi,%r8
    778d:	49 8b 78 10          	mov    0x10(%r8),%rdi
    7791:	4d 8b 48 08          	mov    0x8(%r8),%r9
    7795:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    779b:	4d 89 cb             	mov    %r9,%r11
    779e:	4d 21 d3             	and    %r10,%r11
    77a1:	49 8b 40 18          	mov    0x18(%r8),%rax
    77a5:	49 d1 e9             	shr    $1,%r9
    77a8:	4d 21 d1             	and    %r10,%r9
    77ab:	45 31 c0             	xor    %r8d,%r8d
    77ae:	4d 39 c1             	cmp    %r8,%r9
    77b1:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    77b7:	41 0f 95 c1          	setne  %r9b
    77bb:	4d 85 db             	test   %r11,%r11
    77be:	0f 85 c2 06 00 00    	jne    0x7e86
    77c4:	48 63 ff             	movslq %edi,%rdi
    77c7:	49 89 fb             	mov    %rdi,%r11
    77ca:	49 83 fe 05          	cmp    $0x5,%r14
    77ce:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
    77d5:	4c 89 8d 88 fd ff ff 	mov    %r9,-0x278(%rbp)
    77dc:	0f 85 84 00 00 00    	jne    0x7866
    77e2:	48 8b bd 38 fe ff ff 	mov    -0x1c8(%rbp),%rdi
    77e9:	4c 89 d8             	mov    %r11,%rax
    77ec:	48 29 f8             	sub    %rdi,%rax
    77ef:	4c 8b 8d 30 fe ff ff 	mov    -0x1d0(%rbp),%r9
    77f6:	4c 39 c8             	cmp    %r9,%rax
    77f9:	ba 00 00 00 00       	mov    $0x0,%edx
    77fe:	0f 92 c2             	setb   %dl
    7801:	48 85 d2             	test   %rdx,%rdx
    7804:	49 0f 44 c0          	cmove  %r8,%rax
    7808:	48 89 c6             	mov    %rax,%rsi
    780b:	48 c1 ee 06          	shr    $0x6,%rsi
    780f:	48 83 e0 3f          	and    $0x3f,%rax
    7813:	49 8d 3c f7          	lea    (%r15,%rsi,8),%rdi
    7817:	4c 8b 0f             	mov    (%rdi),%r9
    781a:	48 89 c1             	mov    %rax,%rcx
    781d:	49 d3 e9             	shr    %cl,%r9
    7820:	4d 21 d1             	and    %r10,%r9
    7823:	4c 89 cf             	mov    %r9,%rdi
    7826:	48 21 d7             	and    %rdx,%rdi
    7829:	48 8b 8d 28 fe ff ff 	mov    -0x1d8(%rbp),%rcx
    7830:	48 8d 14 f1          	lea    (%rcx,%rsi,8),%rdx
    7834:	4c 8b 0a             	mov    (%rdx),%r9
    7837:	48 89 c1             	mov    %rax,%rcx
    783a:	49 d3 e9             	shr    %cl,%r9
    783d:	4d 21 d1             	and    %r10,%r9
    7840:	48 8b 8d 48 fe ff ff 	mov    -0x1b8(%rbp),%rcx
    7847:	48 8d 14 f1          	lea    (%rcx,%rsi,8),%rdx
    784b:	48 8b 32             	mov    (%rdx),%rsi
    784e:	48 89 c1             	mov    %rax,%rcx
    7851:	48 d3 ee             	shr    %cl,%rsi
    7854:	4c 21 d6             	and    %r10,%rsi
    7857:	4c 89 8d 80 fd ff ff 	mov    %r9,-0x280(%rbp)
    785e:	49 89 f1             	mov    %rsi,%r9
    7861:	e9 7c 00 00 00       	jmp    0x78e2
    7866:	48 8b 85 38 fe ff ff 	mov    -0x1c8(%rbp),%rax
    786d:	49 29 c3             	sub    %rax,%r11
    7870:	48 8b 8d 30 fe ff ff 	mov    -0x1d0(%rbp),%rcx
    7877:	49 39 cb             	cmp    %rcx,%r11
    787a:	ba 00 00 00 00       	mov    $0x0,%edx
    787f:	0f 92 c2             	setb   %dl
    7882:	31 f6                	xor    %esi,%esi
    7884:	48 85 d2             	test   %rdx,%rdx
    7887:	4c 0f 44 de          	cmove  %rsi,%r11
    788b:	4d 89 d8             	mov    %r11,%r8
    788e:	49 c1 e8 06          	shr    $0x6,%r8
    7892:	4d 89 da             	mov    %r11,%r10
    7895:	49 83 e2 3f          	and    $0x3f,%r10
    7899:	4b 8d 04 c7          	lea    (%r15,%r8,8),%rax
    789d:	4c 8b 00             	mov    (%rax),%r8
    78a0:	4c 89 d1             	mov    %r10,%rcx
    78a3:	49 d3 e8             	shr    %cl,%r8
    78a6:	b8 01 00 00 00       	mov    $0x1,%eax
    78ab:	49 21 c0             	and    %rax,%r8
    78ae:	49 21 d0             	and    %rdx,%r8
    78b1:	b9 10 00 00 00       	mov    $0x10,%ecx
    78b6:	4c 0f af d9          	imul   %rcx,%r11
    78ba:	48 8b 8d 40 fe ff ff 	mov    -0x1c0(%rbp),%rcx
    78c1:	4a 8d 54 19 f8       	lea    -0x8(%rcx,%r11,1),%rdx
    78c6:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    78ca:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    78ce:	49 c1 ea 20          	shr    $0x20,%r10
    78d2:	49 21 c2             	and    %rax,%r10
    78d5:	4c 89 c7             	mov    %r8,%rdi
    78d8:	4c 89 9d 80 fd ff ff 	mov    %r11,-0x280(%rbp)
    78df:	4d 89 d1             	mov    %r10,%r9
    78e2:	48 85 ff             	test   %rdi,%rdi
    78e5:	0f 84 9b 05 00 00    	je     0x7e86
    78eb:	49 83 f9 00          	cmp    $0x0,%r9
    78ef:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    78f5:	41 0f 95 c1          	setne  %r9b
    78f9:	48 8b 85 d0 fd ff ff 	mov    -0x230(%rbp),%rax
    7900:	48 89 c1             	mov    %rax,%rcx
    7903:	48 83 c1 01          	add    $0x1,%rcx
    7907:	48 8b 95 80 fd ff ff 	mov    -0x280(%rbp),%rdx
    790e:	48 63 d2             	movslq %edx,%rdx
    7911:	31 f6                	xor    %esi,%esi
    7913:	4d 85 c9             	test   %r9,%r9
    7916:	48 0f 44 f2          	cmove  %rdx,%rsi
    791a:	48 8b 95 c8 fd ff ff 	mov    -0x238(%rbp),%rdx
    7921:	48 39 f2             	cmp    %rsi,%rdx
    7924:	bf 00 00 00 00       	mov    $0x0,%edi
    7929:	40 0f 94 c7          	sete   %dil
    792d:	4c 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%r8
    7934:	4d 39 c8             	cmp    %r9,%r8
    7937:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    793d:	41 0f 94 c2          	sete   %r10b
    7941:	4c 21 d7             	and    %r10,%rdi
    7944:	48 85 ff             	test   %rdi,%rdi
    7947:	48 89 8d 80 fd ff ff 	mov    %rcx,-0x280(%rbp)
    794e:	48 89 b5 78 fd ff ff 	mov    %rsi,-0x288(%rbp)
    7955:	4c 89 8d 70 fd ff ff 	mov    %r9,-0x290(%rbp)
    795c:	0f 84 69 00 00 00    	je     0x79cb
    7962:	48 8b bd a8 fd ff ff 	mov    -0x258(%rbp),%rdi
    7969:	49 89 fa             	mov    %rdi,%r10
    796c:	49 83 c2 01          	add    $0x1,%r10
    7970:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    7976:	48 8b b5 88 fd ff ff 	mov    -0x278(%rbp),%rsi
    797d:	49 89 f1             	mov    %rsi,%r9
    7980:	4d 31 d9             	xor    %r11,%r9
    7983:	45 31 db             	xor    %r11d,%r11d
    7986:	48 8b b5 90 fd ff ff 	mov    -0x270(%rbp),%rsi
    798d:	48 89 f1             	mov    %rsi,%rcx
    7990:	4d 85 c9             	test   %r9,%r9
    7993:	49 0f 44 cb          	cmove  %r11,%rcx
    7997:	4c 8b 9d 98 fd ff ff 	mov    -0x268(%rbp),%r11
    799e:	4c 89 de             	mov    %r11,%rsi
    79a1:	4c 01 ce             	add    %r9,%rsi
    79a4:	4c 8b 8d a0 fd ff ff 	mov    -0x260(%rbp),%r9
    79ab:	4c 89 ca             	mov    %r9,%rdx
    79ae:	48 01 ca             	add    %rcx,%rdx
    79b1:	4c 89 95 a8 fd ff ff 	mov    %r10,-0x258(%rbp)
    79b8:	48 89 95 a0 fd ff ff 	mov    %rdx,-0x260(%rbp)
    79bf:	48 89 b5 98 fd ff ff 	mov    %rsi,-0x268(%rbp)
    79c6:	e9 a1 04 00 00       	jmp    0x7e6c
    79cb:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
    79d2:	48 85 c0             	test   %rax,%rax
    79d5:	0f 84 fb 03 00 00    	je     0x7dd6
    79db:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    79e2:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    79e6:	48 85 d2             	test   %rdx,%rdx
    79e9:	0f 84 3d 01 00 00    	je     0x7b2c
    79ef:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    79f3:	be 40 00 00 00       	mov    $0x40,%esi
    79f8:	48 29 d6             	sub    %rdx,%rsi
    79fb:	48 8b bd b8 fd ff ff 	mov    -0x248(%rbp),%rdi
    7a02:	48 89 f1             	mov    %rsi,%rcx
    7a05:	49 89 f8             	mov    %rdi,%r8
    7a08:	49 d3 e8             	shr    %cl,%r8
    7a0b:	31 c9                	xor    %ecx,%ecx
    7a0d:	48 39 ca             	cmp    %rcx,%rdx
    7a10:	ba 00 00 00 00       	mov    $0x0,%edx
    7a15:	0f 94 c2             	sete   %dl
    7a18:	48 85 d2             	test   %rdx,%rdx
    7a1b:	49 0f 44 c8          	cmove  %r8,%rcx
    7a1f:	48 8b 95 58 fe ff ff 	mov    -0x1a8(%rbp),%rdx
    7a26:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    7a2a:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    7a2e:	49 8b 30             	mov    (%r8),%rsi
    7a31:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    7a38:	00 28 00 
    7a3b:	4c 39 ce             	cmp    %r9,%rsi
    7a3e:	4c 89 85 68 fd ff ff 	mov    %r8,-0x298(%rbp)
    7a45:	0f 82 0c 00 00 00    	jb     0x7a57
    7a4b:	48 89 b5 60 fd ff ff 	mov    %rsi,-0x2a0(%rbp)
    7a52:	e9 47 00 00 00       	jmp    0x7a9e
    7a57:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    7a5b:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    7a5f:	48 89 b5 58 fd ff ff 	mov    %rsi,-0x2a8(%rbp)
    7a66:	48 89 d6             	mov    %rdx,%rsi
    7a69:	48 89 ca             	mov    %rcx,%rdx
    7a6c:	48 8b 8d 58 fd ff ff 	mov    -0x2a8(%rbp),%rcx
    7a73:	e8 68 86 ff ff       	call   0xe0
    7a78:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    7a7f:	31 d2                	xor    %edx,%edx
    7a81:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    7a85:	48 83 f8 00          	cmp    $0x0,%rax
    7a89:	0f 8f 08 00 00 00    	jg     0x7a97
    7a8f:	49 89 c4             	mov    %rax,%r12
    7a92:	e9 b3 29 00 00       	jmp    0xa44a
    7a97:	48 89 85 60 fd ff ff 	mov    %rax,-0x2a0(%rbp)
    7a9e:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
    7aa5:	48 89 c1             	mov    %rax,%rcx
    7aa8:	48 83 c1 28          	add    $0x28,%rcx
    7aac:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    7ab3:	00 28 00 
    7ab6:	48 29 d1             	sub    %rdx,%rcx
    7ab9:	48 8b 95 68 fd ff ff 	mov    -0x298(%rbp),%rdx
    7ac0:	48 89 0a             	mov    %rcx,(%rdx)
    7ac3:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    7aca:	ff 00 00 
    7acd:	48 21 c8             	and    %rcx,%rax
    7ad0:	31 c9                	xor    %ecx,%ecx
    7ad2:	48 8b 95 c8 fd ff ff 	mov    -0x238(%rbp),%rdx
    7ad9:	48 89 10             	mov    %rdx,(%rax)
    7adc:	48 8b b5 c0 fd ff ff 	mov    -0x240(%rbp),%rsi
    7ae3:	48 89 70 08          	mov    %rsi,0x8(%rax)
    7ae7:	48 89 48 10          	mov    %rcx,0x10(%rax)
    7aeb:	48 89 48 18          	mov    %rcx,0x18(%rax)
    7aef:	48 89 48 20          	mov    %rcx,0x20(%rax)
    7af3:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    7afa:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    7afe:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    7b04:	4c 01 c7             	add    %r8,%rdi
    7b07:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    7b0b:	48 89 85 60 fd ff ff 	mov    %rax,-0x2a0(%rbp)
    7b12:	b8 01 00 00 00       	mov    $0x1,%eax
    7b17:	48 89 85 68 fd ff ff 	mov    %rax,-0x298(%rbp)
    7b1e:	31 c0                	xor    %eax,%eax
    7b20:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
    7b27:	e9 a4 01 00 00       	jmp    0x7cd0
    7b2c:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    7b33:	48 8b 70 10          	mov    0x10(%rax),%rsi
    7b37:	48 8b 48 18          	mov    0x18(%rax),%rcx
    7b3b:	48 89 ca             	mov    %rcx,%rdx
    7b3e:	f3 48 0f b8 d2       	popcnt %rdx,%rdx
    7b43:	bf 40 00 00 00       	mov    $0x40,%edi
    7b48:	48 29 d7             	sub    %rdx,%rdi
    7b4b:	48 89 8d 50 fd ff ff 	mov    %rcx,-0x2b0(%rbp)
    7b52:	4c 8b 85 b8 fd ff ff 	mov    -0x248(%rbp),%r8
    7b59:	48 89 f9             	mov    %rdi,%rcx
    7b5c:	4d 89 c1             	mov    %r8,%r9
    7b5f:	49 d3 e9             	shr    %cl,%r9
    7b62:	31 c9                	xor    %ecx,%ecx
    7b64:	48 39 ca             	cmp    %rcx,%rdx
    7b67:	ba 00 00 00 00       	mov    $0x0,%edx
    7b6c:	0f 94 c2             	sete   %dl
    7b6f:	48 85 d2             	test   %rdx,%rdx
    7b72:	49 0f 44 c9          	cmove  %r9,%rcx
    7b76:	ba 01 00 00 00       	mov    $0x1,%edx
    7b7b:	48 89 cf             	mov    %rcx,%rdi
    7b7e:	48 01 d7             	add    %rdx,%rdi
    7b81:	4c 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%r10
    7b88:	49 89 f9             	mov    %rdi,%r9
    7b8b:	4d 21 d1             	and    %r10,%r9
    7b8e:	bf 28 00 00 00       	mov    $0x28,%edi
    7b93:	48 0f af cf          	imul   %rdi,%rcx
    7b97:	48 8d 3c 0e          	lea    (%rsi,%rcx,1),%rdi
    7b9b:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    7b9f:	48 85 c9             	test   %rcx,%rcx
    7ba2:	0f 84 b2 00 00 00    	je     0x7c5a
    7ba8:	48 8b 0f             	mov    (%rdi),%rcx
    7bab:	4c 8b 57 08          	mov    0x8(%rdi),%r10
    7baf:	4c 8b 9d c8 fd ff ff 	mov    -0x238(%rbp),%r11
    7bb6:	49 39 cb             	cmp    %rcx,%r11
    7bb9:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    7bbf:	41 0f 94 c0          	sete   %r8b
    7bc3:	48 8b 8d c0 fd ff ff 	mov    -0x240(%rbp),%rcx
    7bca:	4c 39 d1             	cmp    %r10,%rcx
    7bcd:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    7bd3:	41 0f 94 c3          	sete   %r11b
    7bd7:	4d 21 d8             	and    %r11,%r8
    7bda:	4d 85 c0             	test   %r8,%r8
    7bdd:	0f 84 0c 00 00 00    	je     0x7bef
    7be3:	48 89 bd 60 fd ff ff 	mov    %rdi,-0x2a0(%rbp)
    7bea:	e9 54 00 00 00       	jmp    0x7c43
    7bef:	bf 28 00 00 00       	mov    $0x28,%edi
    7bf4:	4c 0f af cf          	imul   %rdi,%r9
    7bf8:	4a 8d 3c 0e          	lea    (%rsi,%r9,1),%rdi
    7bfc:	48 8b 77 10          	mov    0x10(%rdi),%rsi
    7c00:	48 85 f6             	test   %rsi,%rsi
    7c03:	0f 84 51 00 00 00    	je     0x7c5a
    7c09:	48 8b 37             	mov    (%rdi),%rsi
    7c0c:	4c 8b 47 08          	mov    0x8(%rdi),%r8
    7c10:	4c 8b 8d c8 fd ff ff 	mov    -0x238(%rbp),%r9
    7c17:	49 39 f1             	cmp    %rsi,%r9
    7c1a:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    7c20:	41 0f 94 c2          	sete   %r10b
    7c24:	4c 39 c1             	cmp    %r8,%rcx
    7c27:	be 00 00 00 00       	mov    $0x0,%esi
    7c2c:	40 0f 94 c6          	sete   %sil
    7c30:	49 21 f2             	and    %rsi,%r10
    7c33:	4d 85 d2             	test   %r10,%r10
    7c36:	0f 84 1e 00 00 00    	je     0x7c5a
    7c3c:	48 89 bd 60 fd ff ff 	mov    %rdi,-0x2a0(%rbp)
    7c43:	31 c0                	xor    %eax,%eax
    7c45:	48 89 85 68 fd ff ff 	mov    %rax,-0x298(%rbp)
    7c4c:	31 c0                	xor    %eax,%eax
    7c4e:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
    7c55:	e9 76 00 00 00       	jmp    0x7cd0
    7c5a:	48 8d 85 10 ff ff ff 	lea    -0xf0(%rbp),%rax
    7c61:	48 89 c1             	mov    %rax,%rcx
    7c64:	48 8b 95 c8 fd ff ff 	mov    -0x238(%rbp),%rdx
    7c6b:	48 89 11             	mov    %rdx,(%rcx)
    7c6e:	48 8b b5 c0 fd ff ff 	mov    -0x240(%rbp),%rsi
    7c75:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    7c79:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    7c7d:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
    7c84:	48 89 ca             	mov    %rcx,%rdx
    7c87:	e8 64 84 ff ff       	call   0xf0
    7c8c:	48 83 f8 00          	cmp    $0x0,%rax
    7c90:	0f 8d 08 00 00 00    	jge    0x7c9e
    7c96:	49 89 c4             	mov    %rax,%r12
    7c99:	e9 ac 27 00 00       	jmp    0xa44a
    7c9e:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    7ca5:	48 8b 11             	mov    (%rcx),%rdx
    7ca8:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    7cac:	48 83 e6 01          	and    $0x1,%rsi
    7cb0:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    7cb4:	48 89 85 60 fd ff ff 	mov    %rax,-0x2a0(%rbp)
    7cbb:	b8 01 00 00 00       	mov    $0x1,%eax
    7cc0:	48 89 85 68 fd ff ff 	mov    %rax,-0x298(%rbp)
    7cc7:	31 c0                	xor    %eax,%eax
    7cc9:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
    7cd0:	48 8b 85 68 fd ff ff 	mov    -0x298(%rbp),%rax
    7cd7:	48 85 c0             	test   %rax,%rax
    7cda:	0f 84 68 00 00 00    	je     0x7d48
    7ce0:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
    7ce7:	48 8b 8d a8 fd ff ff 	mov    -0x258(%rbp),%rcx
    7cee:	48 89 48 10          	mov    %rcx,0x10(%rax)
    7cf2:	31 d2                	xor    %edx,%edx
    7cf4:	48 39 d1             	cmp    %rdx,%rcx
    7cf7:	be 00 00 00 00       	mov    $0x0,%esi
    7cfc:	40 0f 95 c6          	setne  %sil
    7d00:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    7d04:	48 09 f7             	or     %rsi,%rdi
    7d07:	40 88 78 20          	mov    %dil,0x20(%rax)
    7d0b:	48 8b b5 a0 fd ff ff 	mov    -0x260(%rbp),%rsi
    7d12:	48 89 70 18          	mov    %rsi,0x18(%rax)
    7d16:	48 8b bd 98 fd ff ff 	mov    -0x268(%rbp),%rdi
    7d1d:	48 39 d7             	cmp    %rdx,%rdi
    7d20:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    7d26:	41 0f 95 c0          	setne  %r8b
    7d2a:	44 0f b6 48 20       	movzbl 0x20(%rax),%r9d
    7d2f:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    7d35:	4d 85 c0             	test   %r8,%r8
    7d38:	4c 0f 44 d2          	cmove  %rdx,%r10
    7d3c:	4d 09 d1             	or     %r10,%r9
    7d3f:	44 88 48 20          	mov    %r9b,0x20(%rax)
    7d43:	e9 8e 00 00 00       	jmp    0x7dd6
    7d48:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
    7d4f:	48 8b 48 10          	mov    0x10(%rax),%rcx
    7d53:	48 8b 95 a8 fd ff ff 	mov    -0x258(%rbp),%rdx
    7d5a:	48 01 d1             	add    %rdx,%rcx
    7d5d:	48 89 48 10          	mov    %rcx,0x10(%rax)
    7d61:	31 f6                	xor    %esi,%esi
    7d63:	48 39 f1             	cmp    %rsi,%rcx
    7d66:	b9 00 00 00 00       	mov    $0x0,%ecx
    7d6b:	0f 95 c1             	setne  %cl
    7d6e:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    7d72:	48 09 cf             	or     %rcx,%rdi
    7d75:	40 88 78 20          	mov    %dil,0x20(%rax)
    7d79:	48 8b 48 18          	mov    0x18(%rax),%rcx
    7d7d:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    7d81:	48 83 e7 02          	and    $0x2,%rdi
    7d85:	48 39 f7             	cmp    %rsi,%rdi
    7d88:	bf 00 00 00 00       	mov    $0x0,%edi
    7d8d:	40 0f 95 c7          	setne  %dil
    7d91:	45 31 c0             	xor    %r8d,%r8d
    7d94:	48 85 ff             	test   %rdi,%rdi
    7d97:	49 0f 44 c8          	cmove  %r8,%rcx
    7d9b:	4c 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%r8
    7da2:	4c 01 c7             	add    %r8,%rdi
    7da5:	4c 8b 8d a0 fd ff ff 	mov    -0x260(%rbp),%r9
    7dac:	4c 01 c9             	add    %r9,%rcx
    7daf:	48 89 48 18          	mov    %rcx,0x18(%rax)
    7db3:	48 39 f7             	cmp    %rsi,%rdi
    7db6:	bf 00 00 00 00       	mov    $0x0,%edi
    7dbb:	40 0f 95 c7          	setne  %dil
    7dbf:	0f b6 48 20          	movzbl 0x20(%rax),%ecx
    7dc3:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    7dc9:	48 85 ff             	test   %rdi,%rdi
    7dcc:	4c 0f 44 d6          	cmove  %rsi,%r10
    7dd0:	4c 09 d1             	or     %r10,%rcx
    7dd3:	88 48 20             	mov    %cl,0x20(%rax)
    7dd6:	b8 01 00 00 00       	mov    $0x1,%eax
    7ddb:	48 8b 8d 88 fd ff ff 	mov    -0x278(%rbp),%rcx
    7de2:	48 31 c1             	xor    %rax,%rcx
    7de5:	31 c0                	xor    %eax,%eax
    7de7:	48 8b 95 90 fd ff ff 	mov    -0x270(%rbp),%rdx
    7dee:	48 85 c9             	test   %rcx,%rcx
    7df1:	48 0f 44 d0          	cmove  %rax,%rdx
    7df5:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    7dfc:	79 37 9e 
    7dff:	48 be 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%rsi
    7e06:	79 37 9e 
    7e09:	48 8b bd 78 fd ff ff 	mov    -0x288(%rbp),%rdi
    7e10:	48 31 fe             	xor    %rdi,%rsi
    7e13:	48 0f af f0          	imul   %rax,%rsi
    7e17:	49 89 f0             	mov    %rsi,%r8
    7e1a:	49 c1 e8 1d          	shr    $0x1d,%r8
    7e1e:	4c 31 c6             	xor    %r8,%rsi
    7e21:	4c 8b 85 70 fd ff ff 	mov    -0x290(%rbp),%r8
    7e28:	4c 31 c6             	xor    %r8,%rsi
    7e2b:	48 0f af f0          	imul   %rax,%rsi
    7e2f:	49 89 f1             	mov    %rsi,%r9
    7e32:	49 c1 e9 1d          	shr    $0x1d,%r9
    7e36:	4c 31 ce             	xor    %r9,%rsi
    7e39:	48 0f af f0          	imul   %rax,%rsi
    7e3d:	48 89 bd c8 fd ff ff 	mov    %rdi,-0x238(%rbp)
    7e44:	4c 89 85 c0 fd ff ff 	mov    %r8,-0x240(%rbp)
    7e4b:	48 89 b5 b8 fd ff ff 	mov    %rsi,-0x248(%rbp)
    7e52:	b8 01 00 00 00       	mov    $0x1,%eax
    7e57:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
    7e5e:	48 89 95 a0 fd ff ff 	mov    %rdx,-0x260(%rbp)
    7e65:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
    7e6c:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
    7e73:	48 89 85 d0 fd ff ff 	mov    %rax,-0x230(%rbp)
    7e7a:	b8 01 00 00 00       	mov    $0x1,%eax
    7e7f:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
    7e86:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
    7e8d:	b9 01 00 00 00       	mov    $0x1,%ecx
    7e92:	48 89 c2             	mov    %rax,%rdx
    7e95:	48 01 ca             	add    %rcx,%rdx
    7e98:	48 89 95 d8 fd ff ff 	mov    %rdx,-0x228(%rbp)
    7e9f:	e9 b7 f8 ff ff       	jmp    0x775b
    7ea4:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
    7eab:	48 85 c0             	test   %rax,%rax
    7eae:	0f 84 f8 03 00 00    	je     0x82ac
    7eb4:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    7ebb:	48 8b 48 68          	mov    0x68(%rax),%rcx
    7ebf:	48 85 c9             	test   %rcx,%rcx
    7ec2:	0f 84 44 01 00 00    	je     0x800c
    7ec8:	48 8b 48 38          	mov    0x38(%rax),%rcx
    7ecc:	ba 40 00 00 00       	mov    $0x40,%edx
    7ed1:	48 29 ca             	sub    %rcx,%rdx
    7ed4:	48 89 8d b0 fd ff ff 	mov    %rcx,-0x250(%rbp)
    7edb:	48 8b b5 b8 fd ff ff 	mov    -0x248(%rbp),%rsi
    7ee2:	48 89 d1             	mov    %rdx,%rcx
    7ee5:	48 89 f7             	mov    %rsi,%rdi
    7ee8:	48 d3 ef             	shr    %cl,%rdi
    7eeb:	31 c9                	xor    %ecx,%ecx
    7eed:	48 8b 95 b0 fd ff ff 	mov    -0x250(%rbp),%rdx
    7ef4:	48 39 ca             	cmp    %rcx,%rdx
    7ef7:	ba 00 00 00 00       	mov    $0x0,%edx
    7efc:	0f 94 c2             	sete   %dl
    7eff:	48 85 d2             	test   %rdx,%rdx
    7f02:	48 0f 44 cf          	cmove  %rdi,%rcx
    7f06:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7f0a:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    7f0e:	48 8b 17             	mov    (%rdi),%rdx
    7f11:	49 b8 00 00 00 00 00 	movabs $0x28000000000000,%r8
    7f18:	00 28 00 
    7f1b:	4c 39 c2             	cmp    %r8,%rdx
    7f1e:	48 89 bd b0 fd ff ff 	mov    %rdi,-0x250(%rbp)
    7f25:	0f 82 0c 00 00 00    	jb     0x7f37
    7f2b:	48 89 95 d8 fd ff ff 	mov    %rdx,-0x228(%rbp)
    7f32:	e9 47 00 00 00       	jmp    0x7f7e
    7f37:	48 8b 50 60          	mov    0x60(%rax),%rdx
    7f3b:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    7f3f:	48 89 c6             	mov    %rax,%rsi
    7f42:	48 89 95 80 fd ff ff 	mov    %rdx,-0x280(%rbp)
    7f49:	48 89 ca             	mov    %rcx,%rdx
    7f4c:	48 8b 8d 80 fd ff ff 	mov    -0x280(%rbp),%rcx
    7f53:	e8 88 81 ff ff       	call   0xe0
    7f58:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    7f5f:	31 d2                	xor    %edx,%edx
    7f61:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    7f65:	48 83 f8 00          	cmp    $0x0,%rax
    7f69:	0f 8f 08 00 00 00    	jg     0x7f77
    7f6f:	49 89 c4             	mov    %rax,%r12
    7f72:	e9 d3 24 00 00       	jmp    0xa44a
    7f77:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
    7f7e:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
    7f85:	48 89 c1             	mov    %rax,%rcx
    7f88:	48 83 c1 28          	add    $0x28,%rcx
    7f8c:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    7f93:	00 28 00 
    7f96:	48 29 d1             	sub    %rdx,%rcx
    7f99:	48 8b 95 b0 fd ff ff 	mov    -0x250(%rbp),%rdx
    7fa0:	48 89 0a             	mov    %rcx,(%rdx)
    7fa3:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    7faa:	ff 00 00 
    7fad:	48 21 c8             	and    %rcx,%rax
    7fb0:	31 c9                	xor    %ecx,%ecx
    7fb2:	48 8b 95 c8 fd ff ff 	mov    -0x238(%rbp),%rdx
    7fb9:	48 89 10             	mov    %rdx,(%rax)
    7fbc:	48 8b b5 c0 fd ff ff 	mov    -0x240(%rbp),%rsi
    7fc3:	48 89 70 08          	mov    %rsi,0x8(%rax)
    7fc7:	48 89 48 10          	mov    %rcx,0x10(%rax)
    7fcb:	48 89 48 18          	mov    %rcx,0x18(%rax)
    7fcf:	48 89 48 20          	mov    %rcx,0x20(%rax)
    7fd3:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    7fda:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    7fde:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    7fe4:	4c 01 c7             	add    %r8,%rdi
    7fe7:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    7feb:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
    7ff2:	b8 01 00 00 00       	mov    $0x1,%eax
    7ff7:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
    7ffe:	31 c0                	xor    %eax,%eax
    8000:	48 89 85 80 fd ff ff 	mov    %rax,-0x280(%rbp)
    8007:	e9 9c 01 00 00       	jmp    0x81a8
    800c:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    8013:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8017:	48 8b 50 18          	mov    0x18(%rax),%rdx
    801b:	48 89 d6             	mov    %rdx,%rsi
    801e:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    8023:	bf 40 00 00 00       	mov    $0x40,%edi
    8028:	48 29 f7             	sub    %rsi,%rdi
    802b:	48 89 8d 70 fd ff ff 	mov    %rcx,-0x290(%rbp)
    8032:	4c 8b 85 b8 fd ff ff 	mov    -0x248(%rbp),%r8
    8039:	48 89 f9             	mov    %rdi,%rcx
    803c:	49 d3 e8             	shr    %cl,%r8
    803f:	31 c9                	xor    %ecx,%ecx
    8041:	48 39 ce             	cmp    %rcx,%rsi
    8044:	be 00 00 00 00       	mov    $0x0,%esi
    8049:	40 0f 94 c6          	sete   %sil
    804d:	48 85 f6             	test   %rsi,%rsi
    8050:	49 0f 44 c8          	cmove  %r8,%rcx
    8054:	be 01 00 00 00       	mov    $0x1,%esi
    8059:	48 89 cf             	mov    %rcx,%rdi
    805c:	48 01 f7             	add    %rsi,%rdi
    805f:	48 21 d7             	and    %rdx,%rdi
    8062:	ba 28 00 00 00       	mov    $0x28,%edx
    8067:	48 0f af ca          	imul   %rdx,%rcx
    806b:	48 8b 95 70 fd ff ff 	mov    -0x290(%rbp),%rdx
    8072:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
    8076:	49 8b 48 10          	mov    0x10(%r8),%rcx
    807a:	48 85 c9             	test   %rcx,%rcx
    807d:	0f 84 af 00 00 00    	je     0x8132
    8083:	49 8b 08             	mov    (%r8),%rcx
    8086:	4d 8b 48 08          	mov    0x8(%r8),%r9
    808a:	4c 8b 95 c8 fd ff ff 	mov    -0x238(%rbp),%r10
    8091:	49 39 ca             	cmp    %rcx,%r10
    8094:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    809a:	41 0f 94 c3          	sete   %r11b
    809e:	48 8b 8d c0 fd ff ff 	mov    -0x240(%rbp),%rcx
    80a5:	4c 39 c9             	cmp    %r9,%rcx
    80a8:	ba 00 00 00 00       	mov    $0x0,%edx
    80ad:	0f 94 c2             	sete   %dl
    80b0:	49 21 d3             	and    %rdx,%r11
    80b3:	4d 85 db             	test   %r11,%r11
    80b6:	0f 84 0c 00 00 00    	je     0x80c8
    80bc:	4c 89 85 d8 fd ff ff 	mov    %r8,-0x228(%rbp)
    80c3:	e9 53 00 00 00       	jmp    0x811b
    80c8:	ba 28 00 00 00       	mov    $0x28,%edx
    80cd:	48 0f af fa          	imul   %rdx,%rdi
    80d1:	48 8b 95 70 fd ff ff 	mov    -0x290(%rbp),%rdx
    80d8:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    80dc:	49 8b 50 10          	mov    0x10(%r8),%rdx
    80e0:	48 85 d2             	test   %rdx,%rdx
    80e3:	0f 84 49 00 00 00    	je     0x8132
    80e9:	49 8b 10             	mov    (%r8),%rdx
    80ec:	49 8b 78 08          	mov    0x8(%r8),%rdi
    80f0:	49 39 d2             	cmp    %rdx,%r10
    80f3:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    80f9:	41 0f 94 c1          	sete   %r9b
    80fd:	48 39 f9             	cmp    %rdi,%rcx
    8100:	ba 00 00 00 00       	mov    $0x0,%edx
    8105:	0f 94 c2             	sete   %dl
    8108:	49 21 d1             	and    %rdx,%r9
    810b:	4d 85 c9             	test   %r9,%r9
    810e:	0f 84 1e 00 00 00    	je     0x8132
    8114:	4c 89 85 d8 fd ff ff 	mov    %r8,-0x228(%rbp)
    811b:	31 c0                	xor    %eax,%eax
    811d:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
    8124:	31 c0                	xor    %eax,%eax
    8126:	48 89 85 80 fd ff ff 	mov    %rax,-0x280(%rbp)
    812d:	e9 76 00 00 00       	jmp    0x81a8
    8132:	48 8d 85 00 ff ff ff 	lea    -0x100(%rbp),%rax
    8139:	48 89 c1             	mov    %rax,%rcx
    813c:	48 8b 95 c8 fd ff ff 	mov    -0x238(%rbp),%rdx
    8143:	48 89 11             	mov    %rdx,(%rcx)
    8146:	48 8b 95 c0 fd ff ff 	mov    -0x240(%rbp),%rdx
    814d:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    8151:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    8155:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
    815c:	48 89 ca             	mov    %rcx,%rdx
    815f:	e8 8c 7f ff ff       	call   0xf0
    8164:	48 83 f8 00          	cmp    $0x0,%rax
    8168:	0f 8d 08 00 00 00    	jge    0x8176
    816e:	49 89 c4             	mov    %rax,%r12
    8171:	e9 d4 22 00 00       	jmp    0xa44a
    8176:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    817d:	48 8b 11             	mov    (%rcx),%rdx
    8180:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    8184:	48 83 e6 01          	and    $0x1,%rsi
    8188:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    818c:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
    8193:	b8 01 00 00 00       	mov    $0x1,%eax
    8198:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
    819f:	31 c0                	xor    %eax,%eax
    81a1:	48 89 85 80 fd ff ff 	mov    %rax,-0x280(%rbp)
    81a8:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
    81af:	48 85 c0             	test   %rax,%rax
    81b2:	0f 84 68 00 00 00    	je     0x8220
    81b8:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
    81bf:	48 8b 8d a8 fd ff ff 	mov    -0x258(%rbp),%rcx
    81c6:	48 89 48 10          	mov    %rcx,0x10(%rax)
    81ca:	31 d2                	xor    %edx,%edx
    81cc:	48 39 d1             	cmp    %rdx,%rcx
    81cf:	be 00 00 00 00       	mov    $0x0,%esi
    81d4:	40 0f 95 c6          	setne  %sil
    81d8:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    81dc:	48 09 f7             	or     %rsi,%rdi
    81df:	40 88 78 20          	mov    %dil,0x20(%rax)
    81e3:	48 8b b5 a0 fd ff ff 	mov    -0x260(%rbp),%rsi
    81ea:	48 89 70 18          	mov    %rsi,0x18(%rax)
    81ee:	48 8b bd 98 fd ff ff 	mov    -0x268(%rbp),%rdi
    81f5:	48 39 d7             	cmp    %rdx,%rdi
    81f8:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    81fe:	41 0f 95 c0          	setne  %r8b
    8202:	44 0f b6 48 20       	movzbl 0x20(%rax),%r9d
    8207:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    820d:	4d 85 c0             	test   %r8,%r8
    8210:	4c 0f 44 d2          	cmove  %rdx,%r10
    8214:	4d 09 d1             	or     %r10,%r9
    8217:	44 88 48 20          	mov    %r9b,0x20(%rax)
    821b:	e9 8c 00 00 00       	jmp    0x82ac
    8220:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
    8227:	48 8b 48 10          	mov    0x10(%rax),%rcx
    822b:	48 8b 95 a8 fd ff ff 	mov    -0x258(%rbp),%rdx
    8232:	48 01 d1             	add    %rdx,%rcx
    8235:	48 89 48 10          	mov    %rcx,0x10(%rax)
    8239:	31 d2                	xor    %edx,%edx
    823b:	48 39 d1             	cmp    %rdx,%rcx
    823e:	b9 00 00 00 00       	mov    $0x0,%ecx
    8243:	0f 95 c1             	setne  %cl
    8246:	0f b6 70 20          	movzbl 0x20(%rax),%esi
    824a:	48 09 ce             	or     %rcx,%rsi
    824d:	40 88 70 20          	mov    %sil,0x20(%rax)
    8251:	48 8b 48 18          	mov    0x18(%rax),%rcx
    8255:	0f b6 70 20          	movzbl 0x20(%rax),%esi
    8259:	48 83 e6 02          	and    $0x2,%rsi
    825d:	48 39 d6             	cmp    %rdx,%rsi
    8260:	be 00 00 00 00       	mov    $0x0,%esi
    8265:	40 0f 95 c6          	setne  %sil
    8269:	31 ff                	xor    %edi,%edi
    826b:	48 85 f6             	test   %rsi,%rsi
    826e:	48 0f 44 cf          	cmove  %rdi,%rcx
    8272:	48 8b bd 98 fd ff ff 	mov    -0x268(%rbp),%rdi
    8279:	48 01 fe             	add    %rdi,%rsi
    827c:	48 8b bd a0 fd ff ff 	mov    -0x260(%rbp),%rdi
    8283:	48 01 f9             	add    %rdi,%rcx
    8286:	48 89 48 18          	mov    %rcx,0x18(%rax)
    828a:	48 39 d6             	cmp    %rdx,%rsi
    828d:	be 00 00 00 00       	mov    $0x0,%esi
    8292:	40 0f 95 c6          	setne  %sil
    8296:	0f b6 48 20          	movzbl 0x20(%rax),%ecx
    829a:	bf 02 00 00 00       	mov    $0x2,%edi
    829f:	48 85 f6             	test   %rsi,%rsi
    82a2:	48 0f 44 fa          	cmove  %rdx,%rdi
    82a6:	48 09 f9             	or     %rdi,%rcx
    82a9:	88 48 20             	mov    %cl,0x20(%rax)
    82ac:	48 8b 85 d0 fd ff ff 	mov    -0x230(%rbp),%rax
    82b3:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
    82ba:	e9 d8 20 00 00       	jmp    0xa397
    82bf:	48 8b 85 00 fe ff ff 	mov    -0x200(%rbp),%rax
    82c6:	48 85 c0             	test   %rax,%rax
    82c9:	0f 84 a0 11 00 00    	je     0x946f
    82cf:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
    82d6:	82 28 52 
    82d9:	31 c9                	xor    %ecx,%ecx
    82db:	48 8b 95 f8 fd ff ff 	mov    -0x208(%rbp),%rdx
    82e2:	48 89 95 00 fe ff ff 	mov    %rdx,-0x200(%rbp)
    82e9:	31 d2                	xor    %edx,%edx
    82eb:	48 89 95 d0 fd ff ff 	mov    %rdx,-0x230(%rbp)
    82f2:	31 d2                	xor    %edx,%edx
    82f4:	48 89 95 a0 fd ff ff 	mov    %rdx,-0x260(%rbp)
    82fb:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
    8302:	31 d2                	xor    %edx,%edx
    8304:	48 89 95 a8 fd ff ff 	mov    %rdx,-0x258(%rbp)
    830b:	31 d2                	xor    %edx,%edx
    830d:	48 89 95 b0 fd ff ff 	mov    %rdx,-0x250(%rbp)
    8314:	48 89 8d 80 fd ff ff 	mov    %rcx,-0x280(%rbp)
    831b:	31 d2                	xor    %edx,%edx
    831d:	48 89 95 c0 fd ff ff 	mov    %rdx,-0x240(%rbp)
    8324:	31 d2                	xor    %edx,%edx
    8326:	48 89 95 c8 fd ff ff 	mov    %rdx,-0x238(%rbp)
    832d:	48 8b 85 00 fe ff ff 	mov    -0x200(%rbp),%rax
    8334:	48 8b 8d e8 fd ff ff 	mov    -0x218(%rbp),%rcx
    833b:	48 39 c8             	cmp    %rcx,%rax
    833e:	0f 8d 10 0d 00 00    	jge    0x9054
    8344:	48 8b 95 e0 fd ff ff 	mov    -0x220(%rbp),%rdx
    834b:	48 8d 34 c2          	lea    (%rdx,%rax,8),%rsi
    834f:	48 8b 3e             	mov    (%rsi),%rdi
    8352:	48 8b b5 f0 fd ff ff 	mov    -0x210(%rbp),%rsi
    8359:	49 89 f0             	mov    %rsi,%r8
    835c:	49 01 f8             	add    %rdi,%r8
    835f:	49 8b 78 10          	mov    0x10(%r8),%rdi
    8363:	4d 8b 48 08          	mov    0x8(%r8),%r9
    8367:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    836d:	4d 89 cb             	mov    %r9,%r11
    8370:	4d 21 d3             	and    %r10,%r11
    8373:	49 8b 40 18          	mov    0x18(%r8),%rax
    8377:	49 d1 e9             	shr    $1,%r9
    837a:	4d 21 d1             	and    %r10,%r9
    837d:	45 31 c0             	xor    %r8d,%r8d
    8380:	4d 39 c1             	cmp    %r8,%r9
    8383:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    8389:	41 0f 95 c1          	setne  %r9b
    838d:	4d 85 db             	test   %r11,%r11
    8390:	48 89 85 70 fd ff ff 	mov    %rax,-0x290(%rbp)
    8397:	4c 89 8d b8 fd ff ff 	mov    %r9,-0x248(%rbp)
    839e:	0f 85 7b 0c 00 00    	jne    0x901f
    83a4:	48 63 ff             	movslq %edi,%rdi
    83a7:	49 89 fb             	mov    %rdi,%r11
    83aa:	49 83 fe 05          	cmp    $0x5,%r14
    83ae:	0f 85 ab 00 00 00    	jne    0x845f
    83b4:	48 8b bd 38 fe ff ff 	mov    -0x1c8(%rbp),%rdi
    83bb:	4c 89 d8             	mov    %r11,%rax
    83be:	48 29 f8             	sub    %rdi,%rax
    83c1:	4c 8b 8d 30 fe ff ff 	mov    -0x1d0(%rbp),%r9
    83c8:	4c 39 c8             	cmp    %r9,%rax
    83cb:	ba 00 00 00 00       	mov    $0x0,%edx
    83d0:	0f 92 c2             	setb   %dl
    83d3:	48 85 d2             	test   %rdx,%rdx
    83d6:	49 0f 44 c0          	cmove  %r8,%rax
    83da:	48 89 c6             	mov    %rax,%rsi
    83dd:	48 c1 ee 06          	shr    $0x6,%rsi
    83e1:	48 83 e0 3f          	and    $0x3f,%rax
    83e5:	49 8d 3c f7          	lea    (%r15,%rsi,8),%rdi
    83e9:	4c 8b 0f             	mov    (%rdi),%r9
    83ec:	48 89 c1             	mov    %rax,%rcx
    83ef:	49 d3 e9             	shr    %cl,%r9
    83f2:	4d 21 d1             	and    %r10,%r9
    83f5:	49 21 d1             	and    %rdx,%r9
    83f8:	48 8b 8d 28 fe ff ff 	mov    -0x1d8(%rbp),%rcx
    83ff:	48 8d 14 f1          	lea    (%rcx,%rsi,8),%rdx
    8403:	48 8b 3a             	mov    (%rdx),%rdi
    8406:	48 89 c1             	mov    %rax,%rcx
    8409:	48 d3 ef             	shr    %cl,%rdi
    840c:	4c 21 d7             	and    %r10,%rdi
    840f:	48 8b 8d 48 fe ff ff 	mov    -0x1b8(%rbp),%rcx
    8416:	48 8d 14 f1          	lea    (%rcx,%rsi,8),%rdx
    841a:	48 8b 32             	mov    (%rdx),%rsi
    841d:	48 89 c1             	mov    %rax,%rcx
    8420:	48 d3 ee             	shr    %cl,%rsi
    8423:	4c 21 d6             	and    %r10,%rsi
    8426:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
    842d:	48 89 c1             	mov    %rax,%rcx
    8430:	48 c1 e6 20          	shl    $0x20,%rsi
    8434:	4c 89 19             	mov    %r11,(%rcx)
    8437:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    843b:	48 89 79 10          	mov    %rdi,0x10(%rcx)
    843f:	4d 39 c1             	cmp    %r8,%r9
    8442:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    8448:	41 0f 95 c1          	setne  %r9b
    844c:	4d 85 c9             	test   %r9,%r9
    844f:	49 0f 44 c8          	cmove  %r8,%rcx
    8453:	48 89 8d 78 fd ff ff 	mov    %rcx,-0x288(%rbp)
    845a:	e9 1b 04 00 00       	jmp    0x887a
    845f:	49 83 fe 01          	cmp    $0x1,%r14
    8463:	0f 85 20 03 00 00    	jne    0x8789
    8469:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    8470:	79 37 9e 
    8473:	4c 89 d9             	mov    %r11,%rcx
    8476:	48 c1 e9 2b          	shr    $0x2b,%rcx
    847a:	4c 89 da             	mov    %r11,%rdx
    847d:	48 c1 ea 2c          	shr    $0x2c,%rdx
    8481:	48 31 d1             	xor    %rdx,%rcx
    8484:	4c 89 da             	mov    %r11,%rdx
    8487:	48 31 ca             	xor    %rcx,%rdx
    848a:	48 0f af d0          	imul   %rax,%rdx
    848e:	48 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%rax
    8495:	48 85 c0             	test   %rax,%rax
    8498:	48 89 95 90 fd ff ff 	mov    %rdx,-0x270(%rbp)
    849f:	0f 84 27 01 00 00    	je     0x85cc
    84a5:	b9 40 00 00 00       	mov    $0x40,%ecx
    84aa:	48 8b b5 18 fe ff ff 	mov    -0x1e8(%rbp),%rsi
    84b1:	48 29 f1             	sub    %rsi,%rcx
    84b4:	48 89 8d 88 fd ff ff 	mov    %rcx,-0x278(%rbp)
    84bb:	48 8b bd 88 fd ff ff 	mov    -0x278(%rbp),%rdi
    84c2:	48 89 f9             	mov    %rdi,%rcx
    84c5:	49 89 d0             	mov    %rdx,%r8
    84c8:	49 d3 e8             	shr    %cl,%r8
    84cb:	31 c9                	xor    %ecx,%ecx
    84cd:	48 39 ce             	cmp    %rcx,%rsi
    84d0:	bf 00 00 00 00       	mov    $0x0,%edi
    84d5:	40 0f 94 c7          	sete   %dil
    84d9:	48 85 ff             	test   %rdi,%rdi
    84dc:	49 0f 44 c8          	cmove  %r8,%rcx
    84e0:	48 8b bd 10 fe ff ff 	mov    -0x1f0(%rbp),%rdi
    84e7:	4c 8d 04 cf          	lea    (%rdi,%rcx,8),%r8
    84eb:	49 8b 08             	mov    (%r8),%rcx
    84ee:	49 89 d0             	mov    %rdx,%r8
    84f1:	49 c1 e8 20          	shr    $0x20,%r8
    84f5:	49 89 d1             	mov    %rdx,%r9
    84f8:	4d 31 c1             	xor    %r8,%r9
    84fb:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    8501:	4d 21 c1             	and    %r8,%r9
    8504:	4d 89 c8             	mov    %r9,%r8
    8507:	49 83 e0 3f          	and    $0x3f,%r8
    850b:	48 89 8d 88 fd ff ff 	mov    %rcx,-0x278(%rbp)
    8512:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    8518:	4c 89 c1             	mov    %r8,%rcx
    851b:	4c 89 d2             	mov    %r10,%rdx
    851e:	48 d3 e2             	shl    %cl,%rdx
    8521:	4c 89 c9             	mov    %r9,%rcx
    8524:	48 c1 e9 06          	shr    $0x6,%rcx
    8528:	48 83 e1 3f          	and    $0x3f,%rcx
    852c:	48 89 8d 60 fd ff ff 	mov    %rcx,-0x2a0(%rbp)
    8533:	4c 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%r8
    853a:	4c 89 c1             	mov    %r8,%rcx
    853d:	4c 89 d7             	mov    %r10,%rdi
    8540:	48 d3 e7             	shl    %cl,%rdi
    8543:	48 09 fa             	or     %rdi,%rdx
    8546:	4c 89 c9             	mov    %r9,%rcx
    8549:	48 c1 e9 0c          	shr    $0xc,%rcx
    854d:	48 83 e1 3f          	and    $0x3f,%rcx
    8551:	48 89 8d 60 fd ff ff 	mov    %rcx,-0x2a0(%rbp)
    8558:	48 8b bd 60 fd ff ff 	mov    -0x2a0(%rbp),%rdi
    855f:	48 89 f9             	mov    %rdi,%rcx
    8562:	4d 89 d0             	mov    %r10,%r8
    8565:	49 d3 e0             	shl    %cl,%r8
    8568:	4c 09 c2             	or     %r8,%rdx
    856b:	49 c1 e9 12          	shr    $0x12,%r9
    856f:	49 83 e1 3f          	and    $0x3f,%r9
    8573:	4c 89 c9             	mov    %r9,%rcx
    8576:	4c 89 d7             	mov    %r10,%rdi
    8579:	48 d3 e7             	shl    %cl,%rdi
    857c:	48 09 fa             	or     %rdi,%rdx
    857f:	48 8b 8d 88 fd ff ff 	mov    -0x278(%rbp),%rcx
    8586:	48 21 d1             	and    %rdx,%rcx
    8589:	48 39 d1             	cmp    %rdx,%rcx
    858c:	b9 00 00 00 00       	mov    $0x0,%ecx
    8591:	0f 94 c1             	sete   %cl
    8594:	ba 01 00 00 00       	mov    $0x1,%edx
    8599:	48 bf 00 00 00 00 01 	movabs $0x100000000,%rdi
    85a0:	00 00 00 
    85a3:	48 85 c9             	test   %rcx,%rcx
    85a6:	48 0f 44 d7          	cmove  %rdi,%rdx
    85aa:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    85ae:	48 01 d7             	add    %rdx,%rdi
    85b1:	48 89 7b 20          	mov    %rdi,0x20(%rbx)
    85b5:	48 85 c9             	test   %rcx,%rcx
    85b8:	0f 85 fa 00 00 00    	jne    0x86b8
    85be:	31 c9                	xor    %ecx,%ecx
    85c0:	48 89 8d 78 fd ff ff 	mov    %rcx,-0x288(%rbp)
    85c7:	e9 b8 01 00 00       	jmp    0x8784
    85cc:	b8 40 00 00 00       	mov    $0x40,%eax
    85d1:	48 8b 8d 18 fe ff ff 	mov    -0x1e8(%rbp),%rcx
    85d8:	48 29 c8             	sub    %rcx,%rax
    85db:	48 8b 95 90 fd ff ff 	mov    -0x270(%rbp),%rdx
    85e2:	48 89 c1             	mov    %rax,%rcx
    85e5:	48 89 d6             	mov    %rdx,%rsi
    85e8:	48 d3 ee             	shr    %cl,%rsi
    85eb:	31 c0                	xor    %eax,%eax
    85ed:	48 8b 8d 18 fe ff ff 	mov    -0x1e8(%rbp),%rcx
    85f4:	48 39 c1             	cmp    %rax,%rcx
    85f7:	bf 00 00 00 00       	mov    $0x0,%edi
    85fc:	40 0f 94 c7          	sete   %dil
    8600:	48 85 ff             	test   %rdi,%rdi
    8603:	48 0f 44 c6          	cmove  %rsi,%rax
    8607:	48 8b b5 10 fe ff ff 	mov    -0x1f0(%rbp),%rsi
    860e:	48 8d 3c c6          	lea    (%rsi,%rax,8),%rdi
    8612:	48 8b 07             	mov    (%rdi),%rax
    8615:	48 89 d7             	mov    %rdx,%rdi
    8618:	48 c1 ef 20          	shr    $0x20,%rdi
    861c:	49 89 d0             	mov    %rdx,%r8
    861f:	49 31 f8             	xor    %rdi,%r8
    8622:	bf ff ff ff ff       	mov    $0xffffffff,%edi
    8627:	49 21 f8             	and    %rdi,%r8
    862a:	4c 89 c7             	mov    %r8,%rdi
    862d:	48 83 e7 3f          	and    $0x3f,%rdi
    8631:	41 b9 01 00 00 00    	mov    $0x1,%r9d
    8637:	48 89 f9             	mov    %rdi,%rcx
    863a:	4d 89 ca             	mov    %r9,%r10
    863d:	49 d3 e2             	shl    %cl,%r10
    8640:	4c 89 c1             	mov    %r8,%rcx
    8643:	48 c1 e9 06          	shr    $0x6,%rcx
    8647:	48 83 e1 3f          	and    $0x3f,%rcx
    864b:	48 89 8d 88 fd ff ff 	mov    %rcx,-0x278(%rbp)
    8652:	48 8b bd 88 fd ff ff 	mov    -0x278(%rbp),%rdi
    8659:	48 89 f9             	mov    %rdi,%rcx
    865c:	4c 89 ca             	mov    %r9,%rdx
    865f:	48 d3 e2             	shl    %cl,%rdx
    8662:	49 09 d2             	or     %rdx,%r10
    8665:	4c 89 c1             	mov    %r8,%rcx
    8668:	48 c1 e9 0c          	shr    $0xc,%rcx
    866c:	48 83 e1 3f          	and    $0x3f,%rcx
    8670:	48 89 8d 88 fd ff ff 	mov    %rcx,-0x278(%rbp)
    8677:	48 8b 95 88 fd ff ff 	mov    -0x278(%rbp),%rdx
    867e:	48 89 d1             	mov    %rdx,%rcx
    8681:	4c 89 cf             	mov    %r9,%rdi
    8684:	48 d3 e7             	shl    %cl,%rdi
    8687:	49 09 fa             	or     %rdi,%r10
    868a:	49 c1 e8 12          	shr    $0x12,%r8
    868e:	49 83 e0 3f          	and    $0x3f,%r8
    8692:	4c 89 c1             	mov    %r8,%rcx
    8695:	4c 89 ca             	mov    %r9,%rdx
    8698:	48 d3 e2             	shl    %cl,%rdx
    869b:	49 09 d2             	or     %rdx,%r10
    869e:	4c 21 d0             	and    %r10,%rax
    86a1:	4c 39 d0             	cmp    %r10,%rax
    86a4:	0f 84 0e 00 00 00    	je     0x86b8
    86aa:	31 c0                	xor    %eax,%eax
    86ac:	48 89 85 78 fd ff ff 	mov    %rax,-0x288(%rbp)
    86b3:	e9 cc 00 00 00       	jmp    0x8784
    86b8:	b8 40 00 00 00       	mov    $0x40,%eax
    86bd:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
    86c4:	48 29 c8             	sub    %rcx,%rax
    86c7:	48 8b 95 90 fd ff ff 	mov    -0x270(%rbp),%rdx
    86ce:	48 89 c1             	mov    %rax,%rcx
    86d1:	48 89 d6             	mov    %rdx,%rsi
    86d4:	48 d3 ee             	shr    %cl,%rsi
    86d7:	31 c0                	xor    %eax,%eax
    86d9:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
    86e0:	48 39 c1             	cmp    %rax,%rcx
    86e3:	bf 00 00 00 00       	mov    $0x0,%edi
    86e8:	40 0f 94 c7          	sete   %dil
    86ec:	48 85 ff             	test   %rdi,%rdi
    86ef:	48 0f 44 c6          	cmove  %rsi,%rax
    86f3:	49 8d 34 c7          	lea    (%r15,%rax,8),%rsi
    86f7:	48 8b 06             	mov    (%rsi),%rax
    86fa:	48 be ff ff ff ff ff 	movabs $0xffffffffffff,%rsi
    8701:	ff 00 00 
    8704:	48 89 c7             	mov    %rax,%rdi
    8707:	48 21 f7             	and    %rsi,%rdi
    870a:	31 f6                	xor    %esi,%esi
    870c:	48 39 f7             	cmp    %rsi,%rdi
    870f:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    8715:	41 0f 94 c0          	sete   %r8b
    8719:	49 89 d1             	mov    %rdx,%r9
    871c:	49 c1 e9 20          	shr    $0x20,%r9
    8720:	4c 31 ca             	xor    %r9,%rdx
    8723:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    8729:	4c 21 ca             	and    %r9,%rdx
    872c:	48 83 e2 0f          	and    $0xf,%rdx
    8730:	48 83 c2 30          	add    $0x30,%rdx
    8734:	48 89 d1             	mov    %rdx,%rcx
    8737:	48 d3 e8             	shr    %cl,%rax
    873a:	48 83 e0 01          	and    $0x1,%rax
    873e:	48 83 f8 00          	cmp    $0x0,%rax
    8742:	b8 00 00 00 00       	mov    $0x0,%eax
    8747:	0f 95 c0             	setne  %al
    874a:	b9 01 00 00 00       	mov    $0x1,%ecx
    874f:	48 31 c8             	xor    %rcx,%rax
    8752:	49 09 c0             	or     %rax,%r8
    8755:	b8 01 00 00 00       	mov    $0x1,%eax
    875a:	48 29 c7             	sub    %rax,%rdi
    875d:	b9 18 00 00 00       	mov    $0x18,%ecx
    8762:	48 0f af f9          	imul   %rcx,%rdi
    8766:	48 8b 8d 20 fe ff ff 	mov    -0x1e0(%rbp),%rcx
    876d:	48 89 ca             	mov    %rcx,%rdx
    8770:	48 01 fa             	add    %rdi,%rdx
    8773:	48 89 f7             	mov    %rsi,%rdi
    8776:	4d 85 c0             	test   %r8,%r8
    8779:	48 0f 44 fa          	cmove  %rdx,%rdi
    877d:	48 89 bd 78 fd ff ff 	mov    %rdi,-0x288(%rbp)
    8784:	e9 f1 00 00 00       	jmp    0x887a
    8789:	48 8b 85 38 fe ff ff 	mov    -0x1c8(%rbp),%rax
    8790:	4c 89 d9             	mov    %r11,%rcx
    8793:	48 29 c1             	sub    %rax,%rcx
    8796:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
    879d:	48 39 d1             	cmp    %rdx,%rcx
    87a0:	0f 82 0e 00 00 00    	jb     0x87b4
    87a6:	31 f6                	xor    %esi,%esi
    87a8:	48 89 b5 78 fd ff ff 	mov    %rsi,-0x288(%rbp)
    87af:	e9 c6 00 00 00       	jmp    0x887a
    87b4:	49 83 fe 02          	cmp    $0x2,%r14
    87b8:	48 89 8d 90 fd ff ff 	mov    %rcx,-0x270(%rbp)
    87bf:	0f 85 69 00 00 00    	jne    0x882e
    87c5:	48 89 ce             	mov    %rcx,%rsi
    87c8:	48 c1 ee 06          	shr    $0x6,%rsi
    87cc:	49 8d 3c f7          	lea    (%r15,%rsi,8),%rdi
    87d0:	48 8b 37             	mov    (%rdi),%rsi
    87d3:	48 89 cf             	mov    %rcx,%rdi
    87d6:	48 83 e7 3f          	and    $0x3f,%rdi
    87da:	48 89 f9             	mov    %rdi,%rcx
    87dd:	48 d3 ee             	shr    %cl,%rsi
    87e0:	b9 01 00 00 00       	mov    $0x1,%ecx
    87e5:	48 21 ce             	and    %rcx,%rsi
    87e8:	31 ff                	xor    %edi,%edi
    87ea:	48 39 fe             	cmp    %rdi,%rsi
    87ed:	be 00 00 00 00       	mov    $0x0,%esi
    87f2:	40 0f 95 c6          	setne  %sil
    87f6:	41 b8 10 00 00 00    	mov    $0x10,%r8d
    87fc:	4c 8b 8d 90 fd ff ff 	mov    -0x270(%rbp),%r9
    8803:	4d 89 ca             	mov    %r9,%r10
    8806:	4d 0f af d0          	imul   %r8,%r10
    880a:	4c 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%r8
    8811:	4d 89 c1             	mov    %r8,%r9
    8814:	4d 01 d1             	add    %r10,%r9
    8817:	49 83 e9 08          	sub    $0x8,%r9
    881b:	48 85 f6             	test   %rsi,%rsi
    881e:	4c 0f 44 cf          	cmove  %rdi,%r9
    8822:	4c 89 8d 78 fd ff ff 	mov    %r9,-0x288(%rbp)
    8829:	e9 4c 00 00 00       	jmp    0x887a
    882e:	48 8b 85 90 fd ff ff 	mov    -0x270(%rbp),%rax
    8835:	49 8d 0c 87          	lea    (%r15,%rax,4),%rcx
    8839:	8b 01                	mov    (%rcx),%eax
    883b:	b9 01 00 00 00       	mov    $0x1,%ecx
    8840:	48 89 c2             	mov    %rax,%rdx
    8843:	48 29 ca             	sub    %rcx,%rdx
    8846:	be 18 00 00 00       	mov    $0x18,%esi
    884b:	48 0f af d6          	imul   %rsi,%rdx
    884f:	48 8b b5 20 fe ff ff 	mov    -0x1e0(%rbp),%rsi
    8856:	48 89 f7             	mov    %rsi,%rdi
    8859:	48 01 d7             	add    %rdx,%rdi
    885c:	31 d2                	xor    %edx,%edx
    885e:	48 39 d0             	cmp    %rdx,%rax
    8861:	b8 00 00 00 00       	mov    $0x0,%eax
    8866:	0f 94 c0             	sete   %al
    8869:	49 89 d0             	mov    %rdx,%r8
    886c:	48 85 c0             	test   %rax,%rax
    886f:	4c 0f 44 c7          	cmove  %rdi,%r8
    8873:	4c 89 85 78 fd ff ff 	mov    %r8,-0x288(%rbp)
    887a:	49 83 fe 01          	cmp    $0x1,%r14
    887e:	be 00 00 00 00       	mov    $0x0,%esi
    8883:	40 0f 95 c6          	setne  %sil
    8887:	31 ff                	xor    %edi,%edi
    8889:	48 8b 85 c8 fd ff ff 	mov    -0x238(%rbp),%rax
    8890:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
    8897:	48 8b 85 d0 fd ff ff 	mov    -0x230(%rbp),%rax
    889e:	48 89 85 88 fd ff ff 	mov    %rax,-0x278(%rbp)
    88a5:	48 8b 85 a0 fd ff ff 	mov    -0x260(%rbp),%rax
    88ac:	48 89 85 60 fd ff ff 	mov    %rax,-0x2a0(%rbp)
    88b3:	48 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%rax
    88ba:	48 89 85 68 fd ff ff 	mov    %rax,-0x298(%rbp)
    88c1:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
    88c8:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
    88cf:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
    88d6:	48 89 85 50 fd ff ff 	mov    %rax,-0x2b0(%rbp)
    88dd:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
    88e4:	48 89 85 48 fd ff ff 	mov    %rax,-0x2b8(%rbp)
    88eb:	48 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%rax
    88f2:	48 89 85 40 fd ff ff 	mov    %rax,-0x2c0(%rbp)
    88f9:	48 8b 85 78 fd ff ff 	mov    -0x288(%rbp),%rax
    8900:	48 85 c0             	test   %rax,%rax
    8903:	0f 85 75 00 00 00    	jne    0x897e
    8909:	48 8b 8d 90 fd ff ff 	mov    -0x270(%rbp),%rcx
    8910:	48 89 8d c8 fd ff ff 	mov    %rcx,-0x238(%rbp)
    8917:	48 8b 8d 88 fd ff ff 	mov    -0x278(%rbp),%rcx
    891e:	48 89 8d d0 fd ff ff 	mov    %rcx,-0x230(%rbp)
    8925:	48 8b 8d 60 fd ff ff 	mov    -0x2a0(%rbp),%rcx
    892c:	48 89 8d a0 fd ff ff 	mov    %rcx,-0x260(%rbp)
    8933:	48 8b 8d 68 fd ff ff 	mov    -0x298(%rbp),%rcx
    893a:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
    8941:	48 8b 8d 58 fd ff ff 	mov    -0x2a8(%rbp),%rcx
    8948:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
    894f:	48 8b 8d 50 fd ff ff 	mov    -0x2b0(%rbp),%rcx
    8956:	48 89 8d b0 fd ff ff 	mov    %rcx,-0x250(%rbp)
    895d:	48 8b 8d 48 fd ff ff 	mov    -0x2b8(%rbp),%rcx
    8964:	48 89 8d 80 fd ff ff 	mov    %rcx,-0x280(%rbp)
    896b:	48 8b 8d 40 fd ff ff 	mov    -0x2c0(%rbp),%rcx
    8972:	48 89 8d c0 fd ff ff 	mov    %rcx,-0x240(%rbp)
    8979:	e9 9b 06 00 00       	jmp    0x9019
    897e:	48 8b 48 08          	mov    0x8(%rax),%rcx
    8982:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    8987:	49 89 c8             	mov    %rcx,%r8
    898a:	49 21 d0             	and    %rdx,%r8
    898d:	ba 01 00 00 00       	mov    $0x1,%edx
    8992:	4d 89 c1             	mov    %r8,%r9
    8995:	49 29 d1             	sub    %rdx,%r9
    8998:	41 ba 18 00 00 00    	mov    $0x18,%r10d
    899e:	4d 0f af ca          	imul   %r10,%r9
    89a2:	4c 8b 95 20 fe ff ff 	mov    -0x1e0(%rbp),%r10
    89a9:	4c 89 d0             	mov    %r10,%rax
    89ac:	4c 01 c8             	add    %r9,%rax
    89af:	45 31 c9             	xor    %r9d,%r9d
    89b2:	4d 39 c8             	cmp    %r9,%r8
    89b5:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    89bb:	41 0f 94 c0          	sete   %r8b
    89bf:	4d 89 ca             	mov    %r9,%r10
    89c2:	4d 85 c0             	test   %r8,%r8
    89c5:	4c 0f 44 d0          	cmove  %rax,%r10
    89c9:	48 8b 85 78 fd ff ff 	mov    -0x288(%rbp),%rax
    89d0:	4c 8b 00             	mov    (%rax),%r8
    89d3:	4d 39 c3             	cmp    %r8,%r11
    89d6:	b8 00 00 00 00       	mov    $0x0,%eax
    89db:	0f 94 c0             	sete   %al
    89de:	48 09 f0             	or     %rsi,%rax
    89e1:	49 89 f8             	mov    %rdi,%r8
    89e4:	49 01 d0             	add    %rdx,%r8
    89e7:	48 85 c0             	test   %rax,%rax
    89ea:	0f 85 0c 00 00 00    	jne    0x89fc
    89f0:	4c 89 95 78 fd ff ff 	mov    %r10,-0x288(%rbp)
    89f7:	e9 fd fe ff ff       	jmp    0x88f9
    89fc:	48 8b 43 18          	mov    0x18(%rbx),%rax
    8a00:	48 39 c7             	cmp    %rax,%rdi
    8a03:	0f 8d 0f 00 00 00    	jge    0x8a18
    8a09:	4c 89 95 78 fd ff ff 	mov    %r10,-0x288(%rbp)
    8a10:	4c 89 c7             	mov    %r8,%rdi
    8a13:	e9 e1 fe ff ff       	jmp    0x88f9
    8a18:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
    8a1c:	48 8b 70 18          	mov    0x18(%rax),%rsi
    8a20:	48 85 f6             	test   %rsi,%rsi
    8a23:	48 89 8d 38 fd ff ff 	mov    %rcx,-0x2c8(%rbp)
    8a2a:	4c 89 85 30 fd ff ff 	mov    %r8,-0x2d0(%rbp)
    8a31:	0f 84 0c 00 00 00    	je     0x8a43
    8a37:	0f b6 3e             	movzbl (%rsi),%edi
    8a3a:	48 85 ff             	test   %rdi,%rdi
    8a3d:	0f 85 fa 05 00 00    	jne    0x903d
    8a43:	48 8b 85 78 fd ff ff 	mov    -0x288(%rbp),%rax
    8a4a:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8a4e:	48 8b 95 38 fd ff ff 	mov    -0x2c8(%rbp),%rdx
    8a55:	48 89 d6             	mov    %rdx,%rsi
    8a58:	48 c1 ee 20          	shr    $0x20,%rsi
    8a5c:	48 83 e6 01          	and    $0x1,%rsi
    8a60:	48 83 fe 00          	cmp    $0x0,%rsi
    8a64:	be 00 00 00 00       	mov    $0x0,%esi
    8a69:	40 0f 95 c6          	setne  %sil
    8a6d:	48 8b bd 30 fd ff ff 	mov    -0x2d0(%rbp),%rdi
    8a74:	48 89 7b 18          	mov    %rdi,0x18(%rbx)
    8a78:	4c 8b 85 90 fd ff ff 	mov    -0x270(%rbp),%r8
    8a7f:	4d 89 c1             	mov    %r8,%r9
    8a82:	49 83 c1 01          	add    $0x1,%r9
    8a86:	48 63 c9             	movslq %ecx,%rcx
    8a89:	45 31 d2             	xor    %r10d,%r10d
    8a8c:	48 85 f6             	test   %rsi,%rsi
    8a8f:	4c 0f 44 d1          	cmove  %rcx,%r10
    8a93:	48 8b 8d 88 fd ff ff 	mov    -0x278(%rbp),%rcx
    8a9a:	4c 39 d1             	cmp    %r10,%rcx
    8a9d:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    8aa3:	41 0f 94 c3          	sete   %r11b
    8aa7:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
    8aae:	48 39 f0             	cmp    %rsi,%rax
    8ab1:	ba 00 00 00 00       	mov    $0x0,%edx
    8ab6:	0f 94 c2             	sete   %dl
    8ab9:	49 21 d3             	and    %rdx,%r11
    8abc:	4d 85 db             	test   %r11,%r11
    8abf:	48 89 b5 28 fd ff ff 	mov    %rsi,-0x2d8(%rbp)
    8ac6:	4c 89 8d 20 fd ff ff 	mov    %r9,-0x2e0(%rbp)
    8acd:	4c 89 95 18 fd ff ff 	mov    %r10,-0x2e8(%rbp)
    8ad4:	0f 84 83 00 00 00    	je     0x8b5d
    8ada:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
    8ae1:	49 89 d3             	mov    %rdx,%r11
    8ae4:	49 83 c3 01          	add    $0x1,%r11
    8ae8:	be 01 00 00 00       	mov    $0x1,%esi
    8aed:	4c 8b 95 b8 fd ff ff 	mov    -0x248(%rbp),%r10
    8af4:	4d 89 d1             	mov    %r10,%r9
    8af7:	49 31 f1             	xor    %rsi,%r9
    8afa:	31 f6                	xor    %esi,%esi
    8afc:	4c 8b 95 70 fd ff ff 	mov    -0x290(%rbp),%r10
    8b03:	4c 89 d2             	mov    %r10,%rdx
    8b06:	4d 85 c9             	test   %r9,%r9
    8b09:	48 0f 44 d6          	cmove  %rsi,%rdx
    8b0d:	48 8b b5 40 fd ff ff 	mov    -0x2c0(%rbp),%rsi
    8b14:	49 89 f2             	mov    %rsi,%r10
    8b17:	4d 01 ca             	add    %r9,%r10
    8b1a:	4c 8b 8d 48 fd ff ff 	mov    -0x2b8(%rbp),%r9
    8b21:	4c 89 ce             	mov    %r9,%rsi
    8b24:	48 01 d6             	add    %rdx,%rsi
    8b27:	48 89 8d d0 fd ff ff 	mov    %rcx,-0x230(%rbp)
    8b2e:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
    8b35:	48 8b 95 68 fd ff ff 	mov    -0x298(%rbp),%rdx
    8b3c:	48 89 95 98 fd ff ff 	mov    %rdx,-0x268(%rbp)
    8b43:	4c 89 9d b0 fd ff ff 	mov    %r11,-0x250(%rbp)
    8b4a:	48 89 b5 80 fd ff ff 	mov    %rsi,-0x280(%rbp)
    8b51:	4c 89 95 c0 fd ff ff 	mov    %r10,-0x240(%rbp)
    8b58:	e9 a2 04 00 00       	jmp    0x8fff
    8b5d:	48 8b 85 58 fd ff ff 	mov    -0x2a8(%rbp),%rax
    8b64:	48 85 c0             	test   %rax,%rax
    8b67:	0f 84 f6 03 00 00    	je     0x8f63
    8b6d:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    8b74:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    8b78:	48 85 d2             	test   %rdx,%rdx
    8b7b:	0f 84 3d 01 00 00    	je     0x8cbe
    8b81:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    8b85:	be 40 00 00 00       	mov    $0x40,%esi
    8b8a:	48 29 d6             	sub    %rdx,%rsi
    8b8d:	48 8b bd 68 fd ff ff 	mov    -0x298(%rbp),%rdi
    8b94:	48 89 f1             	mov    %rsi,%rcx
    8b97:	49 89 f8             	mov    %rdi,%r8
    8b9a:	49 d3 e8             	shr    %cl,%r8
    8b9d:	31 c9                	xor    %ecx,%ecx
    8b9f:	48 39 ca             	cmp    %rcx,%rdx
    8ba2:	ba 00 00 00 00       	mov    $0x0,%edx
    8ba7:	0f 94 c2             	sete   %dl
    8baa:	48 85 d2             	test   %rdx,%rdx
    8bad:	49 0f 44 c8          	cmove  %r8,%rcx
    8bb1:	48 8b 95 58 fe ff ff 	mov    -0x1a8(%rbp),%rdx
    8bb8:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    8bbc:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    8bc0:	49 8b 30             	mov    (%r8),%rsi
    8bc3:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    8bca:	00 28 00 
    8bcd:	4c 39 ce             	cmp    %r9,%rsi
    8bd0:	4c 89 85 10 fd ff ff 	mov    %r8,-0x2f0(%rbp)
    8bd7:	0f 82 0c 00 00 00    	jb     0x8be9
    8bdd:	48 89 b5 08 fd ff ff 	mov    %rsi,-0x2f8(%rbp)
    8be4:	e9 47 00 00 00       	jmp    0x8c30
    8be9:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    8bed:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    8bf1:	48 89 b5 00 fd ff ff 	mov    %rsi,-0x300(%rbp)
    8bf8:	48 89 d6             	mov    %rdx,%rsi
    8bfb:	48 89 ca             	mov    %rcx,%rdx
    8bfe:	48 8b 8d 00 fd ff ff 	mov    -0x300(%rbp),%rcx
    8c05:	e8 d6 74 ff ff       	call   0xe0
    8c0a:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    8c11:	31 d2                	xor    %edx,%edx
    8c13:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    8c17:	48 83 f8 00          	cmp    $0x0,%rax
    8c1b:	0f 8f 08 00 00 00    	jg     0x8c29
    8c21:	49 89 c4             	mov    %rax,%r12
    8c24:	e9 21 18 00 00       	jmp    0xa44a
    8c29:	48 89 85 08 fd ff ff 	mov    %rax,-0x2f8(%rbp)
    8c30:	48 8b 85 08 fd ff ff 	mov    -0x2f8(%rbp),%rax
    8c37:	48 89 c1             	mov    %rax,%rcx
    8c3a:	48 83 c1 28          	add    $0x28,%rcx
    8c3e:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    8c45:	00 28 00 
    8c48:	48 29 d1             	sub    %rdx,%rcx
    8c4b:	48 8b 95 10 fd ff ff 	mov    -0x2f0(%rbp),%rdx
    8c52:	48 89 0a             	mov    %rcx,(%rdx)
    8c55:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    8c5c:	ff 00 00 
    8c5f:	48 21 c8             	and    %rcx,%rax
    8c62:	31 c9                	xor    %ecx,%ecx
    8c64:	48 8b 95 88 fd ff ff 	mov    -0x278(%rbp),%rdx
    8c6b:	48 89 10             	mov    %rdx,(%rax)
    8c6e:	48 8b b5 60 fd ff ff 	mov    -0x2a0(%rbp),%rsi
    8c75:	48 89 70 08          	mov    %rsi,0x8(%rax)
    8c79:	48 89 48 10          	mov    %rcx,0x10(%rax)
    8c7d:	48 89 48 18          	mov    %rcx,0x18(%rax)
    8c81:	48 89 48 20          	mov    %rcx,0x20(%rax)
    8c85:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    8c8c:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    8c90:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    8c96:	4c 01 c7             	add    %r8,%rdi
    8c99:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    8c9d:	48 89 85 08 fd ff ff 	mov    %rax,-0x2f8(%rbp)
    8ca4:	b8 01 00 00 00       	mov    $0x1,%eax
    8ca9:	48 89 85 10 fd ff ff 	mov    %rax,-0x2f0(%rbp)
    8cb0:	31 c0                	xor    %eax,%eax
    8cb2:	48 89 85 00 fd ff ff 	mov    %rax,-0x300(%rbp)
    8cb9:	e9 9f 01 00 00       	jmp    0x8e5d
    8cbe:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    8cc5:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8cc9:	48 8b 50 18          	mov    0x18(%rax),%rdx
    8ccd:	48 89 d6             	mov    %rdx,%rsi
    8cd0:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    8cd5:	bf 40 00 00 00       	mov    $0x40,%edi
    8cda:	48 29 f7             	sub    %rsi,%rdi
    8cdd:	48 89 8d f8 fc ff ff 	mov    %rcx,-0x308(%rbp)
    8ce4:	4c 8b 85 68 fd ff ff 	mov    -0x298(%rbp),%r8
    8ceb:	48 89 f9             	mov    %rdi,%rcx
    8cee:	4d 89 c1             	mov    %r8,%r9
    8cf1:	49 d3 e9             	shr    %cl,%r9
    8cf4:	31 c9                	xor    %ecx,%ecx
    8cf6:	48 39 ce             	cmp    %rcx,%rsi
    8cf9:	be 00 00 00 00       	mov    $0x0,%esi
    8cfe:	40 0f 94 c6          	sete   %sil
    8d02:	48 85 f6             	test   %rsi,%rsi
    8d05:	49 0f 44 c9          	cmove  %r9,%rcx
    8d09:	be 01 00 00 00       	mov    $0x1,%esi
    8d0e:	48 89 cf             	mov    %rcx,%rdi
    8d11:	48 01 f7             	add    %rsi,%rdi
    8d14:	48 21 d7             	and    %rdx,%rdi
    8d17:	ba 28 00 00 00       	mov    $0x28,%edx
    8d1c:	48 0f af ca          	imul   %rdx,%rcx
    8d20:	48 8b 95 f8 fc ff ff 	mov    -0x308(%rbp),%rdx
    8d27:	4c 8d 0c 0a          	lea    (%rdx,%rcx,1),%r9
    8d2b:	49 8b 49 10          	mov    0x10(%r9),%rcx
    8d2f:	48 85 c9             	test   %rcx,%rcx
    8d32:	0f 84 af 00 00 00    	je     0x8de7
    8d38:	49 8b 09             	mov    (%r9),%rcx
    8d3b:	4d 8b 51 08          	mov    0x8(%r9),%r10
    8d3f:	4c 8b 9d 88 fd ff ff 	mov    -0x278(%rbp),%r11
    8d46:	49 39 cb             	cmp    %rcx,%r11
    8d49:	ba 00 00 00 00       	mov    $0x0,%edx
    8d4e:	0f 94 c2             	sete   %dl
    8d51:	48 8b 8d 60 fd ff ff 	mov    -0x2a0(%rbp),%rcx
    8d58:	4c 39 d1             	cmp    %r10,%rcx
    8d5b:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    8d61:	41 0f 94 c0          	sete   %r8b
    8d65:	4c 21 c2             	and    %r8,%rdx
    8d68:	48 85 d2             	test   %rdx,%rdx
    8d6b:	0f 84 0c 00 00 00    	je     0x8d7d
    8d71:	4c 89 8d 08 fd ff ff 	mov    %r9,-0x2f8(%rbp)
    8d78:	e9 53 00 00 00       	jmp    0x8dd0
    8d7d:	ba 28 00 00 00       	mov    $0x28,%edx
    8d82:	48 0f af fa          	imul   %rdx,%rdi
    8d86:	48 8b 95 f8 fc ff ff 	mov    -0x308(%rbp),%rdx
    8d8d:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    8d91:	49 8b 50 10          	mov    0x10(%r8),%rdx
    8d95:	48 85 d2             	test   %rdx,%rdx
    8d98:	0f 84 49 00 00 00    	je     0x8de7
    8d9e:	49 8b 10             	mov    (%r8),%rdx
    8da1:	49 8b 78 08          	mov    0x8(%r8),%rdi
    8da5:	49 39 d3             	cmp    %rdx,%r11
    8da8:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    8dae:	41 0f 94 c1          	sete   %r9b
    8db2:	48 39 f9             	cmp    %rdi,%rcx
    8db5:	ba 00 00 00 00       	mov    $0x0,%edx
    8dba:	0f 94 c2             	sete   %dl
    8dbd:	49 21 d1             	and    %rdx,%r9
    8dc0:	4d 85 c9             	test   %r9,%r9
    8dc3:	0f 84 1e 00 00 00    	je     0x8de7
    8dc9:	4c 89 85 08 fd ff ff 	mov    %r8,-0x2f8(%rbp)
    8dd0:	31 c0                	xor    %eax,%eax
    8dd2:	48 89 85 10 fd ff ff 	mov    %rax,-0x2f0(%rbp)
    8dd9:	31 c0                	xor    %eax,%eax
    8ddb:	48 89 85 00 fd ff ff 	mov    %rax,-0x300(%rbp)
    8de2:	e9 76 00 00 00       	jmp    0x8e5d
    8de7:	48 8d 85 c0 fe ff ff 	lea    -0x140(%rbp),%rax
    8dee:	48 89 c1             	mov    %rax,%rcx
    8df1:	48 8b 95 88 fd ff ff 	mov    -0x278(%rbp),%rdx
    8df8:	48 89 11             	mov    %rdx,(%rcx)
    8dfb:	48 8b b5 60 fd ff ff 	mov    -0x2a0(%rbp),%rsi
    8e02:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    8e06:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    8e0a:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
    8e11:	48 89 ca             	mov    %rcx,%rdx
    8e14:	e8 d7 72 ff ff       	call   0xf0
    8e19:	48 83 f8 00          	cmp    $0x0,%rax
    8e1d:	0f 8d 08 00 00 00    	jge    0x8e2b
    8e23:	49 89 c4             	mov    %rax,%r12
    8e26:	e9 1f 16 00 00       	jmp    0xa44a
    8e2b:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    8e32:	48 8b 11             	mov    (%rcx),%rdx
    8e35:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    8e39:	48 83 e6 01          	and    $0x1,%rsi
    8e3d:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    8e41:	48 89 85 08 fd ff ff 	mov    %rax,-0x2f8(%rbp)
    8e48:	b8 01 00 00 00       	mov    $0x1,%eax
    8e4d:	48 89 85 10 fd ff ff 	mov    %rax,-0x2f0(%rbp)
    8e54:	31 c0                	xor    %eax,%eax
    8e56:	48 89 85 00 fd ff ff 	mov    %rax,-0x300(%rbp)
    8e5d:	48 8b 85 10 fd ff ff 	mov    -0x2f0(%rbp),%rax
    8e64:	48 85 c0             	test   %rax,%rax
    8e67:	0f 84 68 00 00 00    	je     0x8ed5
    8e6d:	48 8b 85 08 fd ff ff 	mov    -0x2f8(%rbp),%rax
    8e74:	48 8b 8d 50 fd ff ff 	mov    -0x2b0(%rbp),%rcx
    8e7b:	48 89 48 10          	mov    %rcx,0x10(%rax)
    8e7f:	31 d2                	xor    %edx,%edx
    8e81:	48 39 d1             	cmp    %rdx,%rcx
    8e84:	be 00 00 00 00       	mov    $0x0,%esi
    8e89:	40 0f 95 c6          	setne  %sil
    8e8d:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    8e91:	48 09 f7             	or     %rsi,%rdi
    8e94:	40 88 78 20          	mov    %dil,0x20(%rax)
    8e98:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
    8e9f:	48 89 70 18          	mov    %rsi,0x18(%rax)
    8ea3:	48 8b bd 40 fd ff ff 	mov    -0x2c0(%rbp),%rdi
    8eaa:	48 39 d7             	cmp    %rdx,%rdi
    8ead:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    8eb3:	41 0f 95 c0          	setne  %r8b
    8eb7:	44 0f b6 48 20       	movzbl 0x20(%rax),%r9d
    8ebc:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    8ec2:	4d 85 c0             	test   %r8,%r8
    8ec5:	4c 0f 44 d2          	cmove  %rdx,%r10
    8ec9:	4d 09 d1             	or     %r10,%r9
    8ecc:	44 88 48 20          	mov    %r9b,0x20(%rax)
    8ed0:	e9 8e 00 00 00       	jmp    0x8f63
    8ed5:	48 8b 85 08 fd ff ff 	mov    -0x2f8(%rbp),%rax
    8edc:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8ee0:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
    8ee7:	48 01 d1             	add    %rdx,%rcx
    8eea:	48 89 48 10          	mov    %rcx,0x10(%rax)
    8eee:	31 f6                	xor    %esi,%esi
    8ef0:	48 39 f1             	cmp    %rsi,%rcx
    8ef3:	b9 00 00 00 00       	mov    $0x0,%ecx
    8ef8:	0f 95 c1             	setne  %cl
    8efb:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    8eff:	48 09 cf             	or     %rcx,%rdi
    8f02:	40 88 78 20          	mov    %dil,0x20(%rax)
    8f06:	48 8b 48 18          	mov    0x18(%rax),%rcx
    8f0a:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    8f0e:	48 83 e7 02          	and    $0x2,%rdi
    8f12:	48 39 f7             	cmp    %rsi,%rdi
    8f15:	bf 00 00 00 00       	mov    $0x0,%edi
    8f1a:	40 0f 95 c7          	setne  %dil
    8f1e:	45 31 c0             	xor    %r8d,%r8d
    8f21:	48 85 ff             	test   %rdi,%rdi
    8f24:	49 0f 44 c8          	cmove  %r8,%rcx
    8f28:	4c 8b 85 40 fd ff ff 	mov    -0x2c0(%rbp),%r8
    8f2f:	4c 01 c7             	add    %r8,%rdi
    8f32:	4c 8b 8d 48 fd ff ff 	mov    -0x2b8(%rbp),%r9
    8f39:	4c 01 c9             	add    %r9,%rcx
    8f3c:	48 89 48 18          	mov    %rcx,0x18(%rax)
    8f40:	48 39 f7             	cmp    %rsi,%rdi
    8f43:	bf 00 00 00 00       	mov    $0x0,%edi
    8f48:	40 0f 95 c7          	setne  %dil
    8f4c:	0f b6 48 20          	movzbl 0x20(%rax),%ecx
    8f50:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    8f56:	48 85 ff             	test   %rdi,%rdi
    8f59:	4c 0f 44 d6          	cmove  %rsi,%r10
    8f5d:	4c 09 d1             	or     %r10,%rcx
    8f60:	88 48 20             	mov    %cl,0x20(%rax)
    8f63:	b8 01 00 00 00       	mov    $0x1,%eax
    8f68:	48 8b 8d b8 fd ff ff 	mov    -0x248(%rbp),%rcx
    8f6f:	48 89 ca             	mov    %rcx,%rdx
    8f72:	48 31 c2             	xor    %rax,%rdx
    8f75:	31 c0                	xor    %eax,%eax
    8f77:	48 8b b5 70 fd ff ff 	mov    -0x290(%rbp),%rsi
    8f7e:	48 89 f7             	mov    %rsi,%rdi
    8f81:	48 85 d2             	test   %rdx,%rdx
    8f84:	48 0f 44 f8          	cmove  %rax,%rdi
    8f88:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    8f8f:	79 37 9e 
    8f92:	49 b8 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%r8
    8f99:	79 37 9e 
    8f9c:	4c 8b 8d 18 fd ff ff 	mov    -0x2e8(%rbp),%r9
    8fa3:	4d 31 c8             	xor    %r9,%r8
    8fa6:	4c 0f af c0          	imul   %rax,%r8
    8faa:	4d 89 c2             	mov    %r8,%r10
    8fad:	49 c1 ea 1d          	shr    $0x1d,%r10
    8fb1:	4d 31 d0             	xor    %r10,%r8
    8fb4:	4c 8b 95 28 fd ff ff 	mov    -0x2d8(%rbp),%r10
    8fbb:	4d 31 d0             	xor    %r10,%r8
    8fbe:	4c 0f af c0          	imul   %rax,%r8
    8fc2:	4d 89 c3             	mov    %r8,%r11
    8fc5:	49 c1 eb 1d          	shr    $0x1d,%r11
    8fc9:	4d 31 d8             	xor    %r11,%r8
    8fcc:	4c 0f af c0          	imul   %rax,%r8
    8fd0:	4c 89 8d d0 fd ff ff 	mov    %r9,-0x230(%rbp)
    8fd7:	4c 89 95 a0 fd ff ff 	mov    %r10,-0x260(%rbp)
    8fde:	4c 89 85 98 fd ff ff 	mov    %r8,-0x268(%rbp)
    8fe5:	b8 01 00 00 00       	mov    $0x1,%eax
    8fea:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
    8ff1:	48 89 bd 80 fd ff ff 	mov    %rdi,-0x280(%rbp)
    8ff8:	48 89 95 c0 fd ff ff 	mov    %rdx,-0x240(%rbp)
    8fff:	48 8b 85 20 fd ff ff 	mov    -0x2e0(%rbp),%rax
    9006:	48 89 85 c8 fd ff ff 	mov    %rax,-0x238(%rbp)
    900d:	b8 01 00 00 00       	mov    $0x1,%eax
    9012:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
    9019:	31 c0                	xor    %eax,%eax
    901b:	48 89 43 18          	mov    %rax,0x18(%rbx)
    901f:	48 8b 85 00 fe ff ff 	mov    -0x200(%rbp),%rax
    9026:	b9 01 00 00 00       	mov    $0x1,%ecx
    902b:	48 89 c2             	mov    %rax,%rdx
    902e:	48 01 ca             	add    %rcx,%rdx
    9031:	48 89 95 00 fe ff ff 	mov    %rdx,-0x200(%rbp)
    9038:	e9 f0 f2 ff ff       	jmp    0x832d
    903d:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    9041:	e8 fa 6f ff ff       	call   0x40
    9046:	48 85 c0             	test   %rax,%rax
    9049:	0f 84 f4 f9 ff ff    	je     0x8a43
    904f:	e9 ef 13 00 00       	jmp    0xa443
    9054:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
    905b:	48 85 c0             	test   %rax,%rax
    905e:	0f 84 f8 03 00 00    	je     0x945c
    9064:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    906b:	48 8b 48 68          	mov    0x68(%rax),%rcx
    906f:	48 85 c9             	test   %rcx,%rcx
    9072:	0f 84 44 01 00 00    	je     0x91bc
    9078:	48 8b 48 38          	mov    0x38(%rax),%rcx
    907c:	ba 40 00 00 00       	mov    $0x40,%edx
    9081:	48 29 ca             	sub    %rcx,%rdx
    9084:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
    908b:	48 8b b5 98 fd ff ff 	mov    -0x268(%rbp),%rsi
    9092:	48 89 d1             	mov    %rdx,%rcx
    9095:	48 89 f7             	mov    %rsi,%rdi
    9098:	48 d3 ef             	shr    %cl,%rdi
    909b:	31 c9                	xor    %ecx,%ecx
    909d:	48 8b 95 a8 fd ff ff 	mov    -0x258(%rbp),%rdx
    90a4:	48 39 ca             	cmp    %rcx,%rdx
    90a7:	ba 00 00 00 00       	mov    $0x0,%edx
    90ac:	0f 94 c2             	sete   %dl
    90af:	48 85 d2             	test   %rdx,%rdx
    90b2:	48 0f 44 cf          	cmove  %rdi,%rcx
    90b6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    90ba:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    90be:	48 8b 17             	mov    (%rdi),%rdx
    90c1:	49 b8 00 00 00 00 00 	movabs $0x28000000000000,%r8
    90c8:	00 28 00 
    90cb:	4c 39 c2             	cmp    %r8,%rdx
    90ce:	48 89 bd a8 fd ff ff 	mov    %rdi,-0x258(%rbp)
    90d5:	0f 82 0c 00 00 00    	jb     0x90e7
    90db:	48 89 95 08 fe ff ff 	mov    %rdx,-0x1f8(%rbp)
    90e2:	e9 47 00 00 00       	jmp    0x912e
    90e7:	48 8b 50 60          	mov    0x60(%rax),%rdx
    90eb:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    90ef:	48 89 c6             	mov    %rax,%rsi
    90f2:	48 89 95 18 fe ff ff 	mov    %rdx,-0x1e8(%rbp)
    90f9:	48 89 ca             	mov    %rcx,%rdx
    90fc:	48 8b 8d 18 fe ff ff 	mov    -0x1e8(%rbp),%rcx
    9103:	e8 d8 6f ff ff       	call   0xe0
    9108:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    910f:	31 d2                	xor    %edx,%edx
    9111:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    9115:	48 83 f8 00          	cmp    $0x0,%rax
    9119:	0f 8f 08 00 00 00    	jg     0x9127
    911f:	49 89 c4             	mov    %rax,%r12
    9122:	e9 23 13 00 00       	jmp    0xa44a
    9127:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
    912e:	48 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%rax
    9135:	48 89 c1             	mov    %rax,%rcx
    9138:	48 83 c1 28          	add    $0x28,%rcx
    913c:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    9143:	00 28 00 
    9146:	48 29 d1             	sub    %rdx,%rcx
    9149:	48 8b 95 a8 fd ff ff 	mov    -0x258(%rbp),%rdx
    9150:	48 89 0a             	mov    %rcx,(%rdx)
    9153:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    915a:	ff 00 00 
    915d:	48 21 c8             	and    %rcx,%rax
    9160:	31 c9                	xor    %ecx,%ecx
    9162:	48 8b 95 d0 fd ff ff 	mov    -0x230(%rbp),%rdx
    9169:	48 89 10             	mov    %rdx,(%rax)
    916c:	48 8b b5 a0 fd ff ff 	mov    -0x260(%rbp),%rsi
    9173:	48 89 70 08          	mov    %rsi,0x8(%rax)
    9177:	48 89 48 10          	mov    %rcx,0x10(%rax)
    917b:	48 89 48 18          	mov    %rcx,0x18(%rax)
    917f:	48 89 48 20          	mov    %rcx,0x20(%rax)
    9183:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    918a:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    918e:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    9194:	4c 01 c7             	add    %r8,%rdi
    9197:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    919b:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
    91a2:	b8 01 00 00 00       	mov    $0x1,%eax
    91a7:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
    91ae:	31 c0                	xor    %eax,%eax
    91b0:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
    91b7:	e9 9c 01 00 00       	jmp    0x9358
    91bc:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    91c3:	48 8b 48 10          	mov    0x10(%rax),%rcx
    91c7:	48 8b 50 18          	mov    0x18(%rax),%rdx
    91cb:	48 89 d6             	mov    %rdx,%rsi
    91ce:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    91d3:	bf 40 00 00 00       	mov    $0x40,%edi
    91d8:	48 29 f7             	sub    %rsi,%rdi
    91db:	48 89 8d 10 fe ff ff 	mov    %rcx,-0x1f0(%rbp)
    91e2:	4c 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%r8
    91e9:	48 89 f9             	mov    %rdi,%rcx
    91ec:	49 d3 e8             	shr    %cl,%r8
    91ef:	31 c9                	xor    %ecx,%ecx
    91f1:	48 39 ce             	cmp    %rcx,%rsi
    91f4:	be 00 00 00 00       	mov    $0x0,%esi
    91f9:	40 0f 94 c6          	sete   %sil
    91fd:	48 85 f6             	test   %rsi,%rsi
    9200:	49 0f 44 c8          	cmove  %r8,%rcx
    9204:	be 01 00 00 00       	mov    $0x1,%esi
    9209:	48 89 cf             	mov    %rcx,%rdi
    920c:	48 01 f7             	add    %rsi,%rdi
    920f:	48 21 d7             	and    %rdx,%rdi
    9212:	ba 28 00 00 00       	mov    $0x28,%edx
    9217:	48 0f af ca          	imul   %rdx,%rcx
    921b:	48 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%rdx
    9222:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
    9226:	49 8b 48 10          	mov    0x10(%r8),%rcx
    922a:	48 85 c9             	test   %rcx,%rcx
    922d:	0f 84 af 00 00 00    	je     0x92e2
    9233:	49 8b 08             	mov    (%r8),%rcx
    9236:	4d 8b 48 08          	mov    0x8(%r8),%r9
    923a:	4c 8b 95 d0 fd ff ff 	mov    -0x230(%rbp),%r10
    9241:	49 39 ca             	cmp    %rcx,%r10
    9244:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    924a:	41 0f 94 c3          	sete   %r11b
    924e:	48 8b 8d a0 fd ff ff 	mov    -0x260(%rbp),%rcx
    9255:	4c 39 c9             	cmp    %r9,%rcx
    9258:	ba 00 00 00 00       	mov    $0x0,%edx
    925d:	0f 94 c2             	sete   %dl
    9260:	49 21 d3             	and    %rdx,%r11
    9263:	4d 85 db             	test   %r11,%r11
    9266:	0f 84 0c 00 00 00    	je     0x9278
    926c:	4c 89 85 08 fe ff ff 	mov    %r8,-0x1f8(%rbp)
    9273:	e9 53 00 00 00       	jmp    0x92cb
    9278:	ba 28 00 00 00       	mov    $0x28,%edx
    927d:	48 0f af fa          	imul   %rdx,%rdi
    9281:	48 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%rdx
    9288:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    928c:	49 8b 50 10          	mov    0x10(%r8),%rdx
    9290:	48 85 d2             	test   %rdx,%rdx
    9293:	0f 84 49 00 00 00    	je     0x92e2
    9299:	49 8b 10             	mov    (%r8),%rdx
    929c:	49 8b 78 08          	mov    0x8(%r8),%rdi
    92a0:	49 39 d2             	cmp    %rdx,%r10
    92a3:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    92a9:	41 0f 94 c1          	sete   %r9b
    92ad:	48 39 f9             	cmp    %rdi,%rcx
    92b0:	ba 00 00 00 00       	mov    $0x0,%edx
    92b5:	0f 94 c2             	sete   %dl
    92b8:	49 21 d1             	and    %rdx,%r9
    92bb:	4d 85 c9             	test   %r9,%r9
    92be:	0f 84 1e 00 00 00    	je     0x92e2
    92c4:	4c 89 85 08 fe ff ff 	mov    %r8,-0x1f8(%rbp)
    92cb:	31 c0                	xor    %eax,%eax
    92cd:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
    92d4:	31 c0                	xor    %eax,%eax
    92d6:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
    92dd:	e9 76 00 00 00       	jmp    0x9358
    92e2:	48 8d 85 b0 fe ff ff 	lea    -0x150(%rbp),%rax
    92e9:	48 89 c1             	mov    %rax,%rcx
    92ec:	48 8b 95 d0 fd ff ff 	mov    -0x230(%rbp),%rdx
    92f3:	48 89 11             	mov    %rdx,(%rcx)
    92f6:	48 8b 95 a0 fd ff ff 	mov    -0x260(%rbp),%rdx
    92fd:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    9301:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    9305:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
    930c:	48 89 ca             	mov    %rcx,%rdx
    930f:	e8 dc 6d ff ff       	call   0xf0
    9314:	48 83 f8 00          	cmp    $0x0,%rax
    9318:	0f 8d 08 00 00 00    	jge    0x9326
    931e:	49 89 c4             	mov    %rax,%r12
    9321:	e9 24 11 00 00       	jmp    0xa44a
    9326:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    932d:	48 8b 11             	mov    (%rcx),%rdx
    9330:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    9334:	48 83 e6 01          	and    $0x1,%rsi
    9338:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    933c:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
    9343:	b8 01 00 00 00       	mov    $0x1,%eax
    9348:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
    934f:	31 c0                	xor    %eax,%eax
    9351:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
    9358:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
    935f:	48 85 c0             	test   %rax,%rax
    9362:	0f 84 68 00 00 00    	je     0x93d0
    9368:	48 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%rax
    936f:	48 8b 8d b0 fd ff ff 	mov    -0x250(%rbp),%rcx
    9376:	48 89 48 10          	mov    %rcx,0x10(%rax)
    937a:	31 d2                	xor    %edx,%edx
    937c:	48 39 d1             	cmp    %rdx,%rcx
    937f:	be 00 00 00 00       	mov    $0x0,%esi
    9384:	40 0f 95 c6          	setne  %sil
    9388:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    938c:	48 09 f7             	or     %rsi,%rdi
    938f:	40 88 78 20          	mov    %dil,0x20(%rax)
    9393:	48 8b b5 80 fd ff ff 	mov    -0x280(%rbp),%rsi
    939a:	48 89 70 18          	mov    %rsi,0x18(%rax)
    939e:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
    93a5:	48 39 d7             	cmp    %rdx,%rdi
    93a8:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    93ae:	41 0f 95 c0          	setne  %r8b
    93b2:	44 0f b6 48 20       	movzbl 0x20(%rax),%r9d
    93b7:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    93bd:	4d 85 c0             	test   %r8,%r8
    93c0:	4c 0f 44 d2          	cmove  %rdx,%r10
    93c4:	4d 09 d1             	or     %r10,%r9
    93c7:	44 88 48 20          	mov    %r9b,0x20(%rax)
    93cb:	e9 8c 00 00 00       	jmp    0x945c
    93d0:	48 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%rax
    93d7:	48 8b 48 10          	mov    0x10(%rax),%rcx
    93db:	48 8b 95 b0 fd ff ff 	mov    -0x250(%rbp),%rdx
    93e2:	48 01 d1             	add    %rdx,%rcx
    93e5:	48 89 48 10          	mov    %rcx,0x10(%rax)
    93e9:	31 d2                	xor    %edx,%edx
    93eb:	48 39 d1             	cmp    %rdx,%rcx
    93ee:	b9 00 00 00 00       	mov    $0x0,%ecx
    93f3:	0f 95 c1             	setne  %cl
    93f6:	0f b6 70 20          	movzbl 0x20(%rax),%esi
    93fa:	48 09 ce             	or     %rcx,%rsi
    93fd:	40 88 70 20          	mov    %sil,0x20(%rax)
    9401:	48 8b 48 18          	mov    0x18(%rax),%rcx
    9405:	0f b6 70 20          	movzbl 0x20(%rax),%esi
    9409:	48 83 e6 02          	and    $0x2,%rsi
    940d:	48 39 d6             	cmp    %rdx,%rsi
    9410:	be 00 00 00 00       	mov    $0x0,%esi
    9415:	40 0f 95 c6          	setne  %sil
    9419:	31 ff                	xor    %edi,%edi
    941b:	48 85 f6             	test   %rsi,%rsi
    941e:	48 0f 44 cf          	cmove  %rdi,%rcx
    9422:	48 8b bd c0 fd ff ff 	mov    -0x240(%rbp),%rdi
    9429:	48 01 fe             	add    %rdi,%rsi
    942c:	48 8b bd 80 fd ff ff 	mov    -0x280(%rbp),%rdi
    9433:	48 01 f9             	add    %rdi,%rcx
    9436:	48 89 48 18          	mov    %rcx,0x18(%rax)
    943a:	48 39 d6             	cmp    %rdx,%rsi
    943d:	be 00 00 00 00       	mov    $0x0,%esi
    9442:	40 0f 95 c6          	setne  %sil
    9446:	0f b6 48 20          	movzbl 0x20(%rax),%ecx
    944a:	bf 02 00 00 00       	mov    $0x2,%edi
    944f:	48 85 f6             	test   %rsi,%rsi
    9452:	48 0f 44 fa          	cmove  %rdx,%rdi
    9456:	48 09 f9             	or     %rdi,%rcx
    9459:	88 48 20             	mov    %cl,0x20(%rax)
    945c:	48 8b 85 c8 fd ff ff 	mov    -0x238(%rbp),%rax
    9463:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
    946a:	e9 28 0f 00 00       	jmp    0xa397
    946f:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
    9476:	82 28 52 
    9479:	31 c9                	xor    %ecx,%ecx
    947b:	48 8b 95 f8 fd ff ff 	mov    -0x208(%rbp),%rdx
    9482:	48 89 95 c8 fd ff ff 	mov    %rdx,-0x238(%rbp)
    9489:	31 d2                	xor    %edx,%edx
    948b:	48 89 95 f8 fd ff ff 	mov    %rdx,-0x208(%rbp)
    9492:	31 d2                	xor    %edx,%edx
    9494:	48 89 95 08 fe ff ff 	mov    %rdx,-0x1f8(%rbp)
    949b:	48 89 85 80 fd ff ff 	mov    %rax,-0x280(%rbp)
    94a2:	31 d2                	xor    %edx,%edx
    94a4:	48 89 95 c0 fd ff ff 	mov    %rdx,-0x240(%rbp)
    94ab:	31 d2                	xor    %edx,%edx
    94ad:	48 89 95 b0 fd ff ff 	mov    %rdx,-0x250(%rbp)
    94b4:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
    94bb:	31 d2                	xor    %edx,%edx
    94bd:	48 89 95 18 fe ff ff 	mov    %rdx,-0x1e8(%rbp)
    94c4:	31 d2                	xor    %edx,%edx
    94c6:	48 89 95 a0 fd ff ff 	mov    %rdx,-0x260(%rbp)
    94cd:	48 8b 85 c8 fd ff ff 	mov    -0x238(%rbp),%rax
    94d4:	48 8b 8d e8 fd ff ff 	mov    -0x218(%rbp),%rcx
    94db:	48 39 c8             	cmp    %rcx,%rax
    94de:	0f 8d df 0a 00 00    	jge    0x9fc3
    94e4:	48 8b 95 e0 fd ff ff 	mov    -0x220(%rbp),%rdx
    94eb:	48 8d 34 c2          	lea    (%rdx,%rax,8),%rsi
    94ef:	48 8b 3e             	mov    (%rsi),%rdi
    94f2:	48 8b b5 f0 fd ff ff 	mov    -0x210(%rbp),%rsi
    94f9:	49 89 f0             	mov    %rsi,%r8
    94fc:	49 01 f8             	add    %rdi,%r8
    94ff:	49 8b 78 10          	mov    0x10(%r8),%rdi
    9503:	4d 8b 48 08          	mov    0x8(%r8),%r9
    9507:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    950d:	4d 89 cb             	mov    %r9,%r11
    9510:	4d 21 d3             	and    %r10,%r11
    9513:	49 8b 50 18          	mov    0x18(%r8),%rdx
    9517:	49 d1 e9             	shr    $1,%r9
    951a:	4d 21 d1             	and    %r10,%r9
    951d:	45 31 c0             	xor    %r8d,%r8d
    9520:	4d 39 c1             	cmp    %r8,%r9
    9523:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    9529:	41 0f 95 c1          	setne  %r9b
    952d:	4d 85 db             	test   %r11,%r11
    9530:	48 89 95 d0 fd ff ff 	mov    %rdx,-0x230(%rbp)
    9537:	4c 89 8d 10 fe ff ff 	mov    %r9,-0x1f0(%rbp)
    953e:	0f 85 4a 0a 00 00    	jne    0x9f8e
    9544:	48 63 ff             	movslq %edi,%rdi
    9547:	49 89 fb             	mov    %rdi,%r11
    954a:	49 83 fe 05          	cmp    $0x5,%r14
    954e:	0f 85 ab 00 00 00    	jne    0x95ff
    9554:	48 8b bd 38 fe ff ff 	mov    -0x1c8(%rbp),%rdi
    955b:	4c 89 de             	mov    %r11,%rsi
    955e:	48 29 fe             	sub    %rdi,%rsi
    9561:	48 8b bd 30 fe ff ff 	mov    -0x1d0(%rbp),%rdi
    9568:	48 39 fe             	cmp    %rdi,%rsi
    956b:	b8 00 00 00 00       	mov    $0x0,%eax
    9570:	0f 92 c0             	setb   %al
    9573:	48 85 c0             	test   %rax,%rax
    9576:	49 0f 44 f0          	cmove  %r8,%rsi
    957a:	48 89 f7             	mov    %rsi,%rdi
    957d:	48 c1 ef 06          	shr    $0x6,%rdi
    9581:	48 83 e6 3f          	and    $0x3f,%rsi
    9585:	49 8d 14 ff          	lea    (%r15,%rdi,8),%rdx
    9589:	4c 8b 0a             	mov    (%rdx),%r9
    958c:	48 89 f1             	mov    %rsi,%rcx
    958f:	49 d3 e9             	shr    %cl,%r9
    9592:	4d 21 d1             	and    %r10,%r9
    9595:	49 21 c1             	and    %rax,%r9
    9598:	48 8b 85 28 fe ff ff 	mov    -0x1d8(%rbp),%rax
    959f:	48 8d 0c f8          	lea    (%rax,%rdi,8),%rcx
    95a3:	48 8b 11             	mov    (%rcx),%rdx
    95a6:	48 89 f1             	mov    %rsi,%rcx
    95a9:	48 d3 ea             	shr    %cl,%rdx
    95ac:	4c 21 d2             	and    %r10,%rdx
    95af:	48 8b 8d 48 fe ff ff 	mov    -0x1b8(%rbp),%rcx
    95b6:	48 8d 04 f9          	lea    (%rcx,%rdi,8),%rax
    95ba:	48 8b 38             	mov    (%rax),%rdi
    95bd:	48 89 f1             	mov    %rsi,%rcx
    95c0:	48 d3 ef             	shr    %cl,%rdi
    95c3:	4c 21 d7             	and    %r10,%rdi
    95c6:	48 8d 85 90 fe ff ff 	lea    -0x170(%rbp),%rax
    95cd:	48 89 c1             	mov    %rax,%rcx
    95d0:	48 c1 e7 20          	shl    $0x20,%rdi
    95d4:	4c 89 19             	mov    %r11,(%rcx)
    95d7:	48 89 79 08          	mov    %rdi,0x8(%rcx)
    95db:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    95df:	4d 39 c1             	cmp    %r8,%r9
    95e2:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    95e8:	41 0f 95 c1          	setne  %r9b
    95ec:	4d 85 c9             	test   %r9,%r9
    95ef:	49 0f 44 c8          	cmove  %r8,%rcx
    95f3:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
    95fa:	e9 ea 01 00 00       	jmp    0x97e9
    95ff:	49 83 fe 01          	cmp    $0x1,%r14
    9603:	0f 85 ef 00 00 00    	jne    0x96f8
    9609:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    9610:	79 37 9e 
    9613:	4c 89 d9             	mov    %r11,%rcx
    9616:	48 c1 e9 2b          	shr    $0x2b,%rcx
    961a:	4c 89 da             	mov    %r11,%rdx
    961d:	48 c1 ea 2c          	shr    $0x2c,%rdx
    9621:	48 31 d1             	xor    %rdx,%rcx
    9624:	4c 89 da             	mov    %r11,%rdx
    9627:	48 31 ca             	xor    %rcx,%rdx
    962a:	48 0f af d0          	imul   %rax,%rdx
    962e:	b8 40 00 00 00       	mov    $0x40,%eax
    9633:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
    963a:	48 29 c8             	sub    %rcx,%rax
    963d:	48 89 c1             	mov    %rax,%rcx
    9640:	48 89 d6             	mov    %rdx,%rsi
    9643:	48 d3 ee             	shr    %cl,%rsi
    9646:	31 c0                	xor    %eax,%eax
    9648:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
    964f:	48 39 c1             	cmp    %rax,%rcx
    9652:	bf 00 00 00 00       	mov    $0x0,%edi
    9657:	40 0f 94 c7          	sete   %dil
    965b:	48 85 ff             	test   %rdi,%rdi
    965e:	48 0f 44 c6          	cmove  %rsi,%rax
    9662:	49 8d 34 c7          	lea    (%r15,%rax,8),%rsi
    9666:	48 8b 06             	mov    (%rsi),%rax
    9669:	48 be ff ff ff ff ff 	movabs $0xffffffffffff,%rsi
    9670:	ff 00 00 
    9673:	48 89 c7             	mov    %rax,%rdi
    9676:	48 21 f7             	and    %rsi,%rdi
    9679:	31 f6                	xor    %esi,%esi
    967b:	48 39 f7             	cmp    %rsi,%rdi
    967e:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    9684:	41 0f 94 c0          	sete   %r8b
    9688:	49 89 d1             	mov    %rdx,%r9
    968b:	49 c1 e9 20          	shr    $0x20,%r9
    968f:	4c 31 ca             	xor    %r9,%rdx
    9692:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    9698:	4c 21 ca             	and    %r9,%rdx
    969b:	48 83 e2 0f          	and    $0xf,%rdx
    969f:	48 83 c2 30          	add    $0x30,%rdx
    96a3:	48 89 d1             	mov    %rdx,%rcx
    96a6:	48 d3 e8             	shr    %cl,%rax
    96a9:	48 83 e0 01          	and    $0x1,%rax
    96ad:	48 83 f8 00          	cmp    $0x0,%rax
    96b1:	b8 00 00 00 00       	mov    $0x0,%eax
    96b6:	0f 95 c0             	setne  %al
    96b9:	b9 01 00 00 00       	mov    $0x1,%ecx
    96be:	48 31 c8             	xor    %rcx,%rax
    96c1:	49 09 c0             	or     %rax,%r8
    96c4:	b8 01 00 00 00       	mov    $0x1,%eax
    96c9:	48 29 c7             	sub    %rax,%rdi
    96cc:	b9 18 00 00 00       	mov    $0x18,%ecx
    96d1:	48 0f af f9          	imul   %rcx,%rdi
    96d5:	48 8b 8d 20 fe ff ff 	mov    -0x1e0(%rbp),%rcx
    96dc:	48 89 ca             	mov    %rcx,%rdx
    96df:	48 01 fa             	add    %rdi,%rdx
    96e2:	48 89 f7             	mov    %rsi,%rdi
    96e5:	4d 85 c0             	test   %r8,%r8
    96e8:	48 0f 44 fa          	cmove  %rdx,%rdi
    96ec:	48 89 bd 98 fd ff ff 	mov    %rdi,-0x268(%rbp)
    96f3:	e9 f1 00 00 00       	jmp    0x97e9
    96f8:	48 8b 85 38 fe ff ff 	mov    -0x1c8(%rbp),%rax
    96ff:	4c 89 d9             	mov    %r11,%rcx
    9702:	48 29 c1             	sub    %rax,%rcx
    9705:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
    970c:	48 39 d1             	cmp    %rdx,%rcx
    970f:	0f 82 0e 00 00 00    	jb     0x9723
    9715:	31 f6                	xor    %esi,%esi
    9717:	48 89 b5 98 fd ff ff 	mov    %rsi,-0x268(%rbp)
    971e:	e9 c6 00 00 00       	jmp    0x97e9
    9723:	49 83 fe 02          	cmp    $0x2,%r14
    9727:	48 89 8d 78 fd ff ff 	mov    %rcx,-0x288(%rbp)
    972e:	0f 85 69 00 00 00    	jne    0x979d
    9734:	48 89 ce             	mov    %rcx,%rsi
    9737:	48 c1 ee 06          	shr    $0x6,%rsi
    973b:	49 8d 3c f7          	lea    (%r15,%rsi,8),%rdi
    973f:	48 8b 37             	mov    (%rdi),%rsi
    9742:	48 89 cf             	mov    %rcx,%rdi
    9745:	48 83 e7 3f          	and    $0x3f,%rdi
    9749:	48 89 f9             	mov    %rdi,%rcx
    974c:	48 d3 ee             	shr    %cl,%rsi
    974f:	b9 01 00 00 00       	mov    $0x1,%ecx
    9754:	48 21 ce             	and    %rcx,%rsi
    9757:	31 ff                	xor    %edi,%edi
    9759:	48 39 fe             	cmp    %rdi,%rsi
    975c:	be 00 00 00 00       	mov    $0x0,%esi
    9761:	40 0f 95 c6          	setne  %sil
    9765:	41 b8 10 00 00 00    	mov    $0x10,%r8d
    976b:	4c 8b 8d 78 fd ff ff 	mov    -0x288(%rbp),%r9
    9772:	4d 89 ca             	mov    %r9,%r10
    9775:	4d 0f af d0          	imul   %r8,%r10
    9779:	4c 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%r8
    9780:	4d 89 c1             	mov    %r8,%r9
    9783:	4d 01 d1             	add    %r10,%r9
    9786:	49 83 e9 08          	sub    $0x8,%r9
    978a:	48 85 f6             	test   %rsi,%rsi
    978d:	4c 0f 44 cf          	cmove  %rdi,%r9
    9791:	4c 89 8d 98 fd ff ff 	mov    %r9,-0x268(%rbp)
    9798:	e9 4c 00 00 00       	jmp    0x97e9
    979d:	48 8b 85 78 fd ff ff 	mov    -0x288(%rbp),%rax
    97a4:	49 8d 0c 87          	lea    (%r15,%rax,4),%rcx
    97a8:	8b 01                	mov    (%rcx),%eax
    97aa:	b9 01 00 00 00       	mov    $0x1,%ecx
    97af:	48 89 c2             	mov    %rax,%rdx
    97b2:	48 29 ca             	sub    %rcx,%rdx
    97b5:	be 18 00 00 00       	mov    $0x18,%esi
    97ba:	48 0f af d6          	imul   %rsi,%rdx
    97be:	48 8b b5 20 fe ff ff 	mov    -0x1e0(%rbp),%rsi
    97c5:	48 89 f7             	mov    %rsi,%rdi
    97c8:	48 01 d7             	add    %rdx,%rdi
    97cb:	31 d2                	xor    %edx,%edx
    97cd:	48 39 d0             	cmp    %rdx,%rax
    97d0:	b8 00 00 00 00       	mov    $0x0,%eax
    97d5:	0f 94 c0             	sete   %al
    97d8:	49 89 d0             	mov    %rdx,%r8
    97db:	48 85 c0             	test   %rax,%rax
    97de:	4c 0f 44 c7          	cmove  %rdi,%r8
    97e2:	4c 89 85 98 fd ff ff 	mov    %r8,-0x268(%rbp)
    97e9:	49 83 fe 01          	cmp    $0x1,%r14
    97ed:	be 00 00 00 00       	mov    $0x0,%esi
    97f2:	40 0f 95 c6          	setne  %sil
    97f6:	31 ff                	xor    %edi,%edi
    97f8:	48 8b 85 a0 fd ff ff 	mov    -0x260(%rbp),%rax
    97ff:	48 89 85 78 fd ff ff 	mov    %rax,-0x288(%rbp)
    9806:	48 8b 85 f8 fd ff ff 	mov    -0x208(%rbp),%rax
    980d:	48 89 85 38 fd ff ff 	mov    %rax,-0x2c8(%rbp)
    9814:	48 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%rax
    981b:	48 89 85 30 fd ff ff 	mov    %rax,-0x2d0(%rbp)
    9822:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
    9829:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
    9830:	48 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%rax
    9837:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
    983e:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
    9845:	48 89 85 68 fd ff ff 	mov    %rax,-0x298(%rbp)
    984c:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
    9853:	48 89 85 88 fd ff ff 	mov    %rax,-0x278(%rbp)
    985a:	48 8b 85 18 fe ff ff 	mov    -0x1e8(%rbp),%rax
    9861:	48 89 85 60 fd ff ff 	mov    %rax,-0x2a0(%rbp)
    9868:	48 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%rax
    986f:	48 85 c0             	test   %rax,%rax
    9872:	0f 85 75 00 00 00    	jne    0x98ed
    9878:	48 8b 8d 78 fd ff ff 	mov    -0x288(%rbp),%rcx
    987f:	48 89 8d a0 fd ff ff 	mov    %rcx,-0x260(%rbp)
    9886:	48 8b 8d 38 fd ff ff 	mov    -0x2c8(%rbp),%rcx
    988d:	48 89 8d f8 fd ff ff 	mov    %rcx,-0x208(%rbp)
    9894:	48 8b 8d 30 fd ff ff 	mov    -0x2d0(%rbp),%rcx
    989b:	48 89 8d 08 fe ff ff 	mov    %rcx,-0x1f8(%rbp)
    98a2:	48 8b 8d 90 fd ff ff 	mov    -0x270(%rbp),%rcx
    98a9:	48 89 8d 80 fd ff ff 	mov    %rcx,-0x280(%rbp)
    98b0:	48 8b 8d 58 fd ff ff 	mov    -0x2a8(%rbp),%rcx
    98b7:	48 89 8d c0 fd ff ff 	mov    %rcx,-0x240(%rbp)
    98be:	48 8b 8d 68 fd ff ff 	mov    -0x298(%rbp),%rcx
    98c5:	48 89 8d b0 fd ff ff 	mov    %rcx,-0x250(%rbp)
    98cc:	48 8b 8d 88 fd ff ff 	mov    -0x278(%rbp),%rcx
    98d3:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
    98da:	48 8b 8d 60 fd ff ff 	mov    -0x2a0(%rbp),%rcx
    98e1:	48 89 8d 18 fe ff ff 	mov    %rcx,-0x1e8(%rbp)
    98e8:	e9 9b 06 00 00       	jmp    0x9f88
    98ed:	48 8b 48 08          	mov    0x8(%rax),%rcx
    98f1:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    98f6:	49 89 c8             	mov    %rcx,%r8
    98f9:	49 21 d0             	and    %rdx,%r8
    98fc:	ba 01 00 00 00       	mov    $0x1,%edx
    9901:	4d 89 c1             	mov    %r8,%r9
    9904:	49 29 d1             	sub    %rdx,%r9
    9907:	41 ba 18 00 00 00    	mov    $0x18,%r10d
    990d:	4d 0f af ca          	imul   %r10,%r9
    9911:	4c 8b 95 20 fe ff ff 	mov    -0x1e0(%rbp),%r10
    9918:	4c 89 d0             	mov    %r10,%rax
    991b:	4c 01 c8             	add    %r9,%rax
    991e:	45 31 c9             	xor    %r9d,%r9d
    9921:	4d 39 c8             	cmp    %r9,%r8
    9924:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    992a:	41 0f 94 c0          	sete   %r8b
    992e:	4d 89 ca             	mov    %r9,%r10
    9931:	4d 85 c0             	test   %r8,%r8
    9934:	4c 0f 44 d0          	cmove  %rax,%r10
    9938:	48 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%rax
    993f:	4c 8b 00             	mov    (%rax),%r8
    9942:	4d 39 c3             	cmp    %r8,%r11
    9945:	b8 00 00 00 00       	mov    $0x0,%eax
    994a:	0f 94 c0             	sete   %al
    994d:	48 09 f0             	or     %rsi,%rax
    9950:	49 89 f8             	mov    %rdi,%r8
    9953:	49 01 d0             	add    %rdx,%r8
    9956:	48 85 c0             	test   %rax,%rax
    9959:	0f 85 0c 00 00 00    	jne    0x996b
    995f:	4c 89 95 98 fd ff ff 	mov    %r10,-0x268(%rbp)
    9966:	e9 fd fe ff ff       	jmp    0x9868
    996b:	48 8b 43 18          	mov    0x18(%rbx),%rax
    996f:	48 39 c7             	cmp    %rax,%rdi
    9972:	0f 8d 0f 00 00 00    	jge    0x9987
    9978:	4c 89 95 98 fd ff ff 	mov    %r10,-0x268(%rbp)
    997f:	4c 89 c7             	mov    %r8,%rdi
    9982:	e9 e1 fe ff ff       	jmp    0x9868
    9987:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
    998b:	48 8b 70 18          	mov    0x18(%rax),%rsi
    998f:	48 85 f6             	test   %rsi,%rsi
    9992:	48 89 8d 50 fd ff ff 	mov    %rcx,-0x2b0(%rbp)
    9999:	4c 89 85 40 fd ff ff 	mov    %r8,-0x2c0(%rbp)
    99a0:	0f 84 0c 00 00 00    	je     0x99b2
    99a6:	0f b6 3e             	movzbl (%rsi),%edi
    99a9:	48 85 ff             	test   %rdi,%rdi
    99ac:	0f 85 fa 05 00 00    	jne    0x9fac
    99b2:	48 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%rax
    99b9:	48 8b 48 10          	mov    0x10(%rax),%rcx
    99bd:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
    99c4:	48 89 d6             	mov    %rdx,%rsi
    99c7:	48 c1 ee 20          	shr    $0x20,%rsi
    99cb:	48 83 e6 01          	and    $0x1,%rsi
    99cf:	48 83 fe 00          	cmp    $0x0,%rsi
    99d3:	be 00 00 00 00       	mov    $0x0,%esi
    99d8:	40 0f 95 c6          	setne  %sil
    99dc:	48 8b bd 40 fd ff ff 	mov    -0x2c0(%rbp),%rdi
    99e3:	48 89 7b 18          	mov    %rdi,0x18(%rbx)
    99e7:	4c 8b 85 78 fd ff ff 	mov    -0x288(%rbp),%r8
    99ee:	4d 89 c1             	mov    %r8,%r9
    99f1:	49 83 c1 01          	add    $0x1,%r9
    99f5:	48 63 c9             	movslq %ecx,%rcx
    99f8:	45 31 d2             	xor    %r10d,%r10d
    99fb:	48 85 f6             	test   %rsi,%rsi
    99fe:	4c 0f 44 d1          	cmove  %rcx,%r10
    9a02:	48 8b 8d 38 fd ff ff 	mov    -0x2c8(%rbp),%rcx
    9a09:	4c 39 d1             	cmp    %r10,%rcx
    9a0c:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    9a12:	41 0f 94 c3          	sete   %r11b
    9a16:	48 8b 85 30 fd ff ff 	mov    -0x2d0(%rbp),%rax
    9a1d:	48 39 f0             	cmp    %rsi,%rax
    9a20:	ba 00 00 00 00       	mov    $0x0,%edx
    9a25:	0f 94 c2             	sete   %dl
    9a28:	49 21 d3             	and    %rdx,%r11
    9a2b:	4d 85 db             	test   %r11,%r11
    9a2e:	48 89 b5 48 fd ff ff 	mov    %rsi,-0x2b8(%rbp)
    9a35:	4c 89 8d b8 fd ff ff 	mov    %r9,-0x248(%rbp)
    9a3c:	4c 89 95 70 fd ff ff 	mov    %r10,-0x290(%rbp)
    9a43:	0f 84 83 00 00 00    	je     0x9acc
    9a49:	48 8b 95 68 fd ff ff 	mov    -0x298(%rbp),%rdx
    9a50:	49 89 d3             	mov    %rdx,%r11
    9a53:	49 83 c3 01          	add    $0x1,%r11
    9a57:	be 01 00 00 00       	mov    $0x1,%esi
    9a5c:	4c 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%r10
    9a63:	4d 89 d1             	mov    %r10,%r9
    9a66:	49 31 f1             	xor    %rsi,%r9
    9a69:	31 f6                	xor    %esi,%esi
    9a6b:	4c 8b 95 d0 fd ff ff 	mov    -0x230(%rbp),%r10
    9a72:	4c 89 d2             	mov    %r10,%rdx
    9a75:	4d 85 c9             	test   %r9,%r9
    9a78:	48 0f 44 d6          	cmove  %rsi,%rdx
    9a7c:	48 8b b5 60 fd ff ff 	mov    -0x2a0(%rbp),%rsi
    9a83:	49 89 f2             	mov    %rsi,%r10
    9a86:	4d 01 ca             	add    %r9,%r10
    9a89:	4c 8b 8d 88 fd ff ff 	mov    -0x278(%rbp),%r9
    9a90:	4c 89 ce             	mov    %r9,%rsi
    9a93:	48 01 d6             	add    %rdx,%rsi
    9a96:	48 89 8d f8 fd ff ff 	mov    %rcx,-0x208(%rbp)
    9a9d:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
    9aa4:	48 8b 95 90 fd ff ff 	mov    -0x270(%rbp),%rdx
    9aab:	48 89 95 80 fd ff ff 	mov    %rdx,-0x280(%rbp)
    9ab2:	4c 89 9d b0 fd ff ff 	mov    %r11,-0x250(%rbp)
    9ab9:	48 89 b5 a8 fd ff ff 	mov    %rsi,-0x258(%rbp)
    9ac0:	4c 89 95 18 fe ff ff 	mov    %r10,-0x1e8(%rbp)
    9ac7:	e9 a2 04 00 00       	jmp    0x9f6e
    9acc:	48 8b 85 58 fd ff ff 	mov    -0x2a8(%rbp),%rax
    9ad3:	48 85 c0             	test   %rax,%rax
    9ad6:	0f 84 f6 03 00 00    	je     0x9ed2
    9adc:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    9ae3:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    9ae7:	48 85 d2             	test   %rdx,%rdx
    9aea:	0f 84 3d 01 00 00    	je     0x9c2d
    9af0:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    9af4:	be 40 00 00 00       	mov    $0x40,%esi
    9af9:	48 29 d6             	sub    %rdx,%rsi
    9afc:	48 8b bd 90 fd ff ff 	mov    -0x270(%rbp),%rdi
    9b03:	48 89 f1             	mov    %rsi,%rcx
    9b06:	49 89 f8             	mov    %rdi,%r8
    9b09:	49 d3 e8             	shr    %cl,%r8
    9b0c:	31 c9                	xor    %ecx,%ecx
    9b0e:	48 39 ca             	cmp    %rcx,%rdx
    9b11:	ba 00 00 00 00       	mov    $0x0,%edx
    9b16:	0f 94 c2             	sete   %dl
    9b19:	48 85 d2             	test   %rdx,%rdx
    9b1c:	49 0f 44 c8          	cmove  %r8,%rcx
    9b20:	48 8b 95 58 fe ff ff 	mov    -0x1a8(%rbp),%rdx
    9b27:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    9b2b:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    9b2f:	49 8b 30             	mov    (%r8),%rsi
    9b32:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    9b39:	00 28 00 
    9b3c:	4c 39 ce             	cmp    %r9,%rsi
    9b3f:	4c 89 85 00 fe ff ff 	mov    %r8,-0x200(%rbp)
    9b46:	0f 82 0c 00 00 00    	jb     0x9b58
    9b4c:	48 89 b5 20 fd ff ff 	mov    %rsi,-0x2e0(%rbp)
    9b53:	e9 47 00 00 00       	jmp    0x9b9f
    9b58:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    9b5c:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    9b60:	48 89 b5 28 fd ff ff 	mov    %rsi,-0x2d8(%rbp)
    9b67:	48 89 d6             	mov    %rdx,%rsi
    9b6a:	48 89 ca             	mov    %rcx,%rdx
    9b6d:	48 8b 8d 28 fd ff ff 	mov    -0x2d8(%rbp),%rcx
    9b74:	e8 67 65 ff ff       	call   0xe0
    9b79:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    9b80:	31 d2                	xor    %edx,%edx
    9b82:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    9b86:	48 83 f8 00          	cmp    $0x0,%rax
    9b8a:	0f 8f 08 00 00 00    	jg     0x9b98
    9b90:	49 89 c4             	mov    %rax,%r12
    9b93:	e9 b2 08 00 00       	jmp    0xa44a
    9b98:	48 89 85 20 fd ff ff 	mov    %rax,-0x2e0(%rbp)
    9b9f:	48 8b 85 20 fd ff ff 	mov    -0x2e0(%rbp),%rax
    9ba6:	48 89 c1             	mov    %rax,%rcx
    9ba9:	48 83 c1 28          	add    $0x28,%rcx
    9bad:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    9bb4:	00 28 00 
    9bb7:	48 29 d1             	sub    %rdx,%rcx
    9bba:	48 8b 95 00 fe ff ff 	mov    -0x200(%rbp),%rdx
    9bc1:	48 89 0a             	mov    %rcx,(%rdx)
    9bc4:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    9bcb:	ff 00 00 
    9bce:	48 21 c8             	and    %rcx,%rax
    9bd1:	31 c9                	xor    %ecx,%ecx
    9bd3:	48 8b 95 38 fd ff ff 	mov    -0x2c8(%rbp),%rdx
    9bda:	48 89 10             	mov    %rdx,(%rax)
    9bdd:	48 8b b5 30 fd ff ff 	mov    -0x2d0(%rbp),%rsi
    9be4:	48 89 70 08          	mov    %rsi,0x8(%rax)
    9be8:	48 89 48 10          	mov    %rcx,0x10(%rax)
    9bec:	48 89 48 18          	mov    %rcx,0x18(%rax)
    9bf0:	48 89 48 20          	mov    %rcx,0x20(%rax)
    9bf4:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    9bfb:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    9bff:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    9c05:	4c 01 c7             	add    %r8,%rdi
    9c08:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    9c0c:	48 89 85 20 fd ff ff 	mov    %rax,-0x2e0(%rbp)
    9c13:	b8 01 00 00 00       	mov    $0x1,%eax
    9c18:	48 89 85 00 fe ff ff 	mov    %rax,-0x200(%rbp)
    9c1f:	31 c0                	xor    %eax,%eax
    9c21:	48 89 85 28 fd ff ff 	mov    %rax,-0x2d8(%rbp)
    9c28:	e9 9f 01 00 00       	jmp    0x9dcc
    9c2d:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    9c34:	48 8b 48 10          	mov    0x10(%rax),%rcx
    9c38:	48 8b 50 18          	mov    0x18(%rax),%rdx
    9c3c:	48 89 d6             	mov    %rdx,%rsi
    9c3f:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    9c44:	bf 40 00 00 00       	mov    $0x40,%edi
    9c49:	48 29 f7             	sub    %rsi,%rdi
    9c4c:	48 89 8d 18 fd ff ff 	mov    %rcx,-0x2e8(%rbp)
    9c53:	4c 8b 85 90 fd ff ff 	mov    -0x270(%rbp),%r8
    9c5a:	48 89 f9             	mov    %rdi,%rcx
    9c5d:	4d 89 c1             	mov    %r8,%r9
    9c60:	49 d3 e9             	shr    %cl,%r9
    9c63:	31 c9                	xor    %ecx,%ecx
    9c65:	48 39 ce             	cmp    %rcx,%rsi
    9c68:	be 00 00 00 00       	mov    $0x0,%esi
    9c6d:	40 0f 94 c6          	sete   %sil
    9c71:	48 85 f6             	test   %rsi,%rsi
    9c74:	49 0f 44 c9          	cmove  %r9,%rcx
    9c78:	be 01 00 00 00       	mov    $0x1,%esi
    9c7d:	48 89 cf             	mov    %rcx,%rdi
    9c80:	48 01 f7             	add    %rsi,%rdi
    9c83:	48 21 d7             	and    %rdx,%rdi
    9c86:	ba 28 00 00 00       	mov    $0x28,%edx
    9c8b:	48 0f af ca          	imul   %rdx,%rcx
    9c8f:	48 8b 95 18 fd ff ff 	mov    -0x2e8(%rbp),%rdx
    9c96:	4c 8d 0c 0a          	lea    (%rdx,%rcx,1),%r9
    9c9a:	49 8b 49 10          	mov    0x10(%r9),%rcx
    9c9e:	48 85 c9             	test   %rcx,%rcx
    9ca1:	0f 84 af 00 00 00    	je     0x9d56
    9ca7:	49 8b 09             	mov    (%r9),%rcx
    9caa:	4d 8b 51 08          	mov    0x8(%r9),%r10
    9cae:	4c 8b 9d 38 fd ff ff 	mov    -0x2c8(%rbp),%r11
    9cb5:	49 39 cb             	cmp    %rcx,%r11
    9cb8:	ba 00 00 00 00       	mov    $0x0,%edx
    9cbd:	0f 94 c2             	sete   %dl
    9cc0:	48 8b 8d 30 fd ff ff 	mov    -0x2d0(%rbp),%rcx
    9cc7:	4c 39 d1             	cmp    %r10,%rcx
    9cca:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    9cd0:	41 0f 94 c0          	sete   %r8b
    9cd4:	4c 21 c2             	and    %r8,%rdx
    9cd7:	48 85 d2             	test   %rdx,%rdx
    9cda:	0f 84 0c 00 00 00    	je     0x9cec
    9ce0:	4c 89 8d 20 fd ff ff 	mov    %r9,-0x2e0(%rbp)
    9ce7:	e9 53 00 00 00       	jmp    0x9d3f
    9cec:	ba 28 00 00 00       	mov    $0x28,%edx
    9cf1:	48 0f af fa          	imul   %rdx,%rdi
    9cf5:	48 8b 95 18 fd ff ff 	mov    -0x2e8(%rbp),%rdx
    9cfc:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    9d00:	49 8b 50 10          	mov    0x10(%r8),%rdx
    9d04:	48 85 d2             	test   %rdx,%rdx
    9d07:	0f 84 49 00 00 00    	je     0x9d56
    9d0d:	49 8b 10             	mov    (%r8),%rdx
    9d10:	49 8b 78 08          	mov    0x8(%r8),%rdi
    9d14:	49 39 d3             	cmp    %rdx,%r11
    9d17:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    9d1d:	41 0f 94 c1          	sete   %r9b
    9d21:	48 39 f9             	cmp    %rdi,%rcx
    9d24:	ba 00 00 00 00       	mov    $0x0,%edx
    9d29:	0f 94 c2             	sete   %dl
    9d2c:	49 21 d1             	and    %rdx,%r9
    9d2f:	4d 85 c9             	test   %r9,%r9
    9d32:	0f 84 1e 00 00 00    	je     0x9d56
    9d38:	4c 89 85 20 fd ff ff 	mov    %r8,-0x2e0(%rbp)
    9d3f:	31 c0                	xor    %eax,%eax
    9d41:	48 89 85 00 fe ff ff 	mov    %rax,-0x200(%rbp)
    9d48:	31 c0                	xor    %eax,%eax
    9d4a:	48 89 85 28 fd ff ff 	mov    %rax,-0x2d8(%rbp)
    9d51:	e9 76 00 00 00       	jmp    0x9dcc
    9d56:	48 8d 85 70 fe ff ff 	lea    -0x190(%rbp),%rax
    9d5d:	48 89 c1             	mov    %rax,%rcx
    9d60:	48 8b 95 38 fd ff ff 	mov    -0x2c8(%rbp),%rdx
    9d67:	48 89 11             	mov    %rdx,(%rcx)
    9d6a:	48 8b b5 30 fd ff ff 	mov    -0x2d0(%rbp),%rsi
    9d71:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    9d75:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    9d79:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
    9d80:	48 89 ca             	mov    %rcx,%rdx
    9d83:	e8 68 63 ff ff       	call   0xf0
    9d88:	48 83 f8 00          	cmp    $0x0,%rax
    9d8c:	0f 8d 08 00 00 00    	jge    0x9d9a
    9d92:	49 89 c4             	mov    %rax,%r12
    9d95:	e9 b0 06 00 00       	jmp    0xa44a
    9d9a:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    9da1:	48 8b 11             	mov    (%rcx),%rdx
    9da4:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    9da8:	48 83 e6 01          	and    $0x1,%rsi
    9dac:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    9db0:	48 89 85 20 fd ff ff 	mov    %rax,-0x2e0(%rbp)
    9db7:	b8 01 00 00 00       	mov    $0x1,%eax
    9dbc:	48 89 85 00 fe ff ff 	mov    %rax,-0x200(%rbp)
    9dc3:	31 c0                	xor    %eax,%eax
    9dc5:	48 89 85 28 fd ff ff 	mov    %rax,-0x2d8(%rbp)
    9dcc:	48 8b 85 00 fe ff ff 	mov    -0x200(%rbp),%rax
    9dd3:	48 85 c0             	test   %rax,%rax
    9dd6:	0f 84 68 00 00 00    	je     0x9e44
    9ddc:	48 8b 85 20 fd ff ff 	mov    -0x2e0(%rbp),%rax
    9de3:	48 8b 8d 68 fd ff ff 	mov    -0x298(%rbp),%rcx
    9dea:	48 89 48 10          	mov    %rcx,0x10(%rax)
    9dee:	31 d2                	xor    %edx,%edx
    9df0:	48 39 d1             	cmp    %rdx,%rcx
    9df3:	be 00 00 00 00       	mov    $0x0,%esi
    9df8:	40 0f 95 c6          	setne  %sil
    9dfc:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    9e00:	48 09 f7             	or     %rsi,%rdi
    9e03:	40 88 78 20          	mov    %dil,0x20(%rax)
    9e07:	48 8b b5 88 fd ff ff 	mov    -0x278(%rbp),%rsi
    9e0e:	48 89 70 18          	mov    %rsi,0x18(%rax)
    9e12:	48 8b bd 60 fd ff ff 	mov    -0x2a0(%rbp),%rdi
    9e19:	48 39 d7             	cmp    %rdx,%rdi
    9e1c:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    9e22:	41 0f 95 c0          	setne  %r8b
    9e26:	44 0f b6 48 20       	movzbl 0x20(%rax),%r9d
    9e2b:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    9e31:	4d 85 c0             	test   %r8,%r8
    9e34:	4c 0f 44 d2          	cmove  %rdx,%r10
    9e38:	4d 09 d1             	or     %r10,%r9
    9e3b:	44 88 48 20          	mov    %r9b,0x20(%rax)
    9e3f:	e9 8e 00 00 00       	jmp    0x9ed2
    9e44:	48 8b 85 20 fd ff ff 	mov    -0x2e0(%rbp),%rax
    9e4b:	48 8b 48 10          	mov    0x10(%rax),%rcx
    9e4f:	48 8b 95 68 fd ff ff 	mov    -0x298(%rbp),%rdx
    9e56:	48 01 d1             	add    %rdx,%rcx
    9e59:	48 89 48 10          	mov    %rcx,0x10(%rax)
    9e5d:	31 f6                	xor    %esi,%esi
    9e5f:	48 39 f1             	cmp    %rsi,%rcx
    9e62:	b9 00 00 00 00       	mov    $0x0,%ecx
    9e67:	0f 95 c1             	setne  %cl
    9e6a:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    9e6e:	48 09 cf             	or     %rcx,%rdi
    9e71:	40 88 78 20          	mov    %dil,0x20(%rax)
    9e75:	48 8b 48 18          	mov    0x18(%rax),%rcx
    9e79:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    9e7d:	48 83 e7 02          	and    $0x2,%rdi
    9e81:	48 39 f7             	cmp    %rsi,%rdi
    9e84:	bf 00 00 00 00       	mov    $0x0,%edi
    9e89:	40 0f 95 c7          	setne  %dil
    9e8d:	45 31 c0             	xor    %r8d,%r8d
    9e90:	48 85 ff             	test   %rdi,%rdi
    9e93:	49 0f 44 c8          	cmove  %r8,%rcx
    9e97:	4c 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%r8
    9e9e:	4c 01 c7             	add    %r8,%rdi
    9ea1:	4c 8b 8d 88 fd ff ff 	mov    -0x278(%rbp),%r9
    9ea8:	4c 01 c9             	add    %r9,%rcx
    9eab:	48 89 48 18          	mov    %rcx,0x18(%rax)
    9eaf:	48 39 f7             	cmp    %rsi,%rdi
    9eb2:	bf 00 00 00 00       	mov    $0x0,%edi
    9eb7:	40 0f 95 c7          	setne  %dil
    9ebb:	0f b6 48 20          	movzbl 0x20(%rax),%ecx
    9ebf:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    9ec5:	48 85 ff             	test   %rdi,%rdi
    9ec8:	4c 0f 44 d6          	cmove  %rsi,%r10
    9ecc:	4c 09 d1             	or     %r10,%rcx
    9ecf:	88 48 20             	mov    %cl,0x20(%rax)
    9ed2:	b8 01 00 00 00       	mov    $0x1,%eax
    9ed7:	48 8b 8d 10 fe ff ff 	mov    -0x1f0(%rbp),%rcx
    9ede:	48 89 ca             	mov    %rcx,%rdx
    9ee1:	48 31 c2             	xor    %rax,%rdx
    9ee4:	31 c0                	xor    %eax,%eax
    9ee6:	48 8b b5 d0 fd ff ff 	mov    -0x230(%rbp),%rsi
    9eed:	48 89 f7             	mov    %rsi,%rdi
    9ef0:	48 85 d2             	test   %rdx,%rdx
    9ef3:	48 0f 44 f8          	cmove  %rax,%rdi
    9ef7:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    9efe:	79 37 9e 
    9f01:	49 b8 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%r8
    9f08:	79 37 9e 
    9f0b:	4c 8b 8d 70 fd ff ff 	mov    -0x290(%rbp),%r9
    9f12:	4d 31 c8             	xor    %r9,%r8
    9f15:	4c 0f af c0          	imul   %rax,%r8
    9f19:	4d 89 c2             	mov    %r8,%r10
    9f1c:	49 c1 ea 1d          	shr    $0x1d,%r10
    9f20:	4d 31 d0             	xor    %r10,%r8
    9f23:	4c 8b 95 48 fd ff ff 	mov    -0x2b8(%rbp),%r10
    9f2a:	4d 31 d0             	xor    %r10,%r8
    9f2d:	4c 0f af c0          	imul   %rax,%r8
    9f31:	4d 89 c3             	mov    %r8,%r11
    9f34:	49 c1 eb 1d          	shr    $0x1d,%r11
    9f38:	4d 31 d8             	xor    %r11,%r8
    9f3b:	4c 0f af c0          	imul   %rax,%r8
    9f3f:	4c 89 8d f8 fd ff ff 	mov    %r9,-0x208(%rbp)
    9f46:	4c 89 95 08 fe ff ff 	mov    %r10,-0x1f8(%rbp)
    9f4d:	4c 89 85 80 fd ff ff 	mov    %r8,-0x280(%rbp)
    9f54:	b8 01 00 00 00       	mov    $0x1,%eax
    9f59:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
    9f60:	48 89 bd a8 fd ff ff 	mov    %rdi,-0x258(%rbp)
    9f67:	48 89 95 18 fe ff ff 	mov    %rdx,-0x1e8(%rbp)
    9f6e:	48 8b 85 b8 fd ff ff 	mov    -0x248(%rbp),%rax
    9f75:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
    9f7c:	b8 01 00 00 00       	mov    $0x1,%eax
    9f81:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
    9f88:	31 c0                	xor    %eax,%eax
    9f8a:	48 89 43 18          	mov    %rax,0x18(%rbx)
    9f8e:	48 8b 85 c8 fd ff ff 	mov    -0x238(%rbp),%rax
    9f95:	b9 01 00 00 00       	mov    $0x1,%ecx
    9f9a:	48 89 c2             	mov    %rax,%rdx
    9f9d:	48 01 ca             	add    %rcx,%rdx
    9fa0:	48 89 95 c8 fd ff ff 	mov    %rdx,-0x238(%rbp)
    9fa7:	e9 21 f5 ff ff       	jmp    0x94cd
    9fac:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    9fb0:	e8 8b 60 ff ff       	call   0x40
    9fb5:	48 85 c0             	test   %rax,%rax
    9fb8:	0f 84 f4 f9 ff ff    	je     0x99b2
    9fbe:	e9 80 04 00 00       	jmp    0xa443
    9fc3:	48 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%rax
    9fca:	48 85 c0             	test   %rax,%rax
    9fcd:	0f 84 b6 03 00 00    	je     0xa389
    9fd3:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    9fda:	48 8b 48 68          	mov    0x68(%rax),%rcx
    9fde:	48 85 c9             	test   %rcx,%rcx
    9fe1:	0f 84 1f 01 00 00    	je     0xa106
    9fe7:	48 8b 48 38          	mov    0x38(%rax),%rcx
    9feb:	ba 40 00 00 00       	mov    $0x40,%edx
    9ff0:	48 29 ca             	sub    %rcx,%rdx
    9ff3:	48 89 8d c0 fd ff ff 	mov    %rcx,-0x240(%rbp)
    9ffa:	48 8b b5 80 fd ff ff 	mov    -0x280(%rbp),%rsi
    a001:	48 89 d1             	mov    %rdx,%rcx
    a004:	48 89 f7             	mov    %rsi,%rdi
    a007:	48 d3 ef             	shr    %cl,%rdi
    a00a:	31 c9                	xor    %ecx,%ecx
    a00c:	48 8b 95 c0 fd ff ff 	mov    -0x240(%rbp),%rdx
    a013:	48 39 ca             	cmp    %rcx,%rdx
    a016:	ba 00 00 00 00       	mov    $0x0,%edx
    a01b:	0f 94 c2             	sete   %dl
    a01e:	48 85 d2             	test   %rdx,%rdx
    a021:	48 0f 44 cf          	cmove  %rdi,%rcx
    a025:	48 8b 50 08          	mov    0x8(%rax),%rdx
    a029:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    a02d:	4c 8b 37             	mov    (%rdi),%r14
    a030:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    a037:	00 28 00 
    a03a:	49 39 d6             	cmp    %rdx,%r14
    a03d:	48 89 bd c0 fd ff ff 	mov    %rdi,-0x240(%rbp)
    a044:	0f 82 05 00 00 00    	jb     0xa04f
    a04a:	e9 38 00 00 00       	jmp    0xa087
    a04f:	4c 8b 40 60          	mov    0x60(%rax),%r8
    a053:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    a057:	48 89 c6             	mov    %rax,%rsi
    a05a:	48 89 ca             	mov    %rcx,%rdx
    a05d:	4c 89 c1             	mov    %r8,%rcx
    a060:	e8 7b 60 ff ff       	call   0xe0
    a065:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    a06c:	31 d2                	xor    %edx,%edx
    a06e:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    a072:	48 83 f8 00          	cmp    $0x0,%rax
    a076:	0f 8f 08 00 00 00    	jg     0xa084
    a07c:	49 89 c4             	mov    %rax,%r12
    a07f:	e9 c6 03 00 00       	jmp    0xa44a
    a084:	49 89 c6             	mov    %rax,%r14
    a087:	4c 89 f0             	mov    %r14,%rax
    a08a:	48 83 c0 28          	add    $0x28,%rax
    a08e:	48 b9 00 00 00 00 00 	movabs $0x28000000000000,%rcx
    a095:	00 28 00 
    a098:	48 29 c8             	sub    %rcx,%rax
    a09b:	48 8b 8d c0 fd ff ff 	mov    -0x240(%rbp),%rcx
    a0a2:	48 89 01             	mov    %rax,(%rcx)
    a0a5:	48 b8 ff ff ff ff ff 	movabs $0xffffffffffff,%rax
    a0ac:	ff 00 00 
    a0af:	49 21 c6             	and    %rax,%r14
    a0b2:	31 c0                	xor    %eax,%eax
    a0b4:	48 8b 8d f8 fd ff ff 	mov    -0x208(%rbp),%rcx
    a0bb:	49 89 0e             	mov    %rcx,(%r14)
    a0be:	48 8b 95 08 fe ff ff 	mov    -0x1f8(%rbp),%rdx
    a0c5:	49 89 56 08          	mov    %rdx,0x8(%r14)
    a0c9:	49 89 46 10          	mov    %rax,0x10(%r14)
    a0cd:	49 89 46 18          	mov    %rax,0x18(%r14)
    a0d1:	49 89 46 20          	mov    %rax,0x20(%r14)
    a0d5:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    a0dc:	48 8b 70 60          	mov    0x60(%rax),%rsi
    a0e0:	bf 01 00 00 00       	mov    $0x1,%edi
    a0e5:	48 01 fe             	add    %rdi,%rsi
    a0e8:	48 89 70 60          	mov    %rsi,0x60(%rax)
    a0ec:	be 01 00 00 00       	mov    $0x1,%esi
    a0f1:	48 89 b5 c0 fd ff ff 	mov    %rsi,-0x240(%rbp)
    a0f8:	31 f6                	xor    %esi,%esi
    a0fa:	48 89 b5 e0 fd ff ff 	mov    %rsi,-0x220(%rbp)
    a101:	e9 8c 01 00 00       	jmp    0xa292
    a106:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    a10d:	48 8b 48 10          	mov    0x10(%rax),%rcx
    a111:	48 8b 50 18          	mov    0x18(%rax),%rdx
    a115:	48 89 d6             	mov    %rdx,%rsi
    a118:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    a11d:	bf 40 00 00 00       	mov    $0x40,%edi
    a122:	48 29 f7             	sub    %rsi,%rdi
    a125:	48 89 8d f0 fd ff ff 	mov    %rcx,-0x210(%rbp)
    a12c:	4c 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%r8
    a133:	48 89 f9             	mov    %rdi,%rcx
    a136:	49 d3 e8             	shr    %cl,%r8
    a139:	31 c9                	xor    %ecx,%ecx
    a13b:	48 39 ce             	cmp    %rcx,%rsi
    a13e:	be 00 00 00 00       	mov    $0x0,%esi
    a143:	40 0f 94 c6          	sete   %sil
    a147:	48 85 f6             	test   %rsi,%rsi
    a14a:	49 0f 44 c8          	cmove  %r8,%rcx
    a14e:	be 01 00 00 00       	mov    $0x1,%esi
    a153:	48 89 cf             	mov    %rcx,%rdi
    a156:	48 01 f7             	add    %rsi,%rdi
    a159:	48 21 d7             	and    %rdx,%rdi
    a15c:	ba 28 00 00 00       	mov    $0x28,%edx
    a161:	48 0f af ca          	imul   %rdx,%rcx
    a165:	48 8b 95 f0 fd ff ff 	mov    -0x210(%rbp),%rdx
    a16c:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
    a170:	49 8b 48 10          	mov    0x10(%r8),%rcx
    a174:	48 85 c9             	test   %rcx,%rcx
    a177:	0f 84 a3 00 00 00    	je     0xa220
    a17d:	49 8b 08             	mov    (%r8),%rcx
    a180:	4d 8b 48 08          	mov    0x8(%r8),%r9
    a184:	4c 8b 95 f8 fd ff ff 	mov    -0x208(%rbp),%r10
    a18b:	49 39 ca             	cmp    %rcx,%r10
    a18e:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    a194:	41 0f 94 c3          	sete   %r11b
    a198:	48 8b 8d 08 fe ff ff 	mov    -0x1f8(%rbp),%rcx
    a19f:	4c 39 c9             	cmp    %r9,%rcx
    a1a2:	41 bf 00 00 00 00    	mov    $0x0,%r15d
    a1a8:	41 0f 94 c7          	sete   %r15b
    a1ac:	4d 21 fb             	and    %r15,%r11
    a1af:	4d 85 db             	test   %r11,%r11
    a1b2:	0f 84 08 00 00 00    	je     0xa1c0
    a1b8:	4d 89 c6             	mov    %r8,%r14
    a1bb:	e9 49 00 00 00       	jmp    0xa209
    a1c0:	41 b8 28 00 00 00    	mov    $0x28,%r8d
    a1c6:	49 0f af f8          	imul   %r8,%rdi
    a1ca:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    a1ce:	49 8b 50 10          	mov    0x10(%r8),%rdx
    a1d2:	48 85 d2             	test   %rdx,%rdx
    a1d5:	0f 84 45 00 00 00    	je     0xa220
    a1db:	49 8b 10             	mov    (%r8),%rdx
    a1de:	49 8b 78 08          	mov    0x8(%r8),%rdi
    a1e2:	49 39 d2             	cmp    %rdx,%r10
    a1e5:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    a1eb:	41 0f 94 c1          	sete   %r9b
    a1ef:	48 39 f9             	cmp    %rdi,%rcx
    a1f2:	ba 00 00 00 00       	mov    $0x0,%edx
    a1f7:	0f 94 c2             	sete   %dl
    a1fa:	49 21 d1             	and    %rdx,%r9
    a1fd:	4d 85 c9             	test   %r9,%r9
    a200:	0f 84 1a 00 00 00    	je     0xa220
    a206:	4d 89 c6             	mov    %r8,%r14
    a209:	31 c0                	xor    %eax,%eax
    a20b:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
    a212:	31 c0                	xor    %eax,%eax
    a214:	48 89 85 e0 fd ff ff 	mov    %rax,-0x220(%rbp)
    a21b:	e9 72 00 00 00       	jmp    0xa292
    a220:	48 8d 85 60 fe ff ff 	lea    -0x1a0(%rbp),%rax
    a227:	48 89 c1             	mov    %rax,%rcx
    a22a:	48 8b 95 f8 fd ff ff 	mov    -0x208(%rbp),%rdx
    a231:	48 89 11             	mov    %rdx,(%rcx)
    a234:	48 8b 95 08 fe ff ff 	mov    -0x1f8(%rbp),%rdx
    a23b:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    a23f:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    a243:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
    a24a:	48 89 ca             	mov    %rcx,%rdx
    a24d:	e8 9e 5e ff ff       	call   0xf0
    a252:	48 83 f8 00          	cmp    $0x0,%rax
    a256:	0f 8d 08 00 00 00    	jge    0xa264
    a25c:	49 89 c4             	mov    %rax,%r12
    a25f:	e9 e6 01 00 00       	jmp    0xa44a
    a264:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    a26b:	48 8b 11             	mov    (%rcx),%rdx
    a26e:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    a272:	48 83 e6 01          	and    $0x1,%rsi
    a276:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    a27a:	49 89 c6             	mov    %rax,%r14
    a27d:	b8 01 00 00 00       	mov    $0x1,%eax
    a282:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
    a289:	31 c0                	xor    %eax,%eax
    a28b:	48 89 85 e0 fd ff ff 	mov    %rax,-0x220(%rbp)
    a292:	48 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%rax
    a299:	48 85 c0             	test   %rax,%rax
    a29c:	0f 84 60 00 00 00    	je     0xa302
    a2a2:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
    a2a9:	49 89 46 10          	mov    %rax,0x10(%r14)
    a2ad:	31 c9                	xor    %ecx,%ecx
    a2af:	48 39 c8             	cmp    %rcx,%rax
    a2b2:	ba 00 00 00 00       	mov    $0x0,%edx
    a2b7:	0f 95 c2             	setne  %dl
    a2ba:	41 0f b6 76 20       	movzbl 0x20(%r14),%esi
    a2bf:	48 09 d6             	or     %rdx,%rsi
    a2c2:	41 88 76 20          	mov    %sil,0x20(%r14)
    a2c6:	48 8b 95 a8 fd ff ff 	mov    -0x258(%rbp),%rdx
    a2cd:	49 89 56 18          	mov    %rdx,0x18(%r14)
    a2d1:	48 8b b5 18 fe ff ff 	mov    -0x1e8(%rbp),%rsi
    a2d8:	48 39 ce             	cmp    %rcx,%rsi
    a2db:	bf 00 00 00 00       	mov    $0x0,%edi
    a2e0:	40 0f 95 c7          	setne  %dil
    a2e4:	45 0f b6 46 20       	movzbl 0x20(%r14),%r8d
    a2e9:	41 b9 02 00 00 00    	mov    $0x2,%r9d
    a2ef:	48 85 ff             	test   %rdi,%rdi
    a2f2:	4c 0f 44 c9          	cmove  %rcx,%r9
    a2f6:	4d 09 c8             	or     %r9,%r8
    a2f9:	45 88 46 20          	mov    %r8b,0x20(%r14)
    a2fd:	e9 87 00 00 00       	jmp    0xa389
    a302:	49 8b 46 10          	mov    0x10(%r14),%rax
    a306:	48 8b 8d b0 fd ff ff 	mov    -0x250(%rbp),%rcx
    a30d:	48 01 c8             	add    %rcx,%rax
    a310:	49 89 46 10          	mov    %rax,0x10(%r14)
    a314:	31 c9                	xor    %ecx,%ecx
    a316:	48 39 c8             	cmp    %rcx,%rax
    a319:	b8 00 00 00 00       	mov    $0x0,%eax
    a31e:	0f 95 c0             	setne  %al
    a321:	41 0f b6 56 20       	movzbl 0x20(%r14),%edx
    a326:	48 09 c2             	or     %rax,%rdx
    a329:	41 88 56 20          	mov    %dl,0x20(%r14)
    a32d:	49 8b 46 18          	mov    0x18(%r14),%rax
    a331:	41 0f b6 56 20       	movzbl 0x20(%r14),%edx
    a336:	48 83 e2 02          	and    $0x2,%rdx
    a33a:	48 39 ca             	cmp    %rcx,%rdx
    a33d:	ba 00 00 00 00       	mov    $0x0,%edx
    a342:	0f 95 c2             	setne  %dl
    a345:	31 f6                	xor    %esi,%esi
    a347:	48 85 d2             	test   %rdx,%rdx
    a34a:	48 0f 44 c6          	cmove  %rsi,%rax
    a34e:	48 8b b5 18 fe ff ff 	mov    -0x1e8(%rbp),%rsi
    a355:	48 01 f2             	add    %rsi,%rdx
    a358:	48 8b b5 a8 fd ff ff 	mov    -0x258(%rbp),%rsi
    a35f:	48 01 f0             	add    %rsi,%rax
    a362:	49 89 46 18          	mov    %rax,0x18(%r14)
    a366:	48 39 ca             	cmp    %rcx,%rdx
    a369:	ba 00 00 00 00       	mov    $0x0,%edx
    a36e:	0f 95 c2             	setne  %dl
    a371:	41 0f b6 46 20       	movzbl 0x20(%r14),%eax
    a376:	be 02 00 00 00       	mov    $0x2,%esi
    a37b:	48 85 d2             	test   %rdx,%rdx
    a37e:	48 0f 44 f1          	cmove  %rcx,%rsi
    a382:	48 09 f0             	or     %rsi,%rax
    a385:	41 88 46 20          	mov    %al,0x20(%r14)
    a389:	48 8b 85 a0 fd ff ff 	mov    -0x260(%rbp),%rax
    a390:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
    a397:	48 b8 01 00 00 00 00 	movabs $0x4000000000001,%rax
    a39e:	00 04 00 
    a3a1:	48 8b 8d e8 fd ff ff 	mov    -0x218(%rbp),%rcx
    a3a8:	48 01 c1             	add    %rax,%rcx
    a3ab:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
    a3af:	48 89 48 50          	mov    %rcx,0x50(%rax)
    a3b3:	e9 91 cf ff ff       	jmp    0x7349
    a3b8:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    a3bc:	e8 7f 5c ff ff       	call   0x40
    a3c1:	48 85 c0             	test   %rax,%rax
    a3c4:	0f 84 9c cf ff ff    	je     0x7366
    a3ca:	e9 74 00 00 00       	jmp    0xa443
    a3cf:	49 c1 e5 08          	shl    $0x8,%r13
    a3d3:	49 83 cd 03          	or     $0x3,%r13
    a3d7:	49 f7 dd             	neg    %r13
    a3da:	4d 89 ec             	mov    %r13,%r12
    a3dd:	e9 68 00 00 00       	jmp    0xa44a
    a3e2:	31 c0                	xor    %eax,%eax
    a3e4:	48 85 c0             	test   %rax,%rax
    a3e7:	0f 84 08 00 00 00    	je     0xa3f5
    a3ed:	49 89 c4             	mov    %rax,%r12
    a3f0:	e9 55 00 00 00       	jmp    0xa44a
    a3f5:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    a3fc:	48 8b 08             	mov    (%rax),%rcx
    a3ff:	48 8b 50 60          	mov    0x60(%rax),%rdx
    a403:	48 8b 59 58          	mov    0x58(%rcx),%rbx
    a407:	48 01 d3             	add    %rdx,%rbx
    a40a:	48 89 59 58          	mov    %rbx,0x58(%rcx)
    a40e:	31 c9                	xor    %ecx,%ecx
    a410:	48 89 48 60          	mov    %rcx,0x60(%rax)
    a414:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    a418:	48 89 c6             	mov    %rax,%rsi
    a41b:	e8 e0 5c ff ff       	call   0x100
    a420:	48 83 f8 00          	cmp    $0x0,%rax
    a424:	0f 8d 08 00 00 00    	jge    0xa432
    a42a:	49 89 c4             	mov    %rax,%r12
    a42d:	e9 18 00 00 00       	jmp    0xa44a
    a432:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    a436:	e8 35 5c ff ff       	call   0x70
    a43b:	49 89 c4             	mov    %rax,%r12
    a43e:	e9 07 00 00 00       	jmp    0xa44a
    a443:	49 c7 c4 fe ff ff ff 	mov    $0xfffffffffffffffe,%r12
    a44a:	4c 89 e0             	mov    %r12,%rax
    a44d:	48 81 c4 e8 02 00 00 	add    $0x2e8,%rsp
    a454:	41 5f                	pop    %r15
    a456:	41 5e                	pop    %r14
    a458:	41 5d                	pop    %r13
    a45a:	41 5c                	pop    %r12
    a45c:	5b                   	pop    %rbx
    a45d:	5d                   	pop    %rbp
    a45e:	c3                   	ret
    a45f:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a466:	00 00 
    a468:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a46f:	00 00 
    a471:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a478:	00 00 
    a47a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a480:	55                   	push   %rbp
    a481:	48 89 e5             	mov    %rsp,%rbp
    a484:	53                   	push   %rbx
    a485:	41 54                	push   %r12
    a487:	41 55                	push   %r13
    a489:	41 56                	push   %r14
    a48b:	41 57                	push   %r15
    a48d:	48 81 ec d8 01 00 00 	sub    $0x1d8,%rsp
    a494:	48 89 fb             	mov    %rdi,%rbx
    a497:	31 c0                	xor    %eax,%eax
    a499:	48 8b 4b 58          	mov    0x58(%rbx),%rcx
    a49d:	4c 8b a3 10 02 00 00 	mov    0x210(%rbx),%r12
    a4a4:	48 8b 53 50          	mov    0x50(%rbx),%rdx
    a4a8:	48 85 d2             	test   %rdx,%rdx
    a4ab:	48 89 4d d0          	mov    %rcx,-0x30(%rbp)
    a4af:	0f 85 d3 01 00 00    	jne    0xa688
    a4b5:	48 ba 01 00 00 00 00 	movabs $0x4000000000001,%rdx
    a4bc:	00 04 00 
    a4bf:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    a4c3:	31 d2                	xor    %edx,%edx
    a4c5:	49 89 54 24 30       	mov    %rdx,0x30(%r12)
    a4ca:	31 d2                	xor    %edx,%edx
    a4cc:	49 89 54 24 38       	mov    %rdx,0x38(%r12)
    a4d1:	31 d2                	xor    %edx,%edx
    a4d3:	49 89 54 24 40       	mov    %rdx,0x40(%r12)
    a4d8:	31 d2                	xor    %edx,%edx
    a4da:	49 89 54 24 48       	mov    %rdx,0x48(%r12)
    a4df:	31 d2                	xor    %edx,%edx
    a4e1:	49 89 54 24 50       	mov    %rdx,0x50(%r12)
    a4e6:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    a4ea:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    a4ee:	0f 85 84 00 00 00    	jne    0xa578
    a4f4:	48 8d 95 10 ff ff ff 	lea    -0xf0(%rbp),%rdx
    a4fb:	48 89 d6             	mov    %rdx,%rsi
    a4fe:	bf 02 02 01 01       	mov    $0x1010202,%edi
    a503:	48 89 3e             	mov    %rdi,(%rsi)
    a506:	bf 00 00 00 01       	mov    $0x1000000,%edi
    a50b:	48 89 7e 08          	mov    %rdi,0x8(%rsi)
    a50f:	bf 00 00 10 18       	mov    $0x18100000,%edi
    a514:	48 89 7e 10          	mov    %rdi,0x10(%rsi)
    a518:	48 bf 00 00 28 01 10 	movabs $0x201001280000,%rdi
    a51f:	20 00 00 
    a522:	48 89 7e 18          	mov    %rdi,0x18(%rsi)
    a526:	31 ff                	xor    %edi,%edi
    a528:	48 89 7e 20          	mov    %rdi,0x20(%rsi)
    a52c:	48 bf 00 00 00 00 02 	movabs $0x200000000,%rdi
    a533:	00 00 00 
    a536:	48 89 7e 28          	mov    %rdi,0x28(%rsi)
    a53a:	bf 01 00 00 00       	mov    $0x1,%edi
    a53f:	48 89 7e 30          	mov    %rdi,0x30(%rsi)
    a543:	bf 00 00 01 00       	mov    $0x10000,%edi
    a548:	48 89 7e 38          	mov    %rdi,0x38(%rsi)
    a54c:	48 8b 79 18          	mov    0x18(%rcx),%rdi
    a550:	48 89 bd 18 fe ff ff 	mov    %rdi,-0x1e8(%rbp)
    a557:	48 89 df             	mov    %rbx,%rdi
    a55a:	48 8b 95 18 fe ff ff 	mov    -0x1e8(%rbp),%rdx
    a561:	e8 ca 5b ff ff       	call   0x130
    a566:	48 83 f8 00          	cmp    $0x0,%rax
    a56a:	0f 8d 08 00 00 00    	jge    0xa578
    a570:	49 89 c5             	mov    %rax,%r13
    a573:	e9 8e 02 00 00       	jmp    0xa806
    a578:	48 8d 85 50 fe ff ff 	lea    -0x1b0(%rbp),%rax
    a57f:	48 89 c1             	mov    %rax,%rcx
    a582:	ba 02 02 01 01       	mov    $0x1010202,%edx
    a587:	48 89 11             	mov    %rdx,(%rcx)
    a58a:	ba 00 00 00 01       	mov    $0x1000000,%edx
    a58f:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    a593:	ba 00 00 10 18       	mov    $0x18100000,%edx
    a598:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    a59c:	48 ba 00 00 28 01 10 	movabs $0x201001280000,%rdx
    a5a3:	20 00 00 
    a5a6:	48 89 51 18          	mov    %rdx,0x18(%rcx)
    a5aa:	31 d2                	xor    %edx,%edx
    a5ac:	48 89 51 20          	mov    %rdx,0x20(%rcx)
    a5b0:	48 ba 00 00 00 00 02 	movabs $0x200000000,%rdx
    a5b7:	00 00 00 
    a5ba:	48 89 51 28          	mov    %rdx,0x28(%rcx)
    a5be:	ba 01 00 00 00       	mov    $0x1,%edx
    a5c3:	48 89 51 30          	mov    %rdx,0x30(%rcx)
    a5c7:	ba 00 00 01 00       	mov    $0x10000,%edx
    a5cc:	48 89 51 38          	mov    %rdx,0x38(%rcx)
    a5d0:	31 d2                	xor    %edx,%edx
    a5d2:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    a5d6:	48 89 df             	mov    %rbx,%rdi
    a5d9:	48 89 ce             	mov    %rcx,%rsi
    a5dc:	48 89 8d 18 fe ff ff 	mov    %rcx,-0x1e8(%rbp)
    a5e3:	e8 58 5b ff ff       	call   0x140
    a5e8:	48 b9 01 00 00 00 00 	movabs $0x4000000000001,%rcx
    a5ef:	00 04 00 
    a5f2:	48 89 4b 50          	mov    %rcx,0x50(%rbx)
    a5f6:	48 85 c0             	test   %rax,%rax
    a5f9:	0f 85 0c 00 00 00    	jne    0xa60b
    a5ff:	49 c7 c6 fa fd ff ff 	mov    $0xfffffffffffffdfa,%r14
    a606:	e9 6b 00 00 00       	jmp    0xa676
    a60b:	48 8b 08             	mov    (%rax),%rcx
    a60e:	48 8b 50 10          	mov    0x10(%rax),%rdx
    a612:	48 89 50 10          	mov    %rdx,0x10(%rax)
    a616:	48 89 df             	mov    %rbx,%rdi
    a619:	48 89 c6             	mov    %rax,%rsi
    a61c:	48 89 95 10 fe ff ff 	mov    %rdx,-0x1f0(%rbp)
    a623:	48 8b 95 18 fe ff ff 	mov    -0x1e8(%rbp),%rdx
    a62a:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
    a631:	48 89 8d 08 fe ff ff 	mov    %rcx,-0x1f8(%rbp)
    a638:	e8 13 5b ff ff       	call   0x150
    a63d:	48 83 f8 00          	cmp    $0x0,%rax
    a641:	0f 8d 08 00 00 00    	jge    0xa64f
    a647:	49 89 c6             	mov    %rax,%r14
    a64a:	e9 27 00 00 00       	jmp    0xa676
    a64f:	48 8b 85 18 fe ff ff 	mov    -0x1e8(%rbp),%rax
    a656:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    a65b:	48 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%rax
    a662:	49 89 44 24 38       	mov    %rax,0x38(%r12)
    a667:	48 8b 85 10 fe ff ff 	mov    -0x1f0(%rbp),%rax
    a66e:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    a673:	45 31 f6             	xor    %r14d,%r14d
    a676:	49 83 fe 00          	cmp    $0x0,%r14
    a67a:	0f 8d 08 00 00 00    	jge    0xa688
    a680:	4d 89 f5             	mov    %r14,%r13
    a683:	e9 7e 01 00 00       	jmp    0xa806
    a688:	48 8b 43 18          	mov    0x18(%rbx),%rax
    a68c:	48 85 c0             	test   %rax,%rax
    a68f:	0f 84 0c 00 00 00    	je     0xa6a1
    a695:	0f b6 08             	movzbl (%rax),%ecx
    a698:	48 85 c9             	test   %rcx,%rcx
    a69b:	0f 85 eb 00 00 00    	jne    0xa78c
    a6a1:	49 8b 44 24 40       	mov    0x40(%r12),%rax
    a6a6:	49 8b 74 24 30       	mov    0x30(%r12),%rsi
    a6ab:	48 39 c6             	cmp    %rax,%rsi
    a6ae:	0f 8d f5 00 00 00    	jge    0xa7a9
    a6b4:	48 89 f1             	mov    %rsi,%rcx
    a6b7:	48 81 c1 00 10 00 00 	add    $0x1000,%rcx
    a6be:	48 39 c1             	cmp    %rax,%rcx
    a6c1:	ba 00 00 00 00       	mov    $0x0,%edx
    a6c6:	0f 9f c2             	setg   %dl
    a6c9:	48 89 c7             	mov    %rax,%rdi
    a6cc:	48 85 d2             	test   %rdx,%rdx
    a6cf:	48 0f 44 f9          	cmove  %rcx,%rdi
    a6d3:	45 31 c0             	xor    %r8d,%r8d
    a6d6:	48 39 fe             	cmp    %rdi,%rsi
    a6d9:	0f 8d a3 00 00 00    	jge    0xa782
    a6df:	48 89 f0             	mov    %rsi,%rax
    a6e2:	48 83 c0 01          	add    $0x1,%rax
    a6e6:	49 8b 4c 24 38       	mov    0x38(%r12),%rcx
    a6eb:	48 8d 14 f1          	lea    (%rcx,%rsi,8),%rdx
    a6ef:	48 8b 0a             	mov    (%rdx),%rcx
    a6f2:	48 8d 95 20 fe ff ff 	lea    -0x1e0(%rbp),%rdx
    a6f9:	49 89 d1             	mov    %rdx,%r9
    a6fc:	49 89 49 20          	mov    %rcx,0x20(%r9)
    a700:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    a704:	4d 89 11             	mov    %r10,(%r9)
    a707:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    a70d:	4d 89 51 08          	mov    %r10,0x8(%r9)
    a711:	4c 8b 51 18          	mov    0x18(%rcx),%r10
    a715:	44 0f b6 59 20       	movzbl 0x20(%rcx),%r11d
    a71a:	49 83 e3 02          	and    $0x2,%r11
    a71e:	45 31 f6             	xor    %r14d,%r14d
    a721:	4d 39 f3             	cmp    %r14,%r11
    a724:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    a72a:	41 0f 95 c3          	setne  %r11b
    a72e:	45 31 ff             	xor    %r15d,%r15d
    a731:	4d 85 db             	test   %r11,%r11
    a734:	4d 0f 44 d7          	cmove  %r15,%r10
    a738:	4d 39 f3             	cmp    %r14,%r11
    a73b:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    a741:	41 0f 94 c3          	sete   %r11b
    a745:	4d 89 51 10          	mov    %r10,0x10(%r9)
    a749:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    a74f:	4d 31 d3             	xor    %r10,%r11
    a752:	4d 89 59 18          	mov    %r11,0x18(%r9)
    a756:	4d 8b 4c 24 50       	mov    0x50(%r12),%r9
    a75b:	4d 8b 54 24 38       	mov    0x38(%r12),%r10
    a760:	4f 8d 1c ca          	lea    (%r10,%r9,8),%r11
    a764:	49 89 0b             	mov    %rcx,(%r11)
    a767:	49 83 c1 01          	add    $0x1,%r9
    a76b:	4d 89 4c 24 50       	mov    %r9,0x50(%r12)
    a770:	4c 89 c1             	mov    %r8,%rcx
    a773:	48 83 c1 01          	add    $0x1,%rcx
    a777:	48 89 c6             	mov    %rax,%rsi
    a77a:	49 89 c8             	mov    %rcx,%r8
    a77d:	e9 54 ff ff ff       	jmp    0xa6d6
    a782:	49 89 7c 24 30       	mov    %rdi,0x30(%r12)
    a787:	e9 fc fe ff ff       	jmp    0xa688
    a78c:	48 89 df             	mov    %rbx,%rdi
    a78f:	e8 ac 58 ff ff       	call   0x40
    a794:	48 85 c0             	test   %rax,%rax
    a797:	0f 84 04 ff ff ff    	je     0xa6a1
    a79d:	49 c7 c5 fe ff ff ff 	mov    $0xfffffffffffffffe,%r13
    a7a4:	e9 5d 00 00 00       	jmp    0xa806
    a7a9:	31 c0                	xor    %eax,%eax
    a7ab:	48 85 c0             	test   %rax,%rax
    a7ae:	0f 84 08 00 00 00    	je     0xa7bc
    a7b4:	49 89 c5             	mov    %rax,%r13
    a7b7:	e9 4a 00 00 00       	jmp    0xa806
    a7bc:	49 8b 44 24 48       	mov    0x48(%r12),%rax
    a7c1:	49 8b 4c 24 50       	mov    0x50(%r12),%rcx
    a7c6:	48 85 c0             	test   %rax,%rax
    a7c9:	0f 84 2c 00 00 00    	je     0xa7fb
    a7cf:	48 89 48 10          	mov    %rcx,0x10(%rax)
    a7d3:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    a7d7:	48 83 fa 40          	cmp    $0x40,%rdx
    a7db:	0f 83 1a 00 00 00    	jae    0xa7fb
    a7e1:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
    a7e5:	48 8b 7e 18          	mov    0x18(%rsi),%rdi
    a7e9:	48 6b f2 10          	imul   $0x10,%rdx,%rsi
    a7ed:	48 8d 34 37          	lea    (%rdi,%rsi,1),%rsi
    a7f1:	48 8b 10             	mov    (%rax),%rdx
    a7f4:	48 89 16             	mov    %rdx,(%rsi)
    a7f7:	48 89 4e 08          	mov    %rcx,0x8(%rsi)
    a7fb:	48 89 df             	mov    %rbx,%rdi
    a7fe:	e8 6d 58 ff ff       	call   0x70
    a803:	49 89 c5             	mov    %rax,%r13
    a806:	4c 89 e8             	mov    %r13,%rax
    a809:	48 81 c4 d8 01 00 00 	add    $0x1d8,%rsp
    a810:	41 5f                	pop    %r15
    a812:	41 5e                	pop    %r14
    a814:	41 5d                	pop    %r13
    a816:	41 5c                	pop    %r12
    a818:	5b                   	pop    %rbx
    a819:	5d                   	pop    %rbp
    a81a:	c3                   	ret
    a81b:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a822:	00 00 
    a824:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a82b:	00 00 
    a82d:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a834:	00 00 
    a836:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a83d:	00 00 
    a83f:	90                   	nop
    a840:	55                   	push   %rbp
    a841:	48 89 e5             	mov    %rsp,%rbp
    a844:	53                   	push   %rbx
    a845:	41 54                	push   %r12
    a847:	41 55                	push   %r13
    a849:	41 56                	push   %r14
    a84b:	41 57                	push   %r15
    a84d:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    a854:	48 89 fb             	mov    %rdi,%rbx
    a857:	31 c0                	xor    %eax,%eax
    a859:	48 8b 4b 58          	mov    0x58(%rbx),%rcx
    a85d:	4c 8b a3 10 02 00 00 	mov    0x210(%rbx),%r12
    a864:	48 8b 53 50          	mov    0x50(%rbx),%rdx
    a868:	48 85 d2             	test   %rdx,%rdx
    a86b:	0f 85 f4 00 00 00    	jne    0xa965
    a871:	48 ba 01 00 00 00 00 	movabs $0x4000000000001,%rdx
    a878:	00 04 00 
    a87b:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    a87f:	31 d2                	xor    %edx,%edx
    a881:	49 89 54 24 58       	mov    %rdx,0x58(%r12)
    a886:	31 d2                	xor    %edx,%edx
    a888:	49 89 54 24 60       	mov    %rdx,0x60(%r12)
    a88d:	31 d2                	xor    %edx,%edx
    a88f:	49 89 54 24 68       	mov    %rdx,0x68(%r12)
    a894:	31 d2                	xor    %edx,%edx
    a896:	49 89 54 24 70       	mov    %rdx,0x70(%r12)
    a89b:	48 8d 95 10 ff ff ff 	lea    -0xf0(%rbp),%rdx
    a8a2:	48 89 d6             	mov    %rdx,%rsi
    a8a5:	bf 02 02 01 01       	mov    $0x1010202,%edi
    a8aa:	48 89 3e             	mov    %rdi,(%rsi)
    a8ad:	bf 00 00 00 01       	mov    $0x1000000,%edi
    a8b2:	48 89 7e 08          	mov    %rdi,0x8(%rsi)
    a8b6:	bf 00 00 10 18       	mov    $0x18100000,%edi
    a8bb:	48 89 7e 10          	mov    %rdi,0x10(%rsi)
    a8bf:	48 bf 00 00 28 01 10 	movabs $0x201001280000,%rdi
    a8c6:	20 00 00 
    a8c9:	48 89 7e 18          	mov    %rdi,0x18(%rsi)
    a8cd:	31 ff                	xor    %edi,%edi
    a8cf:	48 89 7e 20          	mov    %rdi,0x20(%rsi)
    a8d3:	48 bf 00 00 00 00 02 	movabs $0x200000000,%rdi
    a8da:	00 00 00 
    a8dd:	48 89 7e 28          	mov    %rdi,0x28(%rsi)
    a8e1:	bf 01 00 00 00       	mov    $0x1,%edi
    a8e6:	48 89 7e 30          	mov    %rdi,0x30(%rsi)
    a8ea:	bf 00 00 01 00       	mov    $0x10000,%edi
    a8ef:	48 89 7e 38          	mov    %rdi,0x38(%rsi)
    a8f3:	48 8b 79 18          	mov    0x18(%rcx),%rdi
    a8f7:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    a8fe:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
    a902:	48 89 df             	mov    %rbx,%rdi
    a905:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
    a909:	e8 52 58 ff ff       	call   0x160
    a90e:	49 89 c5             	mov    %rax,%r13
    a911:	49 83 fd 00          	cmp    $0x0,%r13
    a915:	0f 8d 08 00 00 00    	jge    0xa923
    a91b:	4d 89 ee             	mov    %r13,%r14
    a91e:	e9 33 00 00 00       	jmp    0xa956
    a923:	4d 85 ed             	test   %r13,%r13
    a926:	0f 85 0c 00 00 00    	jne    0xa938
    a92c:	49 c7 c6 fa fd ff ff 	mov    $0xfffffffffffffdfa,%r14
    a933:	e9 1e 00 00 00       	jmp    0xa956
    a938:	49 8b 45 00          	mov    0x0(%r13),%rax
    a93c:	49 8b 4d 10          	mov    0x10(%r13),%rcx
    a940:	49 89 4d 10          	mov    %rcx,0x10(%r13)
    a944:	4d 89 6c 24 70       	mov    %r13,0x70(%r12)
    a949:	49 89 44 24 60       	mov    %rax,0x60(%r12)
    a94e:	49 89 4c 24 68       	mov    %rcx,0x68(%r12)
    a953:	45 31 f6             	xor    %r14d,%r14d
    a956:	49 83 fe 00          	cmp    $0x0,%r14
    a95a:	0f 8d 05 00 00 00    	jge    0xa965
    a960:	e9 75 02 00 00       	jmp    0xabda
    a965:	48 8b 43 18          	mov    0x18(%rbx),%rax
    a969:	48 85 c0             	test   %rax,%rax
    a96c:	0f 84 0c 00 00 00    	je     0xa97e
    a972:	0f b6 08             	movzbl (%rax),%ecx
    a975:	48 85 c9             	test   %rcx,%rcx
    a978:	0f 85 ec 01 00 00    	jne    0xab6a
    a97e:	49 8b 44 24 68       	mov    0x68(%r12),%rax
    a983:	49 8b 74 24 58       	mov    0x58(%r12),%rsi
    a988:	48 39 c6             	cmp    %rax,%rsi
    a98b:	0f 8d f6 01 00 00    	jge    0xab87
    a991:	48 89 f1             	mov    %rsi,%rcx
    a994:	48 81 c1 00 10 00 00 	add    $0x1000,%rcx
    a99b:	48 39 c1             	cmp    %rax,%rcx
    a99e:	ba 00 00 00 00       	mov    $0x0,%edx
    a9a3:	0f 9f c2             	setg   %dl
    a9a6:	49 89 c5             	mov    %rax,%r13
    a9a9:	48 85 d2             	test   %rdx,%rdx
    a9ac:	4c 0f 44 e9          	cmove  %rcx,%r13
    a9b0:	49 89 f7             	mov    %rsi,%r15
    a9b3:	31 c0                	xor    %eax,%eax
    a9b5:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
    a9b9:	4d 39 ef             	cmp    %r13,%r15
    a9bc:	0f 8d 9e 01 00 00    	jge    0xab60
    a9c2:	4c 89 f8             	mov    %r15,%rax
    a9c5:	48 83 c0 01          	add    $0x1,%rax
    a9c9:	49 8b 4c 24 60       	mov    0x60(%r12),%rcx
    a9ce:	4a 8d 14 f9          	lea    (%rcx,%r15,8),%rdx
    a9d2:	48 8b 0a             	mov    (%rdx),%rcx
    a9d5:	48 8b 51 08          	mov    0x8(%rcx),%rdx
    a9d9:	48 83 e2 01          	and    $0x1,%rdx
    a9dd:	31 f6                	xor    %esi,%esi
    a9df:	48 39 f2             	cmp    %rsi,%rdx
    a9e2:	ba 00 00 00 00       	mov    $0x0,%edx
    a9e7:	0f 95 c2             	setne  %dl
    a9ea:	48 8b 39             	mov    (%rcx),%rdi
    a9ed:	4c 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%r8
    a9f4:	4d 89 c1             	mov    %r8,%r9
    a9f7:	49 89 49 20          	mov    %rcx,0x20(%r9)
    a9fb:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    a9ff:	4d 89 11             	mov    %r10,(%r9)
    aa02:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    aa08:	4d 89 59 08          	mov    %r11,0x8(%r9)
    aa0c:	4c 8b 41 18          	mov    0x18(%rcx),%r8
    aa10:	0f b6 71 20          	movzbl 0x20(%rcx),%esi
    aa14:	48 83 e6 02          	and    $0x2,%rsi
    aa18:	31 c9                	xor    %ecx,%ecx
    aa1a:	48 39 ce             	cmp    %rcx,%rsi
    aa1d:	be 00 00 00 00       	mov    $0x0,%esi
    aa22:	40 0f 95 c6          	setne  %sil
    aa26:	31 c9                	xor    %ecx,%ecx
    aa28:	48 85 f6             	test   %rsi,%rsi
    aa2b:	4c 0f 44 c1          	cmove  %rcx,%r8
    aa2f:	31 c9                	xor    %ecx,%ecx
    aa31:	48 39 ce             	cmp    %rcx,%rsi
    aa34:	be 00 00 00 00       	mov    $0x0,%esi
    aa39:	40 0f 94 c6          	sete   %sil
    aa3d:	4d 89 41 10          	mov    %r8,0x10(%r9)
    aa41:	b9 01 00 00 00       	mov    $0x1,%ecx
    aa46:	48 31 ce             	xor    %rcx,%rsi
    aa49:	49 89 71 18          	mov    %rsi,0x18(%r9)
    aa4d:	b9 01 00 00 00       	mov    $0x1,%ecx
    aa52:	49 83 fb 00          	cmp    $0x0,%r11
    aa56:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    aa5c:	41 0f 95 c3          	setne  %r11b
    aa60:	49 31 cb             	xor    %rcx,%r11
    aa63:	48 83 fe 00          	cmp    $0x0,%rsi
    aa67:	be 00 00 00 00       	mov    $0x0,%esi
    aa6c:	40 0f 95 c6          	setne  %sil
    aa70:	48 31 ce             	xor    %rcx,%rsi
    aa73:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    aa77:	4c 8b 49 10          	mov    0x10(%rcx),%r9
    aa7b:	48 89 95 d8 fe ff ff 	mov    %rdx,-0x128(%rbp)
    aa82:	48 8b 11             	mov    (%rcx),%rdx
    aa85:	48 89 95 d0 fe ff ff 	mov    %rdx,-0x130(%rbp)
    aa8c:	48 8b 51 08          	mov    0x8(%rcx),%rdx
    aa90:	48 89 95 c8 fe ff ff 	mov    %rdx,-0x138(%rbp)
    aa97:	ba 03 00 00 00       	mov    $0x3,%edx
    aa9c:	48 89 b5 c0 fe ff ff 	mov    %rsi,-0x140(%rbp)
    aaa3:	4c 89 ce             	mov    %r9,%rsi
    aaa6:	48 0f af f2          	imul   %rdx,%rsi
    aaaa:	48 8b 95 d0 fe ff ff 	mov    -0x130(%rbp),%rdx
    aab1:	48 89 bd b8 fe ff ff 	mov    %rdi,-0x148(%rbp)
    aab8:	48 8d 3c f2          	lea    (%rdx,%rsi,8),%rdi
    aabc:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
    aac3:	4c 89 85 d0 fe ff ff 	mov    %r8,-0x130(%rbp)
    aaca:	4c 8d 04 32          	lea    (%rdx,%rsi,1),%r8
    aace:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
    aad5:	48 89 17             	mov    %rdx,(%rdi)
    aad8:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
    aadf:	41 88 10             	mov    %dl,(%r8)
    aae2:	4c 89 57 08          	mov    %r10,0x8(%rdi)
    aae6:	45 88 58 01          	mov    %r11b,0x1(%r8)
    aaea:	48 8b 95 d0 fe ff ff 	mov    -0x130(%rbp),%rdx
    aaf1:	48 89 57 10          	mov    %rdx,0x10(%rdi)
    aaf5:	48 8b 95 c0 fe ff ff 	mov    -0x140(%rbp),%rdx
    aafc:	41 88 50 02          	mov    %dl,0x2(%r8)
    ab00:	49 83 c1 01          	add    $0x1,%r9
    ab04:	4c 89 49 10          	mov    %r9,0x10(%rcx)
    ab08:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
    ab0c:	48 89 d6             	mov    %rdx,%rsi
    ab0f:	48 83 c6 01          	add    $0x1,%rsi
    ab13:	48 8b 79 18          	mov    0x18(%rcx),%rdi
    ab17:	49 39 f9             	cmp    %rdi,%r9
    ab1a:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
    ab21:	48 89 b5 d0 fe ff ff 	mov    %rsi,-0x130(%rbp)
    ab28:	0f 8c 18 00 00 00    	jl     0xab46
    ab2e:	48 89 df             	mov    %rbx,%rdi
    ab31:	e8 3a 56 ff ff       	call   0x170
    ab36:	48 85 c0             	test   %rax,%rax
    ab39:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
    ab40:	0f 85 64 00 00 00    	jne    0xabaa
    ab46:	4c 89 f8             	mov    %r15,%rax
    ab49:	48 83 c0 01          	add    $0x1,%rax
    ab4d:	49 89 c7             	mov    %rax,%r15
    ab50:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
    ab57:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
    ab5b:	e9 59 fe ff ff       	jmp    0xa9b9
    ab60:	4d 89 6c 24 58       	mov    %r13,0x58(%r12)
    ab65:	e9 fb fd ff ff       	jmp    0xa965
    ab6a:	48 89 df             	mov    %rbx,%rdi
    ab6d:	e8 ce 54 ff ff       	call   0x40
    ab72:	48 85 c0             	test   %rax,%rax
    ab75:	0f 84 03 fe ff ff    	je     0xa97e
    ab7b:	49 c7 c6 fe ff ff ff 	mov    $0xfffffffffffffffe,%r14
    ab82:	e9 53 00 00 00       	jmp    0xabda
    ab87:	31 c0                	xor    %eax,%eax
    ab89:	48 85 c0             	test   %rax,%rax
    ab8c:	0f 84 08 00 00 00    	je     0xab9a
    ab92:	49 89 c6             	mov    %rax,%r14
    ab95:	e9 40 00 00 00       	jmp    0xabda
    ab9a:	48 89 df             	mov    %rbx,%rdi
    ab9d:	e8 ce 54 ff ff       	call   0x70
    aba2:	49 89 c6             	mov    %rax,%r14
    aba5:	e9 30 00 00 00       	jmp    0xabda
    abaa:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
    abb1:	49 89 44 24 58       	mov    %rax,0x58(%r12)
    abb6:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    abbd:	48 83 f8 00          	cmp    $0x0,%rax
    abc1:	0f 8d 08 00 00 00    	jge    0xabcf
    abc7:	49 89 c6             	mov    %rax,%r14
    abca:	e9 0b 00 00 00       	jmp    0xabda
    abcf:	48 89 df             	mov    %rbx,%rdi
    abd2:	e8 a9 55 ff ff       	call   0x180
    abd7:	49 89 c6             	mov    %rax,%r14
    abda:	4c 89 f0             	mov    %r14,%rax
    abdd:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    abe4:	41 5f                	pop    %r15
    abe6:	41 5e                	pop    %r14
    abe8:	41 5d                	pop    %r13
    abea:	41 5c                	pop    %r12
    abec:	5b                   	pop    %rbx
    abed:	5d                   	pop    %rbp
    abee:	c3                   	ret
	...
    afff:	00 14 00             	add    %dl,(%rax,%rax,1)
    b002:	00 00                	add    %al,(%rax)
    b004:	00 00                	add    %al,(%rax)
    b006:	00 00                	add    %al,(%rax)
    b008:	01 7a 52             	add    %edi,0x52(%rdx)
    b00b:	00 01                	add    %al,(%rcx)
    b00d:	78 10                	js     0xb01f
    b00f:	01 1b                	add    %ebx,(%rbx)
    b011:	0c 07                	or     $0x7,%al
    b013:	08 90 01 00 00 28    	or     %dl,0x28000001(%rax)
    b019:	00 00                	add    %al,(%rax)
    b01b:	00 1c 00             	add    %bl,(%rax,%rax,1)
    b01e:	00 00                	add    %al,(%rax)
    b020:	20 52 ff             	and    %dl,-0x1(%rdx)
    b023:	ff 85 0d 00 00 00    	incl   0xd(%rbp)
    b029:	0a 41 0e             	or     0xe(%rcx),%al
    b02c:	10 86 02 43 0d 06    	adc    %al,0x60d4302(%rsi)
    b032:	50                   	push   %rax
    b033:	83 03 8c             	addl   $0xffffff8c,(%rbx)
    b036:	04 8d                	add    $0x8d,%al
    b038:	05 8e 06 8f 07       	add    $0x78f068e,%eax
    b03d:	03 70 0d             	add    0xd(%rax),%esi
    b040:	0b 00                	or     (%rax),%eax
    b042:	00 00                	add    %al,(%rax)
    b044:	28 00                	sub    %al,(%rax)
    b046:	00 00                	add    %al,(%rax)
    b048:	48 00 00             	rex.W add %al,(%rax)
    b04b:	00 b4 5f ff ff 3c 61 	add    %dh,0x613cffff(%rdi,%rbx,2)
    b052:	00 00                	add    %al,(%rax)
    b054:	00 0a                	add    %cl,(%rdx)
    b056:	41 0e                	rex.B (bad)
    b058:	10 86 02 43 0d 06    	adc    %al,0x60d4302(%rsi)
    b05e:	50                   	push   %rax
    b05f:	83 03 8c             	addl   $0xffffff8c,(%rbx)
    b062:	04 8d                	add    $0x8d,%al
    b064:	05 8e 06 8f 07       	add    $0x78f068e,%eax
    b069:	03 27                	add    (%rdi),%esp
    b06b:	61                   	(bad)
    b06c:	0b 00                	or     (%rax),%eax
    b06e:	00 00                	add    %al,(%rax)
    b070:	28 00                	sub    %al,(%rax)
    b072:	00 00                	add    %al,(%rax)
    b074:	74 00                	je     0xb076
    b076:	00 00                	add    %al,(%rax)
    b078:	c8 c0 ff ff          	enter  $0xffc0,$0xff
    b07c:	1f                   	(bad)
    b07d:	33 00                	xor    (%rax),%eax
    b07f:	00 00                	add    %al,(%rax)
    b081:	0a 41 0e             	or     0xe(%rcx),%al
    b084:	10 86 02 43 0d 06    	adc    %al,0x60d4302(%rsi)
    b08a:	50                   	push   %rax
    b08b:	83 03 8c             	addl   $0xffffff8c,(%rbx)
    b08e:	04 8d                	add    $0x8d,%al
    b090:	05 8e 06 8f 07       	add    $0x78f068e,%eax
    b095:	03 0a                	add    (%rdx),%ecx
    b097:	33 0b                	xor    (%rbx),%ecx
    b099:	00 00                	add    %al,(%rax)
    b09b:	00 28                	add    %ch,(%rax)
    b09d:	00 00                	add    %al,(%rax)
    b09f:	00 a0 00 00 00 dc    	add    %ah,-0x24000000(%rax)
    b0a5:	f3 ff                	repz (bad)
    b0a7:	ff 9b 03 00 00 00    	lcall  *0x3(%rbx)
    b0ad:	0a 41 0e             	or     0xe(%rcx),%al
    b0b0:	10 86 02 43 0d 06    	adc    %al,0x60d4302(%rsi)
    b0b6:	50                   	push   %rax
    b0b7:	83 03 8c             	addl   $0xffffff8c,(%rbx)
    b0ba:	04 8d                	add    $0x8d,%al
    b0bc:	05 8e 06 8f 07       	add    $0x78f068e,%eax
    b0c1:	03 86 03 0b 00 00    	add    0xb03(%rsi),%eax
    b0c7:	00 2c 00             	add    %ch,(%rax,%rax,1)
    b0ca:	00 00                	add    %al,(%rax)
    b0cc:	cc                   	int3
    b0cd:	00 00                	add    %al,(%rax)
    b0cf:	00 70 f7             	add    %dh,-0x9(%rax)
    b0d2:	ff                   	(bad)
    b0d3:	ff af 03 00 00 00    	ljmp   *0x3(%rdi)
    b0d9:	0a 41 0e             	or     0xe(%rcx),%al
    b0dc:	10 86 02 43 0d 06    	adc    %al,0x60d4302(%rsi)
    b0e2:	50                   	push   %rax
    b0e3:	83 03 8c             	addl   $0xffffff8c,(%rbx)
    b0e6:	04 8d                	add    $0x8d,%al
    b0e8:	05 8e 06 8f 07       	add    $0x78f068e,%eax
    b0ed:	03 9a 03 0b 00 00    	add    0xb03(%rdx),%ebx
	...
