
/home/rustsql/profile-candidate-20261030e/jit/914057d8ff5d7e432dc784af8b47b658.x86_64.bin:     file format binary


Disassembly of section .data:

0000000000000240 <.data+0x240>:
     240:	55                   	push   %rbp
     241:	48 89 e5             	mov    %rsp,%rbp
     244:	53                   	push   %rbx
     245:	41 54                	push   %r12
     247:	41 55                	push   %r13
     249:	41 56                	push   %r14
     24b:	41 57                	push   %r15
     24d:	48 81 ec 18 01 00 00 	sub    $0x118,%rsp
     254:	48 89 fb             	mov    %rdi,%rbx
     257:	31 c0                	xor    %eax,%eax
     259:	48 8b 4b 50          	mov    0x50(%rbx),%rcx
     25d:	48 85 c9             	test   %rcx,%rcx
     260:	0f 85 9b 00 00 00    	jne    0x301
     266:	48 b9 01 00 00 00 00 	movabs $0x4000000000001,%rcx
     26d:	00 04 00 
     270:	48 89 4b 50          	mov    %rcx,0x50(%rbx)
     274:	48 8b 0b             	mov    (%rbx),%rcx
     277:	48 8b 51 28          	mov    0x28(%rcx),%rdx
     27b:	48 8b 0a             	mov    (%rdx),%rcx
     27e:	0f b6 11             	movzbl (%rcx),%edx
     281:	48 85 d2             	test   %rdx,%rdx
     284:	0f 85 58 00 00 00    	jne    0x2e2
     28a:	8b 51 08             	mov    0x8(%rcx),%edx
     28d:	48 89 51 38          	mov    %rdx,0x38(%rcx)
     291:	48 89 51 50          	mov    %rdx,0x50(%rcx)
     295:	48 89 41 10          	mov    %rax,0x10(%rcx)
     299:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
     2a0:	ff ff 7f 
     2a3:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
     2aa:	00 00 80 
     2ad:	48 89 51 18          	mov    %rdx,0x18(%rcx)
     2b1:	48 89 71 20          	mov    %rsi,0x20(%rcx)
     2b5:	ba 01 00 00 00       	mov    $0x1,%edx
     2ba:	88 11                	mov    %dl,(%rcx)
     2bc:	48 c7 c2 83 ff ff ff 	mov    $0xffffffffffffff83,%rdx
     2c3:	88 51 03             	mov    %dl,0x3(%rcx)
     2c6:	ba 07 00 00 00       	mov    $0x7,%edx
     2cb:	88 51 0f             	mov    %dl,0xf(%rcx)
     2ce:	31 d2                	xor    %edx,%edx
     2d0:	be 06 00 00 00       	mov    $0x6,%esi
     2d5:	31 ff                	xor    %edi,%edi
     2d7:	88 51 70             	mov    %dl,0x70(%rcx)
     2da:	40 88 71 71          	mov    %sil,0x71(%rcx)
     2de:	48 89 79 78          	mov    %rdi,0x78(%rcx)
     2e2:	31 c0                	xor    %eax,%eax
     2e4:	48 89 df             	mov    %rbx,%rdi
     2e7:	48 89 c6             	mov    %rax,%rsi
     2ea:	e8 11 fd ff ff       	call   0x0
     2ef:	48 83 f8 00          	cmp    $0x0,%rax
     2f3:	0f 8d 08 00 00 00    	jge    0x301
     2f9:	49 89 c4             	mov    %rax,%r12
     2fc:	e9 af 0c 00 00       	jmp    0xfb0
     301:	48 8b 43 18          	mov    0x18(%rbx),%rax
     305:	48 85 c0             	test   %rax,%rax
     308:	0f 84 0c 00 00 00    	je     0x31a
     30e:	0f b6 08             	movzbl (%rax),%ecx
     311:	48 85 c9             	test   %rcx,%rcx
     314:	0f 85 fc 0b 00 00    	jne    0xf16
     31a:	31 c0                	xor    %eax,%eax
     31c:	48 89 df             	mov    %rbx,%rdi
     31f:	48 89 c6             	mov    %rax,%rsi
     322:	e8 e9 fc ff ff       	call   0x10
     327:	48 83 f8 00          	cmp    $0x0,%rax
     32b:	0f 8f 08 00 00 00    	jg     0x339
     331:	49 89 c5             	mov    %rax,%r13
     334:	e9 f3 0b 00 00       	jmp    0xf2c
     339:	8b 83 00 01 00 00    	mov    0x100(%rbx),%eax
     33f:	8b 8b fc 00 00 00    	mov    0xfc(%rbx),%ecx
     345:	4c 8b b3 d0 00 00 00 	mov    0xd0(%rbx),%r14
     34c:	31 d2                	xor    %edx,%edx
     34e:	49 39 d6             	cmp    %rdx,%r14
     351:	41 bf 00 00 00 00    	mov    $0x0,%r15d
     357:	41 0f 94 c7          	sete   %r15b
     35b:	8b b3 04 01 00 00    	mov    0x104(%rbx),%esi
     361:	4d 85 ff             	test   %r15,%r15
     364:	48 0f 44 ce          	cmove  %rsi,%rcx
     368:	48 8b b3 38 01 00 00 	mov    0x138(%rbx),%rsi
     36f:	0f b7 bb 2c 01 00 00 	movzwl 0x12c(%rbx),%edi
     376:	49 89 f8             	mov    %rdi,%r8
     379:	49 83 e0 08          	and    $0x8,%r8
     37d:	49 89 f9             	mov    %rdi,%r9
     380:	49 83 e1 0a          	and    $0xa,%r9
     384:	49 89 fa             	mov    %rdi,%r10
     387:	49 83 e2 03          	and    $0x3,%r10
     38b:	49 89 fb             	mov    %rdi,%r11
     38e:	49 83 e3 10          	and    $0x10,%r11
     392:	49 39 d0             	cmp    %rdx,%r8
     395:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     39b:	41 0f 95 c0          	setne  %r8b
     39f:	49 39 d1             	cmp    %rdx,%r9
     3a2:	41 b9 00 00 00 00    	mov    $0x0,%r9d
     3a8:	41 0f 95 c1          	setne  %r9b
     3ac:	49 83 fa 03          	cmp    $0x3,%r10
     3b0:	41 ba 00 00 00 00    	mov    $0x0,%r10d
     3b6:	41 0f 94 c2          	sete   %r10b
     3ba:	49 39 d3             	cmp    %rdx,%r11
     3bd:	41 bb 00 00 00 00    	mov    $0x0,%r11d
     3c3:	41 0f 95 c3          	setne  %r11b
     3c7:	4d 09 c2             	or     %r8,%r10
     3ca:	4d 89 c8             	mov    %r9,%r8
     3cd:	4d 21 d8             	and    %r11,%r8
     3d0:	4d 85 c9             	test   %r9,%r9
     3d3:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     3d7:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
     3db:	48 89 75 b0          	mov    %rsi,-0x50(%rbp)
     3df:	48 89 7d a8          	mov    %rdi,-0x58(%rbp)
     3e3:	4c 89 45 a0          	mov    %r8,-0x60(%rbp)
     3e7:	4c 89 55 98          	mov    %r10,-0x68(%rbp)
     3eb:	0f 85 46 00 00 00    	jne    0x437
     3f1:	45 31 c9             	xor    %r9d,%r9d
     3f4:	48 89 df             	mov    %rbx,%rdi
     3f7:	31 f6                	xor    %esi,%esi
     3f9:	4c 89 ca             	mov    %r9,%rdx
     3fc:	e8 1f fc ff ff       	call   0x20
     401:	48 83 f8 00          	cmp    $0x0,%rax
     405:	0f 8d 08 00 00 00    	jge    0x413
     40b:	49 89 c5             	mov    %rax,%r13
     40e:	e9 19 0b 00 00       	jmp    0xf2c
     413:	b8 01 00 00 00       	mov    $0x1,%eax
     418:	48 89 df             	mov    %rbx,%rdi
     41b:	31 f6                	xor    %esi,%esi
     41d:	48 89 c2             	mov    %rax,%rdx
     420:	e8 fb fb ff ff       	call   0x20
     425:	48 83 f8 00          	cmp    $0x0,%rax
     429:	0f 8d 08 00 00 00    	jge    0x437
     42f:	49 89 c5             	mov    %rax,%r13
     432:	e9 f5 0a 00 00       	jmp    0xf2c
     437:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
     43e:	48 8b 48 40          	mov    0x40(%rax),%rcx
     442:	48 8b 10             	mov    (%rax),%rdx
     445:	48 8b 70 20          	mov    0x20(%rax),%rsi
     449:	48 8b 78 28          	mov    0x28(%rax),%rdi
     44d:	31 c0                	xor    %eax,%eax
     44f:	48 39 c7             	cmp    %rax,%rdi
     452:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     458:	41 0f 94 c0          	sete   %r8b
     45c:	4c 8b 0b             	mov    (%rbx),%r9
     45f:	4d 8b 51 28          	mov    0x28(%r9),%r10
     463:	4d 8b 0a             	mov    (%r10),%r9
     466:	4d 8b 51 10          	mov    0x10(%r9),%r10
     46a:	4d 8b 59 18          	mov    0x18(%r9),%r11
     46e:	49 8b 41 20          	mov    0x20(%r9),%rax
     472:	48 89 45 90          	mov    %rax,-0x70(%rbp)
     476:	48 8b 45 98          	mov    -0x68(%rbp),%rax
     47a:	4c 21 f8             	and    %r15,%rax
     47d:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
     481:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
     485:	4c 21 c8             	and    %r9,%rax
     488:	48 85 c0             	test   %rax,%rax
     48b:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
     48f:	48 89 55 88          	mov    %rdx,-0x78(%rbp)
     493:	48 89 75 80          	mov    %rsi,-0x80(%rbp)
     497:	48 89 bd 78 ff ff ff 	mov    %rdi,-0x88(%rbp)
     49e:	4c 89 85 70 ff ff ff 	mov    %r8,-0x90(%rbp)
     4a5:	0f 85 3d 00 00 00    	jne    0x4e8
     4ab:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     4af:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
     4b6:	31 c0                	xor    %eax,%eax
     4b8:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
     4bf:	4c 89 95 58 ff ff ff 	mov    %r10,-0xa8(%rbp)
     4c6:	4c 89 9d 50 ff ff ff 	mov    %r11,-0xb0(%rbp)
     4cd:	48 8b 45 90          	mov    -0x70(%rbp),%rax
     4d1:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
     4d8:	48 8b 45 98          	mov    -0x68(%rbp),%rax
     4dc:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
     4e3:	e9 66 03 00 00       	jmp    0x84e
     4e8:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     4ec:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
     4f3:	4c 89 5d c0          	mov    %r11,-0x40(%rbp)
     4f7:	48 8b 45 90          	mov    -0x70(%rbp),%rax
     4fb:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
     502:	31 c0                	xor    %eax,%eax
     504:	48 89 45 90          	mov    %rax,-0x70(%rbp)
     508:	4c 89 95 28 ff ff ff 	mov    %r10,-0xd8(%rbp)
     50f:	48 8b 45 98          	mov    -0x68(%rbp),%rax
     513:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
     51a:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
     521:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
     525:	48 39 c8             	cmp    %rcx,%rax
     528:	0f 8c 42 00 00 00    	jl     0x570
     52e:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
     535:	48 89 55 98          	mov    %rdx,-0x68(%rbp)
     539:	48 8b 55 90          	mov    -0x70(%rbp),%rdx
     53d:	48 89 95 18 ff ff ff 	mov    %rdx,-0xe8(%rbp)
     544:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
     54b:	48 89 95 10 ff ff ff 	mov    %rdx,-0xf0(%rbp)
     552:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
     556:	48 89 95 08 ff ff ff 	mov    %rdx,-0xf8(%rbp)
     55d:	48 8b 95 30 ff ff ff 	mov    -0xd0(%rbp),%rdx
     564:	48 89 95 00 ff ff ff 	mov    %rdx,-0x100(%rbp)
     56b:	e9 24 09 00 00       	jmp    0xe94
     570:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
     574:	48 8d 74 82 18       	lea    0x18(%rdx,%rax,4),%rsi
     579:	8b 3e                	mov    (%rsi),%edi
     57b:	48 81 e7 ff 7f 00 00 	and    $0x7fff,%rdi
     582:	48 8d 34 3a          	lea    (%rdx,%rdi,1),%rsi
     586:	0f b6 7e 16          	movzbl 0x16(%rsi),%edi
     58a:	44 8b 46 12          	mov    0x12(%rsi),%r8d
     58e:	4d 89 c1             	mov    %r8,%r9
     591:	49 81 e1 00 00 01 00 	and    $0x10000,%r9
     598:	4d 85 c9             	test   %r9,%r9
     59b:	0f 85 5f 02 00 00    	jne    0x800
     5a1:	49 81 e0 ff 07 00 00 	and    $0x7ff,%r8
     5a8:	49 83 f8 02          	cmp    $0x2,%r8
     5ac:	0f 82 4e 02 00 00    	jb     0x800
     5b2:	4c 8d 04 3e          	lea    (%rsi,%rdi,1),%r8
     5b6:	49 63 30             	movslq (%r8),%rsi
     5b9:	4d 8d 40 04          	lea    0x4(%r8),%r8
     5bd:	49 63 38             	movslq (%r8),%rdi
     5c0:	48 63 f6             	movslq %esi,%rsi
     5c3:	48 89 b5 f8 fe ff ff 	mov    %rsi,-0x108(%rbp)
     5ca:	48 89 bd f0 fe ff ff 	mov    %rdi,-0x110(%rbp)
     5d1:	4c 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%r8
     5d8:	4c 89 85 e8 fe ff ff 	mov    %r8,-0x118(%rbp)
     5df:	4c 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%r8
     5e6:	4c 89 85 e0 fe ff ff 	mov    %r8,-0x120(%rbp)
     5ed:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
     5f4:	48 8b 48 38          	mov    0x38(%rax),%rcx
     5f8:	ba 18 00 00 00       	mov    $0x18,%edx
     5fd:	48 8b b5 e0 fe ff ff 	mov    -0x120(%rbp),%rsi
     604:	48 89 f7             	mov    %rsi,%rdi
     607:	48 0f af fa          	imul   %rdx,%rdi
     60b:	48 8d 94 38 c0 00 00 	lea    0xc0(%rax,%rdi,1),%rdx
     612:	00 
     613:	48 81 c7 d8 00 00 00 	add    $0xd8,%rdi
     61a:	48 39 cf             	cmp    %rcx,%rdi
     61d:	48 89 8d d8 fe ff ff 	mov    %rcx,-0x128(%rbp)
     624:	48 89 95 d0 fe ff ff 	mov    %rdx,-0x130(%rbp)
     62b:	0f 8e dc 00 00 00    	jle    0x70d
     631:	48 8b 7b 18          	mov    0x18(%rbx),%rdi
     635:	48 85 ff             	test   %rdi,%rdi
     638:	0f 84 0d 00 00 00    	je     0x64b
     63e:	44 0f b6 07          	movzbl (%rdi),%r8d
     642:	4d 85 c0             	test   %r8,%r8
     645:	0f 85 ac 00 00 00    	jne    0x6f7
     64b:	b8 01 00 00 00       	mov    $0x1,%eax
     650:	48 8b 8d e8 fe ff ff 	mov    -0x118(%rbp),%rcx
     657:	88 41 02             	mov    %al,0x2(%rcx)
     65a:	b8 01 00 00 00       	mov    $0x1,%eax
     65f:	88 41 0d             	mov    %al,0xd(%rcx)
     662:	31 c0                	xor    %eax,%eax
     664:	88 41 37             	mov    %al,0x37(%rcx)
     667:	b8 01 00 00 00       	mov    $0x1,%eax
     66c:	88 41 01             	mov    %al,0x1(%rcx)
     66f:	b8 18 00 00 00       	mov    $0x18,%eax
     674:	ba 18 00 00 00       	mov    $0x18,%edx
     679:	89 41 04             	mov    %eax,0x4(%rcx)
     67c:	89 51 58             	mov    %edx,0x58(%rcx)
     67f:	31 c0                	xor    %eax,%eax
     681:	66 89 81 80 00 00 00 	mov    %ax,0x80(%rcx)
     688:	48 8d 45 d0          	lea    -0x30(%rbp),%rax
     68c:	48 89 c2             	mov    %rax,%rdx
     68f:	be 18 00 00 00       	mov    $0x18,%esi
     694:	48 89 df             	mov    %rbx,%rdi
     697:	48 89 ce             	mov    %rcx,%rsi
     69a:	48 89 95 c8 fe ff ff 	mov    %rdx,-0x138(%rbp)
     6a1:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
     6a8:	b9 18 00 00 00       	mov    $0x18,%ecx
     6ad:	4c 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%r8
     6b4:	4c 8b 8d c8 fe ff ff 	mov    -0x138(%rbp),%r9
     6bb:	e8 70 f9 ff ff       	call   0x30
     6c0:	48 85 c0             	test   %rax,%rax
     6c3:	0f 85 11 00 00 00    	jne    0x6da
     6c9:	b9 80 00 00 00       	mov    $0x80,%ecx
     6ce:	48 89 8d c0 fe ff ff 	mov    %rcx,-0x140(%rbp)
     6d5:	e9 c1 08 00 00       	jmp    0xf9b
     6da:	48 8b 8d c8 fe ff ff 	mov    -0x138(%rbp),%rcx
     6e1:	48 8b 11             	mov    (%rcx),%rdx
     6e4:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
     6eb:	48 89 95 e0 fe ff ff 	mov    %rdx,-0x120(%rbp)
     6f2:	e9 f6 fe ff ff       	jmp    0x5ed
     6f7:	48 89 df             	mov    %rbx,%rdi
     6fa:	e8 41 f9 ff ff       	call   0x40
     6ff:	48 85 c0             	test   %rax,%rax
     702:	0f 84 43 ff ff ff    	je     0x64b
     708:	e9 82 08 00 00       	jmp    0xf8f
     70d:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
     714:	48 8b 8d f8 fe ff ff 	mov    -0x108(%rbp),%rcx
     71b:	48 89 08             	mov    %rcx,(%rax)
     71e:	48 8b 95 f0 fe ff ff 	mov    -0x110(%rbp),%rdx
     725:	48 89 50 10          	mov    %rdx,0x10(%rax)
     729:	31 d2                	xor    %edx,%edx
     72b:	48 89 50 08          	mov    %rdx,0x8(%rax)
     72f:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
     736:	0f b6 50 70          	movzbl 0x70(%rax),%edx
     73a:	48 85 d2             	test   %rdx,%rdx
     73d:	0f 85 11 00 00 00    	jne    0x754
     743:	ba 01 00 00 00       	mov    $0x1,%edx
     748:	48 89 95 d0 fe ff ff 	mov    %rdx,-0x130(%rbp)
     74f:	e9 3b 00 00 00       	jmp    0x78f
     754:	48 89 df             	mov    %rbx,%rdi
     757:	48 89 c6             	mov    %rax,%rsi
     75a:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
     761:	48 8b 8d d8 fe ff ff 	mov    -0x128(%rbp),%rcx
     768:	e8 e3 f8 ff ff       	call   0x50
     76d:	48 83 f8 00          	cmp    $0x0,%rax
     771:	0f 8d 11 00 00 00    	jge    0x788
     777:	b9 80 00 00 00       	mov    $0x80,%ecx
     77c:	48 89 8d c0 fe ff ff 	mov    %rcx,-0x140(%rbp)
     783:	e9 13 08 00 00       	jmp    0xf9b
     788:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
     78f:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     793:	48 8b 8d f8 fe ff ff 	mov    -0x108(%rbp),%rcx
     79a:	48 89 c2             	mov    %rax,%rdx
     79d:	48 39 ca             	cmp    %rcx,%rdx
     7a0:	48 0f 4f d1          	cmovg  %rcx,%rdx
     7a4:	48 8b b5 30 ff ff ff 	mov    -0xd0(%rbp),%rsi
     7ab:	48 89 f7             	mov    %rsi,%rdi
     7ae:	48 39 cf             	cmp    %rcx,%rdi
     7b1:	48 0f 4c f9          	cmovl  %rcx,%rdi
     7b5:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
     7bc:	4c 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%r8
     7c3:	4c 01 c1             	add    %r8,%rcx
     7c6:	4c 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%r8
     7cd:	4d 89 c1             	mov    %r8,%r9
     7d0:	49 83 c1 01          	add    $0x1,%r9
     7d4:	4c 89 8d 38 ff ff ff 	mov    %r9,-0xc8(%rbp)
     7db:	48 89 8d 28 ff ff ff 	mov    %rcx,-0xd8(%rbp)
     7e2:	48 89 55 c0          	mov    %rdx,-0x40(%rbp)
     7e6:	48 89 bd 30 ff ff ff 	mov    %rdi,-0xd0(%rbp)
     7ed:	48 8b 8d e8 fe ff ff 	mov    -0x118(%rbp),%rcx
     7f4:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
     7fb:	e9 1a fd ff ff       	jmp    0x51a
     800:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
     807:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
     80e:	48 8b 45 90          	mov    -0x70(%rbp),%rax
     812:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
     819:	48 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%rax
     820:	48 89 85 58 ff ff ff 	mov    %rax,-0xa8(%rbp)
     827:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     82b:	48 89 85 50 ff ff ff 	mov    %rax,-0xb0(%rbp)
     832:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
     839:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
     840:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
     847:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
     84e:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
     855:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
     859:	48 39 c8             	cmp    %rcx,%rax
     85c:	0f 8c 48 00 00 00    	jl     0x8aa
     862:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
     869:	48 89 95 18 ff ff ff 	mov    %rdx,-0xe8(%rbp)
     870:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
     877:	48 89 95 10 ff ff ff 	mov    %rdx,-0xf0(%rbp)
     87e:	48 8b 95 50 ff ff ff 	mov    -0xb0(%rbp),%rdx
     885:	48 89 95 08 ff ff ff 	mov    %rdx,-0xf8(%rbp)
     88c:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
     893:	48 89 95 00 ff ff ff 	mov    %rdx,-0x100(%rbp)
     89a:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
     8a1:	48 89 55 98          	mov    %rdx,-0x68(%rbp)
     8a5:	e9 ea 05 00 00       	jmp    0xe94
     8aa:	4d 85 ff             	test   %r15,%r15
     8ad:	0f 84 0c 00 00 00    	je     0x8bf
     8b3:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
     8ba:	e9 0d 00 00 00       	jmp    0x8cc
     8bf:	49 8d 14 86          	lea    (%r14,%rax,4),%rdx
     8c3:	8b 32                	mov    (%rdx),%esi
     8c5:	48 89 b5 20 ff ff ff 	mov    %rsi,-0xe0(%rbp)
     8cc:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
     8d0:	48 89 c1             	mov    %rax,%rcx
     8d3:	48 83 e1 03          	and    $0x3,%rcx
     8d7:	48 83 f9 03          	cmp    $0x3,%rcx
     8db:	0f 85 5d 00 00 00    	jne    0x93e
     8e1:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
     8e5:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
     8ec:	48 8d 34 51          	lea    (%rcx,%rdx,2),%rsi
     8f0:	0f b7 3e             	movzwl (%rsi),%edi
     8f3:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
     8f7:	4c 8d 44 be 14       	lea    0x14(%rsi,%rdi,4),%r8
     8fc:	41 8b 38             	mov    (%r8),%edi
     8ff:	48 81 e7 ff 7f 00 00 	and    $0x7fff,%rdi
     906:	4c 8d 04 3e          	lea    (%rsi,%rdi,1),%r8
     90a:	41 0f b6 78 16       	movzbl 0x16(%r8),%edi
     90f:	4d 8d 0c 38          	lea    (%r8,%rdi,1),%r9
     913:	49 63 39             	movslq (%r9),%rdi
     916:	4d 8d 49 04          	lea    0x4(%r9),%r9
     91a:	4d 63 01             	movslq (%r9),%r8
     91d:	45 31 c9             	xor    %r9d,%r9d
     920:	4c 89 8d 30 ff ff ff 	mov    %r9,-0xd0(%rbp)
     927:	48 89 7d c0          	mov    %rdi,-0x40(%rbp)
     92b:	4c 89 85 28 ff ff ff 	mov    %r8,-0xd8(%rbp)
     932:	45 31 c9             	xor    %r9d,%r9d
     935:	4c 89 4d 90          	mov    %r9,-0x70(%rbp)
     939:	e9 25 03 00 00       	jmp    0xc63
     93e:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
     942:	48 89 c1             	mov    %rax,%rcx
     945:	48 83 e1 0a          	and    $0xa,%rcx
     949:	48 85 c9             	test   %rcx,%rcx
     94c:	0f 84 7c 02 00 00    	je     0xbce
     952:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
     956:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
     95d:	48 8d 34 51          	lea    (%rcx,%rdx,2),%rsi
     961:	0f b7 3e             	movzwl (%rsi),%edi
     964:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
     968:	4c 8d 44 be 14       	lea    0x14(%rsi,%rdi,4),%r8
     96d:	41 8b 38             	mov    (%r8),%edi
     970:	48 81 e7 ff 7f 00 00 	and    $0x7fff,%rdi
     977:	4c 8d 04 3e          	lea    (%rsi,%rdi,1),%r8
     97b:	41 0f b6 78 16       	movzbl 0x16(%r8),%edi
     980:	45 8b 48 12          	mov    0x12(%r8),%r9d
     984:	4d 89 ca             	mov    %r9,%r10
     987:	49 81 e2 ff 07 00 00 	and    $0x7ff,%r10
     98e:	49 83 fa 02          	cmp    $0x2,%r10
     992:	48 89 bd 38 ff ff ff 	mov    %rdi,-0xc8(%rbp)
     999:	4c 89 85 e8 fe ff ff 	mov    %r8,-0x118(%rbp)
     9a0:	4c 89 8d e0 fe ff ff 	mov    %r9,-0x120(%rbp)
     9a7:	0f 83 19 01 00 00    	jae    0xac6
     9ad:	45 31 d2             	xor    %r10d,%r10d
     9b0:	4c 8b 9b a0 00 00 00 	mov    0xa0(%rbx),%r11
     9b7:	4d 8b 0b             	mov    (%r11),%r9
     9ba:	4d 85 c9             	test   %r9,%r9
     9bd:	4c 89 9d d0 fe ff ff 	mov    %r11,-0x130(%rbp)
     9c4:	0f 85 23 00 00 00    	jne    0x9ed
     9ca:	45 31 c9             	xor    %r9d,%r9d
     9cd:	48 89 df             	mov    %rbx,%rdi
     9d0:	4c 89 d6             	mov    %r10,%rsi
     9d3:	4c 89 ca             	mov    %r9,%rdx
     9d6:	e8 45 f6 ff ff       	call   0x20
     9db:	48 83 f8 00          	cmp    $0x0,%rax
     9df:	0f 8d 08 00 00 00    	jge    0x9ed
     9e5:	49 89 c4             	mov    %rax,%r12
     9e8:	e9 c3 05 00 00       	jmp    0xfb0
     9ed:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
     9f4:	48 8b 48 20          	mov    0x20(%rax),%rcx
     9f8:	48 85 c9             	test   %rcx,%rcx
     9fb:	0f 85 24 00 00 00    	jne    0xa25
     a01:	b9 01 00 00 00       	mov    $0x1,%ecx
     a06:	48 89 df             	mov    %rbx,%rdi
     a09:	31 f6                	xor    %esi,%esi
     a0b:	48 89 ca             	mov    %rcx,%rdx
     a0e:	e8 0d f6 ff ff       	call   0x20
     a13:	48 83 f8 00          	cmp    $0x0,%rax
     a17:	0f 8d 08 00 00 00    	jge    0xa25
     a1d:	49 89 c4             	mov    %rax,%r12
     a20:	e9 8b 05 00 00       	jmp    0xfb0
     a25:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
     a2c:	48 8b 08             	mov    (%rax),%rcx
     a2f:	48 8b 50 20          	mov    0x20(%rax),%rdx
     a33:	48 8b 70 28          	mov    0x28(%rax),%rsi
     a37:	31 c0                	xor    %eax,%eax
     a39:	48 39 c6             	cmp    %rax,%rsi
     a3c:	bf 00 00 00 00       	mov    $0x0,%edi
     a41:	40 0f 94 c7          	sete   %dil
     a45:	4c 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%r8
     a4c:	4e 8d 0c c1          	lea    (%rcx,%r8,8),%r9
     a50:	49 8b 09             	mov    (%r9),%rcx
     a53:	4e 8d 0c c2          	lea    (%rdx,%r8,8),%r9
     a57:	49 8b 11             	mov    (%r9),%rdx
     a5a:	4d 89 c1             	mov    %r8,%r9
     a5d:	49 c1 e9 06          	shr    $0x6,%r9
     a61:	4e 8d 14 ce          	lea    (%rsi,%r9,8),%r10
     a65:	48 89 de             	mov    %rbx,%rsi
     a68:	48 85 ff             	test   %rdi,%rdi
     a6b:	49 0f 44 f2          	cmove  %r10,%rsi
     a6f:	4c 8b 0e             	mov    (%rsi),%r9
     a72:	4c 89 c6             	mov    %r8,%rsi
     a75:	48 83 e6 3f          	and    $0x3f,%rsi
     a79:	48 89 8d d0 fe ff ff 	mov    %rcx,-0x130(%rbp)
     a80:	48 89 f1             	mov    %rsi,%rcx
     a83:	49 d3 e9             	shr    %cl,%r9
     a86:	49 83 e1 01          	and    $0x1,%r9
     a8a:	49 39 c1             	cmp    %rax,%r9
     a8d:	41 b9 00 00 00 00    	mov    $0x0,%r9d
     a93:	41 0f 94 c1          	sete   %r9b
     a97:	b9 01 00 00 00       	mov    $0x1,%ecx
     a9c:	48 31 cf             	xor    %rcx,%rdi
     a9f:	49 21 f9             	and    %rdi,%r9
     aa2:	48 8b 8d d0 fe ff ff 	mov    -0x130(%rbp),%rcx
     aa9:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
     aad:	31 c9                	xor    %ecx,%ecx
     aaf:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
     ab3:	48 89 95 28 ff ff ff 	mov    %rdx,-0xd8(%rbp)
     aba:	4c 89 8d 30 ff ff ff 	mov    %r9,-0xd0(%rbp)
     ac1:	e9 03 01 00 00       	jmp    0xbc9
     ac6:	48 8b 85 e0 fe ff ff 	mov    -0x120(%rbp),%rax
     acd:	48 25 00 00 01 00    	and    $0x10000,%rax
     ad3:	48 85 c0             	test   %rax,%rax
     ad6:	0f 85 3b 00 00 00    	jne    0xb17
     adc:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
     ae3:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
     aea:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
     aee:	48 63 32             	movslq (%rdx),%rsi
     af1:	48 8d 52 04          	lea    0x4(%rdx),%rdx
     af5:	48 63 3a             	movslq (%rdx),%rdi
     af8:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
     afc:	31 d2                	xor    %edx,%edx
     afe:	48 89 55 90          	mov    %rdx,-0x70(%rbp)
     b02:	48 89 bd 28 ff ff ff 	mov    %rdi,-0xd8(%rbp)
     b09:	31 d2                	xor    %edx,%edx
     b0b:	48 89 95 30 ff ff ff 	mov    %rdx,-0xd0(%rbp)
     b12:	e9 b2 00 00 00       	jmp    0xbc9
     b17:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
     b1e:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
     b25:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
     b29:	0f b6 48 17          	movzbl 0x17(%rax),%ecx
     b2d:	48 89 ce             	mov    %rcx,%rsi
     b30:	48 83 e6 01          	and    $0x1,%rsi
     b34:	31 ff                	xor    %edi,%edi
     b36:	48 39 fe             	cmp    %rdi,%rsi
     b39:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     b3f:	41 0f 95 c0          	setne  %r8b
     b43:	48 39 fe             	cmp    %rdi,%rsi
     b46:	be 00 00 00 00       	mov    $0x0,%esi
     b4b:	40 0f 94 c6          	sete   %sil
     b4f:	45 31 c9             	xor    %r9d,%r9d
     b52:	4d 85 c0             	test   %r8,%r8
     b55:	4c 0f 44 cf          	cmove  %rdi,%r9
     b59:	49 89 d2             	mov    %rdx,%r10
     b5c:	4d 85 c0             	test   %r8,%r8
     b5f:	4c 0f 44 d0          	cmove  %rax,%r10
     b63:	4f 8d 1c 0a          	lea    (%r10,%r9,1),%r11
     b67:	4d 63 0b             	movslq (%r11),%r9
     b6a:	41 ba 04 00 00 00    	mov    $0x4,%r10d
     b70:	4d 85 c0             	test   %r8,%r8
     b73:	4c 0f 44 d7          	cmove  %rdi,%r10
     b77:	48 d1 e9             	shr    $1,%rcx
     b7a:	48 83 e1 01          	and    $0x1,%rcx
     b7e:	48 39 f9             	cmp    %rdi,%rcx
     b81:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     b87:	41 0f 95 c0          	setne  %r8b
     b8b:	48 39 f9             	cmp    %rdi,%rcx
     b8e:	b9 00 00 00 00       	mov    $0x0,%ecx
     b93:	0f 94 c1             	sete   %cl
     b96:	49 83 c2 03          	add    $0x3,%r10
     b9a:	49 83 e2 fc          	and    $0xfffffffffffffffc,%r10
     b9e:	4d 85 c0             	test   %r8,%r8
     ba1:	4c 0f 44 d7          	cmove  %rdi,%r10
     ba5:	4d 85 c0             	test   %r8,%r8
     ba8:	48 0f 44 d0          	cmove  %rax,%rdx
     bac:	4a 8d 04 12          	lea    (%rdx,%r10,1),%rax
     bb0:	48 63 10             	movslq (%rax),%rdx
     bb3:	4c 89 4d c0          	mov    %r9,-0x40(%rbp)
     bb7:	48 89 75 90          	mov    %rsi,-0x70(%rbp)
     bbb:	48 89 95 28 ff ff ff 	mov    %rdx,-0xd8(%rbp)
     bc2:	48 89 8d 30 ff ff ff 	mov    %rcx,-0xd0(%rbp)
     bc9:	e9 95 00 00 00       	jmp    0xc63
     bce:	48 8b 45 88          	mov    -0x78(%rbp),%rax
     bd2:	48 8b 8d 20 ff ff ff 	mov    -0xe0(%rbp),%rcx
     bd9:	48 8d 14 c8          	lea    (%rax,%rcx,8),%rdx
     bdd:	48 8b 32             	mov    (%rdx),%rsi
     be0:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
     be4:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
     be8:	4c 8b 07             	mov    (%rdi),%r8
     beb:	48 89 cf             	mov    %rcx,%rdi
     bee:	48 c1 ef 06          	shr    $0x6,%rdi
     bf2:	4c 8b 8d 78 ff ff ff 	mov    -0x88(%rbp),%r9
     bf9:	4d 8d 14 f9          	lea    (%r9,%rdi,8),%r10
     bfd:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
     c04:	49 89 db             	mov    %rbx,%r11
     c07:	48 85 ff             	test   %rdi,%rdi
     c0a:	4d 0f 44 da          	cmove  %r10,%r11
     c0e:	4d 8b 13             	mov    (%r11),%r10
     c11:	48 83 e1 3f          	and    $0x3f,%rcx
     c15:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
     c1c:	4c 8b 9d 20 ff ff ff 	mov    -0xe0(%rbp),%r11
     c23:	4c 89 d9             	mov    %r11,%rcx
     c26:	49 d3 ea             	shr    %cl,%r10
     c29:	49 83 e2 01          	and    $0x1,%r10
     c2d:	31 c9                	xor    %ecx,%ecx
     c2f:	49 39 ca             	cmp    %rcx,%r10
     c32:	41 ba 00 00 00 00    	mov    $0x0,%r10d
     c38:	41 0f 94 c2          	sete   %r10b
     c3c:	41 bb 01 00 00 00    	mov    $0x1,%r11d
     c42:	48 89 f8             	mov    %rdi,%rax
     c45:	4c 31 d8             	xor    %r11,%rax
     c48:	49 21 c2             	and    %rax,%r10
     c4b:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
     c4f:	31 c0                	xor    %eax,%eax
     c51:	48 89 45 90          	mov    %rax,-0x70(%rbp)
     c55:	4c 89 85 28 ff ff ff 	mov    %r8,-0xd8(%rbp)
     c5c:	4c 89 95 30 ff ff ff 	mov    %r10,-0xd0(%rbp)
     c63:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
     c67:	48 63 c0             	movslq %eax,%rax
     c6a:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
     c6e:	48 8b 8d 40 ff ff ff 	mov    -0xc0(%rbp),%rcx
     c75:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
     c79:	48 8b 8d 58 ff ff ff 	mov    -0xa8(%rbp),%rcx
     c80:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
     c87:	48 8b 45 90          	mov    -0x70(%rbp),%rax
     c8b:	48 8b 48 38          	mov    0x38(%rax),%rcx
     c8f:	ba 18 00 00 00       	mov    $0x18,%edx
     c94:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
     c9b:	48 89 f7             	mov    %rsi,%rdi
     c9e:	48 0f af fa          	imul   %rdx,%rdi
     ca2:	48 8d 94 38 c0 00 00 	lea    0xc0(%rax,%rdi,1),%rdx
     ca9:	00 
     caa:	48 81 c7 d8 00 00 00 	add    $0xd8,%rdi
     cb1:	48 39 cf             	cmp    %rcx,%rdi
     cb4:	48 89 8d e8 fe ff ff 	mov    %rcx,-0x118(%rbp)
     cbb:	48 89 95 38 ff ff ff 	mov    %rdx,-0xc8(%rbp)
     cc2:	0f 8e d6 00 00 00    	jle    0xd9e
     cc8:	48 8b 7b 18          	mov    0x18(%rbx),%rdi
     ccc:	48 85 ff             	test   %rdi,%rdi
     ccf:	0f 84 0d 00 00 00    	je     0xce2
     cd5:	44 0f b6 07          	movzbl (%rdi),%r8d
     cd9:	4d 85 c0             	test   %r8,%r8
     cdc:	0f 85 a6 00 00 00    	jne    0xd88
     ce2:	b8 01 00 00 00       	mov    $0x1,%eax
     ce7:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
     ceb:	88 41 02             	mov    %al,0x2(%rcx)
     cee:	b8 01 00 00 00       	mov    $0x1,%eax
     cf3:	88 41 0d             	mov    %al,0xd(%rcx)
     cf6:	31 c0                	xor    %eax,%eax
     cf8:	88 41 37             	mov    %al,0x37(%rcx)
     cfb:	b8 01 00 00 00       	mov    $0x1,%eax
     d00:	88 41 01             	mov    %al,0x1(%rcx)
     d03:	b8 18 00 00 00       	mov    $0x18,%eax
     d08:	ba 18 00 00 00       	mov    $0x18,%edx
     d0d:	89 41 04             	mov    %eax,0x4(%rcx)
     d10:	89 51 58             	mov    %edx,0x58(%rcx)
     d13:	31 c0                	xor    %eax,%eax
     d15:	66 89 81 80 00 00 00 	mov    %ax,0x80(%rcx)
     d1c:	48 8d 45 c8          	lea    -0x38(%rbp),%rax
     d20:	48 89 c2             	mov    %rax,%rdx
     d23:	be 18 00 00 00       	mov    $0x18,%esi
     d28:	48 89 df             	mov    %rbx,%rdi
     d2b:	48 89 ce             	mov    %rcx,%rsi
     d2e:	48 89 95 e0 fe ff ff 	mov    %rdx,-0x120(%rbp)
     d35:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
     d3c:	b9 18 00 00 00       	mov    $0x18,%ecx
     d41:	4c 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%r8
     d48:	4c 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%r9
     d4f:	e8 dc f2 ff ff       	call   0x30
     d54:	48 85 c0             	test   %rax,%rax
     d57:	0f 85 11 00 00 00    	jne    0xd6e
     d5d:	b9 80 00 00 00       	mov    $0x80,%ecx
     d62:	48 89 8d c0 fe ff ff 	mov    %rcx,-0x140(%rbp)
     d69:	e9 2d 02 00 00       	jmp    0xf9b
     d6e:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
     d75:	48 8b 11             	mov    (%rcx),%rdx
     d78:	48 89 45 90          	mov    %rax,-0x70(%rbp)
     d7c:	48 89 95 20 ff ff ff 	mov    %rdx,-0xe0(%rbp)
     d83:	e9 ff fe ff ff       	jmp    0xc87
     d88:	48 89 df             	mov    %rbx,%rdi
     d8b:	e8 b0 f2 ff ff       	call   0x40
     d90:	48 85 c0             	test   %rax,%rax
     d93:	0f 84 49 ff ff ff    	je     0xce2
     d99:	e9 f1 01 00 00       	jmp    0xf8f
     d9e:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
     da5:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
     da9:	48 89 08             	mov    %rcx,(%rax)
     dac:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
     db3:	48 89 50 10          	mov    %rdx,0x10(%rax)
     db7:	48 8b 95 30 ff ff ff 	mov    -0xd0(%rbp),%rdx
     dbe:	48 c1 e2 20          	shl    $0x20,%rdx
     dc2:	48 89 50 08          	mov    %rdx,0x8(%rax)
     dc6:	48 8b 45 90          	mov    -0x70(%rbp),%rax
     dca:	0f b6 50 70          	movzbl 0x70(%rax),%edx
     dce:	48 85 d2             	test   %rdx,%rdx
     dd1:	0f 85 11 00 00 00    	jne    0xde8
     dd7:	ba 01 00 00 00       	mov    $0x1,%edx
     ddc:	48 89 95 38 ff ff ff 	mov    %rdx,-0xc8(%rbp)
     de3:	e9 3b 00 00 00       	jmp    0xe23
     de8:	48 89 df             	mov    %rbx,%rdi
     deb:	48 89 c6             	mov    %rax,%rsi
     dee:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
     df5:	48 8b 8d e8 fe ff ff 	mov    -0x118(%rbp),%rcx
     dfc:	e8 4f f2 ff ff       	call   0x50
     e01:	48 83 f8 00          	cmp    $0x0,%rax
     e05:	0f 8d 11 00 00 00    	jge    0xe1c
     e0b:	b9 80 00 00 00       	mov    $0x80,%ecx
     e10:	48 89 8d c0 fe ff ff 	mov    %rcx,-0x140(%rbp)
     e17:	e9 7f 01 00 00       	jmp    0xf9b
     e1c:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
     e23:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
     e2a:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
     e2e:	48 89 c2             	mov    %rax,%rdx
     e31:	48 39 ca             	cmp    %rcx,%rdx
     e34:	48 0f 4f d1          	cmovg  %rcx,%rdx
     e38:	48 8b b5 48 ff ff ff 	mov    -0xb8(%rbp),%rsi
     e3f:	48 89 f7             	mov    %rsi,%rdi
     e42:	48 39 cf             	cmp    %rcx,%rdi
     e45:	48 0f 4c f9          	cmovl  %rcx,%rdi
     e49:	48 8b 8d 20 ff ff ff 	mov    -0xe0(%rbp),%rcx
     e50:	4c 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%r8
     e57:	4c 01 c1             	add    %r8,%rcx
     e5a:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
     e61:	4d 89 c1             	mov    %r8,%r9
     e64:	49 83 c1 01          	add    $0x1,%r9
     e68:	4c 89 8d 68 ff ff ff 	mov    %r9,-0x98(%rbp)
     e6f:	48 89 8d 58 ff ff ff 	mov    %rcx,-0xa8(%rbp)
     e76:	48 89 95 50 ff ff ff 	mov    %rdx,-0xb0(%rbp)
     e7d:	48 89 bd 48 ff ff ff 	mov    %rdi,-0xb8(%rbp)
     e84:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
     e88:	48 89 8d 40 ff ff ff 	mov    %rcx,-0xc0(%rbp)
     e8f:	e9 ba f9 ff ff       	jmp    0x84e
     e94:	48 8b 45 98          	mov    -0x68(%rbp),%rax
     e98:	48 8b 8d 10 ff ff ff 	mov    -0xf0(%rbp),%rcx
     e9f:	48 89 48 10          	mov    %rcx,0x10(%rax)
     ea3:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
     eaa:	48 89 48 18          	mov    %rcx,0x18(%rax)
     eae:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
     eb5:	48 89 48 20          	mov    %rcx,0x20(%rax)
     eb9:	b9 01 00 00 00       	mov    $0x1,%ecx
     ebe:	88 48 02             	mov    %cl,0x2(%rax)
     ec1:	b9 01 00 00 00       	mov    $0x1,%ecx
     ec6:	88 48 0d             	mov    %cl,0xd(%rax)
     ec9:	31 c9                	xor    %ecx,%ecx
     ecb:	88 48 37             	mov    %cl,0x37(%rax)
     ece:	b9 01 00 00 00       	mov    $0x1,%ecx
     ed3:	88 48 01             	mov    %cl,0x1(%rax)
     ed6:	b9 18 00 00 00       	mov    $0x18,%ecx
     edb:	ba 18 00 00 00       	mov    $0x18,%edx
     ee0:	89 48 04             	mov    %ecx,0x4(%rax)
     ee3:	89 50 58             	mov    %edx,0x58(%rax)
     ee6:	31 c9                	xor    %ecx,%ecx
     ee8:	66 89 88 80 00 00 00 	mov    %cx,0x80(%rax)
     eef:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
     ef6:	48 8b 8d 18 ff ff ff 	mov    -0xe8(%rbp),%rcx
     efd:	48 01 c8             	add    %rcx,%rax
     f00:	48 89 83 e8 00 00 00 	mov    %rax,0xe8(%rbx)
     f07:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
     f0b:	89 83 00 01 00 00    	mov    %eax,0x100(%rbx)
     f11:	e9 eb f3 ff ff       	jmp    0x301
     f16:	48 89 df             	mov    %rbx,%rdi
     f19:	e8 22 f1 ff ff       	call   0x40
     f1e:	48 85 c0             	test   %rax,%rax
     f21:	0f 84 f3 f3 ff ff    	je     0x31a
     f27:	e9 63 00 00 00       	jmp    0xf8f
     f2c:	4d 85 ed             	test   %r13,%r13
     f2f:	0f 84 08 00 00 00    	je     0xf3d
     f35:	4d 89 ec             	mov    %r13,%r12
     f38:	e9 73 00 00 00       	jmp    0xfb0
     f3d:	48 8b 03             	mov    (%rbx),%rax
     f40:	48 8b 48 28          	mov    0x28(%rax),%rcx
     f44:	48 8b 01             	mov    (%rcx),%rax
     f47:	0f b6 48 70          	movzbl 0x70(%rax),%ecx
     f4b:	48 85 c9             	test   %rcx,%rcx
     f4e:	0f 84 2b 00 00 00    	je     0xf7f
     f54:	31 c0                	xor    %eax,%eax
     f56:	48 89 df             	mov    %rbx,%rdi
     f59:	48 89 c6             	mov    %rax,%rsi
     f5c:	48 89 ca             	mov    %rcx,%rdx
     f5f:	e8 fc f0 ff ff       	call   0x60
     f64:	48 83 f8 00          	cmp    $0x0,%rax
     f68:	0f 8d 11 00 00 00    	jge    0xf7f
     f6e:	b8 80 00 00 00       	mov    $0x80,%eax
     f73:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
     f7a:	e9 1c 00 00 00       	jmp    0xf9b
     f7f:	48 89 df             	mov    %rbx,%rdi
     f82:	e8 e9 f0 ff ff       	call   0x70
     f87:	49 89 c4             	mov    %rax,%r12
     f8a:	e9 21 00 00 00       	jmp    0xfb0
     f8f:	49 c7 c4 fe ff ff ff 	mov    $0xfffffffffffffffe,%r12
     f96:	e9 15 00 00 00       	jmp    0xfb0
     f9b:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
     fa2:	48 c1 e0 08          	shl    $0x8,%rax
     fa6:	48 83 c8 03          	or     $0x3,%rax
     faa:	48 f7 d8             	neg    %rax
     fad:	49 89 c4             	mov    %rax,%r12
     fb0:	4c 89 e0             	mov    %r12,%rax
     fb3:	48 81 c4 18 01 00 00 	add    $0x118,%rsp
     fba:	41 5f                	pop    %r15
     fbc:	41 5e                	pop    %r14
     fbe:	41 5d                	pop    %r13
     fc0:	41 5c                	pop    %r12
     fc2:	5b                   	pop    %rbx
     fc3:	5d                   	pop    %rbp
     fc4:	c3                   	ret
     fc5:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     fcc:	00 00 
     fce:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     fd5:	00 00 
     fd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     fde:	00 00 
     fe0:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     fe7:	00 00 
     fe9:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     ff0:	00 00 
     ff2:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
     ff9:	00 00 
     ffb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    1000:	55                   	push   %rbp
    1001:	48 89 e5             	mov    %rsp,%rbp
    1004:	53                   	push   %rbx
    1005:	41 54                	push   %r12
    1007:	41 55                	push   %r13
    1009:	41 56                	push   %r14
    100b:	41 57                	push   %r15
    100d:	48 81 ec 38 05 00 00 	sub    $0x538,%rsp
    1014:	31 c0                	xor    %eax,%eax
    1016:	b9 01 00 00 00       	mov    $0x1,%ecx
    101b:	48 8b 57 58          	mov    0x58(%rdi),%rdx
    101f:	48 8b 1f             	mov    (%rdi),%rbx
    1022:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    1026:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
    102a:	48 85 db             	test   %rbx,%rbx
    102d:	48 89 55 d0          	mov    %rdx,-0x30(%rbp)
    1031:	48 89 bd 98 fc ff ff 	mov    %rdi,-0x368(%rbp)
    1038:	0f 84 82 00 00 00    	je     0x10c0
    103e:	0f b6 73 0c          	movzbl 0xc(%rbx),%esi
    1042:	44 8b 43 30          	mov    0x30(%rbx),%r8d
    1046:	4c 8b 4b 10          	mov    0x10(%rbx),%r9
    104a:	44 0f b6 53 70       	movzbl 0x70(%rbx),%r10d
    104f:	48 83 fe 01          	cmp    $0x1,%rsi
    1053:	be 00 00 00 00       	mov    $0x0,%esi
    1058:	40 0f 94 c6          	sete   %sil
    105c:	bb 08 00 00 00       	mov    $0x8,%ebx
    1061:	4c 89 c1             	mov    %r8,%rcx
    1064:	48 d3 e3             	shl    %cl,%rbx
    1067:	b9 18 00 00 00       	mov    $0x18,%ecx
    106c:	4c 0f af c9          	imul   %rcx,%r9
    1070:	4c 01 cb             	add    %r9,%rbx
    1073:	48 81 fb 00 00 10 00 	cmp    $0x100000,%rbx
    107a:	bb 00 00 00 00       	mov    $0x0,%ebx
    107f:	0f 97 c3             	seta   %bl
    1082:	48 21 de             	and    %rbx,%rsi
    1085:	49 39 c2             	cmp    %rax,%r10
    1088:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    108e:	41 0f 94 c2          	sete   %r10b
    1092:	4c 21 d6             	and    %r10,%rsi
    1095:	48 85 f6             	test   %rsi,%rsi
    1098:	0f 84 22 00 00 00    	je     0x10c0
    109e:	8b 4f 70             	mov    0x70(%rdi),%ecx
    10a1:	48 81 e1 00 00 01 00 	and    $0x10000,%rcx
    10a8:	48 85 c9             	test   %rcx,%rcx
    10ab:	0f 85 0f 00 00 00    	jne    0x10c0
    10b1:	48 c7 c1 f7 ff ff ff 	mov    $0xfffffffffffffff7,%rcx
    10b8:	48 89 c8             	mov    %rcx,%rax
    10bb:	e9 ae 60 00 00       	jmp    0x716e
    10c0:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    10c7:	48 8b 98 10 02 00 00 	mov    0x210(%rax),%rbx
    10ce:	48 8d 8d 60 ff ff ff 	lea    -0xa0(%rbp),%rcx
    10d5:	48 89 ca             	mov    %rcx,%rdx
    10d8:	48 8b 70 50          	mov    0x50(%rax),%rsi
    10dc:	48 85 f6             	test   %rsi,%rsi
    10df:	48 89 95 90 fc ff ff 	mov    %rdx,-0x370(%rbp)
    10e6:	0f 85 d7 01 00 00    	jne    0x12c3
    10ec:	48 be 01 00 00 00 00 	movabs $0x4000000000001,%rsi
    10f3:	00 04 00 
    10f6:	48 89 70 50          	mov    %rsi,0x50(%rax)
    10fa:	31 f6                	xor    %esi,%esi
    10fc:	48 89 33             	mov    %rsi,(%rbx)
    10ff:	be 99 19 00 00       	mov    $0x1999,%esi
    1104:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    1108:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    110c:	45 31 c9             	xor    %r9d,%r9d
    110f:	4d 39 c8             	cmp    %r9,%r8
    1112:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    1118:	41 0f 94 c2          	sete   %r10b
    111c:	4d 85 d2             	test   %r10,%r10
    111f:	49 0f 44 f0          	cmove  %r8,%rsi
    1123:	41 bb 99 19 00 00    	mov    $0x1999,%r11d
    1129:	4d 85 d2             	test   %r10,%r10
    112c:	4d 0f 44 d8          	cmove  %r8,%r11
    1130:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    1136:	4c 39 de             	cmp    %r11,%rsi
    1139:	49 0f 47 f3          	cmova  %r11,%rsi
    113d:	4c 39 c6             	cmp    %r8,%rsi
    1140:	49 0f 47 f0          	cmova  %r8,%rsi
    1144:	4c 8d 85 30 ff ff ff 	lea    -0xd0(%rbp),%r8
    114b:	4d 89 c2             	mov    %r8,%r10
    114e:	41 bb 02 02 01 01    	mov    $0x1010202,%r11d
    1154:	4d 89 1a             	mov    %r11,(%r10)
    1157:	41 bb 00 00 00 01    	mov    $0x1000000,%r11d
    115d:	4d 89 5a 08          	mov    %r11,0x8(%r10)
    1161:	41 bb 00 00 10 18    	mov    $0x18100000,%r11d
    1167:	4d 89 5a 10          	mov    %r11,0x10(%r10)
    116b:	49 bb 00 00 28 01 10 	movabs $0x201001280000,%r11
    1172:	20 00 00 
    1175:	4d 89 5a 18          	mov    %r11,0x18(%r10)
    1179:	45 31 db             	xor    %r11d,%r11d
    117c:	4d 89 5a 20          	mov    %r11,0x20(%r10)
    1180:	41 bb 99 19 00 00    	mov    $0x1999,%r11d
    1186:	4c 8b 67 10          	mov    0x10(%rdi),%r12
    118a:	4d 39 cc             	cmp    %r9,%r12
    118d:	bf 00 00 00 00       	mov    $0x0,%edi
    1192:	40 0f 94 c7          	sete   %dil
    1196:	48 85 ff             	test   %rdi,%rdi
    1199:	4d 0f 44 dc          	cmove  %r12,%r11
    119d:	bf cd cc cc 00       	mov    $0xcccccd,%edi
    11a2:	49 39 fb             	cmp    %rdi,%r11
    11a5:	41 bc 00 00 00 00    	mov    $0x0,%r12d
    11ab:	41 0f 97 c4          	seta   %r12b
    11af:	4d 85 e4             	test   %r12,%r12
    11b2:	49 0f 44 fb          	cmove  %r11,%rdi
    11b6:	41 bb 28 00 00 00    	mov    $0x28,%r11d
    11bc:	49 0f af fb          	imul   %r11,%rdi
    11c0:	48 81 c7 ff ff 03 00 	add    $0x3ffff,%rdi
    11c7:	48 c1 ef 12          	shr    $0x12,%rdi
    11cb:	48 83 ff 01          	cmp    $0x1,%rdi
    11cf:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    11d5:	41 0f 97 c3          	seta   %r11b
    11d9:	48 83 ef 01          	sub    $0x1,%rdi
    11dd:	4c 0f bd e7          	bsr    %rdi,%r12
    11e1:	bf 7f 00 00 00       	mov    $0x7f,%edi
    11e6:	49 0f 45 fc          	cmovne %r12,%rdi
    11ea:	83 f7 3f             	xor    $0x3f,%edi
    11ed:	41 bc 40 00 00 00    	mov    $0x40,%r12d
    11f3:	49 29 fc             	sub    %rdi,%r12
    11f6:	bf 0b 00 00 00       	mov    $0xb,%edi
    11fb:	49 39 fc             	cmp    %rdi,%r12
    11fe:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    1204:	41 0f 97 c5          	seta   %r13b
    1208:	4d 85 ed             	test   %r13,%r13
    120b:	49 0f 44 fc          	cmove  %r12,%rdi
    120f:	45 31 e4             	xor    %r12d,%r12d
    1212:	4d 85 db             	test   %r11,%r11
    1215:	49 0f 44 fc          	cmove  %r12,%rdi
    1219:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
    121d:	48 89 c7             	mov    %rax,%rdi
    1220:	48 89 b5 88 fc ff ff 	mov    %rsi,-0x378(%rbp)
    1227:	48 89 d6             	mov    %rdx,%rsi
    122a:	4c 89 d2             	mov    %r10,%rdx
    122d:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
    1231:	4c 8b 85 88 fc ff ff 	mov    -0x378(%rbp),%r8
    1238:	4c 89 95 88 fc ff ff 	mov    %r10,-0x378(%rbp)
    123f:	e8 3c ee ff ff       	call   0x80
    1244:	48 83 f8 00          	cmp    $0x0,%rax
    1248:	0f 8d 08 00 00 00    	jge    0x1256
    124e:	49 89 c4             	mov    %rax,%r12
    1251:	e9 15 5f 00 00       	jmp    0x716b
    1256:	b8 01 00 00 00       	mov    $0x1,%eax
    125b:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    1262:	48 89 c6             	mov    %rax,%rsi
    1265:	48 8b 95 88 fc ff ff 	mov    -0x378(%rbp),%rdx
    126c:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
    1270:	e8 1b ee ff ff       	call   0x90
    1275:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    127c:	48 8b 08             	mov    (%rax),%rcx
    127f:	31 d2                	xor    %edx,%edx
    1281:	48 8d 74 11 10       	lea    0x10(%rcx,%rdx,1),%rsi
    1286:	48 89 70 40          	mov    %rsi,0x40(%rax)
    128a:	48 89 50 60          	mov    %rdx,0x60(%rax)
    128e:	48 8b 08             	mov    (%rax),%rcx
    1291:	0f b6 71 0d          	movzbl 0xd(%rcx),%esi
    1295:	48 83 e6 01          	and    $0x1,%rsi
    1299:	48 89 70 68          	mov    %rsi,0x68(%rax)
    129d:	b9 01 00 00 00       	mov    $0x1,%ecx
    12a2:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    12a9:	48 89 ce             	mov    %rcx,%rsi
    12ac:	e8 ef ed ff ff       	call   0xa0
    12b1:	48 83 f8 00          	cmp    $0x0,%rax
    12b5:	0f 8d 08 00 00 00    	jge    0x12c3
    12bb:	49 89 c4             	mov    %rax,%r12
    12be:	e9 a8 5e 00 00       	jmp    0x716b
    12c3:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    12ca:	48 8b 48 18          	mov    0x18(%rax),%rcx
    12ce:	48 85 c9             	test   %rcx,%rcx
    12d1:	0f 84 0c 00 00 00    	je     0x12e3
    12d7:	0f b6 11             	movzbl (%rcx),%edx
    12da:	48 85 d2             	test   %rdx,%rdx
    12dd:	0f 85 97 5d 00 00    	jne    0x707a
    12e3:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    12ea:	48 8b 08             	mov    (%rax),%rcx
    12ed:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    12f1:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
    12f5:	44 0f b6 69 0c       	movzbl 0xc(%rcx),%r13d
    12fa:	4d 85 ed             	test   %r13,%r13
    12fd:	0f 84 a9 5d 00 00    	je     0x70ac
    1303:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    1307:	48 8d 34 11          	lea    (%rcx,%rdx,1),%rsi
    130b:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    130f:	48 8d 3c 11          	lea    (%rcx,%rdx,1),%rdi
    1313:	8b 51 30             	mov    0x30(%rcx),%edx
    1316:	4c 8b 41 18          	mov    0x18(%rcx),%r8
    131a:	4c 8b 49 20          	mov    0x20(%rcx),%r9
    131e:	4d 29 c1             	sub    %r8,%r9
    1321:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    1327:	4d 01 d1             	add    %r10,%r9
    132a:	49 89 ce             	mov    %rcx,%r14
    132d:	49 81 c6 c0 00 00 00 	add    $0xc0,%r14
    1334:	49 89 fb             	mov    %rdi,%r11
    1337:	49 29 f3             	sub    %rsi,%r11
    133a:	4e 8d 3c 1e          	lea    (%rsi,%r11,1),%r15
    133e:	4e 8d 14 5e          	lea    (%rsi,%r11,2),%r10
    1342:	44 0f b6 59 70       	movzbl 0x70(%rcx),%r11d
    1347:	48 8b 41 78          	mov    0x78(%rcx),%rax
    134b:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
    134f:	0f b6 41 72          	movzbl 0x72(%rcx),%eax
    1353:	49 83 fd 01          	cmp    $0x1,%r13
    1357:	b9 00 00 00 00       	mov    $0x0,%ecx
    135c:	0f 94 c1             	sete   %cl
    135f:	48 89 8d 88 fc ff ff 	mov    %rcx,-0x378(%rbp)
    1366:	31 c9                	xor    %ecx,%ecx
    1368:	48 89 bd 80 fc ff ff 	mov    %rdi,-0x380(%rbp)
    136f:	48 39 c8             	cmp    %rcx,%rax
    1372:	bf 00 00 00 00       	mov    $0x0,%edi
    1377:	40 0f 95 c7          	setne  %dil
    137b:	48 8b 8d 88 fc ff ff 	mov    -0x378(%rbp),%rcx
    1382:	48 21 f9             	and    %rdi,%rcx
    1385:	48 85 c9             	test   %rcx,%rcx
    1388:	48 89 85 88 fc ff ff 	mov    %rax,-0x378(%rbp)
    138f:	48 89 95 78 fc ff ff 	mov    %rdx,-0x388(%rbp)
    1396:	48 89 b5 70 fc ff ff 	mov    %rsi,-0x390(%rbp)
    139d:	4c 89 85 68 fc ff ff 	mov    %r8,-0x398(%rbp)
    13a4:	4c 89 8d 60 fc ff ff 	mov    %r9,-0x3a0(%rbp)
    13ab:	4c 89 95 58 fc ff ff 	mov    %r10,-0x3a8(%rbp)
    13b2:	4c 89 9d 50 fc ff ff 	mov    %r11,-0x3b0(%rbp)
    13b9:	4c 89 bd 48 fc ff ff 	mov    %r15,-0x3b8(%rbp)
    13c0:	0f 85 1a 00 00 00    	jne    0x13e0
    13c6:	45 31 ff             	xor    %r15d,%r15d
    13c9:	31 c9                	xor    %ecx,%ecx
    13cb:	48 89 8d 40 fc ff ff 	mov    %rcx,-0x3c0(%rbp)
    13d2:	31 c9                	xor    %ecx,%ecx
    13d4:	48 89 8d 38 fc ff ff 	mov    %rcx,-0x3c8(%rbp)
    13db:	e9 91 01 00 00       	jmp    0x1571
    13e0:	b9 08 00 00 00       	mov    $0x8,%ecx
    13e5:	bf 08 00 00 00       	mov    $0x8,%edi
    13ea:	48 89 d1             	mov    %rdx,%rcx
    13ed:	48 d3 e7             	shl    %cl,%rdi
    13f0:	48 8d 0c 3e          	lea    (%rsi,%rdi,1),%rcx
    13f4:	31 c0                	xor    %eax,%eax
    13f6:	4c 8d 54 01 40       	lea    0x40(%rcx,%rax,1),%r10
    13fb:	48 81 ff 00 00 10 00 	cmp    $0x100000,%rdi
    1402:	0f 87 1a 00 00 00    	ja     0x1422
    1408:	31 ff                	xor    %edi,%edi
    140a:	48 89 bd 38 fc ff ff 	mov    %rdi,-0x3c8(%rbp)
    1411:	4d 89 d7             	mov    %r10,%r15
    1414:	31 ff                	xor    %edi,%edi
    1416:	48 89 bd 40 fc ff ff 	mov    %rdi,-0x3c0(%rbp)
    141d:	e9 4f 01 00 00       	jmp    0x1571
    1422:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
    1426:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    142a:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    1430:	4c 01 c2             	add    %r8,%rdx
    1433:	48 89 53 10          	mov    %rdx,0x10(%rbx)
    1437:	4c 8b 49 10          	mov    0x10(%rcx),%r9
    143b:	48 85 ff             	test   %rdi,%rdi
    143e:	48 89 95 30 fc ff ff 	mov    %rdx,-0x3d0(%rbp)
    1445:	4c 89 95 28 fc ff ff 	mov    %r10,-0x3d8(%rbp)
    144c:	0f 85 0c 00 00 00    	jne    0x145e
    1452:	4c 89 8d 20 fc ff ff 	mov    %r9,-0x3e0(%rbp)
    1459:	e9 b3 00 00 00       	jmp    0x1511
    145e:	48 89 43 08          	mov    %rax,0x8(%rbx)
    1462:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    1467:	49 89 fa             	mov    %rdi,%r10
    146a:	49 21 d2             	and    %rdx,%r10
    146d:	48 c1 ef 20          	shr    $0x20,%rdi
    1471:	4c 89 d2             	mov    %r10,%rdx
    1474:	48 01 fa             	add    %rdi,%rdx
    1477:	48 8b 39             	mov    (%rcx),%rdi
    147a:	48 01 d7             	add    %rdx,%rdi
    147d:	48 89 39             	mov    %rdi,(%rcx)
    1480:	48 8b 51 08          	mov    0x8(%rcx),%rdx
    1484:	4c 01 d2             	add    %r10,%rdx
    1487:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    148b:	48 81 ff 00 10 00 00 	cmp    $0x1000,%rdi
    1492:	0f 83 0c 00 00 00    	jae    0x14a4
    1498:	4c 89 8d 20 fc ff ff 	mov    %r9,-0x3e0(%rbp)
    149f:	e9 6d 00 00 00       	jmp    0x1511
    14a4:	41 ba 17 00 00 00    	mov    $0x17,%r10d
    14aa:	be 08 00 00 00       	mov    $0x8,%esi
    14af:	49 89 fb             	mov    %rdi,%r11
    14b2:	49 29 d3             	sub    %rdx,%r11
    14b5:	4d 0f af da          	imul   %r10,%r11
    14b9:	48 0f af fe          	imul   %rsi,%rdi
    14bd:	49 39 fb             	cmp    %rdi,%r11
    14c0:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    14c6:	41 0f 96 c3          	setbe  %r11b
    14ca:	49 83 cb 02          	or     $0x2,%r11
    14ce:	4c 89 59 10          	mov    %r11,0x10(%rcx)
    14d2:	48 89 01             	mov    %rax,(%rcx)
    14d5:	48 89 41 08          	mov    %rax,0x8(%rcx)
    14d9:	4d 31 d9             	xor    %r11,%r9
    14dc:	4d 21 c1             	and    %r8,%r9
    14df:	4d 85 c9             	test   %r9,%r9
    14e2:	0f 85 0c 00 00 00    	jne    0x14f4
    14e8:	4c 89 9d 20 fc ff ff 	mov    %r11,-0x3e0(%rbp)
    14ef:	e9 1d 00 00 00       	jmp    0x1511
    14f4:	4c 89 df             	mov    %r11,%rdi
    14f7:	4c 89 9d 18 fc ff ff 	mov    %r11,-0x3e8(%rbp)
    14fe:	e8 ad eb ff ff       	call   0xb0
    1503:	48 8b 85 18 fc ff ff 	mov    -0x3e8(%rbp),%rax
    150a:	48 89 85 20 fc ff ff 	mov    %rax,-0x3e0(%rbp)
    1511:	48 8b 85 30 fc ff ff 	mov    -0x3d0(%rbp),%rax
    1518:	48 83 e0 1f          	and    $0x1f,%rax
    151c:	31 c9                	xor    %ecx,%ecx
    151e:	48 39 c8             	cmp    %rcx,%rax
    1521:	b8 00 00 00 00       	mov    $0x0,%eax
    1526:	0f 94 c0             	sete   %al
    1529:	48 8b 95 20 fc ff ff 	mov    -0x3e0(%rbp),%rdx
    1530:	48 89 d6             	mov    %rdx,%rsi
    1533:	48 83 e6 02          	and    $0x2,%rsi
    1537:	48 39 ce             	cmp    %rcx,%rsi
    153a:	be 00 00 00 00       	mov    $0x0,%esi
    153f:	40 0f 94 c6          	sete   %sil
    1543:	48 09 c6             	or     %rax,%rsi
    1546:	b8 01 00 00 00       	mov    $0x1,%eax
    154b:	48 21 c2             	and    %rax,%rdx
    154e:	48 39 ca             	cmp    %rcx,%rdx
    1551:	ba 00 00 00 00       	mov    $0x0,%edx
    1556:	0f 94 c2             	sete   %dl
    1559:	48 09 f2             	or     %rsi,%rdx
    155c:	48 89 95 38 fc ff ff 	mov    %rdx,-0x3c8(%rbp)
    1563:	4c 8b bd 28 fc ff ff 	mov    -0x3d8(%rbp),%r15
    156a:	48 89 b5 40 fc ff ff 	mov    %rsi,-0x3c0(%rbp)
    1571:	b8 01 00 00 00       	mov    $0x1,%eax
    1576:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    157d:	48 89 c6             	mov    %rax,%rsi
    1580:	e8 3b eb ff ff       	call   0xc0
    1585:	48 83 f8 00          	cmp    $0x0,%rax
    1589:	48 89 85 28 fc ff ff 	mov    %rax,-0x3d8(%rbp)
    1590:	0f 8e fe 5a 00 00    	jle    0x7094
    1596:	48 8b 8d 98 fc ff ff 	mov    -0x368(%rbp),%rcx
    159d:	8b 91 c0 01 00 00    	mov    0x1c0(%rcx),%edx
    15a3:	8b b1 bc 01 00 00    	mov    0x1bc(%rcx),%esi
    15a9:	48 8b b9 90 01 00 00 	mov    0x190(%rcx),%rdi
    15b0:	45 31 c0             	xor    %r8d,%r8d
    15b3:	4c 39 c7             	cmp    %r8,%rdi
    15b6:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    15bc:	41 0f 94 c1          	sete   %r9b
    15c0:	44 8b 91 c4 01 00 00 	mov    0x1c4(%rcx),%r10d
    15c7:	4d 85 c9             	test   %r9,%r9
    15ca:	49 0f 44 f2          	cmove  %r10,%rsi
    15ce:	4c 8b 91 60 01 00 00 	mov    0x160(%rcx),%r10
    15d5:	4d 8b 1a             	mov    (%r10),%r11
    15d8:	49 8b 42 08          	mov    0x8(%r10),%rax
    15dc:	4c 39 c0             	cmp    %r8,%rax
    15df:	b9 00 00 00 00       	mov    $0x0,%ecx
    15e4:	0f 94 c1             	sete   %cl
    15e7:	4d 8b 42 20          	mov    0x20(%r10),%r8
    15eb:	48 89 85 20 fc ff ff 	mov    %rax,-0x3e0(%rbp)
    15f2:	49 8b 42 28          	mov    0x28(%r10),%rax
    15f6:	45 31 d2             	xor    %r10d,%r10d
    15f9:	48 89 bd 30 fc ff ff 	mov    %rdi,-0x3d0(%rbp)
    1600:	4c 39 d0             	cmp    %r10,%rax
    1603:	bf 00 00 00 00       	mov    $0x0,%edi
    1608:	40 0f 94 c7          	sete   %dil
    160c:	49 89 ca             	mov    %rcx,%r10
    160f:	49 21 fa             	and    %rdi,%r10
    1612:	4c 89 95 18 fc ff ff 	mov    %r10,-0x3e8(%rbp)
    1619:	49 83 fd 05          	cmp    $0x5,%r13
    161d:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    1623:	41 0f 94 c2          	sete   %r10b
    1627:	4c 89 95 10 fc ff ff 	mov    %r10,-0x3f0(%rbp)
    162e:	49 83 fd 02          	cmp    $0x2,%r13
    1632:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    1638:	41 0f 94 c2          	sete   %r10b
    163c:	4c 89 95 08 fc ff ff 	mov    %r10,-0x3f8(%rbp)
    1643:	4c 8b 95 10 fc ff ff 	mov    -0x3f0(%rbp),%r10
    164a:	48 89 85 00 fc ff ff 	mov    %rax,-0x400(%rbp)
    1651:	48 8b 85 08 fc ff ff 	mov    -0x3f8(%rbp),%rax
    1658:	49 09 c2             	or     %rax,%r10
    165b:	4d 85 d2             	test   %r10,%r10
    165e:	48 89 8d 10 fc ff ff 	mov    %rcx,-0x3f0(%rbp)
    1665:	48 89 95 08 fc ff ff 	mov    %rdx,-0x3f8(%rbp)
    166c:	48 89 b5 f8 fb ff ff 	mov    %rsi,-0x408(%rbp)
    1673:	48 89 bd f0 fb ff ff 	mov    %rdi,-0x410(%rbp)
    167a:	4c 89 85 e8 fb ff ff 	mov    %r8,-0x418(%rbp)
    1681:	4c 89 8d e0 fb ff ff 	mov    %r9,-0x420(%rbp)
    1688:	4c 89 9d d8 fb ff ff 	mov    %r11,-0x428(%rbp)
    168f:	0f 84 eb 17 00 00    	je     0x2e80
    1695:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
    169c:	82 28 52 
    169f:	45 31 d2             	xor    %r10d,%r10d
    16a2:	48 8b 8d 18 fc ff ff 	mov    -0x3e8(%rbp),%rcx
    16a9:	48 89 cf             	mov    %rcx,%rdi
    16ac:	4c 21 cf             	and    %r9,%rdi
    16af:	48 85 ff             	test   %rdi,%rdi
    16b2:	0f 85 62 0a 00 00    	jne    0x211a
    16b8:	48 89 95 d0 fb ff ff 	mov    %rdx,-0x430(%rbp)
    16bf:	31 ff                	xor    %edi,%edi
    16c1:	48 89 bd c8 fb ff ff 	mov    %rdi,-0x438(%rbp)
    16c8:	31 ff                	xor    %edi,%edi
    16ca:	48 89 bd c0 fb ff ff 	mov    %rdi,-0x440(%rbp)
    16d1:	31 ff                	xor    %edi,%edi
    16d3:	48 89 bd b8 fb ff ff 	mov    %rdi,-0x448(%rbp)
    16da:	48 89 85 b0 fb ff ff 	mov    %rax,-0x450(%rbp)
    16e1:	31 ff                	xor    %edi,%edi
    16e3:	48 89 bd a8 fb ff ff 	mov    %rdi,-0x458(%rbp)
    16ea:	31 ff                	xor    %edi,%edi
    16ec:	48 89 bd a0 fb ff ff 	mov    %rdi,-0x460(%rbp)
    16f3:	4c 89 95 98 fb ff ff 	mov    %r10,-0x468(%rbp)
    16fa:	31 ff                	xor    %edi,%edi
    16fc:	48 89 bd 90 fb ff ff 	mov    %rdi,-0x470(%rbp)
    1703:	48 8b 85 d0 fb ff ff 	mov    -0x430(%rbp),%rax
    170a:	48 8b 8d f8 fb ff ff 	mov    -0x408(%rbp),%rcx
    1711:	48 39 c8             	cmp    %rcx,%rax
    1714:	0f 8c 75 00 00 00    	jl     0x178f
    171a:	48 8b 95 a8 fb ff ff 	mov    -0x458(%rbp),%rdx
    1721:	48 89 95 88 fb ff ff 	mov    %rdx,-0x478(%rbp)
    1728:	48 8b 95 c8 fb ff ff 	mov    -0x438(%rbp),%rdx
    172f:	48 89 95 80 fb ff ff 	mov    %rdx,-0x480(%rbp)
    1736:	48 8b 95 a0 fb ff ff 	mov    -0x460(%rbp),%rdx
    173d:	48 89 95 78 fb ff ff 	mov    %rdx,-0x488(%rbp)
    1744:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    174b:	48 89 95 70 fb ff ff 	mov    %rdx,-0x490(%rbp)
    1752:	48 8b 95 b8 fb ff ff 	mov    -0x448(%rbp),%rdx
    1759:	48 89 95 68 fb ff ff 	mov    %rdx,-0x498(%rbp)
    1760:	48 8b 95 b0 fb ff ff 	mov    -0x450(%rbp),%rdx
    1767:	48 89 95 60 fb ff ff 	mov    %rdx,-0x4a0(%rbp)
    176e:	48 8b 95 98 fb ff ff 	mov    -0x468(%rbp),%rdx
    1775:	48 89 95 58 fb ff ff 	mov    %rdx,-0x4a8(%rbp)
    177c:	48 8b 95 90 fb ff ff 	mov    -0x470(%rbp),%rdx
    1783:	48 89 95 50 fb ff ff 	mov    %rdx,-0x4b0(%rbp)
    178a:	e9 c8 12 00 00       	jmp    0x2a57
    178f:	48 8b 95 e0 fb ff ff 	mov    -0x420(%rbp),%rdx
    1796:	48 85 d2             	test   %rdx,%rdx
    1799:	0f 84 08 00 00 00    	je     0x17a7
    179f:	48 89 c6             	mov    %rax,%rsi
    17a2:	e9 11 00 00 00       	jmp    0x17b8
    17a7:	48 8b bd 30 fc ff ff 	mov    -0x3d0(%rbp),%rdi
    17ae:	4c 8d 04 87          	lea    (%rdi,%rax,4),%r8
    17b2:	45 8b 08             	mov    (%r8),%r9d
    17b5:	4c 89 ce             	mov    %r9,%rsi
    17b8:	48 8b 85 d8 fb ff ff 	mov    -0x428(%rbp),%rax
    17bf:	48 8d 0c b0          	lea    (%rax,%rsi,4),%rcx
    17c3:	48 89 f2             	mov    %rsi,%rdx
    17c6:	48 c1 ea 06          	shr    $0x6,%rdx
    17ca:	48 8b bd 20 fc ff ff 	mov    -0x3e0(%rbp),%rdi
    17d1:	4c 8d 04 d7          	lea    (%rdi,%rdx,8),%r8
    17d5:	48 8b 95 10 fc ff ff 	mov    -0x3f0(%rbp),%rdx
    17dc:	4c 8b 8d 98 fc ff ff 	mov    -0x368(%rbp),%r9
    17e3:	4d 89 ca             	mov    %r9,%r10
    17e6:	48 85 d2             	test   %rdx,%rdx
    17e9:	4d 0f 44 d0          	cmove  %r8,%r10
    17ed:	4d 8b 02             	mov    (%r10),%r8
    17f0:	49 89 f2             	mov    %rsi,%r10
    17f3:	49 83 e2 3f          	and    $0x3f,%r10
    17f7:	48 89 8d 48 fb ff ff 	mov    %rcx,-0x4b8(%rbp)
    17fe:	4c 89 d1             	mov    %r10,%rcx
    1801:	49 d3 e8             	shr    %cl,%r8
    1804:	b9 01 00 00 00       	mov    $0x1,%ecx
    1809:	49 21 c8             	and    %rcx,%r8
    180c:	45 31 d2             	xor    %r10d,%r10d
    180f:	4d 39 d0             	cmp    %r10,%r8
    1812:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1818:	41 0f 94 c0          	sete   %r8b
    181c:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    1822:	48 89 d7             	mov    %rdx,%rdi
    1825:	4c 31 df             	xor    %r11,%rdi
    1828:	49 21 f8             	and    %rdi,%r8
    182b:	48 8b bd e8 fb ff ff 	mov    -0x418(%rbp),%rdi
    1832:	4c 8d 1c b7          	lea    (%rdi,%rsi,4),%r11
    1836:	48 89 f2             	mov    %rsi,%rdx
    1839:	48 c1 ea 06          	shr    $0x6,%rdx
    183d:	48 8b 85 00 fc ff ff 	mov    -0x400(%rbp),%rax
    1844:	48 8d 3c d0          	lea    (%rax,%rdx,8),%rdi
    1848:	48 8b 95 f0 fb ff ff 	mov    -0x410(%rbp),%rdx
    184f:	4c 89 c8             	mov    %r9,%rax
    1852:	48 85 d2             	test   %rdx,%rdx
    1855:	48 0f 44 c7          	cmove  %rdi,%rax
    1859:	48 8b 38             	mov    (%rax),%rdi
    185c:	48 83 e6 3f          	and    $0x3f,%rsi
    1860:	48 89 f1             	mov    %rsi,%rcx
    1863:	48 d3 ef             	shr    %cl,%rdi
    1866:	b8 01 00 00 00       	mov    $0x1,%eax
    186b:	48 21 c7             	and    %rax,%rdi
    186e:	4c 39 d7             	cmp    %r10,%rdi
    1871:	bf 00 00 00 00       	mov    $0x0,%edi
    1876:	40 0f 94 c7          	sete   %dil
    187a:	b9 01 00 00 00       	mov    $0x1,%ecx
    187f:	48 89 d6             	mov    %rdx,%rsi
    1882:	48 31 ce             	xor    %rcx,%rsi
    1885:	48 21 f7             	and    %rsi,%rdi
    1888:	4d 85 c0             	test   %r8,%r8
    188b:	0f 85 6b 08 00 00    	jne    0x20fc
    1891:	48 8b 8d 48 fb ff ff 	mov    -0x4b8(%rbp),%rcx
    1898:	48 63 31             	movslq (%rcx),%rsi
    189b:	48 8b 8d 50 fc ff ff 	mov    -0x3b0(%rbp),%rcx
    18a2:	48 85 c9             	test   %rcx,%rcx
    18a5:	48 89 b5 40 fb ff ff 	mov    %rsi,-0x4c0(%rbp)
    18ac:	48 89 bd 38 fb ff ff 	mov    %rdi,-0x4c8(%rbp)
    18b3:	4c 89 9d 30 fb ff ff 	mov    %r11,-0x4d0(%rbp)
    18ba:	0f 84 47 01 00 00    	je     0x1a07
    18c0:	48 be 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rsi
    18c7:	79 37 9e 
    18ca:	48 8b bd 40 fb ff ff 	mov    -0x4c0(%rbp),%rdi
    18d1:	49 89 fb             	mov    %rdi,%r11
    18d4:	49 c1 eb 2b          	shr    $0x2b,%r11
    18d8:	48 89 fa             	mov    %rdi,%rdx
    18db:	48 c1 ea 2c          	shr    $0x2c,%rdx
    18df:	49 31 d3             	xor    %rdx,%r11
    18e2:	48 89 fa             	mov    %rdi,%rdx
    18e5:	4c 31 da             	xor    %r11,%rdx
    18e8:	48 0f af d6          	imul   %rsi,%rdx
    18ec:	48 89 d6             	mov    %rdx,%rsi
    18ef:	48 c1 ee 1e          	shr    $0x1e,%rsi
    18f3:	49 89 d3             	mov    %rdx,%r11
    18f6:	49 31 f3             	xor    %rsi,%r11
    18f9:	48 be b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rsi
    1900:	47 58 bf 
    1903:	4c 0f af de          	imul   %rsi,%r11
    1907:	4c 89 de             	mov    %r11,%rsi
    190a:	48 c1 ee 1b          	shr    $0x1b,%rsi
    190e:	49 31 f3             	xor    %rsi,%r11
    1911:	48 be eb 11 31 13 bb 	movabs $0x94d049bb133111eb,%rsi
    1918:	49 d0 94 
    191b:	4c 0f af de          	imul   %rsi,%r11
    191f:	4c 89 de             	mov    %r11,%rsi
    1922:	48 c1 ee 1f          	shr    $0x1f,%rsi
    1926:	49 31 f3             	xor    %rsi,%r11
    1929:	be 40 00 00 00       	mov    $0x40,%esi
    192e:	48 29 ce             	sub    %rcx,%rsi
    1931:	48 89 f1             	mov    %rsi,%rcx
    1934:	49 d3 eb             	shr    %cl,%r11
    1937:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
    193b:	4c 89 d9             	mov    %r11,%rcx
    193e:	48 89 f7             	mov    %rsi,%rdi
    1941:	48 d3 ef             	shr    %cl,%rdi
    1944:	48 21 c7             	and    %rax,%rdi
    1947:	48 85 ff             	test   %rdi,%rdi
    194a:	0f 84 b7 00 00 00    	je     0x1a07
    1950:	48 8d 8d b0 fe ff ff 	lea    -0x150(%rbp),%rcx
    1957:	48 89 cf             	mov    %rcx,%rdi
    195a:	48 8b 8d 48 fb ff ff 	mov    -0x4b8(%rbp),%rcx
    1961:	48 63 31             	movslq (%rcx),%rsi
    1964:	31 c9                	xor    %ecx,%ecx
    1966:	48 89 0f             	mov    %rcx,(%rdi)
    1969:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    196d:	4c 89 47 10          	mov    %r8,0x10(%rdi)
    1971:	48 8b 8d 30 fb ff ff 	mov    -0x4d0(%rbp),%rcx
    1978:	48 63 31             	movslq (%rcx),%rsi
    197b:	45 31 c0             	xor    %r8d,%r8d
    197e:	4c 89 47 18          	mov    %r8,0x18(%rdi)
    1982:	48 89 77 20          	mov    %rsi,0x20(%rdi)
    1986:	48 8b b5 38 fb ff ff 	mov    -0x4c8(%rbp),%rsi
    198d:	48 89 77 28          	mov    %rsi,0x28(%rdi)
    1991:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    1997:	48 8b b5 50 fc ff ff 	mov    -0x3b0(%rbp),%rsi
    199e:	48 89 f1             	mov    %rsi,%rcx
    19a1:	49 d3 e0             	shl    %cl,%r8
    19a4:	4d 01 d8             	add    %r11,%r8
    19a7:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    19ac:	41 bb 02 00 00 00    	mov    $0x2,%r11d
    19b2:	48 89 bd 48 fb ff ff 	mov    %rdi,-0x4b8(%rbp)
    19b9:	4c 89 cf             	mov    %r9,%rdi
    19bc:	48 89 ce             	mov    %rcx,%rsi
    19bf:	48 89 95 28 fb ff ff 	mov    %rdx,-0x4d8(%rbp)
    19c6:	48 8b 95 50 fc ff ff 	mov    -0x3b0(%rbp),%rdx
    19cd:	4c 89 c1             	mov    %r8,%rcx
    19d0:	4c 8b 85 28 fb ff ff 	mov    -0x4d8(%rbp),%r8
    19d7:	4c 8b 8d 48 fb ff ff 	mov    -0x4b8(%rbp),%r9
    19de:	4c 89 1c 24          	mov    %r11,(%rsp)
    19e2:	e8 e9 e6 ff ff       	call   0xd0
    19e7:	48 83 f8 00          	cmp    $0x0,%rax
    19eb:	0f 8d 11 00 00 00    	jge    0x1a02
    19f1:	b8 80 00 00 00       	mov    $0x80,%eax
    19f6:	48 89 85 48 fb ff ff 	mov    %rax,-0x4b8(%rbp)
    19fd:	e9 48 57 00 00       	jmp    0x714a
    1a02:	e9 f5 06 00 00       	jmp    0x20fc
    1a07:	49 83 fd 05          	cmp    $0x5,%r13
    1a0b:	0f 85 a7 00 00 00    	jne    0x1ab8
    1a11:	48 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%rax
    1a18:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    1a1f:	48 89 c2             	mov    %rax,%rdx
    1a22:	48 29 ca             	sub    %rcx,%rdx
    1a25:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    1a2c:	48 39 f2             	cmp    %rsi,%rdx
    1a2f:	bf 00 00 00 00       	mov    $0x0,%edi
    1a34:	40 0f 92 c7          	setb   %dil
    1a38:	45 31 c0             	xor    %r8d,%r8d
    1a3b:	48 85 ff             	test   %rdi,%rdi
    1a3e:	49 0f 44 d0          	cmove  %r8,%rdx
    1a42:	49 89 d1             	mov    %rdx,%r9
    1a45:	49 c1 e9 06          	shr    $0x6,%r9
    1a49:	48 83 e2 3f          	and    $0x3f,%rdx
    1a4d:	4c 8b 95 70 fc ff ff 	mov    -0x390(%rbp),%r10
    1a54:	4f 8d 1c ca          	lea    (%r10,%r9,8),%r11
    1a58:	49 8b 03             	mov    (%r11),%rax
    1a5b:	48 89 d1             	mov    %rdx,%rcx
    1a5e:	48 d3 e8             	shr    %cl,%rax
    1a61:	b9 01 00 00 00       	mov    $0x1,%ecx
    1a66:	48 21 c8             	and    %rcx,%rax
    1a69:	49 89 c3             	mov    %rax,%r11
    1a6c:	49 21 fb             	and    %rdi,%r11
    1a6f:	48 8b 85 48 fc ff ff 	mov    -0x3b8(%rbp),%rax
    1a76:	4a 8d 3c c8          	lea    (%rax,%r9,8),%rdi
    1a7a:	48 8b 07             	mov    (%rdi),%rax
    1a7d:	48 89 d1             	mov    %rdx,%rcx
    1a80:	48 d3 e8             	shr    %cl,%rax
    1a83:	b9 01 00 00 00       	mov    $0x1,%ecx
    1a88:	48 89 c7             	mov    %rax,%rdi
    1a8b:	48 21 cf             	and    %rcx,%rdi
    1a8e:	48 8b 85 58 fc ff ff 	mov    -0x3a8(%rbp),%rax
    1a95:	4a 8d 34 c8          	lea    (%rax,%r9,8),%rsi
    1a99:	4c 8b 0e             	mov    (%rsi),%r9
    1a9c:	48 89 d1             	mov    %rdx,%rcx
    1a9f:	49 d3 e9             	shr    %cl,%r9
    1aa2:	b9 01 00 00 00       	mov    $0x1,%ecx
    1aa7:	4c 89 ce             	mov    %r9,%rsi
    1aaa:	48 21 ce             	and    %rcx,%rsi
    1aad:	49 89 f9             	mov    %rdi,%r9
    1ab0:	48 89 f7             	mov    %rsi,%rdi
    1ab3:	e9 96 00 00 00       	jmp    0x1b4e
    1ab8:	48 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%rax
    1abf:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    1ac6:	48 29 c8             	sub    %rcx,%rax
    1ac9:	48 8b 95 60 fc ff ff 	mov    -0x3a0(%rbp),%rdx
    1ad0:	48 39 d0             	cmp    %rdx,%rax
    1ad3:	be 00 00 00 00       	mov    $0x0,%esi
    1ad8:	40 0f 92 c6          	setb   %sil
    1adc:	45 31 c0             	xor    %r8d,%r8d
    1adf:	48 85 f6             	test   %rsi,%rsi
    1ae2:	49 0f 44 c0          	cmove  %r8,%rax
    1ae6:	49 89 c2             	mov    %rax,%r10
    1ae9:	49 c1 ea 06          	shr    $0x6,%r10
    1aed:	48 89 c1             	mov    %rax,%rcx
    1af0:	48 83 e1 3f          	and    $0x3f,%rcx
    1af4:	48 8b 95 70 fc ff ff 	mov    -0x390(%rbp),%rdx
    1afb:	4e 8d 04 d2          	lea    (%rdx,%r10,8),%r8
    1aff:	4d 8b 10             	mov    (%r8),%r10
    1b02:	48 89 8d 40 fb ff ff 	mov    %rcx,-0x4c0(%rbp)
    1b09:	4c 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%r8
    1b10:	4c 89 c1             	mov    %r8,%rcx
    1b13:	49 d3 ea             	shr    %cl,%r10
    1b16:	b9 01 00 00 00       	mov    $0x1,%ecx
    1b1b:	49 21 ca             	and    %rcx,%r10
    1b1e:	49 21 f2             	and    %rsi,%r10
    1b21:	be 10 00 00 00       	mov    $0x10,%esi
    1b26:	48 0f af c6          	imul   %rsi,%rax
    1b2a:	48 8b b5 80 fc ff ff 	mov    -0x380(%rbp),%rsi
    1b31:	4c 8d 44 06 f8       	lea    -0x8(%rsi,%rax,1),%r8
    1b36:	49 8b 40 08          	mov    0x8(%r8),%rax
    1b3a:	49 8b 70 10          	mov    0x10(%r8),%rsi
    1b3e:	48 c1 e8 20          	shr    $0x20,%rax
    1b42:	48 21 c8             	and    %rcx,%rax
    1b45:	4d 89 d3             	mov    %r10,%r11
    1b48:	49 89 f1             	mov    %rsi,%r9
    1b4b:	48 89 c7             	mov    %rax,%rdi
    1b4e:	4d 85 db             	test   %r11,%r11
    1b51:	0f 84 a5 05 00 00    	je     0x20fc
    1b57:	48 83 ff 00          	cmp    $0x0,%rdi
    1b5b:	bf 00 00 00 00       	mov    $0x0,%edi
    1b60:	40 0f 95 c7          	setne  %dil
    1b64:	48 8b 85 c8 fb ff ff 	mov    -0x438(%rbp),%rax
    1b6b:	48 89 c1             	mov    %rax,%rcx
    1b6e:	48 83 c1 01          	add    $0x1,%rcx
    1b72:	4d 63 c9             	movslq %r9d,%r9
    1b75:	31 d2                	xor    %edx,%edx
    1b77:	48 85 ff             	test   %rdi,%rdi
    1b7a:	49 0f 44 d1          	cmove  %r9,%rdx
    1b7e:	48 8b b5 c0 fb ff ff 	mov    -0x440(%rbp),%rsi
    1b85:	48 39 d6             	cmp    %rdx,%rsi
    1b88:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1b8e:	41 0f 94 c0          	sete   %r8b
    1b92:	4c 8b 8d b8 fb ff ff 	mov    -0x448(%rbp),%r9
    1b99:	49 39 f9             	cmp    %rdi,%r9
    1b9c:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    1ba2:	41 0f 94 c2          	sete   %r10b
    1ba6:	4d 21 d0             	and    %r10,%r8
    1ba9:	4d 85 c0             	test   %r8,%r8
    1bac:	48 89 8d 40 fb ff ff 	mov    %rcx,-0x4c0(%rbp)
    1bb3:	48 89 95 28 fb ff ff 	mov    %rdx,-0x4d8(%rbp)
    1bba:	48 89 bd 20 fb ff ff 	mov    %rdi,-0x4e0(%rbp)
    1bc1:	0f 84 69 00 00 00    	je     0x1c30
    1bc7:	4c 8b 85 a0 fb ff ff 	mov    -0x460(%rbp),%r8
    1bce:	4d 89 c2             	mov    %r8,%r10
    1bd1:	49 83 c2 01          	add    $0x1,%r10
    1bd5:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    1bdb:	48 8b 95 30 fb ff ff 	mov    -0x4d0(%rbp),%rdx
    1be2:	48 63 3a             	movslq (%rdx),%rdi
    1be5:	48 8b 95 38 fb ff ff 	mov    -0x4c8(%rbp),%rdx
    1bec:	48 89 d1             	mov    %rdx,%rcx
    1bef:	4c 31 d9             	xor    %r11,%rcx
    1bf2:	45 31 db             	xor    %r11d,%r11d
    1bf5:	48 85 c9             	test   %rcx,%rcx
    1bf8:	49 0f 44 fb          	cmove  %r11,%rdi
    1bfc:	4c 8b 9d 90 fb ff ff 	mov    -0x470(%rbp),%r11
    1c03:	4c 89 da             	mov    %r11,%rdx
    1c06:	48 01 ca             	add    %rcx,%rdx
    1c09:	48 8b 8d 98 fb ff ff 	mov    -0x468(%rbp),%rcx
    1c10:	48 89 c8             	mov    %rcx,%rax
    1c13:	48 01 f8             	add    %rdi,%rax
    1c16:	4c 89 95 a0 fb ff ff 	mov    %r10,-0x460(%rbp)
    1c1d:	48 89 85 98 fb ff ff 	mov    %rax,-0x468(%rbp)
    1c24:	48 89 95 90 fb ff ff 	mov    %rdx,-0x470(%rbp)
    1c2b:	e9 b2 04 00 00       	jmp    0x20e2
    1c30:	48 8b 85 a8 fb ff ff 	mov    -0x458(%rbp),%rax
    1c37:	48 85 c0             	test   %rax,%rax
    1c3a:	0f 84 09 04 00 00    	je     0x2049
    1c40:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    1c47:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    1c4b:	48 85 d2             	test   %rdx,%rdx
    1c4e:	0f 84 40 01 00 00    	je     0x1d94
    1c54:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    1c58:	be 40 00 00 00       	mov    $0x40,%esi
    1c5d:	48 29 d6             	sub    %rdx,%rsi
    1c60:	48 8b bd b0 fb ff ff 	mov    -0x450(%rbp),%rdi
    1c67:	48 89 f1             	mov    %rsi,%rcx
    1c6a:	49 89 f8             	mov    %rdi,%r8
    1c6d:	49 d3 e8             	shr    %cl,%r8
    1c70:	31 c9                	xor    %ecx,%ecx
    1c72:	48 39 ca             	cmp    %rcx,%rdx
    1c75:	ba 00 00 00 00       	mov    $0x0,%edx
    1c7a:	0f 94 c2             	sete   %dl
    1c7d:	48 85 d2             	test   %rdx,%rdx
    1c80:	49 0f 44 c8          	cmove  %r8,%rcx
    1c84:	48 8b 95 90 fc ff ff 	mov    -0x370(%rbp),%rdx
    1c8b:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    1c8f:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    1c93:	49 8b 30             	mov    (%r8),%rsi
    1c96:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    1c9d:	00 28 00 
    1ca0:	4c 39 ce             	cmp    %r9,%rsi
    1ca3:	4c 89 85 18 fb ff ff 	mov    %r8,-0x4e8(%rbp)
    1caa:	0f 82 0c 00 00 00    	jb     0x1cbc
    1cb0:	48 89 b5 10 fb ff ff 	mov    %rsi,-0x4f0(%rbp)
    1cb7:	e9 4a 00 00 00       	jmp    0x1d06
    1cbc:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    1cc0:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    1cc7:	48 89 b5 08 fb ff ff 	mov    %rsi,-0x4f8(%rbp)
    1cce:	48 89 d6             	mov    %rdx,%rsi
    1cd1:	48 89 ca             	mov    %rcx,%rdx
    1cd4:	48 8b 8d 08 fb ff ff 	mov    -0x4f8(%rbp),%rcx
    1cdb:	e8 00 e4 ff ff       	call   0xe0
    1ce0:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    1ce7:	31 d2                	xor    %edx,%edx
    1ce9:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    1ced:	48 83 f8 00          	cmp    $0x0,%rax
    1cf1:	0f 8f 08 00 00 00    	jg     0x1cff
    1cf7:	49 89 c4             	mov    %rax,%r12
    1cfa:	e9 6c 54 00 00       	jmp    0x716b
    1cff:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    1d06:	48 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%rax
    1d0d:	48 89 c1             	mov    %rax,%rcx
    1d10:	48 83 c1 28          	add    $0x28,%rcx
    1d14:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    1d1b:	00 28 00 
    1d1e:	48 29 d1             	sub    %rdx,%rcx
    1d21:	48 8b 95 18 fb ff ff 	mov    -0x4e8(%rbp),%rdx
    1d28:	48 89 0a             	mov    %rcx,(%rdx)
    1d2b:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    1d32:	ff 00 00 
    1d35:	48 21 c8             	and    %rcx,%rax
    1d38:	31 c9                	xor    %ecx,%ecx
    1d3a:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    1d41:	48 89 10             	mov    %rdx,(%rax)
    1d44:	48 8b b5 b8 fb ff ff 	mov    -0x448(%rbp),%rsi
    1d4b:	48 89 70 08          	mov    %rsi,0x8(%rax)
    1d4f:	48 89 48 10          	mov    %rcx,0x10(%rax)
    1d53:	48 89 48 18          	mov    %rcx,0x18(%rax)
    1d57:	48 89 48 20          	mov    %rcx,0x20(%rax)
    1d5b:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    1d62:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    1d66:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    1d6c:	4c 01 c7             	add    %r8,%rdi
    1d6f:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    1d73:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    1d7a:	b8 01 00 00 00       	mov    $0x1,%eax
    1d7f:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    1d86:	31 c0                	xor    %eax,%eax
    1d88:	48 89 85 08 fb ff ff 	mov    %rax,-0x4f8(%rbp)
    1d8f:	e9 a7 01 00 00       	jmp    0x1f3b
    1d94:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    1d9b:	48 8b 70 10          	mov    0x10(%rax),%rsi
    1d9f:	48 8b 48 18          	mov    0x18(%rax),%rcx
    1da3:	48 89 ca             	mov    %rcx,%rdx
    1da6:	f3 48 0f b8 d2       	popcnt %rdx,%rdx
    1dab:	bf 40 00 00 00       	mov    $0x40,%edi
    1db0:	48 29 d7             	sub    %rdx,%rdi
    1db3:	48 89 8d 00 fb ff ff 	mov    %rcx,-0x500(%rbp)
    1dba:	4c 8b 85 b0 fb ff ff 	mov    -0x450(%rbp),%r8
    1dc1:	48 89 f9             	mov    %rdi,%rcx
    1dc4:	4d 89 c1             	mov    %r8,%r9
    1dc7:	49 d3 e9             	shr    %cl,%r9
    1dca:	31 c9                	xor    %ecx,%ecx
    1dcc:	48 39 ca             	cmp    %rcx,%rdx
    1dcf:	ba 00 00 00 00       	mov    $0x0,%edx
    1dd4:	0f 94 c2             	sete   %dl
    1dd7:	48 85 d2             	test   %rdx,%rdx
    1dda:	49 0f 44 c9          	cmove  %r9,%rcx
    1dde:	ba 01 00 00 00       	mov    $0x1,%edx
    1de3:	48 89 cf             	mov    %rcx,%rdi
    1de6:	48 01 d7             	add    %rdx,%rdi
    1de9:	4c 8b 95 00 fb ff ff 	mov    -0x500(%rbp),%r10
    1df0:	49 89 f9             	mov    %rdi,%r9
    1df3:	4d 21 d1             	and    %r10,%r9
    1df6:	bf 28 00 00 00       	mov    $0x28,%edi
    1dfb:	48 0f af cf          	imul   %rdi,%rcx
    1dff:	48 8d 3c 0e          	lea    (%rsi,%rcx,1),%rdi
    1e03:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    1e07:	48 85 c9             	test   %rcx,%rcx
    1e0a:	0f 84 b2 00 00 00    	je     0x1ec2
    1e10:	48 8b 0f             	mov    (%rdi),%rcx
    1e13:	4c 8b 57 08          	mov    0x8(%rdi),%r10
    1e17:	4c 8b 9d c0 fb ff ff 	mov    -0x440(%rbp),%r11
    1e1e:	49 39 cb             	cmp    %rcx,%r11
    1e21:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1e27:	41 0f 94 c0          	sete   %r8b
    1e2b:	48 8b 8d b8 fb ff ff 	mov    -0x448(%rbp),%rcx
    1e32:	4c 39 d1             	cmp    %r10,%rcx
    1e35:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    1e3b:	41 0f 94 c3          	sete   %r11b
    1e3f:	4d 21 d8             	and    %r11,%r8
    1e42:	4d 85 c0             	test   %r8,%r8
    1e45:	0f 84 0c 00 00 00    	je     0x1e57
    1e4b:	48 89 bd 10 fb ff ff 	mov    %rdi,-0x4f0(%rbp)
    1e52:	e9 54 00 00 00       	jmp    0x1eab
    1e57:	bf 28 00 00 00       	mov    $0x28,%edi
    1e5c:	4c 0f af cf          	imul   %rdi,%r9
    1e60:	4a 8d 3c 0e          	lea    (%rsi,%r9,1),%rdi
    1e64:	48 8b 77 10          	mov    0x10(%rdi),%rsi
    1e68:	48 85 f6             	test   %rsi,%rsi
    1e6b:	0f 84 51 00 00 00    	je     0x1ec2
    1e71:	48 8b 37             	mov    (%rdi),%rsi
    1e74:	4c 8b 47 08          	mov    0x8(%rdi),%r8
    1e78:	4c 8b 8d c0 fb ff ff 	mov    -0x440(%rbp),%r9
    1e7f:	49 39 f1             	cmp    %rsi,%r9
    1e82:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    1e88:	41 0f 94 c2          	sete   %r10b
    1e8c:	4c 39 c1             	cmp    %r8,%rcx
    1e8f:	be 00 00 00 00       	mov    $0x0,%esi
    1e94:	40 0f 94 c6          	sete   %sil
    1e98:	49 21 f2             	and    %rsi,%r10
    1e9b:	4d 85 d2             	test   %r10,%r10
    1e9e:	0f 84 1e 00 00 00    	je     0x1ec2
    1ea4:	48 89 bd 10 fb ff ff 	mov    %rdi,-0x4f0(%rbp)
    1eab:	31 c0                	xor    %eax,%eax
    1ead:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    1eb4:	31 c0                	xor    %eax,%eax
    1eb6:	48 89 85 08 fb ff ff 	mov    %rax,-0x4f8(%rbp)
    1ebd:	e9 79 00 00 00       	jmp    0x1f3b
    1ec2:	48 8d 85 90 fe ff ff 	lea    -0x170(%rbp),%rax
    1ec9:	48 89 c1             	mov    %rax,%rcx
    1ecc:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    1ed3:	48 89 11             	mov    %rdx,(%rcx)
    1ed6:	48 8b b5 b8 fb ff ff 	mov    -0x448(%rbp),%rsi
    1edd:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    1ee1:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    1ee8:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    1eef:	48 89 ca             	mov    %rcx,%rdx
    1ef2:	e8 f9 e1 ff ff       	call   0xf0
    1ef7:	48 83 f8 00          	cmp    $0x0,%rax
    1efb:	0f 8d 08 00 00 00    	jge    0x1f09
    1f01:	49 89 c4             	mov    %rax,%r12
    1f04:	e9 62 52 00 00       	jmp    0x716b
    1f09:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    1f10:	48 8b 11             	mov    (%rcx),%rdx
    1f13:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    1f17:	48 83 e6 01          	and    $0x1,%rsi
    1f1b:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    1f1f:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    1f26:	b8 01 00 00 00       	mov    $0x1,%eax
    1f2b:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    1f32:	31 c0                	xor    %eax,%eax
    1f34:	48 89 85 08 fb ff ff 	mov    %rax,-0x4f8(%rbp)
    1f3b:	48 8b 85 18 fb ff ff 	mov    -0x4e8(%rbp),%rax
    1f42:	48 85 c0             	test   %rax,%rax
    1f45:	0f 84 6b 00 00 00    	je     0x1fb6
    1f4b:	48 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%rax
    1f52:	48 8b 8d a0 fb ff ff 	mov    -0x460(%rbp),%rcx
    1f59:	48 89 48 10          	mov    %rcx,0x10(%rax)
    1f5d:	31 d2                	xor    %edx,%edx
    1f5f:	48 39 d1             	cmp    %rdx,%rcx
    1f62:	be 00 00 00 00       	mov    $0x0,%esi
    1f67:	40 0f 95 c6          	setne  %sil
    1f6b:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    1f6f:	48 09 f7             	or     %rsi,%rdi
    1f72:	48 0f be ff          	movsbq %dil,%rdi
    1f76:	40 88 78 20          	mov    %dil,0x20(%rax)
    1f7a:	48 8b b5 98 fb ff ff 	mov    -0x468(%rbp),%rsi
    1f81:	48 89 70 18          	mov    %rsi,0x18(%rax)
    1f85:	4c 8b 85 90 fb ff ff 	mov    -0x470(%rbp),%r8
    1f8c:	49 39 d0             	cmp    %rdx,%r8
    1f8f:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    1f95:	41 0f 95 c1          	setne  %r9b
    1f99:	40 0f b6 ff          	movzbl %dil,%edi
    1f9d:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    1fa3:	4d 85 c9             	test   %r9,%r9
    1fa6:	4c 0f 44 d2          	cmove  %rdx,%r10
    1faa:	4c 09 d7             	or     %r10,%rdi
    1fad:	40 88 78 20          	mov    %dil,0x20(%rax)
    1fb1:	e9 93 00 00 00       	jmp    0x2049
    1fb6:	48 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%rax
    1fbd:	48 8b 48 10          	mov    0x10(%rax),%rcx
    1fc1:	48 8b 95 a0 fb ff ff 	mov    -0x460(%rbp),%rdx
    1fc8:	48 01 d1             	add    %rdx,%rcx
    1fcb:	48 89 48 10          	mov    %rcx,0x10(%rax)
    1fcf:	31 f6                	xor    %esi,%esi
    1fd1:	48 39 f1             	cmp    %rsi,%rcx
    1fd4:	b9 00 00 00 00       	mov    $0x0,%ecx
    1fd9:	0f 95 c1             	setne  %cl
    1fdc:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    1fe0:	48 09 cf             	or     %rcx,%rdi
    1fe3:	48 0f be ff          	movsbq %dil,%rdi
    1fe7:	40 88 78 20          	mov    %dil,0x20(%rax)
    1feb:	48 8b 48 18          	mov    0x18(%rax),%rcx
    1fef:	40 0f b6 ff          	movzbl %dil,%edi
    1ff3:	49 89 f8             	mov    %rdi,%r8
    1ff6:	49 83 e0 02          	and    $0x2,%r8
    1ffa:	49 39 f0             	cmp    %rsi,%r8
    1ffd:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    2003:	41 0f 95 c0          	setne  %r8b
    2007:	45 31 c9             	xor    %r9d,%r9d
    200a:	4d 85 c0             	test   %r8,%r8
    200d:	49 0f 44 c9          	cmove  %r9,%rcx
    2011:	4c 8b 8d 90 fb ff ff 	mov    -0x470(%rbp),%r9
    2018:	4d 01 c8             	add    %r9,%r8
    201b:	4c 8b 95 98 fb ff ff 	mov    -0x468(%rbp),%r10
    2022:	4c 01 d1             	add    %r10,%rcx
    2025:	48 89 48 18          	mov    %rcx,0x18(%rax)
    2029:	49 39 f0             	cmp    %rsi,%r8
    202c:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    2032:	41 0f 95 c0          	setne  %r8b
    2036:	b9 02 00 00 00       	mov    $0x2,%ecx
    203b:	4d 85 c0             	test   %r8,%r8
    203e:	48 0f 44 ce          	cmove  %rsi,%rcx
    2042:	48 09 cf             	or     %rcx,%rdi
    2045:	40 88 78 20          	mov    %dil,0x20(%rax)
    2049:	b8 01 00 00 00       	mov    $0x1,%eax
    204e:	48 8b 8d 30 fb ff ff 	mov    -0x4d0(%rbp),%rcx
    2055:	48 63 11             	movslq (%rcx),%rdx
    2058:	48 8b 8d 38 fb ff ff 	mov    -0x4c8(%rbp),%rcx
    205f:	48 31 c1             	xor    %rax,%rcx
    2062:	31 c0                	xor    %eax,%eax
    2064:	48 85 c9             	test   %rcx,%rcx
    2067:	48 0f 44 d0          	cmove  %rax,%rdx
    206b:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    2072:	79 37 9e 
    2075:	48 be 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%rsi
    207c:	79 37 9e 
    207f:	48 8b bd 28 fb ff ff 	mov    -0x4d8(%rbp),%rdi
    2086:	48 31 fe             	xor    %rdi,%rsi
    2089:	48 0f af f0          	imul   %rax,%rsi
    208d:	49 89 f0             	mov    %rsi,%r8
    2090:	49 c1 e8 1d          	shr    $0x1d,%r8
    2094:	4c 31 c6             	xor    %r8,%rsi
    2097:	4c 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%r8
    209e:	4c 31 c6             	xor    %r8,%rsi
    20a1:	48 0f af f0          	imul   %rax,%rsi
    20a5:	49 89 f1             	mov    %rsi,%r9
    20a8:	49 c1 e9 1d          	shr    $0x1d,%r9
    20ac:	4c 31 ce             	xor    %r9,%rsi
    20af:	48 0f af f0          	imul   %rax,%rsi
    20b3:	48 89 bd c0 fb ff ff 	mov    %rdi,-0x440(%rbp)
    20ba:	4c 89 85 b8 fb ff ff 	mov    %r8,-0x448(%rbp)
    20c1:	48 89 b5 b0 fb ff ff 	mov    %rsi,-0x450(%rbp)
    20c8:	b8 01 00 00 00       	mov    $0x1,%eax
    20cd:	48 89 85 a0 fb ff ff 	mov    %rax,-0x460(%rbp)
    20d4:	48 89 95 98 fb ff ff 	mov    %rdx,-0x468(%rbp)
    20db:	48 89 8d 90 fb ff ff 	mov    %rcx,-0x470(%rbp)
    20e2:	48 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%rax
    20e9:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    20f0:	b8 01 00 00 00       	mov    $0x1,%eax
    20f5:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
    20fc:	48 8b 85 d0 fb ff ff 	mov    -0x430(%rbp),%rax
    2103:	b9 01 00 00 00       	mov    $0x1,%ecx
    2108:	48 89 c2             	mov    %rax,%rdx
    210b:	48 01 ca             	add    %rcx,%rdx
    210e:	48 89 95 d0 fb ff ff 	mov    %rdx,-0x430(%rbp)
    2115:	e9 e9 f5 ff ff       	jmp    0x1703
    211a:	48 8b 85 08 fc ff ff 	mov    -0x3f8(%rbp),%rax
    2121:	48 89 85 d0 fb ff ff 	mov    %rax,-0x430(%rbp)
    2128:	31 c0                	xor    %eax,%eax
    212a:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    2131:	31 c0                	xor    %eax,%eax
    2133:	48 89 85 c0 fb ff ff 	mov    %rax,-0x440(%rbp)
    213a:	31 c0                	xor    %eax,%eax
    213c:	48 89 85 b8 fb ff ff 	mov    %rax,-0x448(%rbp)
    2143:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
    214a:	82 28 52 
    214d:	48 89 85 b0 fb ff ff 	mov    %rax,-0x450(%rbp)
    2154:	31 c0                	xor    %eax,%eax
    2156:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
    215d:	31 c0                	xor    %eax,%eax
    215f:	48 89 85 a0 fb ff ff 	mov    %rax,-0x460(%rbp)
    2166:	31 c0                	xor    %eax,%eax
    2168:	48 89 85 98 fb ff ff 	mov    %rax,-0x468(%rbp)
    216f:	31 c0                	xor    %eax,%eax
    2171:	48 89 85 90 fb ff ff 	mov    %rax,-0x470(%rbp)
    2178:	48 8b 85 d0 fb ff ff 	mov    -0x430(%rbp),%rax
    217f:	48 8b 8d f8 fb ff ff 	mov    -0x408(%rbp),%rcx
    2186:	48 39 c8             	cmp    %rcx,%rax
    2189:	0f 8c 75 00 00 00    	jl     0x2204
    218f:	48 8b 95 c8 fb ff ff 	mov    -0x438(%rbp),%rdx
    2196:	48 89 95 80 fb ff ff 	mov    %rdx,-0x480(%rbp)
    219d:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    21a4:	48 89 95 70 fb ff ff 	mov    %rdx,-0x490(%rbp)
    21ab:	48 8b 95 b8 fb ff ff 	mov    -0x448(%rbp),%rdx
    21b2:	48 89 95 68 fb ff ff 	mov    %rdx,-0x498(%rbp)
    21b9:	48 8b 95 b0 fb ff ff 	mov    -0x450(%rbp),%rdx
    21c0:	48 89 95 60 fb ff ff 	mov    %rdx,-0x4a0(%rbp)
    21c7:	48 8b 95 a8 fb ff ff 	mov    -0x458(%rbp),%rdx
    21ce:	48 89 95 88 fb ff ff 	mov    %rdx,-0x478(%rbp)
    21d5:	48 8b 95 a0 fb ff ff 	mov    -0x460(%rbp),%rdx
    21dc:	48 89 95 78 fb ff ff 	mov    %rdx,-0x488(%rbp)
    21e3:	48 8b 95 98 fb ff ff 	mov    -0x468(%rbp),%rdx
    21ea:	48 89 95 58 fb ff ff 	mov    %rdx,-0x4a8(%rbp)
    21f1:	48 8b 95 90 fb ff ff 	mov    -0x470(%rbp),%rdx
    21f8:	48 89 95 50 fb ff ff 	mov    %rdx,-0x4b0(%rbp)
    21ff:	e9 53 08 00 00       	jmp    0x2a57
    2204:	48 8b 95 d8 fb ff ff 	mov    -0x428(%rbp),%rdx
    220b:	48 8d 34 82          	lea    (%rdx,%rax,4),%rsi
    220f:	48 8b bd e8 fb ff ff 	mov    -0x418(%rbp),%rdi
    2216:	4c 8d 04 87          	lea    (%rdi,%rax,4),%r8
    221a:	4c 63 0e             	movslq (%rsi),%r9
    221d:	4c 8b 95 50 fc ff ff 	mov    -0x3b0(%rbp),%r10
    2224:	4d 85 d2             	test   %r10,%r10
    2227:	4c 89 85 40 fb ff ff 	mov    %r8,-0x4c0(%rbp)
    222e:	4c 89 8d 20 fb ff ff 	mov    %r9,-0x4e0(%rbp)
    2235:	0f 84 38 01 00 00    	je     0x2373
    223b:	49 bb 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%r11
    2242:	79 37 9e 
    2245:	4d 89 c8             	mov    %r9,%r8
    2248:	49 c1 e8 2b          	shr    $0x2b,%r8
    224c:	4c 89 c8             	mov    %r9,%rax
    224f:	48 c1 e8 2c          	shr    $0x2c,%rax
    2253:	49 31 c0             	xor    %rax,%r8
    2256:	4c 89 c8             	mov    %r9,%rax
    2259:	4c 31 c0             	xor    %r8,%rax
    225c:	49 0f af c3          	imul   %r11,%rax
    2260:	49 89 c0             	mov    %rax,%r8
    2263:	49 c1 e8 1e          	shr    $0x1e,%r8
    2267:	49 89 c3             	mov    %rax,%r11
    226a:	4d 31 c3             	xor    %r8,%r11
    226d:	49 b8 b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%r8
    2274:	47 58 bf 
    2277:	4d 0f af d8          	imul   %r8,%r11
    227b:	4d 89 d8             	mov    %r11,%r8
    227e:	49 c1 e8 1b          	shr    $0x1b,%r8
    2282:	4d 31 c3             	xor    %r8,%r11
    2285:	49 b8 eb 11 31 13 bb 	movabs $0x94d049bb133111eb,%r8
    228c:	49 d0 94 
    228f:	4d 0f af d8          	imul   %r8,%r11
    2293:	4d 89 d8             	mov    %r11,%r8
    2296:	49 c1 e8 1f          	shr    $0x1f,%r8
    229a:	4d 31 c3             	xor    %r8,%r11
    229d:	41 b8 40 00 00 00    	mov    $0x40,%r8d
    22a3:	4d 29 d0             	sub    %r10,%r8
    22a6:	4c 89 c1             	mov    %r8,%rcx
    22a9:	49 d3 eb             	shr    %cl,%r11
    22ac:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
    22b0:	4c 89 d9             	mov    %r11,%rcx
    22b3:	4d 89 c1             	mov    %r8,%r9
    22b6:	49 d3 e9             	shr    %cl,%r9
    22b9:	b9 01 00 00 00       	mov    $0x1,%ecx
    22be:	49 21 c9             	and    %rcx,%r9
    22c1:	4d 85 c9             	test   %r9,%r9
    22c4:	0f 84 a9 00 00 00    	je     0x2373
    22ca:	4c 8d 8d 00 ff ff ff 	lea    -0x100(%rbp),%r9
    22d1:	4c 89 ca             	mov    %r9,%rdx
    22d4:	4c 63 0e             	movslq (%rsi),%r9
    22d7:	31 f6                	xor    %esi,%esi
    22d9:	31 ff                	xor    %edi,%edi
    22db:	48 89 32             	mov    %rsi,(%rdx)
    22de:	4c 89 4a 08          	mov    %r9,0x8(%rdx)
    22e2:	48 89 7a 10          	mov    %rdi,0x10(%rdx)
    22e6:	48 8b b5 40 fb ff ff 	mov    -0x4c0(%rbp),%rsi
    22ed:	48 63 3e             	movslq (%rsi),%rdi
    22f0:	45 31 c9             	xor    %r9d,%r9d
    22f3:	31 f6                	xor    %esi,%esi
    22f5:	4c 89 4a 18          	mov    %r9,0x18(%rdx)
    22f9:	48 89 7a 20          	mov    %rdi,0x20(%rdx)
    22fd:	48 89 72 28          	mov    %rsi,0x28(%rdx)
    2301:	be 01 00 00 00       	mov    $0x1,%esi
    2306:	4c 89 d1             	mov    %r10,%rcx
    2309:	48 d3 e6             	shl    %cl,%rsi
    230c:	4c 01 de             	add    %r11,%rsi
    230f:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    2314:	bf 02 00 00 00       	mov    $0x2,%edi
    2319:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    2320:	48 89 b5 28 fb ff ff 	mov    %rsi,-0x4d8(%rbp)
    2327:	48 89 ce             	mov    %rcx,%rsi
    232a:	48 89 95 38 fb ff ff 	mov    %rdx,-0x4c8(%rbp)
    2331:	4c 89 d2             	mov    %r10,%rdx
    2334:	48 8b 8d 28 fb ff ff 	mov    -0x4d8(%rbp),%rcx
    233b:	49 89 c0             	mov    %rax,%r8
    233e:	4c 8b 8d 38 fb ff ff 	mov    -0x4c8(%rbp),%r9
    2345:	b8 02 00 00 00       	mov    $0x2,%eax
    234a:	48 89 04 24          	mov    %rax,(%rsp)
    234e:	e8 7d dd ff ff       	call   0xd0
    2353:	48 83 f8 00          	cmp    $0x0,%rax
    2357:	0f 8d 11 00 00 00    	jge    0x236e
    235d:	b8 80 00 00 00       	mov    $0x80,%eax
    2362:	48 89 85 48 fb ff ff 	mov    %rax,-0x4b8(%rbp)
    2369:	e9 dc 4d 00 00       	jmp    0x714a
    236e:	e9 c6 06 00 00       	jmp    0x2a39
    2373:	49 83 fd 05          	cmp    $0x5,%r13
    2377:	0f 85 a7 00 00 00    	jne    0x2424
    237d:	48 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%rax
    2384:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    238b:	48 89 c2             	mov    %rax,%rdx
    238e:	48 29 ca             	sub    %rcx,%rdx
    2391:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    2398:	48 39 f2             	cmp    %rsi,%rdx
    239b:	bf 00 00 00 00       	mov    $0x0,%edi
    23a0:	40 0f 92 c7          	setb   %dil
    23a4:	45 31 c0             	xor    %r8d,%r8d
    23a7:	48 85 ff             	test   %rdi,%rdi
    23aa:	49 0f 44 d0          	cmove  %r8,%rdx
    23ae:	49 89 d1             	mov    %rdx,%r9
    23b1:	49 c1 e9 06          	shr    $0x6,%r9
    23b5:	48 83 e2 3f          	and    $0x3f,%rdx
    23b9:	4c 8b 95 70 fc ff ff 	mov    -0x390(%rbp),%r10
    23c0:	4f 8d 1c ca          	lea    (%r10,%r9,8),%r11
    23c4:	49 8b 03             	mov    (%r11),%rax
    23c7:	48 89 d1             	mov    %rdx,%rcx
    23ca:	48 d3 e8             	shr    %cl,%rax
    23cd:	b9 01 00 00 00       	mov    $0x1,%ecx
    23d2:	48 21 c8             	and    %rcx,%rax
    23d5:	49 89 c3             	mov    %rax,%r11
    23d8:	49 21 fb             	and    %rdi,%r11
    23db:	48 8b 85 48 fc ff ff 	mov    -0x3b8(%rbp),%rax
    23e2:	4a 8d 3c c8          	lea    (%rax,%r9,8),%rdi
    23e6:	48 8b 07             	mov    (%rdi),%rax
    23e9:	48 89 d1             	mov    %rdx,%rcx
    23ec:	48 d3 e8             	shr    %cl,%rax
    23ef:	b9 01 00 00 00       	mov    $0x1,%ecx
    23f4:	48 89 c7             	mov    %rax,%rdi
    23f7:	48 21 cf             	and    %rcx,%rdi
    23fa:	48 8b 85 58 fc ff ff 	mov    -0x3a8(%rbp),%rax
    2401:	4a 8d 34 c8          	lea    (%rax,%r9,8),%rsi
    2405:	4c 8b 0e             	mov    (%rsi),%r9
    2408:	48 89 d1             	mov    %rdx,%rcx
    240b:	49 d3 e9             	shr    %cl,%r9
    240e:	b9 01 00 00 00       	mov    $0x1,%ecx
    2413:	4c 89 ce             	mov    %r9,%rsi
    2416:	48 21 ce             	and    %rcx,%rsi
    2419:	49 89 f9             	mov    %rdi,%r9
    241c:	48 89 f7             	mov    %rsi,%rdi
    241f:	e9 96 00 00 00       	jmp    0x24ba
    2424:	48 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%rax
    242b:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    2432:	48 29 c8             	sub    %rcx,%rax
    2435:	48 8b 95 60 fc ff ff 	mov    -0x3a0(%rbp),%rdx
    243c:	48 39 d0             	cmp    %rdx,%rax
    243f:	be 00 00 00 00       	mov    $0x0,%esi
    2444:	40 0f 92 c6          	setb   %sil
    2448:	45 31 c0             	xor    %r8d,%r8d
    244b:	48 85 f6             	test   %rsi,%rsi
    244e:	49 0f 44 c0          	cmove  %r8,%rax
    2452:	49 89 c2             	mov    %rax,%r10
    2455:	49 c1 ea 06          	shr    $0x6,%r10
    2459:	48 89 c1             	mov    %rax,%rcx
    245c:	48 83 e1 3f          	and    $0x3f,%rcx
    2460:	48 8b 95 70 fc ff ff 	mov    -0x390(%rbp),%rdx
    2467:	4e 8d 04 d2          	lea    (%rdx,%r10,8),%r8
    246b:	4d 8b 10             	mov    (%r8),%r10
    246e:	48 89 8d 20 fb ff ff 	mov    %rcx,-0x4e0(%rbp)
    2475:	4c 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%r8
    247c:	4c 89 c1             	mov    %r8,%rcx
    247f:	49 d3 ea             	shr    %cl,%r10
    2482:	b9 01 00 00 00       	mov    $0x1,%ecx
    2487:	49 21 ca             	and    %rcx,%r10
    248a:	49 21 f2             	and    %rsi,%r10
    248d:	be 10 00 00 00       	mov    $0x10,%esi
    2492:	48 0f af c6          	imul   %rsi,%rax
    2496:	48 8b b5 80 fc ff ff 	mov    -0x380(%rbp),%rsi
    249d:	4c 8d 44 06 f8       	lea    -0x8(%rsi,%rax,1),%r8
    24a2:	49 8b 40 08          	mov    0x8(%r8),%rax
    24a6:	49 8b 70 10          	mov    0x10(%r8),%rsi
    24aa:	48 c1 e8 20          	shr    $0x20,%rax
    24ae:	48 21 c8             	and    %rcx,%rax
    24b1:	4d 89 d3             	mov    %r10,%r11
    24b4:	49 89 f1             	mov    %rsi,%r9
    24b7:	48 89 c7             	mov    %rax,%rdi
    24ba:	4d 85 db             	test   %r11,%r11
    24bd:	0f 84 76 05 00 00    	je     0x2a39
    24c3:	48 83 ff 00          	cmp    $0x0,%rdi
    24c7:	bf 00 00 00 00       	mov    $0x0,%edi
    24cc:	40 0f 95 c7          	setne  %dil
    24d0:	48 8b 85 c8 fb ff ff 	mov    -0x438(%rbp),%rax
    24d7:	48 89 c1             	mov    %rax,%rcx
    24da:	48 83 c1 01          	add    $0x1,%rcx
    24de:	4d 63 c9             	movslq %r9d,%r9
    24e1:	31 d2                	xor    %edx,%edx
    24e3:	48 85 ff             	test   %rdi,%rdi
    24e6:	49 0f 44 d1          	cmove  %r9,%rdx
    24ea:	48 8b b5 c0 fb ff ff 	mov    -0x440(%rbp),%rsi
    24f1:	48 39 d6             	cmp    %rdx,%rsi
    24f4:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    24fa:	41 0f 94 c0          	sete   %r8b
    24fe:	4c 8b 8d b8 fb ff ff 	mov    -0x448(%rbp),%r9
    2505:	49 39 f9             	cmp    %rdi,%r9
    2508:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    250e:	41 0f 94 c2          	sete   %r10b
    2512:	4d 21 d0             	and    %r10,%r8
    2515:	4d 85 c0             	test   %r8,%r8
    2518:	48 89 8d 20 fb ff ff 	mov    %rcx,-0x4e0(%rbp)
    251f:	48 89 95 38 fb ff ff 	mov    %rdx,-0x4c8(%rbp)
    2526:	48 89 bd 28 fb ff ff 	mov    %rdi,-0x4d8(%rbp)
    252d:	0f 84 4d 00 00 00    	je     0x2580
    2533:	4c 8b 85 a0 fb ff ff 	mov    -0x460(%rbp),%r8
    253a:	4d 89 c2             	mov    %r8,%r10
    253d:	49 83 c2 01          	add    $0x1,%r10
    2541:	4c 8b 9d 40 fb ff ff 	mov    -0x4c0(%rbp),%r11
    2548:	49 63 13             	movslq (%r11),%rdx
    254b:	4c 8b 9d 90 fb ff ff 	mov    -0x470(%rbp),%r11
    2552:	4c 89 df             	mov    %r11,%rdi
    2555:	48 83 c7 01          	add    $0x1,%rdi
    2559:	48 8b 8d 98 fb ff ff 	mov    -0x468(%rbp),%rcx
    2560:	48 89 c8             	mov    %rcx,%rax
    2563:	48 01 d0             	add    %rdx,%rax
    2566:	4c 89 95 a0 fb ff ff 	mov    %r10,-0x460(%rbp)
    256d:	48 89 85 98 fb ff ff 	mov    %rax,-0x468(%rbp)
    2574:	48 89 bd 90 fb ff ff 	mov    %rdi,-0x470(%rbp)
    257b:	e9 9f 04 00 00       	jmp    0x2a1f
    2580:	48 8b 85 a8 fb ff ff 	mov    -0x458(%rbp),%rax
    2587:	48 85 c0             	test   %rax,%rax
    258a:	0f 84 09 04 00 00    	je     0x2999
    2590:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    2597:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    259b:	48 85 d2             	test   %rdx,%rdx
    259e:	0f 84 40 01 00 00    	je     0x26e4
    25a4:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    25a8:	be 40 00 00 00       	mov    $0x40,%esi
    25ad:	48 29 d6             	sub    %rdx,%rsi
    25b0:	48 8b bd b0 fb ff ff 	mov    -0x450(%rbp),%rdi
    25b7:	48 89 f1             	mov    %rsi,%rcx
    25ba:	49 89 f8             	mov    %rdi,%r8
    25bd:	49 d3 e8             	shr    %cl,%r8
    25c0:	31 c9                	xor    %ecx,%ecx
    25c2:	48 39 ca             	cmp    %rcx,%rdx
    25c5:	ba 00 00 00 00       	mov    $0x0,%edx
    25ca:	0f 94 c2             	sete   %dl
    25cd:	48 85 d2             	test   %rdx,%rdx
    25d0:	49 0f 44 c8          	cmove  %r8,%rcx
    25d4:	48 8b 95 90 fc ff ff 	mov    -0x370(%rbp),%rdx
    25db:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    25df:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    25e3:	49 8b 30             	mov    (%r8),%rsi
    25e6:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    25ed:	00 28 00 
    25f0:	4c 39 ce             	cmp    %r9,%rsi
    25f3:	4c 89 85 30 fb ff ff 	mov    %r8,-0x4d0(%rbp)
    25fa:	0f 82 0c 00 00 00    	jb     0x260c
    2600:	48 89 b5 10 fb ff ff 	mov    %rsi,-0x4f0(%rbp)
    2607:	e9 4a 00 00 00       	jmp    0x2656
    260c:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    2610:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    2617:	48 89 b5 18 fb ff ff 	mov    %rsi,-0x4e8(%rbp)
    261e:	48 89 d6             	mov    %rdx,%rsi
    2621:	48 89 ca             	mov    %rcx,%rdx
    2624:	48 8b 8d 18 fb ff ff 	mov    -0x4e8(%rbp),%rcx
    262b:	e8 b0 da ff ff       	call   0xe0
    2630:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    2637:	31 d2                	xor    %edx,%edx
    2639:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    263d:	48 83 f8 00          	cmp    $0x0,%rax
    2641:	0f 8f 08 00 00 00    	jg     0x264f
    2647:	49 89 c4             	mov    %rax,%r12
    264a:	e9 1c 4b 00 00       	jmp    0x716b
    264f:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    2656:	48 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%rax
    265d:	48 89 c1             	mov    %rax,%rcx
    2660:	48 83 c1 28          	add    $0x28,%rcx
    2664:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    266b:	00 28 00 
    266e:	48 29 d1             	sub    %rdx,%rcx
    2671:	48 8b 95 30 fb ff ff 	mov    -0x4d0(%rbp),%rdx
    2678:	48 89 0a             	mov    %rcx,(%rdx)
    267b:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    2682:	ff 00 00 
    2685:	48 21 c8             	and    %rcx,%rax
    2688:	31 c9                	xor    %ecx,%ecx
    268a:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    2691:	48 89 10             	mov    %rdx,(%rax)
    2694:	48 8b b5 b8 fb ff ff 	mov    -0x448(%rbp),%rsi
    269b:	48 89 70 08          	mov    %rsi,0x8(%rax)
    269f:	48 89 48 10          	mov    %rcx,0x10(%rax)
    26a3:	48 89 48 18          	mov    %rcx,0x18(%rax)
    26a7:	48 89 48 20          	mov    %rcx,0x20(%rax)
    26ab:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    26b2:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    26b6:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    26bc:	4c 01 c7             	add    %r8,%rdi
    26bf:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    26c3:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    26ca:	b8 01 00 00 00       	mov    $0x1,%eax
    26cf:	48 89 85 30 fb ff ff 	mov    %rax,-0x4d0(%rbp)
    26d6:	31 c0                	xor    %eax,%eax
    26d8:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    26df:	e9 a7 01 00 00       	jmp    0x288b
    26e4:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    26eb:	48 8b 70 10          	mov    0x10(%rax),%rsi
    26ef:	48 8b 48 18          	mov    0x18(%rax),%rcx
    26f3:	48 89 ca             	mov    %rcx,%rdx
    26f6:	f3 48 0f b8 d2       	popcnt %rdx,%rdx
    26fb:	bf 40 00 00 00       	mov    $0x40,%edi
    2700:	48 29 d7             	sub    %rdx,%rdi
    2703:	48 89 8d 08 fb ff ff 	mov    %rcx,-0x4f8(%rbp)
    270a:	4c 8b 85 b0 fb ff ff 	mov    -0x450(%rbp),%r8
    2711:	48 89 f9             	mov    %rdi,%rcx
    2714:	4d 89 c1             	mov    %r8,%r9
    2717:	49 d3 e9             	shr    %cl,%r9
    271a:	31 c9                	xor    %ecx,%ecx
    271c:	48 39 ca             	cmp    %rcx,%rdx
    271f:	ba 00 00 00 00       	mov    $0x0,%edx
    2724:	0f 94 c2             	sete   %dl
    2727:	48 85 d2             	test   %rdx,%rdx
    272a:	49 0f 44 c9          	cmove  %r9,%rcx
    272e:	ba 01 00 00 00       	mov    $0x1,%edx
    2733:	48 89 cf             	mov    %rcx,%rdi
    2736:	48 01 d7             	add    %rdx,%rdi
    2739:	4c 8b 95 08 fb ff ff 	mov    -0x4f8(%rbp),%r10
    2740:	49 89 f9             	mov    %rdi,%r9
    2743:	4d 21 d1             	and    %r10,%r9
    2746:	bf 28 00 00 00       	mov    $0x28,%edi
    274b:	48 0f af cf          	imul   %rdi,%rcx
    274f:	48 8d 3c 0e          	lea    (%rsi,%rcx,1),%rdi
    2753:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    2757:	48 85 c9             	test   %rcx,%rcx
    275a:	0f 84 b2 00 00 00    	je     0x2812
    2760:	48 8b 0f             	mov    (%rdi),%rcx
    2763:	4c 8b 57 08          	mov    0x8(%rdi),%r10
    2767:	4c 8b 9d c0 fb ff ff 	mov    -0x440(%rbp),%r11
    276e:	49 39 cb             	cmp    %rcx,%r11
    2771:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    2777:	41 0f 94 c0          	sete   %r8b
    277b:	48 8b 8d b8 fb ff ff 	mov    -0x448(%rbp),%rcx
    2782:	4c 39 d1             	cmp    %r10,%rcx
    2785:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    278b:	41 0f 94 c3          	sete   %r11b
    278f:	4d 21 d8             	and    %r11,%r8
    2792:	4d 85 c0             	test   %r8,%r8
    2795:	0f 84 0c 00 00 00    	je     0x27a7
    279b:	48 89 bd 10 fb ff ff 	mov    %rdi,-0x4f0(%rbp)
    27a2:	e9 54 00 00 00       	jmp    0x27fb
    27a7:	bf 28 00 00 00       	mov    $0x28,%edi
    27ac:	4c 0f af cf          	imul   %rdi,%r9
    27b0:	4a 8d 3c 0e          	lea    (%rsi,%r9,1),%rdi
    27b4:	48 8b 77 10          	mov    0x10(%rdi),%rsi
    27b8:	48 85 f6             	test   %rsi,%rsi
    27bb:	0f 84 51 00 00 00    	je     0x2812
    27c1:	48 8b 37             	mov    (%rdi),%rsi
    27c4:	4c 8b 47 08          	mov    0x8(%rdi),%r8
    27c8:	4c 8b 8d c0 fb ff ff 	mov    -0x440(%rbp),%r9
    27cf:	49 39 f1             	cmp    %rsi,%r9
    27d2:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    27d8:	41 0f 94 c2          	sete   %r10b
    27dc:	4c 39 c1             	cmp    %r8,%rcx
    27df:	be 00 00 00 00       	mov    $0x0,%esi
    27e4:	40 0f 94 c6          	sete   %sil
    27e8:	49 21 f2             	and    %rsi,%r10
    27eb:	4d 85 d2             	test   %r10,%r10
    27ee:	0f 84 1e 00 00 00    	je     0x2812
    27f4:	48 89 bd 10 fb ff ff 	mov    %rdi,-0x4f0(%rbp)
    27fb:	31 c0                	xor    %eax,%eax
    27fd:	48 89 85 30 fb ff ff 	mov    %rax,-0x4d0(%rbp)
    2804:	31 c0                	xor    %eax,%eax
    2806:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    280d:	e9 79 00 00 00       	jmp    0x288b
    2812:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
    2819:	48 89 c1             	mov    %rax,%rcx
    281c:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    2823:	48 89 11             	mov    %rdx,(%rcx)
    2826:	48 8b b5 b8 fb ff ff 	mov    -0x448(%rbp),%rsi
    282d:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    2831:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    2838:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    283f:	48 89 ca             	mov    %rcx,%rdx
    2842:	e8 a9 d8 ff ff       	call   0xf0
    2847:	48 83 f8 00          	cmp    $0x0,%rax
    284b:	0f 8d 08 00 00 00    	jge    0x2859
    2851:	49 89 c4             	mov    %rax,%r12
    2854:	e9 12 49 00 00       	jmp    0x716b
    2859:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    2860:	48 8b 11             	mov    (%rcx),%rdx
    2863:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    2867:	48 83 e6 01          	and    $0x1,%rsi
    286b:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    286f:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    2876:	b8 01 00 00 00       	mov    $0x1,%eax
    287b:	48 89 85 30 fb ff ff 	mov    %rax,-0x4d0(%rbp)
    2882:	31 c0                	xor    %eax,%eax
    2884:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    288b:	48 8b 85 30 fb ff ff 	mov    -0x4d0(%rbp),%rax
    2892:	48 85 c0             	test   %rax,%rax
    2895:	0f 84 6b 00 00 00    	je     0x2906
    289b:	48 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%rax
    28a2:	48 8b 8d a0 fb ff ff 	mov    -0x460(%rbp),%rcx
    28a9:	48 89 48 10          	mov    %rcx,0x10(%rax)
    28ad:	31 d2                	xor    %edx,%edx
    28af:	48 39 d1             	cmp    %rdx,%rcx
    28b2:	be 00 00 00 00       	mov    $0x0,%esi
    28b7:	40 0f 95 c6          	setne  %sil
    28bb:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    28bf:	48 09 f7             	or     %rsi,%rdi
    28c2:	48 0f be ff          	movsbq %dil,%rdi
    28c6:	40 88 78 20          	mov    %dil,0x20(%rax)
    28ca:	48 8b b5 98 fb ff ff 	mov    -0x468(%rbp),%rsi
    28d1:	48 89 70 18          	mov    %rsi,0x18(%rax)
    28d5:	4c 8b 85 90 fb ff ff 	mov    -0x470(%rbp),%r8
    28dc:	49 39 d0             	cmp    %rdx,%r8
    28df:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    28e5:	41 0f 95 c1          	setne  %r9b
    28e9:	40 0f b6 ff          	movzbl %dil,%edi
    28ed:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    28f3:	4d 85 c9             	test   %r9,%r9
    28f6:	4c 0f 44 d2          	cmove  %rdx,%r10
    28fa:	4c 09 d7             	or     %r10,%rdi
    28fd:	40 88 78 20          	mov    %dil,0x20(%rax)
    2901:	e9 93 00 00 00       	jmp    0x2999
    2906:	48 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%rax
    290d:	48 8b 48 10          	mov    0x10(%rax),%rcx
    2911:	48 8b 95 a0 fb ff ff 	mov    -0x460(%rbp),%rdx
    2918:	48 01 d1             	add    %rdx,%rcx
    291b:	48 89 48 10          	mov    %rcx,0x10(%rax)
    291f:	31 f6                	xor    %esi,%esi
    2921:	48 39 f1             	cmp    %rsi,%rcx
    2924:	b9 00 00 00 00       	mov    $0x0,%ecx
    2929:	0f 95 c1             	setne  %cl
    292c:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    2930:	48 09 cf             	or     %rcx,%rdi
    2933:	48 0f be ff          	movsbq %dil,%rdi
    2937:	40 88 78 20          	mov    %dil,0x20(%rax)
    293b:	48 8b 48 18          	mov    0x18(%rax),%rcx
    293f:	40 0f b6 ff          	movzbl %dil,%edi
    2943:	49 89 f8             	mov    %rdi,%r8
    2946:	49 83 e0 02          	and    $0x2,%r8
    294a:	49 39 f0             	cmp    %rsi,%r8
    294d:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    2953:	41 0f 95 c0          	setne  %r8b
    2957:	45 31 c9             	xor    %r9d,%r9d
    295a:	4d 85 c0             	test   %r8,%r8
    295d:	49 0f 44 c9          	cmove  %r9,%rcx
    2961:	4c 8b 8d 90 fb ff ff 	mov    -0x470(%rbp),%r9
    2968:	4d 01 c8             	add    %r9,%r8
    296b:	4c 8b 95 98 fb ff ff 	mov    -0x468(%rbp),%r10
    2972:	4c 01 d1             	add    %r10,%rcx
    2975:	48 89 48 18          	mov    %rcx,0x18(%rax)
    2979:	49 39 f0             	cmp    %rsi,%r8
    297c:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    2982:	41 0f 95 c0          	setne  %r8b
    2986:	b9 02 00 00 00       	mov    $0x2,%ecx
    298b:	4d 85 c0             	test   %r8,%r8
    298e:	48 0f 44 ce          	cmove  %rsi,%rcx
    2992:	48 09 cf             	or     %rcx,%rdi
    2995:	40 88 78 20          	mov    %dil,0x20(%rax)
    2999:	48 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%rax
    29a0:	48 63 08             	movslq (%rax),%rcx
    29a3:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    29aa:	79 37 9e 
    29ad:	48 ba 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%rdx
    29b4:	79 37 9e 
    29b7:	48 8b b5 38 fb ff ff 	mov    -0x4c8(%rbp),%rsi
    29be:	48 31 f2             	xor    %rsi,%rdx
    29c1:	48 0f af d0          	imul   %rax,%rdx
    29c5:	48 89 d7             	mov    %rdx,%rdi
    29c8:	48 c1 ef 1d          	shr    $0x1d,%rdi
    29cc:	48 31 fa             	xor    %rdi,%rdx
    29cf:	48 8b bd 28 fb ff ff 	mov    -0x4d8(%rbp),%rdi
    29d6:	48 31 fa             	xor    %rdi,%rdx
    29d9:	48 0f af d0          	imul   %rax,%rdx
    29dd:	49 89 d0             	mov    %rdx,%r8
    29e0:	49 c1 e8 1d          	shr    $0x1d,%r8
    29e4:	4c 31 c2             	xor    %r8,%rdx
    29e7:	48 0f af d0          	imul   %rax,%rdx
    29eb:	48 89 b5 c0 fb ff ff 	mov    %rsi,-0x440(%rbp)
    29f2:	48 89 bd b8 fb ff ff 	mov    %rdi,-0x448(%rbp)
    29f9:	48 89 95 b0 fb ff ff 	mov    %rdx,-0x450(%rbp)
    2a00:	b8 01 00 00 00       	mov    $0x1,%eax
    2a05:	48 89 85 a0 fb ff ff 	mov    %rax,-0x460(%rbp)
    2a0c:	48 89 8d 98 fb ff ff 	mov    %rcx,-0x468(%rbp)
    2a13:	b8 01 00 00 00       	mov    $0x1,%eax
    2a18:	48 89 85 90 fb ff ff 	mov    %rax,-0x470(%rbp)
    2a1f:	48 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%rax
    2a26:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    2a2d:	b8 01 00 00 00       	mov    $0x1,%eax
    2a32:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
    2a39:	48 8b 85 d0 fb ff ff 	mov    -0x430(%rbp),%rax
    2a40:	b9 01 00 00 00       	mov    $0x1,%ecx
    2a45:	48 89 c2             	mov    %rax,%rdx
    2a48:	48 01 ca             	add    %rcx,%rdx
    2a4b:	48 89 95 d0 fb ff ff 	mov    %rdx,-0x430(%rbp)
    2a52:	e9 21 f7 ff ff       	jmp    0x2178
    2a57:	48 8b 85 88 fb ff ff 	mov    -0x478(%rbp),%rax
    2a5e:	48 85 c0             	test   %rax,%rax
    2a61:	0f 84 06 04 00 00    	je     0x2e6d
    2a67:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    2a6e:	48 8b 48 68          	mov    0x68(%rax),%rcx
    2a72:	48 85 c9             	test   %rcx,%rcx
    2a75:	0f 84 47 01 00 00    	je     0x2bc2
    2a7b:	48 8b 48 38          	mov    0x38(%rax),%rcx
    2a7f:	ba 40 00 00 00       	mov    $0x40,%edx
    2a84:	48 29 ca             	sub    %rcx,%rdx
    2a87:	48 89 8d 88 fb ff ff 	mov    %rcx,-0x478(%rbp)
    2a8e:	48 8b b5 60 fb ff ff 	mov    -0x4a0(%rbp),%rsi
    2a95:	48 89 d1             	mov    %rdx,%rcx
    2a98:	48 89 f7             	mov    %rsi,%rdi
    2a9b:	48 d3 ef             	shr    %cl,%rdi
    2a9e:	31 c9                	xor    %ecx,%ecx
    2aa0:	48 8b 95 88 fb ff ff 	mov    -0x478(%rbp),%rdx
    2aa7:	48 39 ca             	cmp    %rcx,%rdx
    2aaa:	ba 00 00 00 00       	mov    $0x0,%edx
    2aaf:	0f 94 c2             	sete   %dl
    2ab2:	48 85 d2             	test   %rdx,%rdx
    2ab5:	48 0f 44 cf          	cmove  %rdi,%rcx
    2ab9:	48 8b 50 08          	mov    0x8(%rax),%rdx
    2abd:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    2ac1:	48 8b 17             	mov    (%rdi),%rdx
    2ac4:	49 b8 00 00 00 00 00 	movabs $0x28000000000000,%r8
    2acb:	00 28 00 
    2ace:	4c 39 c2             	cmp    %r8,%rdx
    2ad1:	48 89 bd 88 fb ff ff 	mov    %rdi,-0x478(%rbp)
    2ad8:	0f 82 0c 00 00 00    	jb     0x2aea
    2ade:	48 89 95 d0 fb ff ff 	mov    %rdx,-0x430(%rbp)
    2ae5:	e9 4a 00 00 00       	jmp    0x2b34
    2aea:	48 8b 50 60          	mov    0x60(%rax),%rdx
    2aee:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    2af5:	48 89 c6             	mov    %rax,%rsi
    2af8:	48 89 95 c8 fb ff ff 	mov    %rdx,-0x438(%rbp)
    2aff:	48 89 ca             	mov    %rcx,%rdx
    2b02:	48 8b 8d c8 fb ff ff 	mov    -0x438(%rbp),%rcx
    2b09:	e8 d2 d5 ff ff       	call   0xe0
    2b0e:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    2b15:	31 d2                	xor    %edx,%edx
    2b17:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    2b1b:	48 83 f8 00          	cmp    $0x0,%rax
    2b1f:	0f 8f 08 00 00 00    	jg     0x2b2d
    2b25:	49 89 c4             	mov    %rax,%r12
    2b28:	e9 3e 46 00 00       	jmp    0x716b
    2b2d:	48 89 85 d0 fb ff ff 	mov    %rax,-0x430(%rbp)
    2b34:	48 8b 85 d0 fb ff ff 	mov    -0x430(%rbp),%rax
    2b3b:	48 89 c1             	mov    %rax,%rcx
    2b3e:	48 83 c1 28          	add    $0x28,%rcx
    2b42:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    2b49:	00 28 00 
    2b4c:	48 29 d1             	sub    %rdx,%rcx
    2b4f:	48 8b 95 88 fb ff ff 	mov    -0x478(%rbp),%rdx
    2b56:	48 89 0a             	mov    %rcx,(%rdx)
    2b59:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    2b60:	ff 00 00 
    2b63:	48 21 c8             	and    %rcx,%rax
    2b66:	31 c9                	xor    %ecx,%ecx
    2b68:	48 8b 95 70 fb ff ff 	mov    -0x490(%rbp),%rdx
    2b6f:	48 89 10             	mov    %rdx,(%rax)
    2b72:	48 8b b5 68 fb ff ff 	mov    -0x498(%rbp),%rsi
    2b79:	48 89 70 08          	mov    %rsi,0x8(%rax)
    2b7d:	48 89 48 10          	mov    %rcx,0x10(%rax)
    2b81:	48 89 48 18          	mov    %rcx,0x18(%rax)
    2b85:	48 89 48 20          	mov    %rcx,0x20(%rax)
    2b89:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    2b90:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    2b94:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    2b9a:	4c 01 c7             	add    %r8,%rdi
    2b9d:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    2ba1:	48 89 85 d0 fb ff ff 	mov    %rax,-0x430(%rbp)
    2ba8:	b8 01 00 00 00       	mov    $0x1,%eax
    2bad:	48 89 85 88 fb ff ff 	mov    %rax,-0x478(%rbp)
    2bb4:	31 c0                	xor    %eax,%eax
    2bb6:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    2bbd:	e9 9f 01 00 00       	jmp    0x2d61
    2bc2:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    2bc9:	48 8b 48 10          	mov    0x10(%rax),%rcx
    2bcd:	48 8b 50 18          	mov    0x18(%rax),%rdx
    2bd1:	48 89 d6             	mov    %rdx,%rsi
    2bd4:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    2bd9:	bf 40 00 00 00       	mov    $0x40,%edi
    2bde:	48 29 f7             	sub    %rsi,%rdi
    2be1:	48 89 8d c0 fb ff ff 	mov    %rcx,-0x440(%rbp)
    2be8:	4c 8b 85 60 fb ff ff 	mov    -0x4a0(%rbp),%r8
    2bef:	48 89 f9             	mov    %rdi,%rcx
    2bf2:	49 d3 e8             	shr    %cl,%r8
    2bf5:	31 c9                	xor    %ecx,%ecx
    2bf7:	48 39 ce             	cmp    %rcx,%rsi
    2bfa:	be 00 00 00 00       	mov    $0x0,%esi
    2bff:	40 0f 94 c6          	sete   %sil
    2c03:	48 85 f6             	test   %rsi,%rsi
    2c06:	49 0f 44 c8          	cmove  %r8,%rcx
    2c0a:	be 01 00 00 00       	mov    $0x1,%esi
    2c0f:	48 89 cf             	mov    %rcx,%rdi
    2c12:	48 01 f7             	add    %rsi,%rdi
    2c15:	48 21 d7             	and    %rdx,%rdi
    2c18:	ba 28 00 00 00       	mov    $0x28,%edx
    2c1d:	48 0f af ca          	imul   %rdx,%rcx
    2c21:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    2c28:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
    2c2c:	49 8b 48 10          	mov    0x10(%r8),%rcx
    2c30:	48 85 c9             	test   %rcx,%rcx
    2c33:	0f 84 af 00 00 00    	je     0x2ce8
    2c39:	49 8b 08             	mov    (%r8),%rcx
    2c3c:	4d 8b 48 08          	mov    0x8(%r8),%r9
    2c40:	4c 8b 95 70 fb ff ff 	mov    -0x490(%rbp),%r10
    2c47:	49 39 ca             	cmp    %rcx,%r10
    2c4a:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    2c50:	41 0f 94 c3          	sete   %r11b
    2c54:	48 8b 8d 68 fb ff ff 	mov    -0x498(%rbp),%rcx
    2c5b:	4c 39 c9             	cmp    %r9,%rcx
    2c5e:	ba 00 00 00 00       	mov    $0x0,%edx
    2c63:	0f 94 c2             	sete   %dl
    2c66:	49 21 d3             	and    %rdx,%r11
    2c69:	4d 85 db             	test   %r11,%r11
    2c6c:	0f 84 0c 00 00 00    	je     0x2c7e
    2c72:	4c 89 85 d0 fb ff ff 	mov    %r8,-0x430(%rbp)
    2c79:	e9 53 00 00 00       	jmp    0x2cd1
    2c7e:	ba 28 00 00 00       	mov    $0x28,%edx
    2c83:	48 0f af fa          	imul   %rdx,%rdi
    2c87:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    2c8e:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    2c92:	49 8b 50 10          	mov    0x10(%r8),%rdx
    2c96:	48 85 d2             	test   %rdx,%rdx
    2c99:	0f 84 49 00 00 00    	je     0x2ce8
    2c9f:	49 8b 10             	mov    (%r8),%rdx
    2ca2:	49 8b 78 08          	mov    0x8(%r8),%rdi
    2ca6:	49 39 d2             	cmp    %rdx,%r10
    2ca9:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    2caf:	41 0f 94 c1          	sete   %r9b
    2cb3:	48 39 f9             	cmp    %rdi,%rcx
    2cb6:	ba 00 00 00 00       	mov    $0x0,%edx
    2cbb:	0f 94 c2             	sete   %dl
    2cbe:	49 21 d1             	and    %rdx,%r9
    2cc1:	4d 85 c9             	test   %r9,%r9
    2cc4:	0f 84 1e 00 00 00    	je     0x2ce8
    2cca:	4c 89 85 d0 fb ff ff 	mov    %r8,-0x430(%rbp)
    2cd1:	31 c0                	xor    %eax,%eax
    2cd3:	48 89 85 88 fb ff ff 	mov    %rax,-0x478(%rbp)
    2cda:	31 c0                	xor    %eax,%eax
    2cdc:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    2ce3:	e9 79 00 00 00       	jmp    0x2d61
    2ce8:	48 8d 85 80 fe ff ff 	lea    -0x180(%rbp),%rax
    2cef:	48 89 c1             	mov    %rax,%rcx
    2cf2:	48 8b 95 70 fb ff ff 	mov    -0x490(%rbp),%rdx
    2cf9:	48 89 11             	mov    %rdx,(%rcx)
    2cfc:	48 8b 95 68 fb ff ff 	mov    -0x498(%rbp),%rdx
    2d03:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    2d07:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    2d0e:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    2d15:	48 89 ca             	mov    %rcx,%rdx
    2d18:	e8 d3 d3 ff ff       	call   0xf0
    2d1d:	48 83 f8 00          	cmp    $0x0,%rax
    2d21:	0f 8d 08 00 00 00    	jge    0x2d2f
    2d27:	49 89 c4             	mov    %rax,%r12
    2d2a:	e9 3c 44 00 00       	jmp    0x716b
    2d2f:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    2d36:	48 8b 11             	mov    (%rcx),%rdx
    2d39:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    2d3d:	48 83 e6 01          	and    $0x1,%rsi
    2d41:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    2d45:	48 89 85 d0 fb ff ff 	mov    %rax,-0x430(%rbp)
    2d4c:	b8 01 00 00 00       	mov    $0x1,%eax
    2d51:	48 89 85 88 fb ff ff 	mov    %rax,-0x478(%rbp)
    2d58:	31 c0                	xor    %eax,%eax
    2d5a:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    2d61:	48 8b 85 88 fb ff ff 	mov    -0x478(%rbp),%rax
    2d68:	48 85 c0             	test   %rax,%rax
    2d6b:	0f 84 6b 00 00 00    	je     0x2ddc
    2d71:	48 8b 85 d0 fb ff ff 	mov    -0x430(%rbp),%rax
    2d78:	48 8b 8d 78 fb ff ff 	mov    -0x488(%rbp),%rcx
    2d7f:	48 89 48 10          	mov    %rcx,0x10(%rax)
    2d83:	31 d2                	xor    %edx,%edx
    2d85:	48 39 d1             	cmp    %rdx,%rcx
    2d88:	be 00 00 00 00       	mov    $0x0,%esi
    2d8d:	40 0f 95 c6          	setne  %sil
    2d91:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    2d95:	48 09 f7             	or     %rsi,%rdi
    2d98:	48 0f be ff          	movsbq %dil,%rdi
    2d9c:	40 88 78 20          	mov    %dil,0x20(%rax)
    2da0:	48 8b b5 58 fb ff ff 	mov    -0x4a8(%rbp),%rsi
    2da7:	48 89 70 18          	mov    %rsi,0x18(%rax)
    2dab:	4c 8b 85 50 fb ff ff 	mov    -0x4b0(%rbp),%r8
    2db2:	49 39 d0             	cmp    %rdx,%r8
    2db5:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    2dbb:	41 0f 95 c1          	setne  %r9b
    2dbf:	40 0f b6 ff          	movzbl %dil,%edi
    2dc3:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    2dc9:	4d 85 c9             	test   %r9,%r9
    2dcc:	4c 0f 44 d2          	cmove  %rdx,%r10
    2dd0:	4c 09 d7             	or     %r10,%rdi
    2dd3:	40 88 78 20          	mov    %dil,0x20(%rax)
    2dd7:	e9 91 00 00 00       	jmp    0x2e6d
    2ddc:	48 8b 85 d0 fb ff ff 	mov    -0x430(%rbp),%rax
    2de3:	48 8b 48 10          	mov    0x10(%rax),%rcx
    2de7:	48 8b 95 78 fb ff ff 	mov    -0x488(%rbp),%rdx
    2dee:	48 01 d1             	add    %rdx,%rcx
    2df1:	48 89 48 10          	mov    %rcx,0x10(%rax)
    2df5:	31 d2                	xor    %edx,%edx
    2df7:	48 39 d1             	cmp    %rdx,%rcx
    2dfa:	b9 00 00 00 00       	mov    $0x0,%ecx
    2dff:	0f 95 c1             	setne  %cl
    2e02:	0f b6 70 20          	movzbl 0x20(%rax),%esi
    2e06:	48 09 ce             	or     %rcx,%rsi
    2e09:	48 0f be f6          	movsbq %sil,%rsi
    2e0d:	40 88 70 20          	mov    %sil,0x20(%rax)
    2e11:	48 8b 48 18          	mov    0x18(%rax),%rcx
    2e15:	40 0f b6 f6          	movzbl %sil,%esi
    2e19:	48 89 f7             	mov    %rsi,%rdi
    2e1c:	48 83 e7 02          	and    $0x2,%rdi
    2e20:	48 39 d7             	cmp    %rdx,%rdi
    2e23:	bf 00 00 00 00       	mov    $0x0,%edi
    2e28:	40 0f 95 c7          	setne  %dil
    2e2c:	45 31 c0             	xor    %r8d,%r8d
    2e2f:	48 85 ff             	test   %rdi,%rdi
    2e32:	49 0f 44 c8          	cmove  %r8,%rcx
    2e36:	4c 8b 85 50 fb ff ff 	mov    -0x4b0(%rbp),%r8
    2e3d:	4c 01 c7             	add    %r8,%rdi
    2e40:	4c 8b 85 58 fb ff ff 	mov    -0x4a8(%rbp),%r8
    2e47:	4c 01 c1             	add    %r8,%rcx
    2e4a:	48 89 48 18          	mov    %rcx,0x18(%rax)
    2e4e:	48 39 d7             	cmp    %rdx,%rdi
    2e51:	bf 00 00 00 00       	mov    $0x0,%edi
    2e56:	40 0f 95 c7          	setne  %dil
    2e5a:	b9 02 00 00 00       	mov    $0x2,%ecx
    2e5f:	48 85 ff             	test   %rdi,%rdi
    2e62:	48 0f 44 ca          	cmove  %rdx,%rcx
    2e66:	48 09 ce             	or     %rcx,%rsi
    2e69:	40 88 70 20          	mov    %sil,0x20(%rax)
    2e6d:	48 8b 85 80 fb ff ff 	mov    -0x480(%rbp),%rax
    2e74:	48 89 85 d0 fb ff ff 	mov    %rax,-0x430(%rbp)
    2e7b:	e9 c9 41 00 00       	jmp    0x7049
    2e80:	48 8b 85 38 fc ff ff 	mov    -0x3c8(%rbp),%rax
    2e87:	48 85 c0             	test   %rax,%rax
    2e8a:	0f 84 18 23 00 00    	je     0x51a8
    2e90:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
    2e97:	82 28 52 
    2e9a:	31 c9                	xor    %ecx,%ecx
    2e9c:	48 8b 95 18 fc ff ff 	mov    -0x3e8(%rbp),%rdx
    2ea3:	48 8b b5 e0 fb ff ff 	mov    -0x420(%rbp),%rsi
    2eaa:	48 89 d7             	mov    %rdx,%rdi
    2ead:	48 21 f7             	and    %rsi,%rdi
    2eb0:	48 85 ff             	test   %rdi,%rdi
    2eb3:	0f 85 21 10 00 00    	jne    0x3eda
    2eb9:	48 8b bd 08 fc ff ff 	mov    -0x3f8(%rbp),%rdi
    2ec0:	48 89 bd 38 fc ff ff 	mov    %rdi,-0x3c8(%rbp)
    2ec7:	31 ff                	xor    %edi,%edi
    2ec9:	48 89 bd 80 fb ff ff 	mov    %rdi,-0x480(%rbp)
    2ed0:	31 ff                	xor    %edi,%edi
    2ed2:	48 89 bd 58 fb ff ff 	mov    %rdi,-0x4a8(%rbp)
    2ed9:	48 89 85 50 fb ff ff 	mov    %rax,-0x4b0(%rbp)
    2ee0:	31 ff                	xor    %edi,%edi
    2ee2:	48 89 bd 78 fb ff ff 	mov    %rdi,-0x488(%rbp)
    2ee9:	48 89 8d 88 fb ff ff 	mov    %rcx,-0x478(%rbp)
    2ef0:	31 ff                	xor    %edi,%edi
    2ef2:	48 89 bd c8 fb ff ff 	mov    %rdi,-0x438(%rbp)
    2ef9:	31 ff                	xor    %edi,%edi
    2efb:	48 89 bd 68 fb ff ff 	mov    %rdi,-0x498(%rbp)
    2f02:	31 ff                	xor    %edi,%edi
    2f04:	48 89 bd 70 fb ff ff 	mov    %rdi,-0x490(%rbp)
    2f0b:	48 8b 85 38 fc ff ff 	mov    -0x3c8(%rbp),%rax
    2f12:	48 8b 8d f8 fb ff ff 	mov    -0x408(%rbp),%rcx
    2f19:	48 39 c8             	cmp    %rcx,%rax
    2f1c:	0f 8c 75 00 00 00    	jl     0x2f97
    2f22:	48 8b 95 70 fb ff ff 	mov    -0x490(%rbp),%rdx
    2f29:	48 89 95 c0 fb ff ff 	mov    %rdx,-0x440(%rbp)
    2f30:	48 8b 95 68 fb ff ff 	mov    -0x498(%rbp),%rdx
    2f37:	48 89 95 60 fb ff ff 	mov    %rdx,-0x4a0(%rbp)
    2f3e:	48 8b 95 78 fb ff ff 	mov    -0x488(%rbp),%rdx
    2f45:	48 89 95 b8 fb ff ff 	mov    %rdx,-0x448(%rbp)
    2f4c:	48 8b 95 80 fb ff ff 	mov    -0x480(%rbp),%rdx
    2f53:	48 89 95 b0 fb ff ff 	mov    %rdx,-0x450(%rbp)
    2f5a:	48 8b 95 58 fb ff ff 	mov    -0x4a8(%rbp),%rdx
    2f61:	48 89 95 a8 fb ff ff 	mov    %rdx,-0x458(%rbp)
    2f68:	48 8b 95 50 fb ff ff 	mov    -0x4b0(%rbp),%rdx
    2f6f:	48 89 95 a0 fb ff ff 	mov    %rdx,-0x460(%rbp)
    2f76:	48 8b 95 88 fb ff ff 	mov    -0x478(%rbp),%rdx
    2f7d:	48 89 95 98 fb ff ff 	mov    %rdx,-0x468(%rbp)
    2f84:	48 8b 95 c8 fb ff ff 	mov    -0x438(%rbp),%rdx
    2f8b:	48 89 95 90 fb ff ff 	mov    %rdx,-0x470(%rbp)
    2f92:	e9 28 1e 00 00       	jmp    0x4dbf
    2f97:	48 8b 95 e0 fb ff ff 	mov    -0x420(%rbp),%rdx
    2f9e:	48 85 d2             	test   %rdx,%rdx
    2fa1:	0f 84 08 00 00 00    	je     0x2faf
    2fa7:	48 89 c6             	mov    %rax,%rsi
    2faa:	e9 11 00 00 00       	jmp    0x2fc0
    2faf:	48 8b bd 30 fc ff ff 	mov    -0x3d0(%rbp),%rdi
    2fb6:	4c 8d 04 87          	lea    (%rdi,%rax,4),%r8
    2fba:	45 8b 08             	mov    (%r8),%r9d
    2fbd:	4c 89 ce             	mov    %r9,%rsi
    2fc0:	48 8b 85 d8 fb ff ff 	mov    -0x428(%rbp),%rax
    2fc7:	48 8d 0c b0          	lea    (%rax,%rsi,4),%rcx
    2fcb:	48 89 f2             	mov    %rsi,%rdx
    2fce:	48 c1 ea 06          	shr    $0x6,%rdx
    2fd2:	48 8b bd 20 fc ff ff 	mov    -0x3e0(%rbp),%rdi
    2fd9:	4c 8d 04 d7          	lea    (%rdi,%rdx,8),%r8
    2fdd:	48 8b 95 10 fc ff ff 	mov    -0x3f0(%rbp),%rdx
    2fe4:	4c 8b 8d 98 fc ff ff 	mov    -0x368(%rbp),%r9
    2feb:	4d 89 ca             	mov    %r9,%r10
    2fee:	48 85 d2             	test   %rdx,%rdx
    2ff1:	4d 0f 44 d0          	cmove  %r8,%r10
    2ff5:	4d 8b 02             	mov    (%r10),%r8
    2ff8:	49 89 f2             	mov    %rsi,%r10
    2ffb:	49 83 e2 3f          	and    $0x3f,%r10
    2fff:	48 89 8d 20 fb ff ff 	mov    %rcx,-0x4e0(%rbp)
    3006:	4c 89 d1             	mov    %r10,%rcx
    3009:	49 d3 e8             	shr    %cl,%r8
    300c:	b9 01 00 00 00       	mov    $0x1,%ecx
    3011:	49 21 c8             	and    %rcx,%r8
    3014:	45 31 d2             	xor    %r10d,%r10d
    3017:	4d 39 d0             	cmp    %r10,%r8
    301a:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    3020:	41 0f 94 c0          	sete   %r8b
    3024:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    302a:	48 89 d7             	mov    %rdx,%rdi
    302d:	4c 31 df             	xor    %r11,%rdi
    3030:	49 21 f8             	and    %rdi,%r8
    3033:	48 8b bd e8 fb ff ff 	mov    -0x418(%rbp),%rdi
    303a:	4c 8d 1c b7          	lea    (%rdi,%rsi,4),%r11
    303e:	48 89 f2             	mov    %rsi,%rdx
    3041:	48 c1 ea 06          	shr    $0x6,%rdx
    3045:	48 8b 85 00 fc ff ff 	mov    -0x400(%rbp),%rax
    304c:	48 8d 3c d0          	lea    (%rax,%rdx,8),%rdi
    3050:	48 8b 95 f0 fb ff ff 	mov    -0x410(%rbp),%rdx
    3057:	4c 89 c8             	mov    %r9,%rax
    305a:	48 85 d2             	test   %rdx,%rdx
    305d:	48 0f 44 c7          	cmove  %rdi,%rax
    3061:	48 8b 38             	mov    (%rax),%rdi
    3064:	48 83 e6 3f          	and    $0x3f,%rsi
    3068:	48 89 f1             	mov    %rsi,%rcx
    306b:	48 d3 ef             	shr    %cl,%rdi
    306e:	b8 01 00 00 00       	mov    $0x1,%eax
    3073:	48 21 c7             	and    %rax,%rdi
    3076:	4c 39 d7             	cmp    %r10,%rdi
    3079:	bf 00 00 00 00       	mov    $0x0,%edi
    307e:	40 0f 94 c7          	sete   %dil
    3082:	b9 01 00 00 00       	mov    $0x1,%ecx
    3087:	48 89 d6             	mov    %rdx,%rsi
    308a:	48 31 ce             	xor    %rcx,%rsi
    308d:	48 21 f7             	and    %rsi,%rdi
    3090:	4d 85 c0             	test   %r8,%r8
    3093:	48 89 bd 28 fb ff ff 	mov    %rdi,-0x4d8(%rbp)
    309a:	4c 89 9d 38 fb ff ff 	mov    %r11,-0x4c8(%rbp)
    30a1:	0f 85 fb 0d 00 00    	jne    0x3ea2
    30a7:	48 8b 8d 20 fb ff ff 	mov    -0x4e0(%rbp),%rcx
    30ae:	48 63 31             	movslq (%rcx),%rsi
    30b1:	48 8b 8d 50 fc ff ff 	mov    -0x3b0(%rbp),%rcx
    30b8:	48 85 c9             	test   %rcx,%rcx
    30bb:	48 89 b5 40 fb ff ff 	mov    %rsi,-0x4c0(%rbp)
    30c2:	0f 84 47 01 00 00    	je     0x320f
    30c8:	48 be 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rsi
    30cf:	79 37 9e 
    30d2:	48 8b bd 40 fb ff ff 	mov    -0x4c0(%rbp),%rdi
    30d9:	49 89 fb             	mov    %rdi,%r11
    30dc:	49 c1 eb 2b          	shr    $0x2b,%r11
    30e0:	48 89 fa             	mov    %rdi,%rdx
    30e3:	48 c1 ea 2c          	shr    $0x2c,%rdx
    30e7:	49 31 d3             	xor    %rdx,%r11
    30ea:	48 89 fa             	mov    %rdi,%rdx
    30ed:	4c 31 da             	xor    %r11,%rdx
    30f0:	48 0f af d6          	imul   %rsi,%rdx
    30f4:	48 89 d6             	mov    %rdx,%rsi
    30f7:	48 c1 ee 1e          	shr    $0x1e,%rsi
    30fb:	49 89 d3             	mov    %rdx,%r11
    30fe:	49 31 f3             	xor    %rsi,%r11
    3101:	48 be b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rsi
    3108:	47 58 bf 
    310b:	4c 0f af de          	imul   %rsi,%r11
    310f:	4c 89 de             	mov    %r11,%rsi
    3112:	48 c1 ee 1b          	shr    $0x1b,%rsi
    3116:	49 31 f3             	xor    %rsi,%r11
    3119:	48 be eb 11 31 13 bb 	movabs $0x94d049bb133111eb,%rsi
    3120:	49 d0 94 
    3123:	4c 0f af de          	imul   %rsi,%r11
    3127:	4c 89 de             	mov    %r11,%rsi
    312a:	48 c1 ee 1f          	shr    $0x1f,%rsi
    312e:	49 31 f3             	xor    %rsi,%r11
    3131:	be 40 00 00 00       	mov    $0x40,%esi
    3136:	48 29 ce             	sub    %rcx,%rsi
    3139:	48 89 f1             	mov    %rsi,%rcx
    313c:	49 d3 eb             	shr    %cl,%r11
    313f:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
    3143:	4c 89 d9             	mov    %r11,%rcx
    3146:	48 89 f7             	mov    %rsi,%rdi
    3149:	48 d3 ef             	shr    %cl,%rdi
    314c:	48 21 c7             	and    %rax,%rdi
    314f:	48 85 ff             	test   %rdi,%rdi
    3152:	0f 84 b7 00 00 00    	je     0x320f
    3158:	48 8d 8d e0 fd ff ff 	lea    -0x220(%rbp),%rcx
    315f:	48 89 cf             	mov    %rcx,%rdi
    3162:	48 8b 8d 20 fb ff ff 	mov    -0x4e0(%rbp),%rcx
    3169:	48 63 31             	movslq (%rcx),%rsi
    316c:	31 c9                	xor    %ecx,%ecx
    316e:	48 89 0f             	mov    %rcx,(%rdi)
    3171:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3175:	4c 89 47 10          	mov    %r8,0x10(%rdi)
    3179:	48 8b 8d 38 fb ff ff 	mov    -0x4c8(%rbp),%rcx
    3180:	48 63 31             	movslq (%rcx),%rsi
    3183:	45 31 c0             	xor    %r8d,%r8d
    3186:	4c 89 47 18          	mov    %r8,0x18(%rdi)
    318a:	48 89 77 20          	mov    %rsi,0x20(%rdi)
    318e:	48 8b b5 28 fb ff ff 	mov    -0x4d8(%rbp),%rsi
    3195:	48 89 77 28          	mov    %rsi,0x28(%rdi)
    3199:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    319f:	48 8b b5 50 fc ff ff 	mov    -0x3b0(%rbp),%rsi
    31a6:	48 89 f1             	mov    %rsi,%rcx
    31a9:	49 d3 e0             	shl    %cl,%r8
    31ac:	4d 01 d8             	add    %r11,%r8
    31af:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    31b4:	41 bb 02 00 00 00    	mov    $0x2,%r11d
    31ba:	48 89 bd 20 fb ff ff 	mov    %rdi,-0x4e0(%rbp)
    31c1:	4c 89 cf             	mov    %r9,%rdi
    31c4:	48 89 ce             	mov    %rcx,%rsi
    31c7:	48 89 95 10 fb ff ff 	mov    %rdx,-0x4f0(%rbp)
    31ce:	48 8b 95 50 fc ff ff 	mov    -0x3b0(%rbp),%rdx
    31d5:	4c 89 c1             	mov    %r8,%rcx
    31d8:	4c 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%r8
    31df:	4c 8b 8d 20 fb ff ff 	mov    -0x4e0(%rbp),%r9
    31e6:	4c 89 1c 24          	mov    %r11,(%rsp)
    31ea:	e8 e1 ce ff ff       	call   0xd0
    31ef:	48 83 f8 00          	cmp    $0x0,%rax
    31f3:	0f 8d 11 00 00 00    	jge    0x320a
    31f9:	b8 80 00 00 00       	mov    $0x80,%eax
    31fe:	48 89 85 48 fb ff ff 	mov    %rax,-0x4b8(%rbp)
    3205:	e9 40 3f 00 00       	jmp    0x714a
    320a:	e9 93 0c 00 00       	jmp    0x3ea2
    320f:	49 83 fd 05          	cmp    $0x5,%r13
    3213:	0f 85 d1 00 00 00    	jne    0x32ea
    3219:	48 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%rax
    3220:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    3227:	48 89 c2             	mov    %rax,%rdx
    322a:	48 29 ca             	sub    %rcx,%rdx
    322d:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    3234:	48 39 f2             	cmp    %rsi,%rdx
    3237:	bf 00 00 00 00       	mov    $0x0,%edi
    323c:	40 0f 92 c7          	setb   %dil
    3240:	45 31 c0             	xor    %r8d,%r8d
    3243:	48 85 ff             	test   %rdi,%rdi
    3246:	49 0f 44 d0          	cmove  %r8,%rdx
    324a:	49 89 d1             	mov    %rdx,%r9
    324d:	49 c1 e9 06          	shr    $0x6,%r9
    3251:	48 83 e2 3f          	and    $0x3f,%rdx
    3255:	4c 8b 95 70 fc ff ff 	mov    -0x390(%rbp),%r10
    325c:	4f 8d 1c ca          	lea    (%r10,%r9,8),%r11
    3260:	49 8b 03             	mov    (%r11),%rax
    3263:	48 89 d1             	mov    %rdx,%rcx
    3266:	48 d3 e8             	shr    %cl,%rax
    3269:	b9 01 00 00 00       	mov    $0x1,%ecx
    326e:	48 21 c8             	and    %rcx,%rax
    3271:	48 21 f8             	and    %rdi,%rax
    3274:	48 8b bd 48 fc ff ff 	mov    -0x3b8(%rbp),%rdi
    327b:	4e 8d 1c cf          	lea    (%rdi,%r9,8),%r11
    327f:	49 8b 3b             	mov    (%r11),%rdi
    3282:	48 89 d1             	mov    %rdx,%rcx
    3285:	48 d3 ef             	shr    %cl,%rdi
    3288:	b9 01 00 00 00       	mov    $0x1,%ecx
    328d:	48 21 cf             	and    %rcx,%rdi
    3290:	4c 8b 9d 58 fc ff ff 	mov    -0x3a8(%rbp),%r11
    3297:	4b 8d 34 cb          	lea    (%r11,%r9,8),%rsi
    329b:	4c 8b 0e             	mov    (%rsi),%r9
    329e:	48 89 d1             	mov    %rdx,%rcx
    32a1:	49 d3 e9             	shr    %cl,%r9
    32a4:	b9 01 00 00 00       	mov    $0x1,%ecx
    32a9:	49 21 c9             	and    %rcx,%r9
    32ac:	48 8d 95 c0 fd ff ff 	lea    -0x240(%rbp),%rdx
    32b3:	48 89 d6             	mov    %rdx,%rsi
    32b6:	49 c1 e1 20          	shl    $0x20,%r9
    32ba:	48 8b 95 40 fb ff ff 	mov    -0x4c0(%rbp),%rdx
    32c1:	48 89 16             	mov    %rdx,(%rsi)
    32c4:	4c 89 4e 08          	mov    %r9,0x8(%rsi)
    32c8:	48 89 7e 10          	mov    %rdi,0x10(%rsi)
    32cc:	4c 39 c0             	cmp    %r8,%rax
    32cf:	b8 00 00 00 00       	mov    $0x0,%eax
    32d4:	0f 95 c0             	setne  %al
    32d7:	48 85 c0             	test   %rax,%rax
    32da:	49 0f 44 f0          	cmove  %r8,%rsi
    32de:	48 89 b5 20 fb ff ff 	mov    %rsi,-0x4e0(%rbp)
    32e5:	e9 0c 04 00 00       	jmp    0x36f6
    32ea:	49 83 fd 01          	cmp    $0x1,%r13
    32ee:	0f 85 09 03 00 00    	jne    0x35fd
    32f4:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    32fb:	79 37 9e 
    32fe:	48 8b 8d 40 fb ff ff 	mov    -0x4c0(%rbp),%rcx
    3305:	48 89 ca             	mov    %rcx,%rdx
    3308:	48 c1 ea 2b          	shr    $0x2b,%rdx
    330c:	48 89 ce             	mov    %rcx,%rsi
    330f:	48 c1 ee 2c          	shr    $0x2c,%rsi
    3313:	48 31 f2             	xor    %rsi,%rdx
    3316:	48 89 ce             	mov    %rcx,%rsi
    3319:	48 31 d6             	xor    %rdx,%rsi
    331c:	48 0f af f0          	imul   %rax,%rsi
    3320:	48 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%rax
    3327:	48 85 c0             	test   %rax,%rax
    332a:	48 89 b5 10 fb ff ff 	mov    %rsi,-0x4f0(%rbp)
    3331:	0f 84 10 01 00 00    	je     0x3447
    3337:	ba 40 00 00 00       	mov    $0x40,%edx
    333c:	48 8b bd 88 fc ff ff 	mov    -0x378(%rbp),%rdi
    3343:	48 29 fa             	sub    %rdi,%rdx
    3346:	48 89 d1             	mov    %rdx,%rcx
    3349:	49 89 f0             	mov    %rsi,%r8
    334c:	49 d3 e8             	shr    %cl,%r8
    334f:	31 c9                	xor    %ecx,%ecx
    3351:	48 39 cf             	cmp    %rcx,%rdi
    3354:	ba 00 00 00 00       	mov    $0x0,%edx
    3359:	0f 94 c2             	sete   %dl
    335c:	48 85 d2             	test   %rdx,%rdx
    335f:	49 0f 44 c8          	cmove  %r8,%rcx
    3363:	49 8d 14 cf          	lea    (%r15,%rcx,8),%rdx
    3367:	48 8b 0a             	mov    (%rdx),%rcx
    336a:	48 89 f2             	mov    %rsi,%rdx
    336d:	48 c1 ea 20          	shr    $0x20,%rdx
    3371:	49 89 f0             	mov    %rsi,%r8
    3374:	49 31 d0             	xor    %rdx,%r8
    3377:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    337c:	49 21 d0             	and    %rdx,%r8
    337f:	4c 89 c2             	mov    %r8,%rdx
    3382:	48 83 e2 3f          	and    $0x3f,%rdx
    3386:	48 89 8d 30 fb ff ff 	mov    %rcx,-0x4d0(%rbp)
    338d:	41 b9 01 00 00 00    	mov    $0x1,%r9d
    3393:	48 89 d1             	mov    %rdx,%rcx
    3396:	4d 89 ca             	mov    %r9,%r10
    3399:	49 d3 e2             	shl    %cl,%r10
    339c:	4c 89 c1             	mov    %r8,%rcx
    339f:	48 c1 e9 06          	shr    $0x6,%rcx
    33a3:	48 83 e1 3f          	and    $0x3f,%rcx
    33a7:	48 89 8d 18 fb ff ff 	mov    %rcx,-0x4e8(%rbp)
    33ae:	48 8b 95 18 fb ff ff 	mov    -0x4e8(%rbp),%rdx
    33b5:	48 89 d1             	mov    %rdx,%rcx
    33b8:	4d 89 cb             	mov    %r9,%r11
    33bb:	49 d3 e3             	shl    %cl,%r11
    33be:	4d 09 da             	or     %r11,%r10
    33c1:	4c 89 c1             	mov    %r8,%rcx
    33c4:	48 c1 e9 0c          	shr    $0xc,%rcx
    33c8:	48 83 e1 3f          	and    $0x3f,%rcx
    33cc:	48 89 8d 18 fb ff ff 	mov    %rcx,-0x4e8(%rbp)
    33d3:	48 8b 95 18 fb ff ff 	mov    -0x4e8(%rbp),%rdx
    33da:	48 89 d1             	mov    %rdx,%rcx
    33dd:	4d 89 cb             	mov    %r9,%r11
    33e0:	49 d3 e3             	shl    %cl,%r11
    33e3:	4d 09 da             	or     %r11,%r10
    33e6:	49 c1 e8 12          	shr    $0x12,%r8
    33ea:	49 83 e0 3f          	and    $0x3f,%r8
    33ee:	4c 89 c1             	mov    %r8,%rcx
    33f1:	4c 89 ca             	mov    %r9,%rdx
    33f4:	48 d3 e2             	shl    %cl,%rdx
    33f7:	49 09 d2             	or     %rdx,%r10
    33fa:	48 8b 8d 30 fb ff ff 	mov    -0x4d0(%rbp),%rcx
    3401:	4c 21 d1             	and    %r10,%rcx
    3404:	4c 39 d1             	cmp    %r10,%rcx
    3407:	b9 00 00 00 00       	mov    $0x0,%ecx
    340c:	0f 94 c1             	sete   %cl
    340f:	ba 01 00 00 00       	mov    $0x1,%edx
    3414:	49 b8 00 00 00 00 01 	movabs $0x100000000,%r8
    341b:	00 00 00 
    341e:	48 85 c9             	test   %rcx,%rcx
    3421:	49 0f 44 d0          	cmove  %r8,%rdx
    3425:	4c 8b 43 08          	mov    0x8(%rbx),%r8
    3429:	49 01 d0             	add    %rdx,%r8
    342c:	4c 89 43 08          	mov    %r8,0x8(%rbx)
    3430:	48 85 c9             	test   %rcx,%rcx
    3433:	0f 85 f3 00 00 00    	jne    0x352c
    3439:	31 c9                	xor    %ecx,%ecx
    343b:	48 89 8d 20 fb ff ff 	mov    %rcx,-0x4e0(%rbp)
    3442:	e9 b1 01 00 00       	jmp    0x35f8
    3447:	b8 40 00 00 00       	mov    $0x40,%eax
    344c:	48 8b 8d 88 fc ff ff 	mov    -0x378(%rbp),%rcx
    3453:	48 29 c8             	sub    %rcx,%rax
    3456:	48 8b 95 10 fb ff ff 	mov    -0x4f0(%rbp),%rdx
    345d:	48 89 c1             	mov    %rax,%rcx
    3460:	48 89 d6             	mov    %rdx,%rsi
    3463:	48 d3 ee             	shr    %cl,%rsi
    3466:	31 c0                	xor    %eax,%eax
    3468:	48 8b 8d 88 fc ff ff 	mov    -0x378(%rbp),%rcx
    346f:	48 39 c1             	cmp    %rax,%rcx
    3472:	bf 00 00 00 00       	mov    $0x0,%edi
    3477:	40 0f 94 c7          	sete   %dil
    347b:	48 85 ff             	test   %rdi,%rdi
    347e:	48 0f 44 c6          	cmove  %rsi,%rax
    3482:	49 8d 34 c7          	lea    (%r15,%rax,8),%rsi
    3486:	48 8b 06             	mov    (%rsi),%rax
    3489:	48 89 d6             	mov    %rdx,%rsi
    348c:	48 c1 ee 20          	shr    $0x20,%rsi
    3490:	48 89 d7             	mov    %rdx,%rdi
    3493:	48 31 f7             	xor    %rsi,%rdi
    3496:	be ff ff ff ff       	mov    $0xffffffff,%esi
    349b:	48 21 f7             	and    %rsi,%rdi
    349e:	48 89 fe             	mov    %rdi,%rsi
    34a1:	48 83 e6 3f          	and    $0x3f,%rsi
    34a5:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    34ab:	48 89 f1             	mov    %rsi,%rcx
    34ae:	4d 89 c1             	mov    %r8,%r9
    34b1:	49 d3 e1             	shl    %cl,%r9
    34b4:	48 89 f9             	mov    %rdi,%rcx
    34b7:	48 c1 e9 06          	shr    $0x6,%rcx
    34bb:	48 83 e1 3f          	and    $0x3f,%rcx
    34bf:	48 89 8d 30 fb ff ff 	mov    %rcx,-0x4d0(%rbp)
    34c6:	48 8b b5 30 fb ff ff 	mov    -0x4d0(%rbp),%rsi
    34cd:	48 89 f1             	mov    %rsi,%rcx
    34d0:	4d 89 c2             	mov    %r8,%r10
    34d3:	49 d3 e2             	shl    %cl,%r10
    34d6:	4d 09 d1             	or     %r10,%r9
    34d9:	48 89 f9             	mov    %rdi,%rcx
    34dc:	48 c1 e9 0c          	shr    $0xc,%rcx
    34e0:	48 83 e1 3f          	and    $0x3f,%rcx
    34e4:	48 89 8d 30 fb ff ff 	mov    %rcx,-0x4d0(%rbp)
    34eb:	48 8b b5 30 fb ff ff 	mov    -0x4d0(%rbp),%rsi
    34f2:	48 89 f1             	mov    %rsi,%rcx
    34f5:	4d 89 c2             	mov    %r8,%r10
    34f8:	49 d3 e2             	shl    %cl,%r10
    34fb:	4d 09 d1             	or     %r10,%r9
    34fe:	48 c1 ef 12          	shr    $0x12,%rdi
    3502:	48 83 e7 3f          	and    $0x3f,%rdi
    3506:	48 89 f9             	mov    %rdi,%rcx
    3509:	4c 89 c6             	mov    %r8,%rsi
    350c:	48 d3 e6             	shl    %cl,%rsi
    350f:	49 09 f1             	or     %rsi,%r9
    3512:	4c 21 c8             	and    %r9,%rax
    3515:	4c 39 c8             	cmp    %r9,%rax
    3518:	0f 84 0e 00 00 00    	je     0x352c
    351e:	31 c0                	xor    %eax,%eax
    3520:	48 89 85 20 fb ff ff 	mov    %rax,-0x4e0(%rbp)
    3527:	e9 cc 00 00 00       	jmp    0x35f8
    352c:	b8 40 00 00 00       	mov    $0x40,%eax
    3531:	48 8b 8d 78 fc ff ff 	mov    -0x388(%rbp),%rcx
    3538:	48 29 c8             	sub    %rcx,%rax
    353b:	48 8b 95 10 fb ff ff 	mov    -0x4f0(%rbp),%rdx
    3542:	48 89 c1             	mov    %rax,%rcx
    3545:	48 89 d6             	mov    %rdx,%rsi
    3548:	48 d3 ee             	shr    %cl,%rsi
    354b:	31 c0                	xor    %eax,%eax
    354d:	48 8b 8d 78 fc ff ff 	mov    -0x388(%rbp),%rcx
    3554:	48 39 c1             	cmp    %rax,%rcx
    3557:	bf 00 00 00 00       	mov    $0x0,%edi
    355c:	40 0f 94 c7          	sete   %dil
    3560:	48 85 ff             	test   %rdi,%rdi
    3563:	48 0f 44 c6          	cmove  %rsi,%rax
    3567:	48 8b b5 70 fc ff ff 	mov    -0x390(%rbp),%rsi
    356e:	48 8d 3c c6          	lea    (%rsi,%rax,8),%rdi
    3572:	48 8b 07             	mov    (%rdi),%rax
    3575:	48 bf ff ff ff ff ff 	movabs $0xffffffffffff,%rdi
    357c:	ff 00 00 
    357f:	49 89 c0             	mov    %rax,%r8
    3582:	49 21 f8             	and    %rdi,%r8
    3585:	31 ff                	xor    %edi,%edi
    3587:	49 39 f8             	cmp    %rdi,%r8
    358a:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    3590:	41 0f 94 c1          	sete   %r9b
    3594:	49 89 d2             	mov    %rdx,%r10
    3597:	49 c1 ea 20          	shr    $0x20,%r10
    359b:	4c 31 d2             	xor    %r10,%rdx
    359e:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
    35a4:	4c 21 d2             	and    %r10,%rdx
    35a7:	48 83 e2 0f          	and    $0xf,%rdx
    35ab:	48 83 c2 30          	add    $0x30,%rdx
    35af:	48 89 d1             	mov    %rdx,%rcx
    35b2:	48 d3 e8             	shr    %cl,%rax
    35b5:	48 83 e0 01          	and    $0x1,%rax
    35b9:	48 83 f8 00          	cmp    $0x0,%rax
    35bd:	b8 00 00 00 00       	mov    $0x0,%eax
    35c2:	0f 95 c0             	setne  %al
    35c5:	b9 01 00 00 00       	mov    $0x1,%ecx
    35ca:	48 31 c8             	xor    %rcx,%rax
    35cd:	49 09 c1             	or     %rax,%r9
    35d0:	b8 01 00 00 00       	mov    $0x1,%eax
    35d5:	49 29 c0             	sub    %rax,%r8
    35d8:	b9 18 00 00 00       	mov    $0x18,%ecx
    35dd:	4c 0f af c1          	imul   %rcx,%r8
    35e1:	4c 89 f1             	mov    %r14,%rcx
    35e4:	4c 01 c1             	add    %r8,%rcx
    35e7:	48 89 fa             	mov    %rdi,%rdx
    35ea:	4d 85 c9             	test   %r9,%r9
    35ed:	48 0f 44 d1          	cmove  %rcx,%rdx
    35f1:	48 89 95 20 fb ff ff 	mov    %rdx,-0x4e0(%rbp)
    35f8:	e9 f9 00 00 00       	jmp    0x36f6
    35fd:	48 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%rax
    3604:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    360b:	48 89 c2             	mov    %rax,%rdx
    360e:	48 29 ca             	sub    %rcx,%rdx
    3611:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    3618:	48 39 f2             	cmp    %rsi,%rdx
    361b:	0f 82 0e 00 00 00    	jb     0x362f
    3621:	31 ff                	xor    %edi,%edi
    3623:	48 89 bd 20 fb ff ff 	mov    %rdi,-0x4e0(%rbp)
    362a:	e9 c7 00 00 00       	jmp    0x36f6
    362f:	49 83 fd 02          	cmp    $0x2,%r13
    3633:	48 89 95 10 fb ff ff 	mov    %rdx,-0x4f0(%rbp)
    363a:	0f 85 6a 00 00 00    	jne    0x36aa
    3640:	48 89 d7             	mov    %rdx,%rdi
    3643:	48 c1 ef 06          	shr    $0x6,%rdi
    3647:	4c 8b 85 70 fc ff ff 	mov    -0x390(%rbp),%r8
    364e:	4d 8d 0c f8          	lea    (%r8,%rdi,8),%r9
    3652:	49 8b 39             	mov    (%r9),%rdi
    3655:	49 89 d1             	mov    %rdx,%r9
    3658:	49 83 e1 3f          	and    $0x3f,%r9
    365c:	4c 89 c9             	mov    %r9,%rcx
    365f:	48 d3 ef             	shr    %cl,%rdi
    3662:	b9 01 00 00 00       	mov    $0x1,%ecx
    3667:	48 21 cf             	and    %rcx,%rdi
    366a:	45 31 c9             	xor    %r9d,%r9d
    366d:	4c 39 cf             	cmp    %r9,%rdi
    3670:	bf 00 00 00 00       	mov    $0x0,%edi
    3675:	40 0f 95 c7          	setne  %dil
    3679:	41 ba 10 00 00 00    	mov    $0x10,%r10d
    367f:	49 89 d3             	mov    %rdx,%r11
    3682:	4d 0f af da          	imul   %r10,%r11
    3686:	4c 8b 95 80 fc ff ff 	mov    -0x380(%rbp),%r10
    368d:	4c 89 d2             	mov    %r10,%rdx
    3690:	4c 01 da             	add    %r11,%rdx
    3693:	48 83 ea 08          	sub    $0x8,%rdx
    3697:	48 85 ff             	test   %rdi,%rdi
    369a:	49 0f 44 d1          	cmove  %r9,%rdx
    369e:	48 89 95 20 fb ff ff 	mov    %rdx,-0x4e0(%rbp)
    36a5:	e9 4c 00 00 00       	jmp    0x36f6
    36aa:	48 8b 85 70 fc ff ff 	mov    -0x390(%rbp),%rax
    36b1:	48 8b 8d 10 fb ff ff 	mov    -0x4f0(%rbp),%rcx
    36b8:	48 8d 14 88          	lea    (%rax,%rcx,4),%rdx
    36bc:	8b 0a                	mov    (%rdx),%ecx
    36be:	ba 01 00 00 00       	mov    $0x1,%edx
    36c3:	48 89 ce             	mov    %rcx,%rsi
    36c6:	48 29 d6             	sub    %rdx,%rsi
    36c9:	bf 18 00 00 00       	mov    $0x18,%edi
    36ce:	48 0f af f7          	imul   %rdi,%rsi
    36d2:	4c 89 f7             	mov    %r14,%rdi
    36d5:	48 01 f7             	add    %rsi,%rdi
    36d8:	31 f6                	xor    %esi,%esi
    36da:	48 39 f1             	cmp    %rsi,%rcx
    36dd:	b9 00 00 00 00       	mov    $0x0,%ecx
    36e2:	0f 94 c1             	sete   %cl
    36e5:	49 89 f0             	mov    %rsi,%r8
    36e8:	48 85 c9             	test   %rcx,%rcx
    36eb:	4c 0f 44 c7          	cmove  %rdi,%r8
    36ef:	4c 89 85 20 fb ff ff 	mov    %r8,-0x4e0(%rbp)
    36f6:	49 83 fd 01          	cmp    $0x1,%r13
    36fa:	be 00 00 00 00       	mov    $0x0,%esi
    36ff:	40 0f 95 c6          	setne  %sil
    3703:	31 ff                	xor    %edi,%edi
    3705:	48 8b 85 68 fb ff ff 	mov    -0x498(%rbp),%rax
    370c:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    3713:	48 8b 85 80 fb ff ff 	mov    -0x480(%rbp),%rax
    371a:	48 89 85 30 fb ff ff 	mov    %rax,-0x4d0(%rbp)
    3721:	48 8b 85 58 fb ff ff 	mov    -0x4a8(%rbp),%rax
    3728:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    372f:	48 8b 85 50 fb ff ff 	mov    -0x4b0(%rbp),%rax
    3736:	48 89 85 08 fb ff ff 	mov    %rax,-0x4f8(%rbp)
    373d:	48 8b 85 70 fb ff ff 	mov    -0x490(%rbp),%rax
    3744:	48 89 85 00 fb ff ff 	mov    %rax,-0x500(%rbp)
    374b:	48 8b 85 78 fb ff ff 	mov    -0x488(%rbp),%rax
    3752:	48 89 85 f8 fa ff ff 	mov    %rax,-0x508(%rbp)
    3759:	48 8b 85 88 fb ff ff 	mov    -0x478(%rbp),%rax
    3760:	48 89 85 f0 fa ff ff 	mov    %rax,-0x510(%rbp)
    3767:	48 8b 85 c8 fb ff ff 	mov    -0x438(%rbp),%rax
    376e:	48 89 85 e8 fa ff ff 	mov    %rax,-0x518(%rbp)
    3775:	48 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%rax
    377c:	48 85 c0             	test   %rax,%rax
    377f:	0f 85 75 00 00 00    	jne    0x37fa
    3785:	48 8b 8d 10 fb ff ff 	mov    -0x4f0(%rbp),%rcx
    378c:	48 89 8d 68 fb ff ff 	mov    %rcx,-0x498(%rbp)
    3793:	48 8b 8d 30 fb ff ff 	mov    -0x4d0(%rbp),%rcx
    379a:	48 89 8d 80 fb ff ff 	mov    %rcx,-0x480(%rbp)
    37a1:	48 8b 8d 18 fb ff ff 	mov    -0x4e8(%rbp),%rcx
    37a8:	48 89 8d 58 fb ff ff 	mov    %rcx,-0x4a8(%rbp)
    37af:	48 8b 8d 08 fb ff ff 	mov    -0x4f8(%rbp),%rcx
    37b6:	48 89 8d 50 fb ff ff 	mov    %rcx,-0x4b0(%rbp)
    37bd:	48 8b 8d 00 fb ff ff 	mov    -0x500(%rbp),%rcx
    37c4:	48 89 8d 70 fb ff ff 	mov    %rcx,-0x490(%rbp)
    37cb:	48 8b 8d f8 fa ff ff 	mov    -0x508(%rbp),%rcx
    37d2:	48 89 8d 78 fb ff ff 	mov    %rcx,-0x488(%rbp)
    37d9:	48 8b 8d f0 fa ff ff 	mov    -0x510(%rbp),%rcx
    37e0:	48 89 8d 88 fb ff ff 	mov    %rcx,-0x478(%rbp)
    37e7:	48 8b 8d e8 fa ff ff 	mov    -0x518(%rbp),%rcx
    37ee:	48 89 8d c8 fb ff ff 	mov    %rcx,-0x438(%rbp)
    37f5:	e9 a3 06 00 00       	jmp    0x3e9d
    37fa:	48 8b 48 08          	mov    0x8(%rax),%rcx
    37fe:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    3803:	49 89 c8             	mov    %rcx,%r8
    3806:	49 21 d0             	and    %rdx,%r8
    3809:	ba 01 00 00 00       	mov    $0x1,%edx
    380e:	4d 89 c1             	mov    %r8,%r9
    3811:	49 29 d1             	sub    %rdx,%r9
    3814:	41 ba 18 00 00 00    	mov    $0x18,%r10d
    381a:	4d 0f af ca          	imul   %r10,%r9
    381e:	4d 89 f2             	mov    %r14,%r10
    3821:	4d 01 ca             	add    %r9,%r10
    3824:	45 31 c9             	xor    %r9d,%r9d
    3827:	4d 39 c8             	cmp    %r9,%r8
    382a:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    3830:	41 0f 94 c0          	sete   %r8b
    3834:	4d 89 cb             	mov    %r9,%r11
    3837:	4d 85 c0             	test   %r8,%r8
    383a:	4d 0f 44 da          	cmove  %r10,%r11
    383e:	4c 8b 00             	mov    (%rax),%r8
    3841:	4c 8b 95 40 fb ff ff 	mov    -0x4c0(%rbp),%r10
    3848:	4d 39 c2             	cmp    %r8,%r10
    384b:	b8 00 00 00 00       	mov    $0x0,%eax
    3850:	0f 94 c0             	sete   %al
    3853:	48 09 f0             	or     %rsi,%rax
    3856:	49 89 f8             	mov    %rdi,%r8
    3859:	49 01 d0             	add    %rdx,%r8
    385c:	48 85 c0             	test   %rax,%rax
    385f:	0f 85 0c 00 00 00    	jne    0x3871
    3865:	4c 89 9d 20 fb ff ff 	mov    %r11,-0x4e0(%rbp)
    386c:	e9 04 ff ff ff       	jmp    0x3775
    3871:	48 8b 03             	mov    (%rbx),%rax
    3874:	48 39 c7             	cmp    %rax,%rdi
    3877:	0f 8d 0f 00 00 00    	jge    0x388c
    387d:	4c 89 9d 20 fb ff ff 	mov    %r11,-0x4e0(%rbp)
    3884:	4c 89 c7             	mov    %r8,%rdi
    3887:	e9 e9 fe ff ff       	jmp    0x3775
    388c:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    3893:	48 8b 70 18          	mov    0x18(%rax),%rsi
    3897:	48 85 f6             	test   %rsi,%rsi
    389a:	48 89 8d 40 fb ff ff 	mov    %rcx,-0x4c0(%rbp)
    38a1:	4c 89 85 e0 fa ff ff 	mov    %r8,-0x520(%rbp)
    38a8:	0f 84 0c 00 00 00    	je     0x38ba
    38ae:	0f b6 3e             	movzbl (%rsi),%edi
    38b1:	48 85 ff             	test   %rdi,%rdi
    38b4:	0f 85 06 06 00 00    	jne    0x3ec0
    38ba:	48 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%rax
    38c1:	48 8b 48 10          	mov    0x10(%rax),%rcx
    38c5:	48 8b 95 40 fb ff ff 	mov    -0x4c0(%rbp),%rdx
    38cc:	48 89 d6             	mov    %rdx,%rsi
    38cf:	48 c1 ee 20          	shr    $0x20,%rsi
    38d3:	48 83 e6 01          	and    $0x1,%rsi
    38d7:	48 83 fe 00          	cmp    $0x0,%rsi
    38db:	be 00 00 00 00       	mov    $0x0,%esi
    38e0:	40 0f 95 c6          	setne  %sil
    38e4:	48 8b bd e0 fa ff ff 	mov    -0x520(%rbp),%rdi
    38eb:	48 89 3b             	mov    %rdi,(%rbx)
    38ee:	4c 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%r8
    38f5:	4d 89 c1             	mov    %r8,%r9
    38f8:	49 83 c1 01          	add    $0x1,%r9
    38fc:	48 63 c9             	movslq %ecx,%rcx
    38ff:	45 31 d2             	xor    %r10d,%r10d
    3902:	48 85 f6             	test   %rsi,%rsi
    3905:	4c 0f 44 d1          	cmove  %rcx,%r10
    3909:	48 8b 8d 30 fb ff ff 	mov    -0x4d0(%rbp),%rcx
    3910:	4c 39 d1             	cmp    %r10,%rcx
    3913:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    3919:	41 0f 94 c3          	sete   %r11b
    391d:	48 8b 85 18 fb ff ff 	mov    -0x4e8(%rbp),%rax
    3924:	48 39 f0             	cmp    %rsi,%rax
    3927:	ba 00 00 00 00       	mov    $0x0,%edx
    392c:	0f 94 c2             	sete   %dl
    392f:	49 21 d3             	and    %rdx,%r11
    3932:	4d 85 db             	test   %r11,%r11
    3935:	48 89 b5 d8 fa ff ff 	mov    %rsi,-0x528(%rbp)
    393c:	4c 89 8d d0 fa ff ff 	mov    %r9,-0x530(%rbp)
    3943:	4c 89 95 c8 fa ff ff 	mov    %r10,-0x538(%rbp)
    394a:	0f 84 83 00 00 00    	je     0x39d3
    3950:	48 8b 95 f8 fa ff ff 	mov    -0x508(%rbp),%rdx
    3957:	49 89 d3             	mov    %rdx,%r11
    395a:	49 83 c3 01          	add    $0x1,%r11
    395e:	be 01 00 00 00       	mov    $0x1,%esi
    3963:	4c 8b 95 38 fb ff ff 	mov    -0x4c8(%rbp),%r10
    396a:	4d 63 0a             	movslq (%r10),%r9
    396d:	4c 8b 95 28 fb ff ff 	mov    -0x4d8(%rbp),%r10
    3974:	4c 89 d2             	mov    %r10,%rdx
    3977:	48 31 f2             	xor    %rsi,%rdx
    397a:	31 f6                	xor    %esi,%esi
    397c:	48 85 d2             	test   %rdx,%rdx
    397f:	4c 0f 44 ce          	cmove  %rsi,%r9
    3983:	48 8b b5 e8 fa ff ff 	mov    -0x518(%rbp),%rsi
    398a:	49 89 f2             	mov    %rsi,%r10
    398d:	49 01 d2             	add    %rdx,%r10
    3990:	48 8b 95 f0 fa ff ff 	mov    -0x510(%rbp),%rdx
    3997:	48 89 d6             	mov    %rdx,%rsi
    399a:	4c 01 ce             	add    %r9,%rsi
    399d:	48 89 8d 80 fb ff ff 	mov    %rcx,-0x480(%rbp)
    39a4:	48 89 85 58 fb ff ff 	mov    %rax,-0x4a8(%rbp)
    39ab:	4c 8b 8d 08 fb ff ff 	mov    -0x4f8(%rbp),%r9
    39b2:	4c 89 8d 50 fb ff ff 	mov    %r9,-0x4b0(%rbp)
    39b9:	4c 89 9d 78 fb ff ff 	mov    %r11,-0x488(%rbp)
    39c0:	48 89 b5 88 fb ff ff 	mov    %rsi,-0x478(%rbp)
    39c7:	4c 89 95 c8 fb ff ff 	mov    %r10,-0x438(%rbp)
    39ce:	e9 b0 04 00 00       	jmp    0x3e83
    39d3:	48 8b 85 00 fb ff ff 	mov    -0x500(%rbp),%rax
    39da:	48 85 c0             	test   %rax,%rax
    39dd:	0f 84 04 04 00 00    	je     0x3de7
    39e3:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    39ea:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    39ee:	48 85 d2             	test   %rdx,%rdx
    39f1:	0f 84 40 01 00 00    	je     0x3b37
    39f7:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    39fb:	be 40 00 00 00       	mov    $0x40,%esi
    3a00:	48 29 d6             	sub    %rdx,%rsi
    3a03:	48 8b bd 08 fb ff ff 	mov    -0x4f8(%rbp),%rdi
    3a0a:	48 89 f1             	mov    %rsi,%rcx
    3a0d:	49 89 f8             	mov    %rdi,%r8
    3a10:	49 d3 e8             	shr    %cl,%r8
    3a13:	31 c9                	xor    %ecx,%ecx
    3a15:	48 39 ca             	cmp    %rcx,%rdx
    3a18:	ba 00 00 00 00       	mov    $0x0,%edx
    3a1d:	0f 94 c2             	sete   %dl
    3a20:	48 85 d2             	test   %rdx,%rdx
    3a23:	49 0f 44 c8          	cmove  %r8,%rcx
    3a27:	48 8b 95 90 fc ff ff 	mov    -0x370(%rbp),%rdx
    3a2e:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    3a32:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    3a36:	49 8b 30             	mov    (%r8),%rsi
    3a39:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    3a40:	00 28 00 
    3a43:	4c 39 ce             	cmp    %r9,%rsi
    3a46:	4c 89 85 c0 fa ff ff 	mov    %r8,-0x540(%rbp)
    3a4d:	0f 82 0c 00 00 00    	jb     0x3a5f
    3a53:	48 89 b5 b8 fa ff ff 	mov    %rsi,-0x548(%rbp)
    3a5a:	e9 4a 00 00 00       	jmp    0x3aa9
    3a5f:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    3a63:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    3a6a:	48 89 b5 b0 fa ff ff 	mov    %rsi,-0x550(%rbp)
    3a71:	48 89 d6             	mov    %rdx,%rsi
    3a74:	48 89 ca             	mov    %rcx,%rdx
    3a77:	48 8b 8d b0 fa ff ff 	mov    -0x550(%rbp),%rcx
    3a7e:	e8 5d c6 ff ff       	call   0xe0
    3a83:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    3a8a:	31 d2                	xor    %edx,%edx
    3a8c:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    3a90:	48 83 f8 00          	cmp    $0x0,%rax
    3a94:	0f 8f 08 00 00 00    	jg     0x3aa2
    3a9a:	49 89 c4             	mov    %rax,%r12
    3a9d:	e9 c9 36 00 00       	jmp    0x716b
    3aa2:	48 89 85 b8 fa ff ff 	mov    %rax,-0x548(%rbp)
    3aa9:	48 8b 85 b8 fa ff ff 	mov    -0x548(%rbp),%rax
    3ab0:	48 89 c1             	mov    %rax,%rcx
    3ab3:	48 83 c1 28          	add    $0x28,%rcx
    3ab7:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    3abe:	00 28 00 
    3ac1:	48 29 d1             	sub    %rdx,%rcx
    3ac4:	48 8b 95 c0 fa ff ff 	mov    -0x540(%rbp),%rdx
    3acb:	48 89 0a             	mov    %rcx,(%rdx)
    3ace:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    3ad5:	ff 00 00 
    3ad8:	48 21 c8             	and    %rcx,%rax
    3adb:	31 c9                	xor    %ecx,%ecx
    3add:	48 8b 95 30 fb ff ff 	mov    -0x4d0(%rbp),%rdx
    3ae4:	48 89 10             	mov    %rdx,(%rax)
    3ae7:	48 8b b5 18 fb ff ff 	mov    -0x4e8(%rbp),%rsi
    3aee:	48 89 70 08          	mov    %rsi,0x8(%rax)
    3af2:	48 89 48 10          	mov    %rcx,0x10(%rax)
    3af6:	48 89 48 18          	mov    %rcx,0x18(%rax)
    3afa:	48 89 48 20          	mov    %rcx,0x20(%rax)
    3afe:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    3b05:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    3b09:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    3b0f:	4c 01 c7             	add    %r8,%rdi
    3b12:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    3b16:	48 89 85 b8 fa ff ff 	mov    %rax,-0x548(%rbp)
    3b1d:	b8 01 00 00 00       	mov    $0x1,%eax
    3b22:	48 89 85 c0 fa ff ff 	mov    %rax,-0x540(%rbp)
    3b29:	31 c0                	xor    %eax,%eax
    3b2b:	48 89 85 b0 fa ff ff 	mov    %rax,-0x550(%rbp)
    3b32:	e9 a2 01 00 00       	jmp    0x3cd9
    3b37:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    3b3e:	48 8b 48 10          	mov    0x10(%rax),%rcx
    3b42:	48 8b 50 18          	mov    0x18(%rax),%rdx
    3b46:	48 89 d6             	mov    %rdx,%rsi
    3b49:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    3b4e:	bf 40 00 00 00       	mov    $0x40,%edi
    3b53:	48 29 f7             	sub    %rsi,%rdi
    3b56:	48 89 8d a8 fa ff ff 	mov    %rcx,-0x558(%rbp)
    3b5d:	4c 8b 85 08 fb ff ff 	mov    -0x4f8(%rbp),%r8
    3b64:	48 89 f9             	mov    %rdi,%rcx
    3b67:	4d 89 c1             	mov    %r8,%r9
    3b6a:	49 d3 e9             	shr    %cl,%r9
    3b6d:	31 c9                	xor    %ecx,%ecx
    3b6f:	48 39 ce             	cmp    %rcx,%rsi
    3b72:	be 00 00 00 00       	mov    $0x0,%esi
    3b77:	40 0f 94 c6          	sete   %sil
    3b7b:	48 85 f6             	test   %rsi,%rsi
    3b7e:	49 0f 44 c9          	cmove  %r9,%rcx
    3b82:	be 01 00 00 00       	mov    $0x1,%esi
    3b87:	48 89 cf             	mov    %rcx,%rdi
    3b8a:	48 01 f7             	add    %rsi,%rdi
    3b8d:	48 21 d7             	and    %rdx,%rdi
    3b90:	ba 28 00 00 00       	mov    $0x28,%edx
    3b95:	48 0f af ca          	imul   %rdx,%rcx
    3b99:	48 8b 95 a8 fa ff ff 	mov    -0x558(%rbp),%rdx
    3ba0:	4c 8d 0c 0a          	lea    (%rdx,%rcx,1),%r9
    3ba4:	49 8b 49 10          	mov    0x10(%r9),%rcx
    3ba8:	48 85 c9             	test   %rcx,%rcx
    3bab:	0f 84 af 00 00 00    	je     0x3c60
    3bb1:	49 8b 09             	mov    (%r9),%rcx
    3bb4:	4d 8b 51 08          	mov    0x8(%r9),%r10
    3bb8:	4c 8b 9d 30 fb ff ff 	mov    -0x4d0(%rbp),%r11
    3bbf:	49 39 cb             	cmp    %rcx,%r11
    3bc2:	ba 00 00 00 00       	mov    $0x0,%edx
    3bc7:	0f 94 c2             	sete   %dl
    3bca:	48 8b 8d 18 fb ff ff 	mov    -0x4e8(%rbp),%rcx
    3bd1:	4c 39 d1             	cmp    %r10,%rcx
    3bd4:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    3bda:	41 0f 94 c0          	sete   %r8b
    3bde:	4c 21 c2             	and    %r8,%rdx
    3be1:	48 85 d2             	test   %rdx,%rdx
    3be4:	0f 84 0c 00 00 00    	je     0x3bf6
    3bea:	4c 89 8d b8 fa ff ff 	mov    %r9,-0x548(%rbp)
    3bf1:	e9 53 00 00 00       	jmp    0x3c49
    3bf6:	ba 28 00 00 00       	mov    $0x28,%edx
    3bfb:	48 0f af fa          	imul   %rdx,%rdi
    3bff:	48 8b 95 a8 fa ff ff 	mov    -0x558(%rbp),%rdx
    3c06:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    3c0a:	49 8b 50 10          	mov    0x10(%r8),%rdx
    3c0e:	48 85 d2             	test   %rdx,%rdx
    3c11:	0f 84 49 00 00 00    	je     0x3c60
    3c17:	49 8b 10             	mov    (%r8),%rdx
    3c1a:	49 8b 78 08          	mov    0x8(%r8),%rdi
    3c1e:	49 39 d3             	cmp    %rdx,%r11
    3c21:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    3c27:	41 0f 94 c1          	sete   %r9b
    3c2b:	48 39 f9             	cmp    %rdi,%rcx
    3c2e:	ba 00 00 00 00       	mov    $0x0,%edx
    3c33:	0f 94 c2             	sete   %dl
    3c36:	49 21 d1             	and    %rdx,%r9
    3c39:	4d 85 c9             	test   %r9,%r9
    3c3c:	0f 84 1e 00 00 00    	je     0x3c60
    3c42:	4c 89 85 b8 fa ff ff 	mov    %r8,-0x548(%rbp)
    3c49:	31 c0                	xor    %eax,%eax
    3c4b:	48 89 85 c0 fa ff ff 	mov    %rax,-0x540(%rbp)
    3c52:	31 c0                	xor    %eax,%eax
    3c54:	48 89 85 b0 fa ff ff 	mov    %rax,-0x550(%rbp)
    3c5b:	e9 79 00 00 00       	jmp    0x3cd9
    3c60:	48 8d 85 a0 fd ff ff 	lea    -0x260(%rbp),%rax
    3c67:	48 89 c1             	mov    %rax,%rcx
    3c6a:	48 8b 95 30 fb ff ff 	mov    -0x4d0(%rbp),%rdx
    3c71:	48 89 11             	mov    %rdx,(%rcx)
    3c74:	48 8b b5 18 fb ff ff 	mov    -0x4e8(%rbp),%rsi
    3c7b:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    3c7f:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    3c86:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    3c8d:	48 89 ca             	mov    %rcx,%rdx
    3c90:	e8 5b c4 ff ff       	call   0xf0
    3c95:	48 83 f8 00          	cmp    $0x0,%rax
    3c99:	0f 8d 08 00 00 00    	jge    0x3ca7
    3c9f:	49 89 c4             	mov    %rax,%r12
    3ca2:	e9 c4 34 00 00       	jmp    0x716b
    3ca7:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    3cae:	48 8b 11             	mov    (%rcx),%rdx
    3cb1:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    3cb5:	48 83 e6 01          	and    $0x1,%rsi
    3cb9:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    3cbd:	48 89 85 b8 fa ff ff 	mov    %rax,-0x548(%rbp)
    3cc4:	b8 01 00 00 00       	mov    $0x1,%eax
    3cc9:	48 89 85 c0 fa ff ff 	mov    %rax,-0x540(%rbp)
    3cd0:	31 c0                	xor    %eax,%eax
    3cd2:	48 89 85 b0 fa ff ff 	mov    %rax,-0x550(%rbp)
    3cd9:	48 8b 85 c0 fa ff ff 	mov    -0x540(%rbp),%rax
    3ce0:	48 85 c0             	test   %rax,%rax
    3ce3:	0f 84 6b 00 00 00    	je     0x3d54
    3ce9:	48 8b 85 b8 fa ff ff 	mov    -0x548(%rbp),%rax
    3cf0:	48 8b 8d f8 fa ff ff 	mov    -0x508(%rbp),%rcx
    3cf7:	48 89 48 10          	mov    %rcx,0x10(%rax)
    3cfb:	31 d2                	xor    %edx,%edx
    3cfd:	48 39 d1             	cmp    %rdx,%rcx
    3d00:	be 00 00 00 00       	mov    $0x0,%esi
    3d05:	40 0f 95 c6          	setne  %sil
    3d09:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    3d0d:	48 09 f7             	or     %rsi,%rdi
    3d10:	48 0f be ff          	movsbq %dil,%rdi
    3d14:	40 88 78 20          	mov    %dil,0x20(%rax)
    3d18:	48 8b b5 f0 fa ff ff 	mov    -0x510(%rbp),%rsi
    3d1f:	48 89 70 18          	mov    %rsi,0x18(%rax)
    3d23:	4c 8b 85 e8 fa ff ff 	mov    -0x518(%rbp),%r8
    3d2a:	49 39 d0             	cmp    %rdx,%r8
    3d2d:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    3d33:	41 0f 95 c1          	setne  %r9b
    3d37:	40 0f b6 ff          	movzbl %dil,%edi
    3d3b:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    3d41:	4d 85 c9             	test   %r9,%r9
    3d44:	4c 0f 44 d2          	cmove  %rdx,%r10
    3d48:	4c 09 d7             	or     %r10,%rdi
    3d4b:	40 88 78 20          	mov    %dil,0x20(%rax)
    3d4f:	e9 93 00 00 00       	jmp    0x3de7
    3d54:	48 8b 85 b8 fa ff ff 	mov    -0x548(%rbp),%rax
    3d5b:	48 8b 48 10          	mov    0x10(%rax),%rcx
    3d5f:	48 8b 95 f8 fa ff ff 	mov    -0x508(%rbp),%rdx
    3d66:	48 01 d1             	add    %rdx,%rcx
    3d69:	48 89 48 10          	mov    %rcx,0x10(%rax)
    3d6d:	31 f6                	xor    %esi,%esi
    3d6f:	48 39 f1             	cmp    %rsi,%rcx
    3d72:	b9 00 00 00 00       	mov    $0x0,%ecx
    3d77:	0f 95 c1             	setne  %cl
    3d7a:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    3d7e:	48 09 cf             	or     %rcx,%rdi
    3d81:	48 0f be ff          	movsbq %dil,%rdi
    3d85:	40 88 78 20          	mov    %dil,0x20(%rax)
    3d89:	48 8b 48 18          	mov    0x18(%rax),%rcx
    3d8d:	40 0f b6 ff          	movzbl %dil,%edi
    3d91:	49 89 f8             	mov    %rdi,%r8
    3d94:	49 83 e0 02          	and    $0x2,%r8
    3d98:	49 39 f0             	cmp    %rsi,%r8
    3d9b:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    3da1:	41 0f 95 c0          	setne  %r8b
    3da5:	45 31 c9             	xor    %r9d,%r9d
    3da8:	4d 85 c0             	test   %r8,%r8
    3dab:	49 0f 44 c9          	cmove  %r9,%rcx
    3daf:	4c 8b 8d e8 fa ff ff 	mov    -0x518(%rbp),%r9
    3db6:	4d 01 c8             	add    %r9,%r8
    3db9:	4c 8b 95 f0 fa ff ff 	mov    -0x510(%rbp),%r10
    3dc0:	4c 01 d1             	add    %r10,%rcx
    3dc3:	48 89 48 18          	mov    %rcx,0x18(%rax)
    3dc7:	49 39 f0             	cmp    %rsi,%r8
    3dca:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    3dd0:	41 0f 95 c0          	setne  %r8b
    3dd4:	b9 02 00 00 00       	mov    $0x2,%ecx
    3dd9:	4d 85 c0             	test   %r8,%r8
    3ddc:	48 0f 44 ce          	cmove  %rsi,%rcx
    3de0:	48 09 cf             	or     %rcx,%rdi
    3de3:	40 88 78 20          	mov    %dil,0x20(%rax)
    3de7:	b8 01 00 00 00       	mov    $0x1,%eax
    3dec:	48 8b 8d 38 fb ff ff 	mov    -0x4c8(%rbp),%rcx
    3df3:	48 63 11             	movslq (%rcx),%rdx
    3df6:	48 8b b5 28 fb ff ff 	mov    -0x4d8(%rbp),%rsi
    3dfd:	48 89 f7             	mov    %rsi,%rdi
    3e00:	48 31 c7             	xor    %rax,%rdi
    3e03:	31 c0                	xor    %eax,%eax
    3e05:	48 85 ff             	test   %rdi,%rdi
    3e08:	48 0f 44 d0          	cmove  %rax,%rdx
    3e0c:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    3e13:	79 37 9e 
    3e16:	49 b8 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%r8
    3e1d:	79 37 9e 
    3e20:	4c 8b 8d c8 fa ff ff 	mov    -0x538(%rbp),%r9
    3e27:	4d 31 c8             	xor    %r9,%r8
    3e2a:	4c 0f af c0          	imul   %rax,%r8
    3e2e:	4d 89 c2             	mov    %r8,%r10
    3e31:	49 c1 ea 1d          	shr    $0x1d,%r10
    3e35:	4d 31 d0             	xor    %r10,%r8
    3e38:	4c 8b 95 d8 fa ff ff 	mov    -0x528(%rbp),%r10
    3e3f:	4d 31 d0             	xor    %r10,%r8
    3e42:	4c 0f af c0          	imul   %rax,%r8
    3e46:	4d 89 c3             	mov    %r8,%r11
    3e49:	49 c1 eb 1d          	shr    $0x1d,%r11
    3e4d:	4d 31 d8             	xor    %r11,%r8
    3e50:	4c 0f af c0          	imul   %rax,%r8
    3e54:	4c 89 8d 80 fb ff ff 	mov    %r9,-0x480(%rbp)
    3e5b:	4c 89 95 58 fb ff ff 	mov    %r10,-0x4a8(%rbp)
    3e62:	4c 89 85 50 fb ff ff 	mov    %r8,-0x4b0(%rbp)
    3e69:	b8 01 00 00 00       	mov    $0x1,%eax
    3e6e:	48 89 85 78 fb ff ff 	mov    %rax,-0x488(%rbp)
    3e75:	48 89 95 88 fb ff ff 	mov    %rdx,-0x478(%rbp)
    3e7c:	48 89 bd c8 fb ff ff 	mov    %rdi,-0x438(%rbp)
    3e83:	48 8b 85 d0 fa ff ff 	mov    -0x530(%rbp),%rax
    3e8a:	48 89 85 68 fb ff ff 	mov    %rax,-0x498(%rbp)
    3e91:	b8 01 00 00 00       	mov    $0x1,%eax
    3e96:	48 89 85 70 fb ff ff 	mov    %rax,-0x490(%rbp)
    3e9d:	31 c0                	xor    %eax,%eax
    3e9f:	48 89 03             	mov    %rax,(%rbx)
    3ea2:	48 8b 85 38 fc ff ff 	mov    -0x3c8(%rbp),%rax
    3ea9:	b9 01 00 00 00       	mov    $0x1,%ecx
    3eae:	48 89 c2             	mov    %rax,%rdx
    3eb1:	48 01 ca             	add    %rcx,%rdx
    3eb4:	48 89 95 38 fc ff ff 	mov    %rdx,-0x3c8(%rbp)
    3ebb:	e9 4b f0 ff ff       	jmp    0x2f0b
    3ec0:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    3ec7:	e8 74 c1 ff ff       	call   0x40
    3ecc:	48 85 c0             	test   %rax,%rax
    3ecf:	0f 84 e5 f9 ff ff    	je     0x38ba
    3ed5:	e9 8a 32 00 00       	jmp    0x7164
    3eda:	48 8b 85 08 fc ff ff 	mov    -0x3f8(%rbp),%rax
    3ee1:	48 89 85 20 fb ff ff 	mov    %rax,-0x4e0(%rbp)
    3ee8:	31 c0                	xor    %eax,%eax
    3eea:	48 89 85 40 fb ff ff 	mov    %rax,-0x4c0(%rbp)
    3ef1:	31 c0                	xor    %eax,%eax
    3ef3:	48 89 85 e0 fa ff ff 	mov    %rax,-0x520(%rbp)
    3efa:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
    3f01:	82 28 52 
    3f04:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    3f0b:	31 c0                	xor    %eax,%eax
    3f0d:	48 89 85 00 fb ff ff 	mov    %rax,-0x500(%rbp)
    3f14:	31 c0                	xor    %eax,%eax
    3f16:	48 89 85 08 fb ff ff 	mov    %rax,-0x4f8(%rbp)
    3f1d:	31 c0                	xor    %eax,%eax
    3f1f:	48 89 85 30 fb ff ff 	mov    %rax,-0x4d0(%rbp)
    3f26:	31 c0                	xor    %eax,%eax
    3f28:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    3f2f:	31 c0                	xor    %eax,%eax
    3f31:	48 89 85 f8 fa ff ff 	mov    %rax,-0x508(%rbp)
    3f38:	48 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%rax
    3f3f:	48 8b 8d f8 fb ff ff 	mov    -0x408(%rbp),%rcx
    3f46:	48 39 c8             	cmp    %rcx,%rax
    3f49:	0f 8c 75 00 00 00    	jl     0x3fc4
    3f4f:	48 8b 95 18 fb ff ff 	mov    -0x4e8(%rbp),%rdx
    3f56:	48 89 95 60 fb ff ff 	mov    %rdx,-0x4a0(%rbp)
    3f5d:	48 8b 95 40 fb ff ff 	mov    -0x4c0(%rbp),%rdx
    3f64:	48 89 95 b0 fb ff ff 	mov    %rdx,-0x450(%rbp)
    3f6b:	48 8b 95 e0 fa ff ff 	mov    -0x520(%rbp),%rdx
    3f72:	48 89 95 a8 fb ff ff 	mov    %rdx,-0x458(%rbp)
    3f79:	48 8b 95 10 fb ff ff 	mov    -0x4f0(%rbp),%rdx
    3f80:	48 89 95 a0 fb ff ff 	mov    %rdx,-0x460(%rbp)
    3f87:	48 8b 95 f8 fa ff ff 	mov    -0x508(%rbp),%rdx
    3f8e:	48 89 95 c0 fb ff ff 	mov    %rdx,-0x440(%rbp)
    3f95:	48 8b 95 00 fb ff ff 	mov    -0x500(%rbp),%rdx
    3f9c:	48 89 95 b8 fb ff ff 	mov    %rdx,-0x448(%rbp)
    3fa3:	48 8b 95 08 fb ff ff 	mov    -0x4f8(%rbp),%rdx
    3faa:	48 89 95 98 fb ff ff 	mov    %rdx,-0x468(%rbp)
    3fb1:	48 8b 95 30 fb ff ff 	mov    -0x4d0(%rbp),%rdx
    3fb8:	48 89 95 90 fb ff ff 	mov    %rdx,-0x470(%rbp)
    3fbf:	e9 fb 0d 00 00       	jmp    0x4dbf
    3fc4:	48 8b 95 d8 fb ff ff 	mov    -0x428(%rbp),%rdx
    3fcb:	48 8d 34 82          	lea    (%rdx,%rax,4),%rsi
    3fcf:	48 8b bd e8 fb ff ff 	mov    -0x418(%rbp),%rdi
    3fd6:	4c 8d 04 87          	lea    (%rdi,%rax,4),%r8
    3fda:	4c 63 0e             	movslq (%rsi),%r9
    3fdd:	4c 8b 95 50 fc ff ff 	mov    -0x3b0(%rbp),%r10
    3fe4:	4d 85 d2             	test   %r10,%r10
    3fe7:	4c 89 85 e8 fa ff ff 	mov    %r8,-0x518(%rbp)
    3fee:	4c 89 8d f0 fa ff ff 	mov    %r9,-0x510(%rbp)
    3ff5:	0f 84 29 01 00 00    	je     0x4124
    3ffb:	49 bb 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%r11
    4002:	79 37 9e 
    4005:	4c 89 c8             	mov    %r9,%rax
    4008:	48 c1 e8 2b          	shr    $0x2b,%rax
    400c:	4d 89 c8             	mov    %r9,%r8
    400f:	49 c1 e8 2c          	shr    $0x2c,%r8
    4013:	4c 31 c0             	xor    %r8,%rax
    4016:	4d 89 c8             	mov    %r9,%r8
    4019:	49 31 c0             	xor    %rax,%r8
    401c:	4d 0f af c3          	imul   %r11,%r8
    4020:	4c 89 c0             	mov    %r8,%rax
    4023:	48 c1 e8 1e          	shr    $0x1e,%rax
    4027:	4d 89 c3             	mov    %r8,%r11
    402a:	49 31 c3             	xor    %rax,%r11
    402d:	48 b8 b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rax
    4034:	47 58 bf 
    4037:	4c 0f af d8          	imul   %rax,%r11
    403b:	4c 89 d8             	mov    %r11,%rax
    403e:	48 c1 e8 1b          	shr    $0x1b,%rax
    4042:	49 31 c3             	xor    %rax,%r11
    4045:	48 b8 eb 11 31 13 bb 	movabs $0x94d049bb133111eb,%rax
    404c:	49 d0 94 
    404f:	4c 0f af d8          	imul   %rax,%r11
    4053:	4c 89 d8             	mov    %r11,%rax
    4056:	48 c1 e8 1f          	shr    $0x1f,%rax
    405a:	49 31 c3             	xor    %rax,%r11
    405d:	b8 40 00 00 00       	mov    $0x40,%eax
    4062:	4c 29 d0             	sub    %r10,%rax
    4065:	48 89 c1             	mov    %rax,%rcx
    4068:	49 d3 eb             	shr    %cl,%r11
    406b:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
    406f:	4c 89 d9             	mov    %r11,%rcx
    4072:	49 89 c1             	mov    %rax,%r9
    4075:	49 d3 e9             	shr    %cl,%r9
    4078:	b9 01 00 00 00       	mov    $0x1,%ecx
    407d:	49 21 c9             	and    %rcx,%r9
    4080:	4d 85 c9             	test   %r9,%r9
    4083:	0f 84 9b 00 00 00    	je     0x4124
    4089:	4c 8d 8d 50 fe ff ff 	lea    -0x1b0(%rbp),%r9
    4090:	4c 89 c8             	mov    %r9,%rax
    4093:	4c 63 0e             	movslq (%rsi),%r9
    4096:	31 f6                	xor    %esi,%esi
    4098:	31 d2                	xor    %edx,%edx
    409a:	48 89 30             	mov    %rsi,(%rax)
    409d:	4c 89 48 08          	mov    %r9,0x8(%rax)
    40a1:	48 89 50 10          	mov    %rdx,0x10(%rax)
    40a5:	48 8b 95 e8 fa ff ff 	mov    -0x518(%rbp),%rdx
    40ac:	48 63 32             	movslq (%rdx),%rsi
    40af:	45 31 c9             	xor    %r9d,%r9d
    40b2:	31 d2                	xor    %edx,%edx
    40b4:	4c 89 48 18          	mov    %r9,0x18(%rax)
    40b8:	48 89 70 20          	mov    %rsi,0x20(%rax)
    40bc:	48 89 50 28          	mov    %rdx,0x28(%rax)
    40c0:	ba 01 00 00 00       	mov    $0x1,%edx
    40c5:	4c 89 d1             	mov    %r10,%rcx
    40c8:	48 d3 e2             	shl    %cl,%rdx
    40cb:	4c 01 da             	add    %r11,%rdx
    40ce:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    40d3:	be 02 00 00 00       	mov    $0x2,%esi
    40d8:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    40df:	48 89 ce             	mov    %rcx,%rsi
    40e2:	48 89 95 38 fb ff ff 	mov    %rdx,-0x4c8(%rbp)
    40e9:	4c 89 d2             	mov    %r10,%rdx
    40ec:	48 8b 8d 38 fb ff ff 	mov    -0x4c8(%rbp),%rcx
    40f3:	49 89 c1             	mov    %rax,%r9
    40f6:	b8 02 00 00 00       	mov    $0x2,%eax
    40fb:	48 89 04 24          	mov    %rax,(%rsp)
    40ff:	e8 cc bf ff ff       	call   0xd0
    4104:	48 83 f8 00          	cmp    $0x0,%rax
    4108:	0f 8d 11 00 00 00    	jge    0x411f
    410e:	b8 80 00 00 00       	mov    $0x80,%eax
    4113:	48 89 85 48 fb ff ff 	mov    %rax,-0x4b8(%rbp)
    411a:	e9 2b 30 00 00       	jmp    0x714a
    411f:	e9 63 0c 00 00       	jmp    0x4d87
    4124:	49 83 fd 05          	cmp    $0x5,%r13
    4128:	0f 85 d1 00 00 00    	jne    0x41ff
    412e:	48 8b 85 f0 fa ff ff 	mov    -0x510(%rbp),%rax
    4135:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    413c:	48 89 c2             	mov    %rax,%rdx
    413f:	48 29 ca             	sub    %rcx,%rdx
    4142:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    4149:	48 39 f2             	cmp    %rsi,%rdx
    414c:	bf 00 00 00 00       	mov    $0x0,%edi
    4151:	40 0f 92 c7          	setb   %dil
    4155:	45 31 c0             	xor    %r8d,%r8d
    4158:	48 85 ff             	test   %rdi,%rdi
    415b:	49 0f 44 d0          	cmove  %r8,%rdx
    415f:	49 89 d1             	mov    %rdx,%r9
    4162:	49 c1 e9 06          	shr    $0x6,%r9
    4166:	48 83 e2 3f          	and    $0x3f,%rdx
    416a:	4c 8b 95 70 fc ff ff 	mov    -0x390(%rbp),%r10
    4171:	4f 8d 1c ca          	lea    (%r10,%r9,8),%r11
    4175:	49 8b 03             	mov    (%r11),%rax
    4178:	48 89 d1             	mov    %rdx,%rcx
    417b:	48 d3 e8             	shr    %cl,%rax
    417e:	b9 01 00 00 00       	mov    $0x1,%ecx
    4183:	48 21 c8             	and    %rcx,%rax
    4186:	48 21 f8             	and    %rdi,%rax
    4189:	48 8b bd 48 fc ff ff 	mov    -0x3b8(%rbp),%rdi
    4190:	4e 8d 1c cf          	lea    (%rdi,%r9,8),%r11
    4194:	49 8b 3b             	mov    (%r11),%rdi
    4197:	48 89 d1             	mov    %rdx,%rcx
    419a:	48 d3 ef             	shr    %cl,%rdi
    419d:	b9 01 00 00 00       	mov    $0x1,%ecx
    41a2:	48 21 cf             	and    %rcx,%rdi
    41a5:	4c 8b 9d 58 fc ff ff 	mov    -0x3a8(%rbp),%r11
    41ac:	4b 8d 34 cb          	lea    (%r11,%r9,8),%rsi
    41b0:	4c 8b 0e             	mov    (%rsi),%r9
    41b3:	48 89 d1             	mov    %rdx,%rcx
    41b6:	49 d3 e9             	shr    %cl,%r9
    41b9:	b9 01 00 00 00       	mov    $0x1,%ecx
    41be:	49 21 c9             	and    %rcx,%r9
    41c1:	48 8d 95 30 fe ff ff 	lea    -0x1d0(%rbp),%rdx
    41c8:	48 89 d6             	mov    %rdx,%rsi
    41cb:	49 c1 e1 20          	shl    $0x20,%r9
    41cf:	48 8b 95 f0 fa ff ff 	mov    -0x510(%rbp),%rdx
    41d6:	48 89 16             	mov    %rdx,(%rsi)
    41d9:	4c 89 4e 08          	mov    %r9,0x8(%rsi)
    41dd:	48 89 7e 10          	mov    %rdi,0x10(%rsi)
    41e1:	4c 39 c0             	cmp    %r8,%rax
    41e4:	b8 00 00 00 00       	mov    $0x0,%eax
    41e9:	0f 95 c0             	setne  %al
    41ec:	48 85 c0             	test   %rax,%rax
    41ef:	49 0f 44 f0          	cmove  %r8,%rsi
    41f3:	48 89 b5 38 fb ff ff 	mov    %rsi,-0x4c8(%rbp)
    41fa:	e9 0c 04 00 00       	jmp    0x460b
    41ff:	49 83 fd 01          	cmp    $0x1,%r13
    4203:	0f 85 09 03 00 00    	jne    0x4512
    4209:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    4210:	79 37 9e 
    4213:	48 8b 8d f0 fa ff ff 	mov    -0x510(%rbp),%rcx
    421a:	48 89 ca             	mov    %rcx,%rdx
    421d:	48 c1 ea 2b          	shr    $0x2b,%rdx
    4221:	48 89 ce             	mov    %rcx,%rsi
    4224:	48 c1 ee 2c          	shr    $0x2c,%rsi
    4228:	48 31 f2             	xor    %rsi,%rdx
    422b:	48 89 ce             	mov    %rcx,%rsi
    422e:	48 31 d6             	xor    %rdx,%rsi
    4231:	48 0f af f0          	imul   %rax,%rsi
    4235:	48 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%rax
    423c:	48 85 c0             	test   %rax,%rax
    423f:	48 89 b5 28 fb ff ff 	mov    %rsi,-0x4d8(%rbp)
    4246:	0f 84 10 01 00 00    	je     0x435c
    424c:	ba 40 00 00 00       	mov    $0x40,%edx
    4251:	48 8b bd 88 fc ff ff 	mov    -0x378(%rbp),%rdi
    4258:	48 29 fa             	sub    %rdi,%rdx
    425b:	48 89 d1             	mov    %rdx,%rcx
    425e:	49 89 f0             	mov    %rsi,%r8
    4261:	49 d3 e8             	shr    %cl,%r8
    4264:	31 c9                	xor    %ecx,%ecx
    4266:	48 39 cf             	cmp    %rcx,%rdi
    4269:	ba 00 00 00 00       	mov    $0x0,%edx
    426e:	0f 94 c2             	sete   %dl
    4271:	48 85 d2             	test   %rdx,%rdx
    4274:	49 0f 44 c8          	cmove  %r8,%rcx
    4278:	49 8d 14 cf          	lea    (%r15,%rcx,8),%rdx
    427c:	48 8b 0a             	mov    (%rdx),%rcx
    427f:	48 89 f2             	mov    %rsi,%rdx
    4282:	48 c1 ea 20          	shr    $0x20,%rdx
    4286:	49 89 f0             	mov    %rsi,%r8
    4289:	49 31 d0             	xor    %rdx,%r8
    428c:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    4291:	49 21 d0             	and    %rdx,%r8
    4294:	4c 89 c2             	mov    %r8,%rdx
    4297:	48 83 e2 3f          	and    $0x3f,%rdx
    429b:	48 89 8d 38 fc ff ff 	mov    %rcx,-0x3c8(%rbp)
    42a2:	41 b9 01 00 00 00    	mov    $0x1,%r9d
    42a8:	48 89 d1             	mov    %rdx,%rcx
    42ab:	4d 89 ca             	mov    %r9,%r10
    42ae:	49 d3 e2             	shl    %cl,%r10
    42b1:	4c 89 c1             	mov    %r8,%rcx
    42b4:	48 c1 e9 06          	shr    $0x6,%rcx
    42b8:	48 83 e1 3f          	and    $0x3f,%rcx
    42bc:	48 89 8d 68 fb ff ff 	mov    %rcx,-0x498(%rbp)
    42c3:	48 8b 95 68 fb ff ff 	mov    -0x498(%rbp),%rdx
    42ca:	48 89 d1             	mov    %rdx,%rcx
    42cd:	4d 89 cb             	mov    %r9,%r11
    42d0:	49 d3 e3             	shl    %cl,%r11
    42d3:	4d 09 da             	or     %r11,%r10
    42d6:	4c 89 c1             	mov    %r8,%rcx
    42d9:	48 c1 e9 0c          	shr    $0xc,%rcx
    42dd:	48 83 e1 3f          	and    $0x3f,%rcx
    42e1:	48 89 8d 68 fb ff ff 	mov    %rcx,-0x498(%rbp)
    42e8:	48 8b 95 68 fb ff ff 	mov    -0x498(%rbp),%rdx
    42ef:	48 89 d1             	mov    %rdx,%rcx
    42f2:	4d 89 cb             	mov    %r9,%r11
    42f5:	49 d3 e3             	shl    %cl,%r11
    42f8:	4d 09 da             	or     %r11,%r10
    42fb:	49 c1 e8 12          	shr    $0x12,%r8
    42ff:	49 83 e0 3f          	and    $0x3f,%r8
    4303:	4c 89 c1             	mov    %r8,%rcx
    4306:	4c 89 ca             	mov    %r9,%rdx
    4309:	48 d3 e2             	shl    %cl,%rdx
    430c:	49 09 d2             	or     %rdx,%r10
    430f:	48 8b 8d 38 fc ff ff 	mov    -0x3c8(%rbp),%rcx
    4316:	4c 21 d1             	and    %r10,%rcx
    4319:	4c 39 d1             	cmp    %r10,%rcx
    431c:	b9 00 00 00 00       	mov    $0x0,%ecx
    4321:	0f 94 c1             	sete   %cl
    4324:	ba 01 00 00 00       	mov    $0x1,%edx
    4329:	49 b8 00 00 00 00 01 	movabs $0x100000000,%r8
    4330:	00 00 00 
    4333:	48 85 c9             	test   %rcx,%rcx
    4336:	49 0f 44 d0          	cmove  %r8,%rdx
    433a:	4c 8b 43 08          	mov    0x8(%rbx),%r8
    433e:	49 01 d0             	add    %rdx,%r8
    4341:	4c 89 43 08          	mov    %r8,0x8(%rbx)
    4345:	48 85 c9             	test   %rcx,%rcx
    4348:	0f 85 f3 00 00 00    	jne    0x4441
    434e:	31 c9                	xor    %ecx,%ecx
    4350:	48 89 8d 38 fb ff ff 	mov    %rcx,-0x4c8(%rbp)
    4357:	e9 b1 01 00 00       	jmp    0x450d
    435c:	b8 40 00 00 00       	mov    $0x40,%eax
    4361:	48 8b 8d 88 fc ff ff 	mov    -0x378(%rbp),%rcx
    4368:	48 29 c8             	sub    %rcx,%rax
    436b:	48 8b 95 28 fb ff ff 	mov    -0x4d8(%rbp),%rdx
    4372:	48 89 c1             	mov    %rax,%rcx
    4375:	48 89 d6             	mov    %rdx,%rsi
    4378:	48 d3 ee             	shr    %cl,%rsi
    437b:	31 c0                	xor    %eax,%eax
    437d:	48 8b 8d 88 fc ff ff 	mov    -0x378(%rbp),%rcx
    4384:	48 39 c1             	cmp    %rax,%rcx
    4387:	bf 00 00 00 00       	mov    $0x0,%edi
    438c:	40 0f 94 c7          	sete   %dil
    4390:	48 85 ff             	test   %rdi,%rdi
    4393:	48 0f 44 c6          	cmove  %rsi,%rax
    4397:	49 8d 34 c7          	lea    (%r15,%rax,8),%rsi
    439b:	48 8b 06             	mov    (%rsi),%rax
    439e:	48 89 d6             	mov    %rdx,%rsi
    43a1:	48 c1 ee 20          	shr    $0x20,%rsi
    43a5:	48 89 d7             	mov    %rdx,%rdi
    43a8:	48 31 f7             	xor    %rsi,%rdi
    43ab:	be ff ff ff ff       	mov    $0xffffffff,%esi
    43b0:	48 21 f7             	and    %rsi,%rdi
    43b3:	48 89 fe             	mov    %rdi,%rsi
    43b6:	48 83 e6 3f          	and    $0x3f,%rsi
    43ba:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    43c0:	48 89 f1             	mov    %rsi,%rcx
    43c3:	4d 89 c1             	mov    %r8,%r9
    43c6:	49 d3 e1             	shl    %cl,%r9
    43c9:	48 89 f9             	mov    %rdi,%rcx
    43cc:	48 c1 e9 06          	shr    $0x6,%rcx
    43d0:	48 83 e1 3f          	and    $0x3f,%rcx
    43d4:	48 89 8d 38 fc ff ff 	mov    %rcx,-0x3c8(%rbp)
    43db:	48 8b b5 38 fc ff ff 	mov    -0x3c8(%rbp),%rsi
    43e2:	48 89 f1             	mov    %rsi,%rcx
    43e5:	4d 89 c2             	mov    %r8,%r10
    43e8:	49 d3 e2             	shl    %cl,%r10
    43eb:	4d 09 d1             	or     %r10,%r9
    43ee:	48 89 f9             	mov    %rdi,%rcx
    43f1:	48 c1 e9 0c          	shr    $0xc,%rcx
    43f5:	48 83 e1 3f          	and    $0x3f,%rcx
    43f9:	48 89 8d 38 fc ff ff 	mov    %rcx,-0x3c8(%rbp)
    4400:	48 8b b5 38 fc ff ff 	mov    -0x3c8(%rbp),%rsi
    4407:	48 89 f1             	mov    %rsi,%rcx
    440a:	4d 89 c2             	mov    %r8,%r10
    440d:	49 d3 e2             	shl    %cl,%r10
    4410:	4d 09 d1             	or     %r10,%r9
    4413:	48 c1 ef 12          	shr    $0x12,%rdi
    4417:	48 83 e7 3f          	and    $0x3f,%rdi
    441b:	48 89 f9             	mov    %rdi,%rcx
    441e:	4c 89 c6             	mov    %r8,%rsi
    4421:	48 d3 e6             	shl    %cl,%rsi
    4424:	49 09 f1             	or     %rsi,%r9
    4427:	4c 21 c8             	and    %r9,%rax
    442a:	4c 39 c8             	cmp    %r9,%rax
    442d:	0f 84 0e 00 00 00    	je     0x4441
    4433:	31 c0                	xor    %eax,%eax
    4435:	48 89 85 38 fb ff ff 	mov    %rax,-0x4c8(%rbp)
    443c:	e9 cc 00 00 00       	jmp    0x450d
    4441:	b8 40 00 00 00       	mov    $0x40,%eax
    4446:	48 8b 8d 78 fc ff ff 	mov    -0x388(%rbp),%rcx
    444d:	48 29 c8             	sub    %rcx,%rax
    4450:	48 8b 95 28 fb ff ff 	mov    -0x4d8(%rbp),%rdx
    4457:	48 89 c1             	mov    %rax,%rcx
    445a:	48 89 d6             	mov    %rdx,%rsi
    445d:	48 d3 ee             	shr    %cl,%rsi
    4460:	31 c0                	xor    %eax,%eax
    4462:	48 8b 8d 78 fc ff ff 	mov    -0x388(%rbp),%rcx
    4469:	48 39 c1             	cmp    %rax,%rcx
    446c:	bf 00 00 00 00       	mov    $0x0,%edi
    4471:	40 0f 94 c7          	sete   %dil
    4475:	48 85 ff             	test   %rdi,%rdi
    4478:	48 0f 44 c6          	cmove  %rsi,%rax
    447c:	48 8b b5 70 fc ff ff 	mov    -0x390(%rbp),%rsi
    4483:	48 8d 3c c6          	lea    (%rsi,%rax,8),%rdi
    4487:	48 8b 07             	mov    (%rdi),%rax
    448a:	48 bf ff ff ff ff ff 	movabs $0xffffffffffff,%rdi
    4491:	ff 00 00 
    4494:	49 89 c0             	mov    %rax,%r8
    4497:	49 21 f8             	and    %rdi,%r8
    449a:	31 ff                	xor    %edi,%edi
    449c:	49 39 f8             	cmp    %rdi,%r8
    449f:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    44a5:	41 0f 94 c1          	sete   %r9b
    44a9:	49 89 d2             	mov    %rdx,%r10
    44ac:	49 c1 ea 20          	shr    $0x20,%r10
    44b0:	4c 31 d2             	xor    %r10,%rdx
    44b3:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
    44b9:	4c 21 d2             	and    %r10,%rdx
    44bc:	48 83 e2 0f          	and    $0xf,%rdx
    44c0:	48 83 c2 30          	add    $0x30,%rdx
    44c4:	48 89 d1             	mov    %rdx,%rcx
    44c7:	48 d3 e8             	shr    %cl,%rax
    44ca:	48 83 e0 01          	and    $0x1,%rax
    44ce:	48 83 f8 00          	cmp    $0x0,%rax
    44d2:	b8 00 00 00 00       	mov    $0x0,%eax
    44d7:	0f 95 c0             	setne  %al
    44da:	b9 01 00 00 00       	mov    $0x1,%ecx
    44df:	48 31 c8             	xor    %rcx,%rax
    44e2:	49 09 c1             	or     %rax,%r9
    44e5:	b8 01 00 00 00       	mov    $0x1,%eax
    44ea:	49 29 c0             	sub    %rax,%r8
    44ed:	b9 18 00 00 00       	mov    $0x18,%ecx
    44f2:	4c 0f af c1          	imul   %rcx,%r8
    44f6:	4c 89 f1             	mov    %r14,%rcx
    44f9:	4c 01 c1             	add    %r8,%rcx
    44fc:	48 89 fa             	mov    %rdi,%rdx
    44ff:	4d 85 c9             	test   %r9,%r9
    4502:	48 0f 44 d1          	cmove  %rcx,%rdx
    4506:	48 89 95 38 fb ff ff 	mov    %rdx,-0x4c8(%rbp)
    450d:	e9 f9 00 00 00       	jmp    0x460b
    4512:	48 8b 85 f0 fa ff ff 	mov    -0x510(%rbp),%rax
    4519:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    4520:	48 89 c2             	mov    %rax,%rdx
    4523:	48 29 ca             	sub    %rcx,%rdx
    4526:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    452d:	48 39 f2             	cmp    %rsi,%rdx
    4530:	0f 82 0e 00 00 00    	jb     0x4544
    4536:	31 ff                	xor    %edi,%edi
    4538:	48 89 bd 38 fb ff ff 	mov    %rdi,-0x4c8(%rbp)
    453f:	e9 c7 00 00 00       	jmp    0x460b
    4544:	49 83 fd 02          	cmp    $0x2,%r13
    4548:	48 89 95 28 fb ff ff 	mov    %rdx,-0x4d8(%rbp)
    454f:	0f 85 6a 00 00 00    	jne    0x45bf
    4555:	48 89 d7             	mov    %rdx,%rdi
    4558:	48 c1 ef 06          	shr    $0x6,%rdi
    455c:	4c 8b 85 70 fc ff ff 	mov    -0x390(%rbp),%r8
    4563:	4d 8d 0c f8          	lea    (%r8,%rdi,8),%r9
    4567:	49 8b 39             	mov    (%r9),%rdi
    456a:	49 89 d1             	mov    %rdx,%r9
    456d:	49 83 e1 3f          	and    $0x3f,%r9
    4571:	4c 89 c9             	mov    %r9,%rcx
    4574:	48 d3 ef             	shr    %cl,%rdi
    4577:	b9 01 00 00 00       	mov    $0x1,%ecx
    457c:	48 21 cf             	and    %rcx,%rdi
    457f:	45 31 c9             	xor    %r9d,%r9d
    4582:	4c 39 cf             	cmp    %r9,%rdi
    4585:	bf 00 00 00 00       	mov    $0x0,%edi
    458a:	40 0f 95 c7          	setne  %dil
    458e:	41 ba 10 00 00 00    	mov    $0x10,%r10d
    4594:	49 89 d3             	mov    %rdx,%r11
    4597:	4d 0f af da          	imul   %r10,%r11
    459b:	4c 8b 95 80 fc ff ff 	mov    -0x380(%rbp),%r10
    45a2:	4c 89 d2             	mov    %r10,%rdx
    45a5:	4c 01 da             	add    %r11,%rdx
    45a8:	48 83 ea 08          	sub    $0x8,%rdx
    45ac:	48 85 ff             	test   %rdi,%rdi
    45af:	49 0f 44 d1          	cmove  %r9,%rdx
    45b3:	48 89 95 38 fb ff ff 	mov    %rdx,-0x4c8(%rbp)
    45ba:	e9 4c 00 00 00       	jmp    0x460b
    45bf:	48 8b 85 70 fc ff ff 	mov    -0x390(%rbp),%rax
    45c6:	48 8b 8d 28 fb ff ff 	mov    -0x4d8(%rbp),%rcx
    45cd:	48 8d 14 88          	lea    (%rax,%rcx,4),%rdx
    45d1:	8b 0a                	mov    (%rdx),%ecx
    45d3:	ba 01 00 00 00       	mov    $0x1,%edx
    45d8:	48 89 ce             	mov    %rcx,%rsi
    45db:	48 29 d6             	sub    %rdx,%rsi
    45de:	bf 18 00 00 00       	mov    $0x18,%edi
    45e3:	48 0f af f7          	imul   %rdi,%rsi
    45e7:	4c 89 f7             	mov    %r14,%rdi
    45ea:	48 01 f7             	add    %rsi,%rdi
    45ed:	31 f6                	xor    %esi,%esi
    45ef:	48 39 f1             	cmp    %rsi,%rcx
    45f2:	b9 00 00 00 00       	mov    $0x0,%ecx
    45f7:	0f 94 c1             	sete   %cl
    45fa:	49 89 f0             	mov    %rsi,%r8
    45fd:	48 85 c9             	test   %rcx,%rcx
    4600:	4c 0f 44 c7          	cmove  %rdi,%r8
    4604:	4c 89 85 38 fb ff ff 	mov    %r8,-0x4c8(%rbp)
    460b:	49 83 fd 01          	cmp    $0x1,%r13
    460f:	be 00 00 00 00       	mov    $0x0,%esi
    4614:	40 0f 95 c6          	setne  %sil
    4618:	31 ff                	xor    %edi,%edi
    461a:	48 8b 85 18 fb ff ff 	mov    -0x4e8(%rbp),%rax
    4621:	48 89 85 28 fb ff ff 	mov    %rax,-0x4d8(%rbp)
    4628:	48 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%rax
    462f:	48 89 85 38 fc ff ff 	mov    %rax,-0x3c8(%rbp)
    4636:	48 8b 85 e0 fa ff ff 	mov    -0x520(%rbp),%rax
    463d:	48 89 85 68 fb ff ff 	mov    %rax,-0x498(%rbp)
    4644:	48 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%rax
    464b:	48 89 85 80 fb ff ff 	mov    %rax,-0x480(%rbp)
    4652:	48 8b 85 f8 fa ff ff 	mov    -0x508(%rbp),%rax
    4659:	48 89 85 58 fb ff ff 	mov    %rax,-0x4a8(%rbp)
    4660:	48 8b 85 00 fb ff ff 	mov    -0x500(%rbp),%rax
    4667:	48 89 85 50 fb ff ff 	mov    %rax,-0x4b0(%rbp)
    466e:	48 8b 85 08 fb ff ff 	mov    -0x4f8(%rbp),%rax
    4675:	48 89 85 70 fb ff ff 	mov    %rax,-0x490(%rbp)
    467c:	48 8b 85 30 fb ff ff 	mov    -0x4d0(%rbp),%rax
    4683:	48 89 85 78 fb ff ff 	mov    %rax,-0x488(%rbp)
    468a:	48 8b 85 38 fb ff ff 	mov    -0x4c8(%rbp),%rax
    4691:	48 85 c0             	test   %rax,%rax
    4694:	0f 85 75 00 00 00    	jne    0x470f
    469a:	48 8b 8d 28 fb ff ff 	mov    -0x4d8(%rbp),%rcx
    46a1:	48 89 8d 18 fb ff ff 	mov    %rcx,-0x4e8(%rbp)
    46a8:	48 8b 8d 38 fc ff ff 	mov    -0x3c8(%rbp),%rcx
    46af:	48 89 8d 40 fb ff ff 	mov    %rcx,-0x4c0(%rbp)
    46b6:	48 8b 8d 68 fb ff ff 	mov    -0x498(%rbp),%rcx
    46bd:	48 89 8d e0 fa ff ff 	mov    %rcx,-0x520(%rbp)
    46c4:	48 8b 8d 80 fb ff ff 	mov    -0x480(%rbp),%rcx
    46cb:	48 89 8d 10 fb ff ff 	mov    %rcx,-0x4f0(%rbp)
    46d2:	48 8b 8d 58 fb ff ff 	mov    -0x4a8(%rbp),%rcx
    46d9:	48 89 8d f8 fa ff ff 	mov    %rcx,-0x508(%rbp)
    46e0:	48 8b 8d 50 fb ff ff 	mov    -0x4b0(%rbp),%rcx
    46e7:	48 89 8d 00 fb ff ff 	mov    %rcx,-0x500(%rbp)
    46ee:	48 8b 8d 70 fb ff ff 	mov    -0x490(%rbp),%rcx
    46f5:	48 89 8d 08 fb ff ff 	mov    %rcx,-0x4f8(%rbp)
    46fc:	48 8b 8d 78 fb ff ff 	mov    -0x488(%rbp),%rcx
    4703:	48 89 8d 30 fb ff ff 	mov    %rcx,-0x4d0(%rbp)
    470a:	e9 73 06 00 00       	jmp    0x4d82
    470f:	48 8b 48 08          	mov    0x8(%rax),%rcx
    4713:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    4718:	49 89 c8             	mov    %rcx,%r8
    471b:	49 21 d0             	and    %rdx,%r8
    471e:	ba 01 00 00 00       	mov    $0x1,%edx
    4723:	4d 89 c1             	mov    %r8,%r9
    4726:	49 29 d1             	sub    %rdx,%r9
    4729:	41 ba 18 00 00 00    	mov    $0x18,%r10d
    472f:	4d 0f af ca          	imul   %r10,%r9
    4733:	4d 89 f2             	mov    %r14,%r10
    4736:	4d 01 ca             	add    %r9,%r10
    4739:	45 31 c9             	xor    %r9d,%r9d
    473c:	4d 39 c8             	cmp    %r9,%r8
    473f:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    4745:	41 0f 94 c0          	sete   %r8b
    4749:	4d 89 cb             	mov    %r9,%r11
    474c:	4d 85 c0             	test   %r8,%r8
    474f:	4d 0f 44 da          	cmove  %r10,%r11
    4753:	4c 8b 00             	mov    (%rax),%r8
    4756:	4c 8b 95 f0 fa ff ff 	mov    -0x510(%rbp),%r10
    475d:	4d 39 c2             	cmp    %r8,%r10
    4760:	b8 00 00 00 00       	mov    $0x0,%eax
    4765:	0f 94 c0             	sete   %al
    4768:	48 09 f0             	or     %rsi,%rax
    476b:	49 89 f8             	mov    %rdi,%r8
    476e:	49 01 d0             	add    %rdx,%r8
    4771:	48 85 c0             	test   %rax,%rax
    4774:	0f 85 0c 00 00 00    	jne    0x4786
    477a:	4c 89 9d 38 fb ff ff 	mov    %r11,-0x4c8(%rbp)
    4781:	e9 04 ff ff ff       	jmp    0x468a
    4786:	48 8b 03             	mov    (%rbx),%rax
    4789:	48 39 c7             	cmp    %rax,%rdi
    478c:	0f 8d 0f 00 00 00    	jge    0x47a1
    4792:	4c 89 9d 38 fb ff ff 	mov    %r11,-0x4c8(%rbp)
    4799:	4c 89 c7             	mov    %r8,%rdi
    479c:	e9 e9 fe ff ff       	jmp    0x468a
    47a1:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    47a8:	48 8b 70 18          	mov    0x18(%rax),%rsi
    47ac:	48 85 f6             	test   %rsi,%rsi
    47af:	48 89 8d f0 fa ff ff 	mov    %rcx,-0x510(%rbp)
    47b6:	4c 89 85 88 fb ff ff 	mov    %r8,-0x478(%rbp)
    47bd:	0f 84 0c 00 00 00    	je     0x47cf
    47c3:	0f b6 3e             	movzbl (%rsi),%edi
    47c6:	48 85 ff             	test   %rdi,%rdi
    47c9:	0f 85 d6 05 00 00    	jne    0x4da5
    47cf:	48 8b 85 38 fb ff ff 	mov    -0x4c8(%rbp),%rax
    47d6:	48 8b 48 10          	mov    0x10(%rax),%rcx
    47da:	48 8b 95 f0 fa ff ff 	mov    -0x510(%rbp),%rdx
    47e1:	48 89 d6             	mov    %rdx,%rsi
    47e4:	48 c1 ee 20          	shr    $0x20,%rsi
    47e8:	48 83 e6 01          	and    $0x1,%rsi
    47ec:	48 83 fe 00          	cmp    $0x0,%rsi
    47f0:	be 00 00 00 00       	mov    $0x0,%esi
    47f5:	40 0f 95 c6          	setne  %sil
    47f9:	48 8b bd 88 fb ff ff 	mov    -0x478(%rbp),%rdi
    4800:	48 89 3b             	mov    %rdi,(%rbx)
    4803:	4c 8b 85 28 fb ff ff 	mov    -0x4d8(%rbp),%r8
    480a:	4d 89 c1             	mov    %r8,%r9
    480d:	49 83 c1 01          	add    $0x1,%r9
    4811:	48 63 c9             	movslq %ecx,%rcx
    4814:	45 31 d2             	xor    %r10d,%r10d
    4817:	48 85 f6             	test   %rsi,%rsi
    481a:	4c 0f 44 d1          	cmove  %rcx,%r10
    481e:	48 8b 8d 38 fc ff ff 	mov    -0x3c8(%rbp),%rcx
    4825:	4c 39 d1             	cmp    %r10,%rcx
    4828:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    482e:	41 0f 94 c3          	sete   %r11b
    4832:	48 8b 85 68 fb ff ff 	mov    -0x498(%rbp),%rax
    4839:	48 39 f0             	cmp    %rsi,%rax
    483c:	ba 00 00 00 00       	mov    $0x0,%edx
    4841:	0f 94 c2             	sete   %dl
    4844:	49 21 d3             	and    %rdx,%r11
    4847:	4d 85 db             	test   %r11,%r11
    484a:	48 89 b5 c8 fb ff ff 	mov    %rsi,-0x438(%rbp)
    4851:	4c 89 8d d0 fa ff ff 	mov    %r9,-0x530(%rbp)
    4858:	4c 89 95 d8 fa ff ff 	mov    %r10,-0x528(%rbp)
    485f:	0f 84 69 00 00 00    	je     0x48ce
    4865:	48 8b 95 50 fb ff ff 	mov    -0x4b0(%rbp),%rdx
    486c:	49 89 d3             	mov    %rdx,%r11
    486f:	49 83 c3 01          	add    $0x1,%r11
    4873:	48 8b b5 e8 fa ff ff 	mov    -0x518(%rbp),%rsi
    487a:	4c 63 16             	movslq (%rsi),%r10
    487d:	4c 8b 8d 78 fb ff ff 	mov    -0x488(%rbp),%r9
    4884:	4c 89 ce             	mov    %r9,%rsi
    4887:	48 83 c6 01          	add    $0x1,%rsi
    488b:	4c 8b 8d 70 fb ff ff 	mov    -0x490(%rbp),%r9
    4892:	4c 89 ca             	mov    %r9,%rdx
    4895:	4c 01 d2             	add    %r10,%rdx
    4898:	48 89 8d 40 fb ff ff 	mov    %rcx,-0x4c0(%rbp)
    489f:	48 89 85 e0 fa ff ff 	mov    %rax,-0x520(%rbp)
    48a6:	4c 8b 95 80 fb ff ff 	mov    -0x480(%rbp),%r10
    48ad:	4c 89 95 10 fb ff ff 	mov    %r10,-0x4f0(%rbp)
    48b4:	4c 89 9d 00 fb ff ff 	mov    %r11,-0x500(%rbp)
    48bb:	48 89 95 08 fb ff ff 	mov    %rdx,-0x4f8(%rbp)
    48c2:	48 89 b5 30 fb ff ff 	mov    %rsi,-0x4d0(%rbp)
    48c9:	e9 9a 04 00 00       	jmp    0x4d68
    48ce:	48 8b 85 58 fb ff ff 	mov    -0x4a8(%rbp),%rax
    48d5:	48 85 c0             	test   %rax,%rax
    48d8:	0f 84 04 04 00 00    	je     0x4ce2
    48de:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    48e5:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    48e9:	48 85 d2             	test   %rdx,%rdx
    48ec:	0f 84 40 01 00 00    	je     0x4a32
    48f2:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    48f6:	be 40 00 00 00       	mov    $0x40,%esi
    48fb:	48 29 d6             	sub    %rdx,%rsi
    48fe:	48 8b bd 80 fb ff ff 	mov    -0x480(%rbp),%rdi
    4905:	48 89 f1             	mov    %rsi,%rcx
    4908:	49 89 f8             	mov    %rdi,%r8
    490b:	49 d3 e8             	shr    %cl,%r8
    490e:	31 c9                	xor    %ecx,%ecx
    4910:	48 39 ca             	cmp    %rcx,%rdx
    4913:	ba 00 00 00 00       	mov    $0x0,%edx
    4918:	0f 94 c2             	sete   %dl
    491b:	48 85 d2             	test   %rdx,%rdx
    491e:	49 0f 44 c8          	cmove  %r8,%rcx
    4922:	48 8b 95 90 fc ff ff 	mov    -0x370(%rbp),%rdx
    4929:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    492d:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    4931:	49 8b 30             	mov    (%r8),%rsi
    4934:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    493b:	00 28 00 
    493e:	4c 39 ce             	cmp    %r9,%rsi
    4941:	4c 89 85 c8 fa ff ff 	mov    %r8,-0x538(%rbp)
    4948:	0f 82 0c 00 00 00    	jb     0x495a
    494e:	48 89 b5 b8 fa ff ff 	mov    %rsi,-0x548(%rbp)
    4955:	e9 4a 00 00 00       	jmp    0x49a4
    495a:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    495e:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    4965:	48 89 b5 c0 fa ff ff 	mov    %rsi,-0x540(%rbp)
    496c:	48 89 d6             	mov    %rdx,%rsi
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 8b 8d c0 fa ff ff 	mov    -0x540(%rbp),%rcx
    4979:	e8 62 b7 ff ff       	call   0xe0
    497e:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    4985:	31 d2                	xor    %edx,%edx
    4987:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    498b:	48 83 f8 00          	cmp    $0x0,%rax
    498f:	0f 8f 08 00 00 00    	jg     0x499d
    4995:	49 89 c4             	mov    %rax,%r12
    4998:	e9 ce 27 00 00       	jmp    0x716b
    499d:	48 89 85 b8 fa ff ff 	mov    %rax,-0x548(%rbp)
    49a4:	48 8b 85 b8 fa ff ff 	mov    -0x548(%rbp),%rax
    49ab:	48 89 c1             	mov    %rax,%rcx
    49ae:	48 83 c1 28          	add    $0x28,%rcx
    49b2:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    49b9:	00 28 00 
    49bc:	48 29 d1             	sub    %rdx,%rcx
    49bf:	48 8b 95 c8 fa ff ff 	mov    -0x538(%rbp),%rdx
    49c6:	48 89 0a             	mov    %rcx,(%rdx)
    49c9:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    49d0:	ff 00 00 
    49d3:	48 21 c8             	and    %rcx,%rax
    49d6:	31 c9                	xor    %ecx,%ecx
    49d8:	48 8b 95 38 fc ff ff 	mov    -0x3c8(%rbp),%rdx
    49df:	48 89 10             	mov    %rdx,(%rax)
    49e2:	48 8b b5 68 fb ff ff 	mov    -0x498(%rbp),%rsi
    49e9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    49ed:	48 89 48 10          	mov    %rcx,0x10(%rax)
    49f1:	48 89 48 18          	mov    %rcx,0x18(%rax)
    49f5:	48 89 48 20          	mov    %rcx,0x20(%rax)
    49f9:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    4a00:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    4a04:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    4a0a:	4c 01 c7             	add    %r8,%rdi
    4a0d:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    4a11:	48 89 85 b8 fa ff ff 	mov    %rax,-0x548(%rbp)
    4a18:	b8 01 00 00 00       	mov    $0x1,%eax
    4a1d:	48 89 85 c8 fa ff ff 	mov    %rax,-0x538(%rbp)
    4a24:	31 c0                	xor    %eax,%eax
    4a26:	48 89 85 c0 fa ff ff 	mov    %rax,-0x540(%rbp)
    4a2d:	e9 a2 01 00 00       	jmp    0x4bd4
    4a32:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    4a39:	48 8b 48 10          	mov    0x10(%rax),%rcx
    4a3d:	48 8b 50 18          	mov    0x18(%rax),%rdx
    4a41:	48 89 d6             	mov    %rdx,%rsi
    4a44:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    4a49:	bf 40 00 00 00       	mov    $0x40,%edi
    4a4e:	48 29 f7             	sub    %rsi,%rdi
    4a51:	48 89 8d b0 fa ff ff 	mov    %rcx,-0x550(%rbp)
    4a58:	4c 8b 85 80 fb ff ff 	mov    -0x480(%rbp),%r8
    4a5f:	48 89 f9             	mov    %rdi,%rcx
    4a62:	4d 89 c1             	mov    %r8,%r9
    4a65:	49 d3 e9             	shr    %cl,%r9
    4a68:	31 c9                	xor    %ecx,%ecx
    4a6a:	48 39 ce             	cmp    %rcx,%rsi
    4a6d:	be 00 00 00 00       	mov    $0x0,%esi
    4a72:	40 0f 94 c6          	sete   %sil
    4a76:	48 85 f6             	test   %rsi,%rsi
    4a79:	49 0f 44 c9          	cmove  %r9,%rcx
    4a7d:	be 01 00 00 00       	mov    $0x1,%esi
    4a82:	48 89 cf             	mov    %rcx,%rdi
    4a85:	48 01 f7             	add    %rsi,%rdi
    4a88:	48 21 d7             	and    %rdx,%rdi
    4a8b:	ba 28 00 00 00       	mov    $0x28,%edx
    4a90:	48 0f af ca          	imul   %rdx,%rcx
    4a94:	48 8b 95 b0 fa ff ff 	mov    -0x550(%rbp),%rdx
    4a9b:	4c 8d 0c 0a          	lea    (%rdx,%rcx,1),%r9
    4a9f:	49 8b 49 10          	mov    0x10(%r9),%rcx
    4aa3:	48 85 c9             	test   %rcx,%rcx
    4aa6:	0f 84 af 00 00 00    	je     0x4b5b
    4aac:	49 8b 09             	mov    (%r9),%rcx
    4aaf:	4d 8b 51 08          	mov    0x8(%r9),%r10
    4ab3:	4c 8b 9d 38 fc ff ff 	mov    -0x3c8(%rbp),%r11
    4aba:	49 39 cb             	cmp    %rcx,%r11
    4abd:	ba 00 00 00 00       	mov    $0x0,%edx
    4ac2:	0f 94 c2             	sete   %dl
    4ac5:	48 8b 8d 68 fb ff ff 	mov    -0x498(%rbp),%rcx
    4acc:	4c 39 d1             	cmp    %r10,%rcx
    4acf:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    4ad5:	41 0f 94 c0          	sete   %r8b
    4ad9:	4c 21 c2             	and    %r8,%rdx
    4adc:	48 85 d2             	test   %rdx,%rdx
    4adf:	0f 84 0c 00 00 00    	je     0x4af1
    4ae5:	4c 89 8d b8 fa ff ff 	mov    %r9,-0x548(%rbp)
    4aec:	e9 53 00 00 00       	jmp    0x4b44
    4af1:	ba 28 00 00 00       	mov    $0x28,%edx
    4af6:	48 0f af fa          	imul   %rdx,%rdi
    4afa:	48 8b 95 b0 fa ff ff 	mov    -0x550(%rbp),%rdx
    4b01:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    4b05:	49 8b 50 10          	mov    0x10(%r8),%rdx
    4b09:	48 85 d2             	test   %rdx,%rdx
    4b0c:	0f 84 49 00 00 00    	je     0x4b5b
    4b12:	49 8b 10             	mov    (%r8),%rdx
    4b15:	49 8b 78 08          	mov    0x8(%r8),%rdi
    4b19:	49 39 d3             	cmp    %rdx,%r11
    4b1c:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    4b22:	41 0f 94 c1          	sete   %r9b
    4b26:	48 39 f9             	cmp    %rdi,%rcx
    4b29:	ba 00 00 00 00       	mov    $0x0,%edx
    4b2e:	0f 94 c2             	sete   %dl
    4b31:	49 21 d1             	and    %rdx,%r9
    4b34:	4d 85 c9             	test   %r9,%r9
    4b37:	0f 84 1e 00 00 00    	je     0x4b5b
    4b3d:	4c 89 85 b8 fa ff ff 	mov    %r8,-0x548(%rbp)
    4b44:	31 c0                	xor    %eax,%eax
    4b46:	48 89 85 c8 fa ff ff 	mov    %rax,-0x538(%rbp)
    4b4d:	31 c0                	xor    %eax,%eax
    4b4f:	48 89 85 c0 fa ff ff 	mov    %rax,-0x540(%rbp)
    4b56:	e9 79 00 00 00       	jmp    0x4bd4
    4b5b:	48 8d 85 10 fe ff ff 	lea    -0x1f0(%rbp),%rax
    4b62:	48 89 c1             	mov    %rax,%rcx
    4b65:	48 8b 95 38 fc ff ff 	mov    -0x3c8(%rbp),%rdx
    4b6c:	48 89 11             	mov    %rdx,(%rcx)
    4b6f:	48 8b b5 68 fb ff ff 	mov    -0x498(%rbp),%rsi
    4b76:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    4b7a:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    4b81:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    4b88:	48 89 ca             	mov    %rcx,%rdx
    4b8b:	e8 60 b5 ff ff       	call   0xf0
    4b90:	48 83 f8 00          	cmp    $0x0,%rax
    4b94:	0f 8d 08 00 00 00    	jge    0x4ba2
    4b9a:	49 89 c4             	mov    %rax,%r12
    4b9d:	e9 c9 25 00 00       	jmp    0x716b
    4ba2:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    4ba9:	48 8b 11             	mov    (%rcx),%rdx
    4bac:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    4bb0:	48 83 e6 01          	and    $0x1,%rsi
    4bb4:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    4bb8:	48 89 85 b8 fa ff ff 	mov    %rax,-0x548(%rbp)
    4bbf:	b8 01 00 00 00       	mov    $0x1,%eax
    4bc4:	48 89 85 c8 fa ff ff 	mov    %rax,-0x538(%rbp)
    4bcb:	31 c0                	xor    %eax,%eax
    4bcd:	48 89 85 c0 fa ff ff 	mov    %rax,-0x540(%rbp)
    4bd4:	48 8b 85 c8 fa ff ff 	mov    -0x538(%rbp),%rax
    4bdb:	48 85 c0             	test   %rax,%rax
    4bde:	0f 84 6b 00 00 00    	je     0x4c4f
    4be4:	48 8b 85 b8 fa ff ff 	mov    -0x548(%rbp),%rax
    4beb:	48 8b 8d 50 fb ff ff 	mov    -0x4b0(%rbp),%rcx
    4bf2:	48 89 48 10          	mov    %rcx,0x10(%rax)
    4bf6:	31 d2                	xor    %edx,%edx
    4bf8:	48 39 d1             	cmp    %rdx,%rcx
    4bfb:	be 00 00 00 00       	mov    $0x0,%esi
    4c00:	40 0f 95 c6          	setne  %sil
    4c04:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    4c08:	48 09 f7             	or     %rsi,%rdi
    4c0b:	48 0f be ff          	movsbq %dil,%rdi
    4c0f:	40 88 78 20          	mov    %dil,0x20(%rax)
    4c13:	48 8b b5 70 fb ff ff 	mov    -0x490(%rbp),%rsi
    4c1a:	48 89 70 18          	mov    %rsi,0x18(%rax)
    4c1e:	4c 8b 85 78 fb ff ff 	mov    -0x488(%rbp),%r8
    4c25:	49 39 d0             	cmp    %rdx,%r8
    4c28:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    4c2e:	41 0f 95 c1          	setne  %r9b
    4c32:	40 0f b6 ff          	movzbl %dil,%edi
    4c36:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    4c3c:	4d 85 c9             	test   %r9,%r9
    4c3f:	4c 0f 44 d2          	cmove  %rdx,%r10
    4c43:	4c 09 d7             	or     %r10,%rdi
    4c46:	40 88 78 20          	mov    %dil,0x20(%rax)
    4c4a:	e9 93 00 00 00       	jmp    0x4ce2
    4c4f:	48 8b 85 b8 fa ff ff 	mov    -0x548(%rbp),%rax
    4c56:	48 8b 48 10          	mov    0x10(%rax),%rcx
    4c5a:	48 8b 95 50 fb ff ff 	mov    -0x4b0(%rbp),%rdx
    4c61:	48 01 d1             	add    %rdx,%rcx
    4c64:	48 89 48 10          	mov    %rcx,0x10(%rax)
    4c68:	31 f6                	xor    %esi,%esi
    4c6a:	48 39 f1             	cmp    %rsi,%rcx
    4c6d:	b9 00 00 00 00       	mov    $0x0,%ecx
    4c72:	0f 95 c1             	setne  %cl
    4c75:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    4c79:	48 09 cf             	or     %rcx,%rdi
    4c7c:	48 0f be ff          	movsbq %dil,%rdi
    4c80:	40 88 78 20          	mov    %dil,0x20(%rax)
    4c84:	48 8b 48 18          	mov    0x18(%rax),%rcx
    4c88:	40 0f b6 ff          	movzbl %dil,%edi
    4c8c:	49 89 f8             	mov    %rdi,%r8
    4c8f:	49 83 e0 02          	and    $0x2,%r8
    4c93:	49 39 f0             	cmp    %rsi,%r8
    4c96:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    4c9c:	41 0f 95 c0          	setne  %r8b
    4ca0:	45 31 c9             	xor    %r9d,%r9d
    4ca3:	4d 85 c0             	test   %r8,%r8
    4ca6:	49 0f 44 c9          	cmove  %r9,%rcx
    4caa:	4c 8b 8d 78 fb ff ff 	mov    -0x488(%rbp),%r9
    4cb1:	4d 01 c8             	add    %r9,%r8
    4cb4:	4c 8b 95 70 fb ff ff 	mov    -0x490(%rbp),%r10
    4cbb:	4c 01 d1             	add    %r10,%rcx
    4cbe:	48 89 48 18          	mov    %rcx,0x18(%rax)
    4cc2:	49 39 f0             	cmp    %rsi,%r8
    4cc5:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    4ccb:	41 0f 95 c0          	setne  %r8b
    4ccf:	b9 02 00 00 00       	mov    $0x2,%ecx
    4cd4:	4d 85 c0             	test   %r8,%r8
    4cd7:	48 0f 44 ce          	cmove  %rsi,%rcx
    4cdb:	48 09 cf             	or     %rcx,%rdi
    4cde:	40 88 78 20          	mov    %dil,0x20(%rax)
    4ce2:	48 8b 85 e8 fa ff ff 	mov    -0x518(%rbp),%rax
    4ce9:	48 63 08             	movslq (%rax),%rcx
    4cec:	48 ba 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rdx
    4cf3:	79 37 9e 
    4cf6:	48 be 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%rsi
    4cfd:	79 37 9e 
    4d00:	48 8b bd d8 fa ff ff 	mov    -0x528(%rbp),%rdi
    4d07:	48 31 fe             	xor    %rdi,%rsi
    4d0a:	48 0f af f2          	imul   %rdx,%rsi
    4d0e:	49 89 f0             	mov    %rsi,%r8
    4d11:	49 c1 e8 1d          	shr    $0x1d,%r8
    4d15:	4c 31 c6             	xor    %r8,%rsi
    4d18:	4c 8b 85 c8 fb ff ff 	mov    -0x438(%rbp),%r8
    4d1f:	4c 31 c6             	xor    %r8,%rsi
    4d22:	48 0f af f2          	imul   %rdx,%rsi
    4d26:	49 89 f1             	mov    %rsi,%r9
    4d29:	49 c1 e9 1d          	shr    $0x1d,%r9
    4d2d:	4c 31 ce             	xor    %r9,%rsi
    4d30:	48 0f af f2          	imul   %rdx,%rsi
    4d34:	48 89 bd 40 fb ff ff 	mov    %rdi,-0x4c0(%rbp)
    4d3b:	4c 89 85 e0 fa ff ff 	mov    %r8,-0x520(%rbp)
    4d42:	48 89 b5 10 fb ff ff 	mov    %rsi,-0x4f0(%rbp)
    4d49:	ba 01 00 00 00       	mov    $0x1,%edx
    4d4e:	48 89 95 00 fb ff ff 	mov    %rdx,-0x500(%rbp)
    4d55:	48 89 8d 08 fb ff ff 	mov    %rcx,-0x4f8(%rbp)
    4d5c:	ba 01 00 00 00       	mov    $0x1,%edx
    4d61:	48 89 95 30 fb ff ff 	mov    %rdx,-0x4d0(%rbp)
    4d68:	48 8b 85 d0 fa ff ff 	mov    -0x530(%rbp),%rax
    4d6f:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    4d76:	b8 01 00 00 00       	mov    $0x1,%eax
    4d7b:	48 89 85 f8 fa ff ff 	mov    %rax,-0x508(%rbp)
    4d82:	31 c0                	xor    %eax,%eax
    4d84:	48 89 03             	mov    %rax,(%rbx)
    4d87:	48 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%rax
    4d8e:	b9 01 00 00 00       	mov    $0x1,%ecx
    4d93:	48 89 c2             	mov    %rax,%rdx
    4d96:	48 01 ca             	add    %rcx,%rdx
    4d99:	48 89 95 20 fb ff ff 	mov    %rdx,-0x4e0(%rbp)
    4da0:	e9 93 f1 ff ff       	jmp    0x3f38
    4da5:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    4dac:	e8 8f b2 ff ff       	call   0x40
    4db1:	48 85 c0             	test   %rax,%rax
    4db4:	0f 84 15 fa ff ff    	je     0x47cf
    4dba:	e9 a5 23 00 00       	jmp    0x7164
    4dbf:	48 8b 85 c0 fb ff ff 	mov    -0x440(%rbp),%rax
    4dc6:	48 85 c0             	test   %rax,%rax
    4dc9:	0f 84 c6 03 00 00    	je     0x5195
    4dcf:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    4dd6:	48 8b 48 68          	mov    0x68(%rax),%rcx
    4dda:	48 85 c9             	test   %rcx,%rcx
    4ddd:	0f 84 22 01 00 00    	je     0x4f05
    4de3:	48 8b 48 38          	mov    0x38(%rax),%rcx
    4de7:	ba 40 00 00 00       	mov    $0x40,%edx
    4dec:	48 29 ca             	sub    %rcx,%rdx
    4def:	48 89 8d c0 fb ff ff 	mov    %rcx,-0x440(%rbp)
    4df6:	48 8b b5 a0 fb ff ff 	mov    -0x460(%rbp),%rsi
    4dfd:	48 89 d1             	mov    %rdx,%rcx
    4e00:	48 89 f7             	mov    %rsi,%rdi
    4e03:	48 d3 ef             	shr    %cl,%rdi
    4e06:	31 c9                	xor    %ecx,%ecx
    4e08:	48 8b 95 c0 fb ff ff 	mov    -0x440(%rbp),%rdx
    4e0f:	48 39 ca             	cmp    %rcx,%rdx
    4e12:	ba 00 00 00 00       	mov    $0x0,%edx
    4e17:	0f 94 c2             	sete   %dl
    4e1a:	48 85 d2             	test   %rdx,%rdx
    4e1d:	48 0f 44 cf          	cmove  %rdi,%rcx
    4e21:	48 8b 50 08          	mov    0x8(%rax),%rdx
    4e25:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    4e29:	4c 8b 3f             	mov    (%rdi),%r15
    4e2c:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    4e33:	00 28 00 
    4e36:	49 39 d7             	cmp    %rdx,%r15
    4e39:	48 89 bd c0 fb ff ff 	mov    %rdi,-0x440(%rbp)
    4e40:	0f 82 05 00 00 00    	jb     0x4e4b
    4e46:	e9 3b 00 00 00       	jmp    0x4e86
    4e4b:	4c 8b 40 60          	mov    0x60(%rax),%r8
    4e4f:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    4e56:	48 89 c6             	mov    %rax,%rsi
    4e59:	48 89 ca             	mov    %rcx,%rdx
    4e5c:	4c 89 c1             	mov    %r8,%rcx
    4e5f:	e8 7c b2 ff ff       	call   0xe0
    4e64:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    4e6b:	31 d2                	xor    %edx,%edx
    4e6d:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    4e71:	48 83 f8 00          	cmp    $0x0,%rax
    4e75:	0f 8f 08 00 00 00    	jg     0x4e83
    4e7b:	49 89 c4             	mov    %rax,%r12
    4e7e:	e9 e8 22 00 00       	jmp    0x716b
    4e83:	49 89 c7             	mov    %rax,%r15
    4e86:	4c 89 f8             	mov    %r15,%rax
    4e89:	48 83 c0 28          	add    $0x28,%rax
    4e8d:	48 b9 00 00 00 00 00 	movabs $0x28000000000000,%rcx
    4e94:	00 28 00 
    4e97:	48 29 c8             	sub    %rcx,%rax
    4e9a:	48 8b 8d c0 fb ff ff 	mov    -0x440(%rbp),%rcx
    4ea1:	48 89 01             	mov    %rax,(%rcx)
    4ea4:	48 b8 ff ff ff ff ff 	movabs $0xffffffffffff,%rax
    4eab:	ff 00 00 
    4eae:	49 21 c7             	and    %rax,%r15
    4eb1:	31 c0                	xor    %eax,%eax
    4eb3:	48 8b 8d b0 fb ff ff 	mov    -0x450(%rbp),%rcx
    4eba:	49 89 0f             	mov    %rcx,(%r15)
    4ebd:	48 8b 95 a8 fb ff ff 	mov    -0x458(%rbp),%rdx
    4ec4:	49 89 57 08          	mov    %rdx,0x8(%r15)
    4ec8:	49 89 47 10          	mov    %rax,0x10(%r15)
    4ecc:	49 89 47 18          	mov    %rax,0x18(%r15)
    4ed0:	49 89 47 20          	mov    %rax,0x20(%r15)
    4ed4:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    4edb:	48 8b 70 60          	mov    0x60(%rax),%rsi
    4edf:	bf 01 00 00 00       	mov    $0x1,%edi
    4ee4:	48 01 fe             	add    %rdi,%rsi
    4ee7:	48 89 70 60          	mov    %rsi,0x60(%rax)
    4eeb:	be 01 00 00 00       	mov    $0x1,%esi
    4ef0:	48 89 b5 c0 fb ff ff 	mov    %rsi,-0x440(%rbp)
    4ef7:	31 f6                	xor    %esi,%esi
    4ef9:	48 89 b5 40 fc ff ff 	mov    %rsi,-0x3c0(%rbp)
    4f00:	e9 93 01 00 00       	jmp    0x5098
    4f05:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    4f0c:	48 8b 48 10          	mov    0x10(%rax),%rcx
    4f10:	48 8b 50 18          	mov    0x18(%rax),%rdx
    4f14:	48 89 d6             	mov    %rdx,%rsi
    4f17:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    4f1c:	bf 40 00 00 00       	mov    $0x40,%edi
    4f21:	48 29 f7             	sub    %rsi,%rdi
    4f24:	48 89 8d 88 fc ff ff 	mov    %rcx,-0x378(%rbp)
    4f2b:	4c 8b 85 a0 fb ff ff 	mov    -0x460(%rbp),%r8
    4f32:	48 89 f9             	mov    %rdi,%rcx
    4f35:	49 d3 e8             	shr    %cl,%r8
    4f38:	31 c9                	xor    %ecx,%ecx
    4f3a:	48 39 ce             	cmp    %rcx,%rsi
    4f3d:	be 00 00 00 00       	mov    $0x0,%esi
    4f42:	40 0f 94 c6          	sete   %sil
    4f46:	48 85 f6             	test   %rsi,%rsi
    4f49:	49 0f 44 c8          	cmove  %r8,%rcx
    4f4d:	be 01 00 00 00       	mov    $0x1,%esi
    4f52:	48 89 cf             	mov    %rcx,%rdi
    4f55:	48 01 f7             	add    %rsi,%rdi
    4f58:	48 21 d7             	and    %rdx,%rdi
    4f5b:	ba 28 00 00 00       	mov    $0x28,%edx
    4f60:	48 0f af ca          	imul   %rdx,%rcx
    4f64:	48 8b 95 88 fc ff ff 	mov    -0x378(%rbp),%rdx
    4f6b:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
    4f6f:	49 8b 48 10          	mov    0x10(%r8),%rcx
    4f73:	48 85 c9             	test   %rcx,%rcx
    4f76:	0f 84 a7 00 00 00    	je     0x5023
    4f7c:	49 8b 08             	mov    (%r8),%rcx
    4f7f:	4d 8b 48 08          	mov    0x8(%r8),%r9
    4f83:	4c 8b 95 b0 fb ff ff 	mov    -0x450(%rbp),%r10
    4f8a:	49 39 ca             	cmp    %rcx,%r10
    4f8d:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    4f93:	41 0f 94 c3          	sete   %r11b
    4f97:	48 8b 8d a8 fb ff ff 	mov    -0x458(%rbp),%rcx
    4f9e:	4c 39 c9             	cmp    %r9,%rcx
    4fa1:	ba 00 00 00 00       	mov    $0x0,%edx
    4fa6:	0f 94 c2             	sete   %dl
    4fa9:	49 21 d3             	and    %rdx,%r11
    4fac:	4d 85 db             	test   %r11,%r11
    4faf:	0f 84 08 00 00 00    	je     0x4fbd
    4fb5:	4d 89 c7             	mov    %r8,%r15
    4fb8:	e9 4f 00 00 00       	jmp    0x500c
    4fbd:	ba 28 00 00 00       	mov    $0x28,%edx
    4fc2:	48 0f af fa          	imul   %rdx,%rdi
    4fc6:	48 8b 95 88 fc ff ff 	mov    -0x378(%rbp),%rdx
    4fcd:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    4fd1:	49 8b 50 10          	mov    0x10(%r8),%rdx
    4fd5:	48 85 d2             	test   %rdx,%rdx
    4fd8:	0f 84 45 00 00 00    	je     0x5023
    4fde:	49 8b 10             	mov    (%r8),%rdx
    4fe1:	49 8b 78 08          	mov    0x8(%r8),%rdi
    4fe5:	49 39 d2             	cmp    %rdx,%r10
    4fe8:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    4fee:	41 0f 94 c1          	sete   %r9b
    4ff2:	48 39 f9             	cmp    %rdi,%rcx
    4ff5:	ba 00 00 00 00       	mov    $0x0,%edx
    4ffa:	0f 94 c2             	sete   %dl
    4ffd:	49 21 d1             	and    %rdx,%r9
    5000:	4d 85 c9             	test   %r9,%r9
    5003:	0f 84 1a 00 00 00    	je     0x5023
    5009:	4d 89 c7             	mov    %r8,%r15
    500c:	31 c0                	xor    %eax,%eax
    500e:	48 89 85 c0 fb ff ff 	mov    %rax,-0x440(%rbp)
    5015:	31 c0                	xor    %eax,%eax
    5017:	48 89 85 40 fc ff ff 	mov    %rax,-0x3c0(%rbp)
    501e:	e9 75 00 00 00       	jmp    0x5098
    5023:	48 8d 85 90 fd ff ff 	lea    -0x270(%rbp),%rax
    502a:	48 89 c1             	mov    %rax,%rcx
    502d:	48 8b 95 b0 fb ff ff 	mov    -0x450(%rbp),%rdx
    5034:	48 89 11             	mov    %rdx,(%rcx)
    5037:	48 8b 95 a8 fb ff ff 	mov    -0x458(%rbp),%rdx
    503e:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    5042:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    5049:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    5050:	48 89 ca             	mov    %rcx,%rdx
    5053:	e8 98 b0 ff ff       	call   0xf0
    5058:	48 83 f8 00          	cmp    $0x0,%rax
    505c:	0f 8d 08 00 00 00    	jge    0x506a
    5062:	49 89 c4             	mov    %rax,%r12
    5065:	e9 01 21 00 00       	jmp    0x716b
    506a:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    5071:	48 8b 11             	mov    (%rcx),%rdx
    5074:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    5078:	48 83 e6 01          	and    $0x1,%rsi
    507c:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    5080:	49 89 c7             	mov    %rax,%r15
    5083:	b8 01 00 00 00       	mov    $0x1,%eax
    5088:	48 89 85 c0 fb ff ff 	mov    %rax,-0x440(%rbp)
    508f:	31 c0                	xor    %eax,%eax
    5091:	48 89 85 40 fc ff ff 	mov    %rax,-0x3c0(%rbp)
    5098:	48 8b 85 c0 fb ff ff 	mov    -0x440(%rbp),%rax
    509f:	48 85 c0             	test   %rax,%rax
    50a2:	0f 84 64 00 00 00    	je     0x510c
    50a8:	48 8b 85 b8 fb ff ff 	mov    -0x448(%rbp),%rax
    50af:	49 89 47 10          	mov    %rax,0x10(%r15)
    50b3:	31 c9                	xor    %ecx,%ecx
    50b5:	48 39 c8             	cmp    %rcx,%rax
    50b8:	ba 00 00 00 00       	mov    $0x0,%edx
    50bd:	0f 95 c2             	setne  %dl
    50c0:	41 0f b6 77 20       	movzbl 0x20(%r15),%esi
    50c5:	48 09 d6             	or     %rdx,%rsi
    50c8:	48 0f be f6          	movsbq %sil,%rsi
    50cc:	41 88 77 20          	mov    %sil,0x20(%r15)
    50d0:	48 8b 95 98 fb ff ff 	mov    -0x468(%rbp),%rdx
    50d7:	49 89 57 18          	mov    %rdx,0x18(%r15)
    50db:	48 8b bd 90 fb ff ff 	mov    -0x470(%rbp),%rdi
    50e2:	48 39 cf             	cmp    %rcx,%rdi
    50e5:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    50eb:	41 0f 95 c0          	setne  %r8b
    50ef:	40 0f b6 f6          	movzbl %sil,%esi
    50f3:	41 b9 02 00 00 00    	mov    $0x2,%r9d
    50f9:	4d 85 c0             	test   %r8,%r8
    50fc:	4c 0f 44 c9          	cmove  %rcx,%r9
    5100:	4c 09 ce             	or     %r9,%rsi
    5103:	41 88 77 20          	mov    %sil,0x20(%r15)
    5107:	e9 89 00 00 00       	jmp    0x5195
    510c:	49 8b 47 10          	mov    0x10(%r15),%rax
    5110:	48 8b 8d b8 fb ff ff 	mov    -0x448(%rbp),%rcx
    5117:	48 01 c8             	add    %rcx,%rax
    511a:	49 89 47 10          	mov    %rax,0x10(%r15)
    511e:	31 c9                	xor    %ecx,%ecx
    5120:	48 39 c8             	cmp    %rcx,%rax
    5123:	b8 00 00 00 00       	mov    $0x0,%eax
    5128:	0f 95 c0             	setne  %al
    512b:	41 0f b6 57 20       	movzbl 0x20(%r15),%edx
    5130:	48 09 c2             	or     %rax,%rdx
    5133:	48 0f be d2          	movsbq %dl,%rdx
    5137:	41 88 57 20          	mov    %dl,0x20(%r15)
    513b:	49 8b 47 18          	mov    0x18(%r15),%rax
    513f:	0f b6 d2             	movzbl %dl,%edx
    5142:	48 89 d6             	mov    %rdx,%rsi
    5145:	48 83 e6 02          	and    $0x2,%rsi
    5149:	48 39 ce             	cmp    %rcx,%rsi
    514c:	be 00 00 00 00       	mov    $0x0,%esi
    5151:	40 0f 95 c6          	setne  %sil
    5155:	31 ff                	xor    %edi,%edi
    5157:	48 85 f6             	test   %rsi,%rsi
    515a:	48 0f 44 c7          	cmove  %rdi,%rax
    515e:	48 8b bd 90 fb ff ff 	mov    -0x470(%rbp),%rdi
    5165:	48 01 fe             	add    %rdi,%rsi
    5168:	48 8b bd 98 fb ff ff 	mov    -0x468(%rbp),%rdi
    516f:	48 01 f8             	add    %rdi,%rax
    5172:	49 89 47 18          	mov    %rax,0x18(%r15)
    5176:	48 39 ce             	cmp    %rcx,%rsi
    5179:	be 00 00 00 00       	mov    $0x0,%esi
    517e:	40 0f 95 c6          	setne  %sil
    5182:	b8 02 00 00 00       	mov    $0x2,%eax
    5187:	48 85 f6             	test   %rsi,%rsi
    518a:	48 0f 44 c1          	cmove  %rcx,%rax
    518e:	48 09 c2             	or     %rax,%rdx
    5191:	41 88 57 20          	mov    %dl,0x20(%r15)
    5195:	48 8b 85 60 fb ff ff 	mov    -0x4a0(%rbp),%rax
    519c:	48 89 85 d0 fb ff ff 	mov    %rax,-0x430(%rbp)
    51a3:	e9 a1 1e 00 00       	jmp    0x7049
    51a8:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
    51af:	82 28 52 
    51b2:	31 c9                	xor    %ecx,%ecx
    51b4:	48 8b 95 18 fc ff ff 	mov    -0x3e8(%rbp),%rdx
    51bb:	48 8b b5 e0 fb ff ff 	mov    -0x420(%rbp),%rsi
    51c2:	48 21 f2             	and    %rsi,%rdx
    51c5:	48 85 d2             	test   %rdx,%rdx
    51c8:	0f 85 e7 0d 00 00    	jne    0x5fb5
    51ce:	4c 8b bd 08 fc ff ff 	mov    -0x3f8(%rbp),%r15
    51d5:	31 d2                	xor    %edx,%edx
    51d7:	48 89 95 18 fc ff ff 	mov    %rdx,-0x3e8(%rbp)
    51de:	31 d2                	xor    %edx,%edx
    51e0:	48 89 95 60 fb ff ff 	mov    %rdx,-0x4a0(%rbp)
    51e7:	48 89 85 98 fb ff ff 	mov    %rax,-0x468(%rbp)
    51ee:	31 d2                	xor    %edx,%edx
    51f0:	48 89 95 90 fb ff ff 	mov    %rdx,-0x470(%rbp)
    51f7:	48 89 8d b8 fb ff ff 	mov    %rcx,-0x448(%rbp)
    51fe:	31 d2                	xor    %edx,%edx
    5200:	48 89 95 c0 fb ff ff 	mov    %rdx,-0x440(%rbp)
    5207:	31 d2                	xor    %edx,%edx
    5209:	48 89 95 40 fc ff ff 	mov    %rdx,-0x3c0(%rbp)
    5210:	31 d2                	xor    %edx,%edx
    5212:	48 89 95 a8 fb ff ff 	mov    %rdx,-0x458(%rbp)
    5219:	48 8b 85 f8 fb ff ff 	mov    -0x408(%rbp),%rax
    5220:	49 39 c7             	cmp    %rax,%r15
    5223:	0f 8c 75 00 00 00    	jl     0x529e
    5229:	48 8b 8d a8 fb ff ff 	mov    -0x458(%rbp),%rcx
    5230:	48 89 8d b0 fb ff ff 	mov    %rcx,-0x450(%rbp)
    5237:	48 8b 8d 40 fc ff ff 	mov    -0x3c0(%rbp),%rcx
    523e:	48 89 8d 88 fc ff ff 	mov    %rcx,-0x378(%rbp)
    5245:	48 8b 8d 90 fb ff ff 	mov    -0x470(%rbp),%rcx
    524c:	48 89 8d a0 fb ff ff 	mov    %rcx,-0x460(%rbp)
    5253:	48 8b 8d 18 fc ff ff 	mov    -0x3e8(%rbp),%rcx
    525a:	48 89 8d 38 fb ff ff 	mov    %rcx,-0x4c8(%rbp)
    5261:	48 8b 8d 60 fb ff ff 	mov    -0x4a0(%rbp),%rcx
    5268:	48 89 8d f0 fa ff ff 	mov    %rcx,-0x510(%rbp)
    526f:	48 8b 8d 98 fb ff ff 	mov    -0x468(%rbp),%rcx
    5276:	48 89 8d 88 fb ff ff 	mov    %rcx,-0x478(%rbp)
    527d:	48 8b 8d b8 fb ff ff 	mov    -0x448(%rbp),%rcx
    5284:	48 89 8d 28 fb ff ff 	mov    %rcx,-0x4d8(%rbp)
    528b:	48 8b 8d c0 fb ff ff 	mov    -0x440(%rbp),%rcx
    5292:	48 89 8d 58 fb ff ff 	mov    %rcx,-0x4a8(%rbp)
    5299:	e9 e1 19 00 00       	jmp    0x6c7f
    529e:	48 8b 8d e0 fb ff ff 	mov    -0x420(%rbp),%rcx
    52a5:	48 85 c9             	test   %rcx,%rcx
    52a8:	0f 84 08 00 00 00    	je     0x52b6
    52ae:	4c 89 fe             	mov    %r15,%rsi
    52b1:	e9 11 00 00 00       	jmp    0x52c7
    52b6:	48 8b 95 30 fc ff ff 	mov    -0x3d0(%rbp),%rdx
    52bd:	4a 8d 3c ba          	lea    (%rdx,%r15,4),%rdi
    52c1:	44 8b 07             	mov    (%rdi),%r8d
    52c4:	4c 89 c6             	mov    %r8,%rsi
    52c7:	48 8b 85 d8 fb ff ff 	mov    -0x428(%rbp),%rax
    52ce:	48 8d 0c b0          	lea    (%rax,%rsi,4),%rcx
    52d2:	48 89 f2             	mov    %rsi,%rdx
    52d5:	48 c1 ea 06          	shr    $0x6,%rdx
    52d9:	48 8b bd 20 fc ff ff 	mov    -0x3e0(%rbp),%rdi
    52e0:	4c 8d 04 d7          	lea    (%rdi,%rdx,8),%r8
    52e4:	48 8b 95 10 fc ff ff 	mov    -0x3f0(%rbp),%rdx
    52eb:	4c 8b 8d 98 fc ff ff 	mov    -0x368(%rbp),%r9
    52f2:	4d 89 ca             	mov    %r9,%r10
    52f5:	48 85 d2             	test   %rdx,%rdx
    52f8:	4d 0f 44 d0          	cmove  %r8,%r10
    52fc:	4d 8b 02             	mov    (%r10),%r8
    52ff:	49 89 f2             	mov    %rsi,%r10
    5302:	49 83 e2 3f          	and    $0x3f,%r10
    5306:	48 89 8d 80 fb ff ff 	mov    %rcx,-0x480(%rbp)
    530d:	4c 89 d1             	mov    %r10,%rcx
    5310:	49 d3 e8             	shr    %cl,%r8
    5313:	b9 01 00 00 00       	mov    $0x1,%ecx
    5318:	49 21 c8             	and    %rcx,%r8
    531b:	45 31 d2             	xor    %r10d,%r10d
    531e:	4d 39 d0             	cmp    %r10,%r8
    5321:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    5327:	41 0f 94 c0          	sete   %r8b
    532b:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5331:	48 89 d7             	mov    %rdx,%rdi
    5334:	4c 31 df             	xor    %r11,%rdi
    5337:	49 21 f8             	and    %rdi,%r8
    533a:	48 8b bd e8 fb ff ff 	mov    -0x418(%rbp),%rdi
    5341:	4c 8d 1c b7          	lea    (%rdi,%rsi,4),%r11
    5345:	48 89 f2             	mov    %rsi,%rdx
    5348:	48 c1 ea 06          	shr    $0x6,%rdx
    534c:	48 8b 85 00 fc ff ff 	mov    -0x400(%rbp),%rax
    5353:	48 8d 3c d0          	lea    (%rax,%rdx,8),%rdi
    5357:	48 8b 95 f0 fb ff ff 	mov    -0x410(%rbp),%rdx
    535e:	4c 89 c8             	mov    %r9,%rax
    5361:	48 85 d2             	test   %rdx,%rdx
    5364:	48 0f 44 c7          	cmove  %rdi,%rax
    5368:	48 8b 38             	mov    (%rax),%rdi
    536b:	48 83 e6 3f          	and    $0x3f,%rsi
    536f:	48 89 f1             	mov    %rsi,%rcx
    5372:	48 d3 ef             	shr    %cl,%rdi
    5375:	b8 01 00 00 00       	mov    $0x1,%eax
    537a:	48 21 c7             	and    %rax,%rdi
    537d:	4c 39 d7             	cmp    %r10,%rdi
    5380:	bf 00 00 00 00       	mov    $0x0,%edi
    5385:	40 0f 94 c7          	sete   %dil
    5389:	b9 01 00 00 00       	mov    $0x1,%ecx
    538e:	48 89 d6             	mov    %rdx,%rsi
    5391:	48 31 ce             	xor    %rcx,%rsi
    5394:	48 21 f7             	and    %rsi,%rdi
    5397:	4d 85 c0             	test   %r8,%r8
    539a:	48 89 bd 38 fc ff ff 	mov    %rdi,-0x3c8(%rbp)
    53a1:	4c 89 9d 68 fb ff ff 	mov    %r11,-0x498(%rbp)
    53a8:	0f 85 da 0b 00 00    	jne    0x5f88
    53ae:	48 8b 8d 80 fb ff ff 	mov    -0x480(%rbp),%rcx
    53b5:	48 63 31             	movslq (%rcx),%rsi
    53b8:	48 8b 8d 50 fc ff ff 	mov    -0x3b0(%rbp),%rcx
    53bf:	48 85 c9             	test   %rcx,%rcx
    53c2:	48 89 b5 50 fb ff ff 	mov    %rsi,-0x4b0(%rbp)
    53c9:	0f 84 41 01 00 00    	je     0x5510
    53cf:	48 be 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rsi
    53d6:	79 37 9e 
    53d9:	48 8b 95 50 fb ff ff 	mov    -0x4b0(%rbp),%rdx
    53e0:	48 89 d7             	mov    %rdx,%rdi
    53e3:	48 c1 ef 2b          	shr    $0x2b,%rdi
    53e7:	49 89 d3             	mov    %rdx,%r11
    53ea:	49 c1 eb 2c          	shr    $0x2c,%r11
    53ee:	4c 31 df             	xor    %r11,%rdi
    53f1:	49 89 d3             	mov    %rdx,%r11
    53f4:	49 31 fb             	xor    %rdi,%r11
    53f7:	4c 0f af de          	imul   %rsi,%r11
    53fb:	4c 89 de             	mov    %r11,%rsi
    53fe:	48 c1 ee 1e          	shr    $0x1e,%rsi
    5402:	4c 89 df             	mov    %r11,%rdi
    5405:	48 31 f7             	xor    %rsi,%rdi
    5408:	48 be b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%rsi
    540f:	47 58 bf 
    5412:	48 0f af fe          	imul   %rsi,%rdi
    5416:	48 89 fe             	mov    %rdi,%rsi
    5419:	48 c1 ee 1b          	shr    $0x1b,%rsi
    541d:	48 31 f7             	xor    %rsi,%rdi
    5420:	48 be eb 11 31 13 bb 	movabs $0x94d049bb133111eb,%rsi
    5427:	49 d0 94 
    542a:	48 0f af fe          	imul   %rsi,%rdi
    542e:	48 89 fe             	mov    %rdi,%rsi
    5431:	48 c1 ee 1f          	shr    $0x1f,%rsi
    5435:	48 31 f7             	xor    %rsi,%rdi
    5438:	be 40 00 00 00       	mov    $0x40,%esi
    543d:	48 29 ce             	sub    %rcx,%rsi
    5440:	48 89 f1             	mov    %rsi,%rcx
    5443:	48 d3 ef             	shr    %cl,%rdi
    5446:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
    544a:	48 89 f9             	mov    %rdi,%rcx
    544d:	48 89 f2             	mov    %rsi,%rdx
    5450:	48 d3 ea             	shr    %cl,%rdx
    5453:	48 21 c2             	and    %rax,%rdx
    5456:	48 85 d2             	test   %rdx,%rdx
    5459:	0f 84 b1 00 00 00    	je     0x5510
    545f:	48 8d 8d f0 fc ff ff 	lea    -0x310(%rbp),%rcx
    5466:	48 89 ca             	mov    %rcx,%rdx
    5469:	48 8b 8d 80 fb ff ff 	mov    -0x480(%rbp),%rcx
    5470:	48 63 31             	movslq (%rcx),%rsi
    5473:	31 c9                	xor    %ecx,%ecx
    5475:	48 89 0a             	mov    %rcx,(%rdx)
    5478:	48 89 72 08          	mov    %rsi,0x8(%rdx)
    547c:	4c 89 42 10          	mov    %r8,0x10(%rdx)
    5480:	48 8b 8d 68 fb ff ff 	mov    -0x498(%rbp),%rcx
    5487:	48 63 31             	movslq (%rcx),%rsi
    548a:	45 31 c0             	xor    %r8d,%r8d
    548d:	4c 89 42 18          	mov    %r8,0x18(%rdx)
    5491:	48 89 72 20          	mov    %rsi,0x20(%rdx)
    5495:	48 8b b5 38 fc ff ff 	mov    -0x3c8(%rbp),%rsi
    549c:	48 89 72 28          	mov    %rsi,0x28(%rdx)
    54a0:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    54a6:	48 8b b5 50 fc ff ff 	mov    -0x3b0(%rbp),%rsi
    54ad:	48 89 f1             	mov    %rsi,%rcx
    54b0:	49 d3 e0             	shl    %cl,%r8
    54b3:	49 01 f8             	add    %rdi,%r8
    54b6:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    54bb:	bf 02 00 00 00       	mov    $0x2,%edi
    54c0:	4c 89 cf             	mov    %r9,%rdi
    54c3:	48 89 ce             	mov    %rcx,%rsi
    54c6:	48 89 95 80 fb ff ff 	mov    %rdx,-0x480(%rbp)
    54cd:	48 8b 95 50 fc ff ff 	mov    -0x3b0(%rbp),%rdx
    54d4:	4c 89 c1             	mov    %r8,%rcx
    54d7:	4d 89 d8             	mov    %r11,%r8
    54da:	4c 8b 8d 80 fb ff ff 	mov    -0x480(%rbp),%r9
    54e1:	41 bb 02 00 00 00    	mov    $0x2,%r11d
    54e7:	4c 89 1c 24          	mov    %r11,(%rsp)
    54eb:	e8 e0 ab ff ff       	call   0xd0
    54f0:	48 83 f8 00          	cmp    $0x0,%rax
    54f4:	0f 8d 11 00 00 00    	jge    0x550b
    54fa:	b8 80 00 00 00       	mov    $0x80,%eax
    54ff:	48 89 85 48 fb ff ff 	mov    %rax,-0x4b8(%rbp)
    5506:	e9 3f 1c 00 00       	jmp    0x714a
    550b:	e9 78 0a 00 00       	jmp    0x5f88
    5510:	49 83 fd 05          	cmp    $0x5,%r13
    5514:	0f 85 d1 00 00 00    	jne    0x55eb
    551a:	48 8b 85 50 fb ff ff 	mov    -0x4b0(%rbp),%rax
    5521:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    5528:	48 89 c2             	mov    %rax,%rdx
    552b:	48 29 ca             	sub    %rcx,%rdx
    552e:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    5535:	48 39 f2             	cmp    %rsi,%rdx
    5538:	bf 00 00 00 00       	mov    $0x0,%edi
    553d:	40 0f 92 c7          	setb   %dil
    5541:	45 31 c0             	xor    %r8d,%r8d
    5544:	48 85 ff             	test   %rdi,%rdi
    5547:	49 0f 44 d0          	cmove  %r8,%rdx
    554b:	49 89 d1             	mov    %rdx,%r9
    554e:	49 c1 e9 06          	shr    $0x6,%r9
    5552:	48 83 e2 3f          	and    $0x3f,%rdx
    5556:	4c 8b 95 70 fc ff ff 	mov    -0x390(%rbp),%r10
    555d:	4f 8d 1c ca          	lea    (%r10,%r9,8),%r11
    5561:	49 8b 03             	mov    (%r11),%rax
    5564:	48 89 d1             	mov    %rdx,%rcx
    5567:	48 d3 e8             	shr    %cl,%rax
    556a:	b9 01 00 00 00       	mov    $0x1,%ecx
    556f:	48 21 c8             	and    %rcx,%rax
    5572:	48 21 f8             	and    %rdi,%rax
    5575:	48 8b bd 48 fc ff ff 	mov    -0x3b8(%rbp),%rdi
    557c:	4e 8d 1c cf          	lea    (%rdi,%r9,8),%r11
    5580:	49 8b 3b             	mov    (%r11),%rdi
    5583:	48 89 d1             	mov    %rdx,%rcx
    5586:	48 d3 ef             	shr    %cl,%rdi
    5589:	b9 01 00 00 00       	mov    $0x1,%ecx
    558e:	48 21 cf             	and    %rcx,%rdi
    5591:	4c 8b 9d 58 fc ff ff 	mov    -0x3a8(%rbp),%r11
    5598:	4b 8d 34 cb          	lea    (%r11,%r9,8),%rsi
    559c:	4c 8b 0e             	mov    (%rsi),%r9
    559f:	48 89 d1             	mov    %rdx,%rcx
    55a2:	49 d3 e9             	shr    %cl,%r9
    55a5:	b9 01 00 00 00       	mov    $0x1,%ecx
    55aa:	49 21 c9             	and    %rcx,%r9
    55ad:	48 8d 95 d0 fc ff ff 	lea    -0x330(%rbp),%rdx
    55b4:	48 89 d6             	mov    %rdx,%rsi
    55b7:	49 c1 e1 20          	shl    $0x20,%r9
    55bb:	48 8b 95 50 fb ff ff 	mov    -0x4b0(%rbp),%rdx
    55c2:	48 89 16             	mov    %rdx,(%rsi)
    55c5:	4c 89 4e 08          	mov    %r9,0x8(%rsi)
    55c9:	48 89 7e 10          	mov    %rdi,0x10(%rsi)
    55cd:	4c 39 c0             	cmp    %r8,%rax
    55d0:	b8 00 00 00 00       	mov    $0x0,%eax
    55d5:	0f 95 c0             	setne  %al
    55d8:	48 85 c0             	test   %rax,%rax
    55db:	49 0f 44 f0          	cmove  %r8,%rsi
    55df:	48 89 b5 80 fb ff ff 	mov    %rsi,-0x480(%rbp)
    55e6:	e9 f1 01 00 00       	jmp    0x57dc
    55eb:	49 83 fd 01          	cmp    $0x1,%r13
    55ef:	0f 85 ee 00 00 00    	jne    0x56e3
    55f5:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    55fc:	79 37 9e 
    55ff:	48 8b 8d 50 fb ff ff 	mov    -0x4b0(%rbp),%rcx
    5606:	48 89 ca             	mov    %rcx,%rdx
    5609:	48 c1 ea 2b          	shr    $0x2b,%rdx
    560d:	48 89 ce             	mov    %rcx,%rsi
    5610:	48 c1 ee 2c          	shr    $0x2c,%rsi
    5614:	48 31 f2             	xor    %rsi,%rdx
    5617:	48 89 ce             	mov    %rcx,%rsi
    561a:	48 31 d6             	xor    %rdx,%rsi
    561d:	48 0f af f0          	imul   %rax,%rsi
    5621:	b8 40 00 00 00       	mov    $0x40,%eax
    5626:	48 8b 95 78 fc ff ff 	mov    -0x388(%rbp),%rdx
    562d:	48 29 d0             	sub    %rdx,%rax
    5630:	48 89 c1             	mov    %rax,%rcx
    5633:	48 89 f7             	mov    %rsi,%rdi
    5636:	48 d3 ef             	shr    %cl,%rdi
    5639:	31 c0                	xor    %eax,%eax
    563b:	48 39 c2             	cmp    %rax,%rdx
    563e:	b9 00 00 00 00       	mov    $0x0,%ecx
    5643:	0f 94 c1             	sete   %cl
    5646:	48 85 c9             	test   %rcx,%rcx
    5649:	48 0f 44 c7          	cmove  %rdi,%rax
    564d:	48 8b 8d 70 fc ff ff 	mov    -0x390(%rbp),%rcx
    5654:	48 8d 3c c1          	lea    (%rcx,%rax,8),%rdi
    5658:	48 8b 07             	mov    (%rdi),%rax
    565b:	48 bf ff ff ff ff ff 	movabs $0xffffffffffff,%rdi
    5662:	ff 00 00 
    5665:	49 89 c0             	mov    %rax,%r8
    5668:	49 21 f8             	and    %rdi,%r8
    566b:	31 ff                	xor    %edi,%edi
    566d:	49 39 f8             	cmp    %rdi,%r8
    5670:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    5676:	41 0f 94 c1          	sete   %r9b
    567a:	49 89 f2             	mov    %rsi,%r10
    567d:	49 c1 ea 20          	shr    $0x20,%r10
    5681:	4c 31 d6             	xor    %r10,%rsi
    5684:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
    568a:	4c 21 d6             	and    %r10,%rsi
    568d:	48 83 e6 0f          	and    $0xf,%rsi
    5691:	48 83 c6 30          	add    $0x30,%rsi
    5695:	48 89 f1             	mov    %rsi,%rcx
    5698:	48 d3 e8             	shr    %cl,%rax
    569b:	48 83 e0 01          	and    $0x1,%rax
    569f:	48 83 f8 00          	cmp    $0x0,%rax
    56a3:	b8 00 00 00 00       	mov    $0x0,%eax
    56a8:	0f 95 c0             	setne  %al
    56ab:	b9 01 00 00 00       	mov    $0x1,%ecx
    56b0:	48 31 c8             	xor    %rcx,%rax
    56b3:	49 09 c1             	or     %rax,%r9
    56b6:	b8 01 00 00 00       	mov    $0x1,%eax
    56bb:	49 29 c0             	sub    %rax,%r8
    56be:	b9 18 00 00 00       	mov    $0x18,%ecx
    56c3:	4c 0f af c1          	imul   %rcx,%r8
    56c7:	4c 89 f1             	mov    %r14,%rcx
    56ca:	4c 01 c1             	add    %r8,%rcx
    56cd:	48 89 fe             	mov    %rdi,%rsi
    56d0:	4d 85 c9             	test   %r9,%r9
    56d3:	48 0f 44 f1          	cmove  %rcx,%rsi
    56d7:	48 89 b5 80 fb ff ff 	mov    %rsi,-0x480(%rbp)
    56de:	e9 f9 00 00 00       	jmp    0x57dc
    56e3:	48 8b 85 50 fb ff ff 	mov    -0x4b0(%rbp),%rax
    56ea:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    56f1:	48 89 c2             	mov    %rax,%rdx
    56f4:	48 29 ca             	sub    %rcx,%rdx
    56f7:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    56fe:	48 39 f2             	cmp    %rsi,%rdx
    5701:	0f 82 0e 00 00 00    	jb     0x5715
    5707:	31 ff                	xor    %edi,%edi
    5709:	48 89 bd 80 fb ff ff 	mov    %rdi,-0x480(%rbp)
    5710:	e9 c7 00 00 00       	jmp    0x57dc
    5715:	49 83 fd 02          	cmp    $0x2,%r13
    5719:	48 89 95 78 fb ff ff 	mov    %rdx,-0x488(%rbp)
    5720:	0f 85 6a 00 00 00    	jne    0x5790
    5726:	48 89 d7             	mov    %rdx,%rdi
    5729:	48 c1 ef 06          	shr    $0x6,%rdi
    572d:	4c 8b 85 70 fc ff ff 	mov    -0x390(%rbp),%r8
    5734:	4d 8d 0c f8          	lea    (%r8,%rdi,8),%r9
    5738:	49 8b 39             	mov    (%r9),%rdi
    573b:	49 89 d1             	mov    %rdx,%r9
    573e:	49 83 e1 3f          	and    $0x3f,%r9
    5742:	4c 89 c9             	mov    %r9,%rcx
    5745:	48 d3 ef             	shr    %cl,%rdi
    5748:	b9 01 00 00 00       	mov    $0x1,%ecx
    574d:	48 21 cf             	and    %rcx,%rdi
    5750:	45 31 c9             	xor    %r9d,%r9d
    5753:	4c 39 cf             	cmp    %r9,%rdi
    5756:	bf 00 00 00 00       	mov    $0x0,%edi
    575b:	40 0f 95 c7          	setne  %dil
    575f:	41 ba 10 00 00 00    	mov    $0x10,%r10d
    5765:	49 89 d3             	mov    %rdx,%r11
    5768:	4d 0f af da          	imul   %r10,%r11
    576c:	4c 8b 95 80 fc ff ff 	mov    -0x380(%rbp),%r10
    5773:	4c 89 d2             	mov    %r10,%rdx
    5776:	4c 01 da             	add    %r11,%rdx
    5779:	48 83 ea 08          	sub    $0x8,%rdx
    577d:	48 85 ff             	test   %rdi,%rdi
    5780:	49 0f 44 d1          	cmove  %r9,%rdx
    5784:	48 89 95 80 fb ff ff 	mov    %rdx,-0x480(%rbp)
    578b:	e9 4c 00 00 00       	jmp    0x57dc
    5790:	48 8b 85 70 fc ff ff 	mov    -0x390(%rbp),%rax
    5797:	48 8b 8d 78 fb ff ff 	mov    -0x488(%rbp),%rcx
    579e:	48 8d 14 88          	lea    (%rax,%rcx,4),%rdx
    57a2:	8b 0a                	mov    (%rdx),%ecx
    57a4:	ba 01 00 00 00       	mov    $0x1,%edx
    57a9:	48 89 ce             	mov    %rcx,%rsi
    57ac:	48 29 d6             	sub    %rdx,%rsi
    57af:	bf 18 00 00 00       	mov    $0x18,%edi
    57b4:	48 0f af f7          	imul   %rdi,%rsi
    57b8:	4c 89 f7             	mov    %r14,%rdi
    57bb:	48 01 f7             	add    %rsi,%rdi
    57be:	31 f6                	xor    %esi,%esi
    57c0:	48 39 f1             	cmp    %rsi,%rcx
    57c3:	b9 00 00 00 00       	mov    $0x0,%ecx
    57c8:	0f 94 c1             	sete   %cl
    57cb:	49 89 f0             	mov    %rsi,%r8
    57ce:	48 85 c9             	test   %rcx,%rcx
    57d1:	4c 0f 44 c7          	cmove  %rdi,%r8
    57d5:	4c 89 85 80 fb ff ff 	mov    %r8,-0x480(%rbp)
    57dc:	49 83 fd 01          	cmp    $0x1,%r13
    57e0:	be 00 00 00 00       	mov    $0x0,%esi
    57e5:	40 0f 95 c6          	setne  %sil
    57e9:	31 ff                	xor    %edi,%edi
    57eb:	48 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%rax
    57f2:	48 89 85 78 fb ff ff 	mov    %rax,-0x488(%rbp)
    57f9:	48 8b 85 18 fc ff ff 	mov    -0x3e8(%rbp),%rax
    5800:	48 89 85 70 fb ff ff 	mov    %rax,-0x490(%rbp)
    5807:	48 8b 85 60 fb ff ff 	mov    -0x4a0(%rbp),%rax
    580e:	48 89 85 e8 fa ff ff 	mov    %rax,-0x518(%rbp)
    5815:	48 8b 85 98 fb ff ff 	mov    -0x468(%rbp),%rax
    581c:	48 89 85 20 fb ff ff 	mov    %rax,-0x4e0(%rbp)
    5823:	48 8b 85 a8 fb ff ff 	mov    -0x458(%rbp),%rax
    582a:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    5831:	48 8b 85 90 fb ff ff 	mov    -0x470(%rbp),%rax
    5838:	48 89 85 40 fb ff ff 	mov    %rax,-0x4c0(%rbp)
    583f:	48 8b 85 b8 fb ff ff 	mov    -0x448(%rbp),%rax
    5846:	48 89 85 e0 fa ff ff 	mov    %rax,-0x520(%rbp)
    584d:	48 8b 85 c0 fb ff ff 	mov    -0x440(%rbp),%rax
    5854:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    585b:	48 8b 85 80 fb ff ff 	mov    -0x480(%rbp),%rax
    5862:	48 85 c0             	test   %rax,%rax
    5865:	0f 85 75 00 00 00    	jne    0x58e0
    586b:	48 8b 8d 78 fb ff ff 	mov    -0x488(%rbp),%rcx
    5872:	48 89 8d 40 fc ff ff 	mov    %rcx,-0x3c0(%rbp)
    5879:	48 8b 8d 70 fb ff ff 	mov    -0x490(%rbp),%rcx
    5880:	48 89 8d 18 fc ff ff 	mov    %rcx,-0x3e8(%rbp)
    5887:	48 8b 8d e8 fa ff ff 	mov    -0x518(%rbp),%rcx
    588e:	48 89 8d 60 fb ff ff 	mov    %rcx,-0x4a0(%rbp)
    5895:	48 8b 8d 20 fb ff ff 	mov    -0x4e0(%rbp),%rcx
    589c:	48 89 8d 98 fb ff ff 	mov    %rcx,-0x468(%rbp)
    58a3:	48 8b 8d 18 fb ff ff 	mov    -0x4e8(%rbp),%rcx
    58aa:	48 89 8d a8 fb ff ff 	mov    %rcx,-0x458(%rbp)
    58b1:	48 8b 8d 40 fb ff ff 	mov    -0x4c0(%rbp),%rcx
    58b8:	48 89 8d 90 fb ff ff 	mov    %rcx,-0x470(%rbp)
    58bf:	48 8b 8d e0 fa ff ff 	mov    -0x520(%rbp),%rcx
    58c6:	48 89 8d b8 fb ff ff 	mov    %rcx,-0x448(%rbp)
    58cd:	48 8b 8d 10 fb ff ff 	mov    -0x4f0(%rbp),%rcx
    58d4:	48 89 8d c0 fb ff ff 	mov    %rcx,-0x440(%rbp)
    58db:	e9 a3 06 00 00       	jmp    0x5f83
    58e0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    58e4:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    58e9:	49 89 c8             	mov    %rcx,%r8
    58ec:	49 21 d0             	and    %rdx,%r8
    58ef:	ba 01 00 00 00       	mov    $0x1,%edx
    58f4:	4d 89 c1             	mov    %r8,%r9
    58f7:	49 29 d1             	sub    %rdx,%r9
    58fa:	41 ba 18 00 00 00    	mov    $0x18,%r10d
    5900:	4d 0f af ca          	imul   %r10,%r9
    5904:	4d 89 f2             	mov    %r14,%r10
    5907:	4d 01 ca             	add    %r9,%r10
    590a:	45 31 c9             	xor    %r9d,%r9d
    590d:	4d 39 c8             	cmp    %r9,%r8
    5910:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    5916:	41 0f 94 c0          	sete   %r8b
    591a:	4d 89 cb             	mov    %r9,%r11
    591d:	4d 85 c0             	test   %r8,%r8
    5920:	4d 0f 44 da          	cmove  %r10,%r11
    5924:	4c 8b 00             	mov    (%rax),%r8
    5927:	4c 8b 95 50 fb ff ff 	mov    -0x4b0(%rbp),%r10
    592e:	4d 39 c2             	cmp    %r8,%r10
    5931:	b8 00 00 00 00       	mov    $0x0,%eax
    5936:	0f 94 c0             	sete   %al
    5939:	48 09 f0             	or     %rsi,%rax
    593c:	49 89 f8             	mov    %rdi,%r8
    593f:	49 01 d0             	add    %rdx,%r8
    5942:	48 85 c0             	test   %rax,%rax
    5945:	0f 85 0c 00 00 00    	jne    0x5957
    594b:	4c 89 9d 80 fb ff ff 	mov    %r11,-0x480(%rbp)
    5952:	e9 04 ff ff ff       	jmp    0x585b
    5957:	48 8b 03             	mov    (%rbx),%rax
    595a:	48 39 c7             	cmp    %rax,%rdi
    595d:	0f 8d 0f 00 00 00    	jge    0x5972
    5963:	4c 89 9d 80 fb ff ff 	mov    %r11,-0x480(%rbp)
    596a:	4c 89 c7             	mov    %r8,%rdi
    596d:	e9 e9 fe ff ff       	jmp    0x585b
    5972:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    5979:	48 8b 70 18          	mov    0x18(%rax),%rsi
    597d:	48 85 f6             	test   %rsi,%rsi
    5980:	48 89 8d 50 fb ff ff 	mov    %rcx,-0x4b0(%rbp)
    5987:	4c 89 85 f8 fa ff ff 	mov    %r8,-0x508(%rbp)
    598e:	0f 84 0c 00 00 00    	je     0x59a0
    5994:	0f b6 3e             	movzbl (%rsi),%edi
    5997:	48 85 ff             	test   %rdi,%rdi
    599a:	0f 85 fb 05 00 00    	jne    0x5f9b
    59a0:	48 8b 85 80 fb ff ff 	mov    -0x480(%rbp),%rax
    59a7:	48 8b 48 10          	mov    0x10(%rax),%rcx
    59ab:	48 8b 95 50 fb ff ff 	mov    -0x4b0(%rbp),%rdx
    59b2:	48 89 d6             	mov    %rdx,%rsi
    59b5:	48 c1 ee 20          	shr    $0x20,%rsi
    59b9:	48 83 e6 01          	and    $0x1,%rsi
    59bd:	48 83 fe 00          	cmp    $0x0,%rsi
    59c1:	be 00 00 00 00       	mov    $0x0,%esi
    59c6:	40 0f 95 c6          	setne  %sil
    59ca:	48 8b bd f8 fa ff ff 	mov    -0x508(%rbp),%rdi
    59d1:	48 89 3b             	mov    %rdi,(%rbx)
    59d4:	4c 8b 85 78 fb ff ff 	mov    -0x488(%rbp),%r8
    59db:	4d 89 c1             	mov    %r8,%r9
    59de:	49 83 c1 01          	add    $0x1,%r9
    59e2:	48 63 c9             	movslq %ecx,%rcx
    59e5:	45 31 d2             	xor    %r10d,%r10d
    59e8:	48 85 f6             	test   %rsi,%rsi
    59eb:	4c 0f 44 d1          	cmove  %rcx,%r10
    59ef:	48 8b 8d 70 fb ff ff 	mov    -0x490(%rbp),%rcx
    59f6:	4c 39 d1             	cmp    %r10,%rcx
    59f9:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    59ff:	41 0f 94 c3          	sete   %r11b
    5a03:	48 8b 85 e8 fa ff ff 	mov    -0x518(%rbp),%rax
    5a0a:	48 39 f0             	cmp    %rsi,%rax
    5a0d:	ba 00 00 00 00       	mov    $0x0,%edx
    5a12:	0f 94 c2             	sete   %dl
    5a15:	49 21 d3             	and    %rdx,%r11
    5a18:	4d 85 db             	test   %r11,%r11
    5a1b:	48 89 b5 00 fb ff ff 	mov    %rsi,-0x500(%rbp)
    5a22:	4c 89 8d 08 fb ff ff 	mov    %r9,-0x4f8(%rbp)
    5a29:	4c 89 95 30 fb ff ff 	mov    %r10,-0x4d0(%rbp)
    5a30:	0f 84 83 00 00 00    	je     0x5ab9
    5a36:	48 8b 95 40 fb ff ff 	mov    -0x4c0(%rbp),%rdx
    5a3d:	49 89 d3             	mov    %rdx,%r11
    5a40:	49 83 c3 01          	add    $0x1,%r11
    5a44:	be 01 00 00 00       	mov    $0x1,%esi
    5a49:	4c 8b 95 68 fb ff ff 	mov    -0x498(%rbp),%r10
    5a50:	4d 63 0a             	movslq (%r10),%r9
    5a53:	4c 8b 95 38 fc ff ff 	mov    -0x3c8(%rbp),%r10
    5a5a:	4c 89 d2             	mov    %r10,%rdx
    5a5d:	48 31 f2             	xor    %rsi,%rdx
    5a60:	31 f6                	xor    %esi,%esi
    5a62:	48 85 d2             	test   %rdx,%rdx
    5a65:	4c 0f 44 ce          	cmove  %rsi,%r9
    5a69:	48 8b b5 10 fb ff ff 	mov    -0x4f0(%rbp),%rsi
    5a70:	49 89 f2             	mov    %rsi,%r10
    5a73:	49 01 d2             	add    %rdx,%r10
    5a76:	48 8b 95 e0 fa ff ff 	mov    -0x520(%rbp),%rdx
    5a7d:	48 89 d6             	mov    %rdx,%rsi
    5a80:	4c 01 ce             	add    %r9,%rsi
    5a83:	48 89 8d 18 fc ff ff 	mov    %rcx,-0x3e8(%rbp)
    5a8a:	48 89 85 60 fb ff ff 	mov    %rax,-0x4a0(%rbp)
    5a91:	4c 8b 8d 20 fb ff ff 	mov    -0x4e0(%rbp),%r9
    5a98:	4c 89 8d 98 fb ff ff 	mov    %r9,-0x468(%rbp)
    5a9f:	4c 89 9d 90 fb ff ff 	mov    %r11,-0x470(%rbp)
    5aa6:	48 89 b5 b8 fb ff ff 	mov    %rsi,-0x448(%rbp)
    5aad:	4c 89 95 c0 fb ff ff 	mov    %r10,-0x440(%rbp)
    5ab4:	e9 b0 04 00 00       	jmp    0x5f69
    5ab9:	48 8b 85 18 fb ff ff 	mov    -0x4e8(%rbp),%rax
    5ac0:	48 85 c0             	test   %rax,%rax
    5ac3:	0f 84 04 04 00 00    	je     0x5ecd
    5ac9:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    5ad0:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    5ad4:	48 85 d2             	test   %rdx,%rdx
    5ad7:	0f 84 40 01 00 00    	je     0x5c1d
    5add:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    5ae1:	be 40 00 00 00       	mov    $0x40,%esi
    5ae6:	48 29 d6             	sub    %rdx,%rsi
    5ae9:	48 8b bd 20 fb ff ff 	mov    -0x4e0(%rbp),%rdi
    5af0:	48 89 f1             	mov    %rsi,%rcx
    5af3:	49 89 f8             	mov    %rdi,%r8
    5af6:	49 d3 e8             	shr    %cl,%r8
    5af9:	31 c9                	xor    %ecx,%ecx
    5afb:	48 39 ca             	cmp    %rcx,%rdx
    5afe:	ba 00 00 00 00       	mov    $0x0,%edx
    5b03:	0f 94 c2             	sete   %dl
    5b06:	48 85 d2             	test   %rdx,%rdx
    5b09:	49 0f 44 c8          	cmove  %r8,%rcx
    5b0d:	48 8b 95 90 fc ff ff 	mov    -0x370(%rbp),%rdx
    5b14:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    5b18:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    5b1c:	49 8b 30             	mov    (%r8),%rsi
    5b1f:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    5b26:	00 28 00 
    5b29:	4c 39 ce             	cmp    %r9,%rsi
    5b2c:	4c 89 85 d0 fa ff ff 	mov    %r8,-0x530(%rbp)
    5b33:	0f 82 0c 00 00 00    	jb     0x5b45
    5b39:	48 89 b5 c8 fb ff ff 	mov    %rsi,-0x438(%rbp)
    5b40:	e9 4a 00 00 00       	jmp    0x5b8f
    5b45:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    5b49:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    5b50:	48 89 b5 d8 fa ff ff 	mov    %rsi,-0x528(%rbp)
    5b57:	48 89 d6             	mov    %rdx,%rsi
    5b5a:	48 89 ca             	mov    %rcx,%rdx
    5b5d:	48 8b 8d d8 fa ff ff 	mov    -0x528(%rbp),%rcx
    5b64:	e8 77 a5 ff ff       	call   0xe0
    5b69:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    5b70:	31 d2                	xor    %edx,%edx
    5b72:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    5b76:	48 83 f8 00          	cmp    $0x0,%rax
    5b7a:	0f 8f 08 00 00 00    	jg     0x5b88
    5b80:	49 89 c4             	mov    %rax,%r12
    5b83:	e9 e3 15 00 00       	jmp    0x716b
    5b88:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    5b8f:	48 8b 85 c8 fb ff ff 	mov    -0x438(%rbp),%rax
    5b96:	48 89 c1             	mov    %rax,%rcx
    5b99:	48 83 c1 28          	add    $0x28,%rcx
    5b9d:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    5ba4:	00 28 00 
    5ba7:	48 29 d1             	sub    %rdx,%rcx
    5baa:	48 8b 95 d0 fa ff ff 	mov    -0x530(%rbp),%rdx
    5bb1:	48 89 0a             	mov    %rcx,(%rdx)
    5bb4:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    5bbb:	ff 00 00 
    5bbe:	48 21 c8             	and    %rcx,%rax
    5bc1:	31 c9                	xor    %ecx,%ecx
    5bc3:	48 8b 95 70 fb ff ff 	mov    -0x490(%rbp),%rdx
    5bca:	48 89 10             	mov    %rdx,(%rax)
    5bcd:	48 8b b5 e8 fa ff ff 	mov    -0x518(%rbp),%rsi
    5bd4:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5bd8:	48 89 48 10          	mov    %rcx,0x10(%rax)
    5bdc:	48 89 48 18          	mov    %rcx,0x18(%rax)
    5be0:	48 89 48 20          	mov    %rcx,0x20(%rax)
    5be4:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    5beb:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    5bef:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    5bf5:	4c 01 c7             	add    %r8,%rdi
    5bf8:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    5bfc:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    5c03:	b8 01 00 00 00       	mov    $0x1,%eax
    5c08:	48 89 85 d0 fa ff ff 	mov    %rax,-0x530(%rbp)
    5c0f:	31 c0                	xor    %eax,%eax
    5c11:	48 89 85 d8 fa ff ff 	mov    %rax,-0x528(%rbp)
    5c18:	e9 a2 01 00 00       	jmp    0x5dbf
    5c1d:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    5c24:	48 8b 48 10          	mov    0x10(%rax),%rcx
    5c28:	48 8b 50 18          	mov    0x18(%rax),%rdx
    5c2c:	48 89 d6             	mov    %rdx,%rsi
    5c2f:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    5c34:	bf 40 00 00 00       	mov    $0x40,%edi
    5c39:	48 29 f7             	sub    %rsi,%rdi
    5c3c:	48 89 8d b8 fa ff ff 	mov    %rcx,-0x548(%rbp)
    5c43:	4c 8b 85 20 fb ff ff 	mov    -0x4e0(%rbp),%r8
    5c4a:	48 89 f9             	mov    %rdi,%rcx
    5c4d:	4d 89 c1             	mov    %r8,%r9
    5c50:	49 d3 e9             	shr    %cl,%r9
    5c53:	31 c9                	xor    %ecx,%ecx
    5c55:	48 39 ce             	cmp    %rcx,%rsi
    5c58:	be 00 00 00 00       	mov    $0x0,%esi
    5c5d:	40 0f 94 c6          	sete   %sil
    5c61:	48 85 f6             	test   %rsi,%rsi
    5c64:	49 0f 44 c9          	cmove  %r9,%rcx
    5c68:	be 01 00 00 00       	mov    $0x1,%esi
    5c6d:	48 89 cf             	mov    %rcx,%rdi
    5c70:	48 01 f7             	add    %rsi,%rdi
    5c73:	48 21 d7             	and    %rdx,%rdi
    5c76:	ba 28 00 00 00       	mov    $0x28,%edx
    5c7b:	48 0f af ca          	imul   %rdx,%rcx
    5c7f:	48 8b 95 b8 fa ff ff 	mov    -0x548(%rbp),%rdx
    5c86:	4c 8d 0c 0a          	lea    (%rdx,%rcx,1),%r9
    5c8a:	49 8b 49 10          	mov    0x10(%r9),%rcx
    5c8e:	48 85 c9             	test   %rcx,%rcx
    5c91:	0f 84 af 00 00 00    	je     0x5d46
    5c97:	49 8b 09             	mov    (%r9),%rcx
    5c9a:	4d 8b 51 08          	mov    0x8(%r9),%r10
    5c9e:	4c 8b 9d 70 fb ff ff 	mov    -0x490(%rbp),%r11
    5ca5:	49 39 cb             	cmp    %rcx,%r11
    5ca8:	ba 00 00 00 00       	mov    $0x0,%edx
    5cad:	0f 94 c2             	sete   %dl
    5cb0:	48 8b 8d e8 fa ff ff 	mov    -0x518(%rbp),%rcx
    5cb7:	4c 39 d1             	cmp    %r10,%rcx
    5cba:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    5cc0:	41 0f 94 c0          	sete   %r8b
    5cc4:	4c 21 c2             	and    %r8,%rdx
    5cc7:	48 85 d2             	test   %rdx,%rdx
    5cca:	0f 84 0c 00 00 00    	je     0x5cdc
    5cd0:	4c 89 8d c8 fb ff ff 	mov    %r9,-0x438(%rbp)
    5cd7:	e9 53 00 00 00       	jmp    0x5d2f
    5cdc:	ba 28 00 00 00       	mov    $0x28,%edx
    5ce1:	48 0f af fa          	imul   %rdx,%rdi
    5ce5:	48 8b 95 b8 fa ff ff 	mov    -0x548(%rbp),%rdx
    5cec:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    5cf0:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5cf4:	48 85 d2             	test   %rdx,%rdx
    5cf7:	0f 84 49 00 00 00    	je     0x5d46
    5cfd:	49 8b 10             	mov    (%r8),%rdx
    5d00:	49 8b 78 08          	mov    0x8(%r8),%rdi
    5d04:	49 39 d3             	cmp    %rdx,%r11
    5d07:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    5d0d:	41 0f 94 c1          	sete   %r9b
    5d11:	48 39 f9             	cmp    %rdi,%rcx
    5d14:	ba 00 00 00 00       	mov    $0x0,%edx
    5d19:	0f 94 c2             	sete   %dl
    5d1c:	49 21 d1             	and    %rdx,%r9
    5d1f:	4d 85 c9             	test   %r9,%r9
    5d22:	0f 84 1e 00 00 00    	je     0x5d46
    5d28:	4c 89 85 c8 fb ff ff 	mov    %r8,-0x438(%rbp)
    5d2f:	31 c0                	xor    %eax,%eax
    5d31:	48 89 85 d0 fa ff ff 	mov    %rax,-0x530(%rbp)
    5d38:	31 c0                	xor    %eax,%eax
    5d3a:	48 89 85 d8 fa ff ff 	mov    %rax,-0x528(%rbp)
    5d41:	e9 79 00 00 00       	jmp    0x5dbf
    5d46:	48 8d 85 b0 fc ff ff 	lea    -0x350(%rbp),%rax
    5d4d:	48 89 c1             	mov    %rax,%rcx
    5d50:	48 8b 95 70 fb ff ff 	mov    -0x490(%rbp),%rdx
    5d57:	48 89 11             	mov    %rdx,(%rcx)
    5d5a:	48 8b b5 e8 fa ff ff 	mov    -0x518(%rbp),%rsi
    5d61:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    5d65:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    5d6c:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    5d73:	48 89 ca             	mov    %rcx,%rdx
    5d76:	e8 75 a3 ff ff       	call   0xf0
    5d7b:	48 83 f8 00          	cmp    $0x0,%rax
    5d7f:	0f 8d 08 00 00 00    	jge    0x5d8d
    5d85:	49 89 c4             	mov    %rax,%r12
    5d88:	e9 de 13 00 00       	jmp    0x716b
    5d8d:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    5d94:	48 8b 11             	mov    (%rcx),%rdx
    5d97:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    5d9b:	48 83 e6 01          	and    $0x1,%rsi
    5d9f:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    5da3:	48 89 85 c8 fb ff ff 	mov    %rax,-0x438(%rbp)
    5daa:	b8 01 00 00 00       	mov    $0x1,%eax
    5daf:	48 89 85 d0 fa ff ff 	mov    %rax,-0x530(%rbp)
    5db6:	31 c0                	xor    %eax,%eax
    5db8:	48 89 85 d8 fa ff ff 	mov    %rax,-0x528(%rbp)
    5dbf:	48 8b 85 d0 fa ff ff 	mov    -0x530(%rbp),%rax
    5dc6:	48 85 c0             	test   %rax,%rax
    5dc9:	0f 84 6b 00 00 00    	je     0x5e3a
    5dcf:	48 8b 85 c8 fb ff ff 	mov    -0x438(%rbp),%rax
    5dd6:	48 8b 8d 40 fb ff ff 	mov    -0x4c0(%rbp),%rcx
    5ddd:	48 89 48 10          	mov    %rcx,0x10(%rax)
    5de1:	31 d2                	xor    %edx,%edx
    5de3:	48 39 d1             	cmp    %rdx,%rcx
    5de6:	be 00 00 00 00       	mov    $0x0,%esi
    5deb:	40 0f 95 c6          	setne  %sil
    5def:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    5df3:	48 09 f7             	or     %rsi,%rdi
    5df6:	48 0f be ff          	movsbq %dil,%rdi
    5dfa:	40 88 78 20          	mov    %dil,0x20(%rax)
    5dfe:	48 8b b5 e0 fa ff ff 	mov    -0x520(%rbp),%rsi
    5e05:	48 89 70 18          	mov    %rsi,0x18(%rax)
    5e09:	4c 8b 85 10 fb ff ff 	mov    -0x4f0(%rbp),%r8
    5e10:	49 39 d0             	cmp    %rdx,%r8
    5e13:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    5e19:	41 0f 95 c1          	setne  %r9b
    5e1d:	40 0f b6 ff          	movzbl %dil,%edi
    5e21:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    5e27:	4d 85 c9             	test   %r9,%r9
    5e2a:	4c 0f 44 d2          	cmove  %rdx,%r10
    5e2e:	4c 09 d7             	or     %r10,%rdi
    5e31:	40 88 78 20          	mov    %dil,0x20(%rax)
    5e35:	e9 93 00 00 00       	jmp    0x5ecd
    5e3a:	48 8b 85 c8 fb ff ff 	mov    -0x438(%rbp),%rax
    5e41:	48 8b 48 10          	mov    0x10(%rax),%rcx
    5e45:	48 8b 95 40 fb ff ff 	mov    -0x4c0(%rbp),%rdx
    5e4c:	48 01 d1             	add    %rdx,%rcx
    5e4f:	48 89 48 10          	mov    %rcx,0x10(%rax)
    5e53:	31 f6                	xor    %esi,%esi
    5e55:	48 39 f1             	cmp    %rsi,%rcx
    5e58:	b9 00 00 00 00       	mov    $0x0,%ecx
    5e5d:	0f 95 c1             	setne  %cl
    5e60:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    5e64:	48 09 cf             	or     %rcx,%rdi
    5e67:	48 0f be ff          	movsbq %dil,%rdi
    5e6b:	40 88 78 20          	mov    %dil,0x20(%rax)
    5e6f:	48 8b 48 18          	mov    0x18(%rax),%rcx
    5e73:	40 0f b6 ff          	movzbl %dil,%edi
    5e77:	49 89 f8             	mov    %rdi,%r8
    5e7a:	49 83 e0 02          	and    $0x2,%r8
    5e7e:	49 39 f0             	cmp    %rsi,%r8
    5e81:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    5e87:	41 0f 95 c0          	setne  %r8b
    5e8b:	45 31 c9             	xor    %r9d,%r9d
    5e8e:	4d 85 c0             	test   %r8,%r8
    5e91:	49 0f 44 c9          	cmove  %r9,%rcx
    5e95:	4c 8b 8d 10 fb ff ff 	mov    -0x4f0(%rbp),%r9
    5e9c:	4d 01 c8             	add    %r9,%r8
    5e9f:	4c 8b 95 e0 fa ff ff 	mov    -0x520(%rbp),%r10
    5ea6:	4c 01 d1             	add    %r10,%rcx
    5ea9:	48 89 48 18          	mov    %rcx,0x18(%rax)
    5ead:	49 39 f0             	cmp    %rsi,%r8
    5eb0:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    5eb6:	41 0f 95 c0          	setne  %r8b
    5eba:	b9 02 00 00 00       	mov    $0x2,%ecx
    5ebf:	4d 85 c0             	test   %r8,%r8
    5ec2:	48 0f 44 ce          	cmove  %rsi,%rcx
    5ec6:	48 09 cf             	or     %rcx,%rdi
    5ec9:	40 88 78 20          	mov    %dil,0x20(%rax)
    5ecd:	b8 01 00 00 00       	mov    $0x1,%eax
    5ed2:	48 8b 8d 68 fb ff ff 	mov    -0x498(%rbp),%rcx
    5ed9:	48 63 11             	movslq (%rcx),%rdx
    5edc:	48 8b b5 38 fc ff ff 	mov    -0x3c8(%rbp),%rsi
    5ee3:	48 89 f7             	mov    %rsi,%rdi
    5ee6:	48 31 c7             	xor    %rax,%rdi
    5ee9:	31 c0                	xor    %eax,%eax
    5eeb:	48 85 ff             	test   %rdi,%rdi
    5eee:	48 0f 44 d0          	cmove  %rax,%rdx
    5ef2:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    5ef9:	79 37 9e 
    5efc:	49 b8 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%r8
    5f03:	79 37 9e 
    5f06:	4c 8b 8d 30 fb ff ff 	mov    -0x4d0(%rbp),%r9
    5f0d:	4d 31 c8             	xor    %r9,%r8
    5f10:	4c 0f af c0          	imul   %rax,%r8
    5f14:	4d 89 c2             	mov    %r8,%r10
    5f17:	49 c1 ea 1d          	shr    $0x1d,%r10
    5f1b:	4d 31 d0             	xor    %r10,%r8
    5f1e:	4c 8b 95 00 fb ff ff 	mov    -0x500(%rbp),%r10
    5f25:	4d 31 d0             	xor    %r10,%r8
    5f28:	4c 0f af c0          	imul   %rax,%r8
    5f2c:	4d 89 c3             	mov    %r8,%r11
    5f2f:	49 c1 eb 1d          	shr    $0x1d,%r11
    5f33:	4d 31 d8             	xor    %r11,%r8
    5f36:	4c 0f af c0          	imul   %rax,%r8
    5f3a:	4c 89 8d 18 fc ff ff 	mov    %r9,-0x3e8(%rbp)
    5f41:	4c 89 95 60 fb ff ff 	mov    %r10,-0x4a0(%rbp)
    5f48:	4c 89 85 98 fb ff ff 	mov    %r8,-0x468(%rbp)
    5f4f:	b8 01 00 00 00       	mov    $0x1,%eax
    5f54:	48 89 85 90 fb ff ff 	mov    %rax,-0x470(%rbp)
    5f5b:	48 89 95 b8 fb ff ff 	mov    %rdx,-0x448(%rbp)
    5f62:	48 89 bd c0 fb ff ff 	mov    %rdi,-0x440(%rbp)
    5f69:	48 8b 85 08 fb ff ff 	mov    -0x4f8(%rbp),%rax
    5f70:	48 89 85 40 fc ff ff 	mov    %rax,-0x3c0(%rbp)
    5f77:	b8 01 00 00 00       	mov    $0x1,%eax
    5f7c:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
    5f83:	31 c0                	xor    %eax,%eax
    5f85:	48 89 03             	mov    %rax,(%rbx)
    5f88:	b8 01 00 00 00       	mov    $0x1,%eax
    5f8d:	4c 89 f9             	mov    %r15,%rcx
    5f90:	48 01 c1             	add    %rax,%rcx
    5f93:	49 89 cf             	mov    %rcx,%r15
    5f96:	e9 7e f2 ff ff       	jmp    0x5219
    5f9b:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    5fa2:	e8 99 a0 ff ff       	call   0x40
    5fa7:	48 85 c0             	test   %rax,%rax
    5faa:	0f 84 f0 f9 ff ff    	je     0x59a0
    5fb0:	e9 af 11 00 00       	jmp    0x7164
    5fb5:	4c 8b bd 08 fc ff ff 	mov    -0x3f8(%rbp),%r15
    5fbc:	31 c0                	xor    %eax,%eax
    5fbe:	48 89 85 08 fc ff ff 	mov    %rax,-0x3f8(%rbp)
    5fc5:	31 c0                	xor    %eax,%eax
    5fc7:	48 89 85 e0 fb ff ff 	mov    %rax,-0x420(%rbp)
    5fce:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
    5fd5:	82 28 52 
    5fd8:	48 89 85 30 fc ff ff 	mov    %rax,-0x3d0(%rbp)
    5fdf:	31 c0                	xor    %eax,%eax
    5fe1:	48 89 85 20 fc ff ff 	mov    %rax,-0x3e0(%rbp)
    5fe8:	31 c0                	xor    %eax,%eax
    5fea:	48 89 85 10 fc ff ff 	mov    %rax,-0x3f0(%rbp)
    5ff1:	31 c0                	xor    %eax,%eax
    5ff3:	48 89 85 00 fc ff ff 	mov    %rax,-0x400(%rbp)
    5ffa:	31 c0                	xor    %eax,%eax
    5ffc:	48 89 85 f0 fb ff ff 	mov    %rax,-0x410(%rbp)
    6003:	31 c0                	xor    %eax,%eax
    6005:	48 89 85 80 fb ff ff 	mov    %rax,-0x480(%rbp)
    600c:	48 8b 85 f8 fb ff ff 	mov    -0x408(%rbp),%rax
    6013:	49 39 c7             	cmp    %rax,%r15
    6016:	0f 8c 75 00 00 00    	jl     0x6091
    601c:	48 8b 8d f0 fb ff ff 	mov    -0x410(%rbp),%rcx
    6023:	48 89 8d 88 fc ff ff 	mov    %rcx,-0x378(%rbp)
    602a:	48 8b 8d 08 fc ff ff 	mov    -0x3f8(%rbp),%rcx
    6031:	48 89 8d 38 fb ff ff 	mov    %rcx,-0x4c8(%rbp)
    6038:	48 8b 8d e0 fb ff ff 	mov    -0x420(%rbp),%rcx
    603f:	48 89 8d f0 fa ff ff 	mov    %rcx,-0x510(%rbp)
    6046:	48 8b 8d 30 fc ff ff 	mov    -0x3d0(%rbp),%rcx
    604d:	48 89 8d 88 fb ff ff 	mov    %rcx,-0x478(%rbp)
    6054:	48 8b 8d 80 fb ff ff 	mov    -0x480(%rbp),%rcx
    605b:	48 89 8d b0 fb ff ff 	mov    %rcx,-0x450(%rbp)
    6062:	48 8b 8d 20 fc ff ff 	mov    -0x3e0(%rbp),%rcx
    6069:	48 89 8d a0 fb ff ff 	mov    %rcx,-0x460(%rbp)
    6070:	48 8b 8d 10 fc ff ff 	mov    -0x3f0(%rbp),%rcx
    6077:	48 89 8d 28 fb ff ff 	mov    %rcx,-0x4d8(%rbp)
    607e:	48 8b 8d 00 fc ff ff 	mov    -0x400(%rbp),%rcx
    6085:	48 89 8d 58 fb ff ff 	mov    %rcx,-0x4a8(%rbp)
    608c:	e9 ee 0b 00 00       	jmp    0x6c7f
    6091:	48 8b 8d d8 fb ff ff 	mov    -0x428(%rbp),%rcx
    6098:	4a 8d 14 b9          	lea    (%rcx,%r15,4),%rdx
    609c:	48 8b b5 e8 fb ff ff 	mov    -0x418(%rbp),%rsi
    60a3:	4a 8d 3c be          	lea    (%rsi,%r15,4),%rdi
    60a7:	4c 63 02             	movslq (%rdx),%r8
    60aa:	4c 8b 8d 50 fc ff ff 	mov    -0x3b0(%rbp),%r9
    60b1:	4d 85 c9             	test   %r9,%r9
    60b4:	48 89 bd 50 fb ff ff 	mov    %rdi,-0x4b0(%rbp)
    60bb:	4c 89 85 f8 fa ff ff 	mov    %r8,-0x508(%rbp)
    60c2:	0f 84 42 01 00 00    	je     0x620a
    60c8:	49 ba 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%r10
    60cf:	79 37 9e 
    60d2:	4d 89 c3             	mov    %r8,%r11
    60d5:	49 c1 eb 2b          	shr    $0x2b,%r11
    60d9:	4c 89 c1             	mov    %r8,%rcx
    60dc:	48 c1 e9 2c          	shr    $0x2c,%rcx
    60e0:	49 31 cb             	xor    %rcx,%r11
    60e3:	4c 89 c1             	mov    %r8,%rcx
    60e6:	4c 31 d9             	xor    %r11,%rcx
    60e9:	49 0f af ca          	imul   %r10,%rcx
    60ed:	49 89 ca             	mov    %rcx,%r10
    60f0:	49 c1 ea 1e          	shr    $0x1e,%r10
    60f4:	49 89 cb             	mov    %rcx,%r11
    60f7:	4d 31 d3             	xor    %r10,%r11
    60fa:	49 ba b9 e5 e4 1c 6d 	movabs $0xbf58476d1ce4e5b9,%r10
    6101:	47 58 bf 
    6104:	4d 0f af da          	imul   %r10,%r11
    6108:	4d 89 da             	mov    %r11,%r10
    610b:	49 c1 ea 1b          	shr    $0x1b,%r10
    610f:	4d 31 d3             	xor    %r10,%r11
    6112:	49 ba eb 11 31 13 bb 	movabs $0x94d049bb133111eb,%r10
    6119:	49 d0 94 
    611c:	4d 0f af da          	imul   %r10,%r11
    6120:	4d 89 da             	mov    %r11,%r10
    6123:	49 c1 ea 1f          	shr    $0x1f,%r10
    6127:	4d 31 d3             	xor    %r10,%r11
    612a:	41 ba 40 00 00 00    	mov    $0x40,%r10d
    6130:	4d 29 ca             	sub    %r9,%r10
    6133:	48 89 8d 78 fb ff ff 	mov    %rcx,-0x488(%rbp)
    613a:	4c 89 d1             	mov    %r10,%rcx
    613d:	49 d3 eb             	shr    %cl,%r11
    6140:	4c 8b 55 d0          	mov    -0x30(%rbp),%r10
    6144:	4c 89 d9             	mov    %r11,%rcx
    6147:	4d 89 d0             	mov    %r10,%r8
    614a:	49 d3 e8             	shr    %cl,%r8
    614d:	b9 01 00 00 00       	mov    $0x1,%ecx
    6152:	49 21 c8             	and    %rcx,%r8
    6155:	4d 85 c0             	test   %r8,%r8
    6158:	0f 84 ac 00 00 00    	je     0x620a
    615e:	4c 8d 85 60 fd ff ff 	lea    -0x2a0(%rbp),%r8
    6165:	4d 89 c1             	mov    %r8,%r9
    6168:	4c 63 02             	movslq (%rdx),%r8
    616b:	31 d2                	xor    %edx,%edx
    616d:	31 ff                	xor    %edi,%edi
    616f:	49 89 11             	mov    %rdx,(%r9)
    6172:	4d 89 41 08          	mov    %r8,0x8(%r9)
    6176:	49 89 79 10          	mov    %rdi,0x10(%r9)
    617a:	48 8b 95 50 fb ff ff 	mov    -0x4b0(%rbp),%rdx
    6181:	48 63 3a             	movslq (%rdx),%rdi
    6184:	45 31 c0             	xor    %r8d,%r8d
    6187:	31 d2                	xor    %edx,%edx
    6189:	4d 89 41 18          	mov    %r8,0x18(%r9)
    618d:	49 89 79 20          	mov    %rdi,0x20(%r9)
    6191:	49 89 51 28          	mov    %rdx,0x28(%r9)
    6195:	ba 01 00 00 00       	mov    $0x1,%edx
    619a:	48 8b bd 50 fc ff ff 	mov    -0x3b0(%rbp),%rdi
    61a1:	48 89 f9             	mov    %rdi,%rcx
    61a4:	48 d3 e2             	shl    %cl,%rdx
    61a7:	4c 01 da             	add    %r11,%rdx
    61aa:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    61af:	41 b8 02 00 00 00    	mov    $0x2,%r8d
    61b5:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    61bc:	48 89 ce             	mov    %rcx,%rsi
    61bf:	48 89 95 18 fb ff ff 	mov    %rdx,-0x4e8(%rbp)
    61c6:	48 8b 95 50 fc ff ff 	mov    -0x3b0(%rbp),%rdx
    61cd:	48 8b 8d 18 fb ff ff 	mov    -0x4e8(%rbp),%rcx
    61d4:	4c 8b 85 78 fb ff ff 	mov    -0x488(%rbp),%r8
    61db:	41 bb 02 00 00 00    	mov    $0x2,%r11d
    61e1:	4c 89 1c 24          	mov    %r11,(%rsp)
    61e5:	e8 e6 9e ff ff       	call   0xd0
    61ea:	48 83 f8 00          	cmp    $0x0,%rax
    61ee:	0f 8d 11 00 00 00    	jge    0x6205
    61f4:	b8 80 00 00 00       	mov    $0x80,%eax
    61f9:	48 89 85 48 fb ff ff 	mov    %rax,-0x4b8(%rbp)
    6200:	e9 45 0f 00 00       	jmp    0x714a
    6205:	e9 48 0a 00 00       	jmp    0x6c52
    620a:	49 83 fd 05          	cmp    $0x5,%r13
    620e:	0f 85 d1 00 00 00    	jne    0x62e5
    6214:	48 8b 85 f8 fa ff ff 	mov    -0x508(%rbp),%rax
    621b:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    6222:	48 89 c2             	mov    %rax,%rdx
    6225:	48 29 ca             	sub    %rcx,%rdx
    6228:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    622f:	48 39 f2             	cmp    %rsi,%rdx
    6232:	bf 00 00 00 00       	mov    $0x0,%edi
    6237:	40 0f 92 c7          	setb   %dil
    623b:	45 31 c0             	xor    %r8d,%r8d
    623e:	48 85 ff             	test   %rdi,%rdi
    6241:	49 0f 44 d0          	cmove  %r8,%rdx
    6245:	49 89 d1             	mov    %rdx,%r9
    6248:	49 c1 e9 06          	shr    $0x6,%r9
    624c:	48 83 e2 3f          	and    $0x3f,%rdx
    6250:	4c 8b 95 70 fc ff ff 	mov    -0x390(%rbp),%r10
    6257:	4f 8d 1c ca          	lea    (%r10,%r9,8),%r11
    625b:	49 8b 03             	mov    (%r11),%rax
    625e:	48 89 d1             	mov    %rdx,%rcx
    6261:	48 d3 e8             	shr    %cl,%rax
    6264:	b9 01 00 00 00       	mov    $0x1,%ecx
    6269:	48 21 c8             	and    %rcx,%rax
    626c:	48 21 f8             	and    %rdi,%rax
    626f:	48 8b bd 48 fc ff ff 	mov    -0x3b8(%rbp),%rdi
    6276:	4e 8d 1c cf          	lea    (%rdi,%r9,8),%r11
    627a:	49 8b 3b             	mov    (%r11),%rdi
    627d:	48 89 d1             	mov    %rdx,%rcx
    6280:	48 d3 ef             	shr    %cl,%rdi
    6283:	b9 01 00 00 00       	mov    $0x1,%ecx
    6288:	48 21 cf             	and    %rcx,%rdi
    628b:	4c 8b 9d 58 fc ff ff 	mov    -0x3a8(%rbp),%r11
    6292:	4b 8d 34 cb          	lea    (%r11,%r9,8),%rsi
    6296:	4c 8b 0e             	mov    (%rsi),%r9
    6299:	48 89 d1             	mov    %rdx,%rcx
    629c:	49 d3 e9             	shr    %cl,%r9
    629f:	b9 01 00 00 00       	mov    $0x1,%ecx
    62a4:	49 21 c9             	and    %rcx,%r9
    62a7:	48 8d 95 40 fd ff ff 	lea    -0x2c0(%rbp),%rdx
    62ae:	48 89 d6             	mov    %rdx,%rsi
    62b1:	49 c1 e1 20          	shl    $0x20,%r9
    62b5:	48 8b 95 f8 fa ff ff 	mov    -0x508(%rbp),%rdx
    62bc:	48 89 16             	mov    %rdx,(%rsi)
    62bf:	4c 89 4e 08          	mov    %r9,0x8(%rsi)
    62c3:	48 89 7e 10          	mov    %rdi,0x10(%rsi)
    62c7:	4c 39 c0             	cmp    %r8,%rax
    62ca:	b8 00 00 00 00       	mov    $0x0,%eax
    62cf:	0f 95 c0             	setne  %al
    62d2:	48 85 c0             	test   %rax,%rax
    62d5:	49 0f 44 f0          	cmove  %r8,%rsi
    62d9:	48 89 b5 78 fb ff ff 	mov    %rsi,-0x488(%rbp)
    62e0:	e9 f1 01 00 00       	jmp    0x64d6
    62e5:	49 83 fd 01          	cmp    $0x1,%r13
    62e9:	0f 85 ee 00 00 00    	jne    0x63dd
    62ef:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    62f6:	79 37 9e 
    62f9:	48 8b 8d f8 fa ff ff 	mov    -0x508(%rbp),%rcx
    6300:	48 89 ca             	mov    %rcx,%rdx
    6303:	48 c1 ea 2b          	shr    $0x2b,%rdx
    6307:	48 89 ce             	mov    %rcx,%rsi
    630a:	48 c1 ee 2c          	shr    $0x2c,%rsi
    630e:	48 31 f2             	xor    %rsi,%rdx
    6311:	48 89 ce             	mov    %rcx,%rsi
    6314:	48 31 d6             	xor    %rdx,%rsi
    6317:	48 0f af f0          	imul   %rax,%rsi
    631b:	b8 40 00 00 00       	mov    $0x40,%eax
    6320:	48 8b 95 78 fc ff ff 	mov    -0x388(%rbp),%rdx
    6327:	48 29 d0             	sub    %rdx,%rax
    632a:	48 89 c1             	mov    %rax,%rcx
    632d:	48 89 f7             	mov    %rsi,%rdi
    6330:	48 d3 ef             	shr    %cl,%rdi
    6333:	31 c0                	xor    %eax,%eax
    6335:	48 39 c2             	cmp    %rax,%rdx
    6338:	b9 00 00 00 00       	mov    $0x0,%ecx
    633d:	0f 94 c1             	sete   %cl
    6340:	48 85 c9             	test   %rcx,%rcx
    6343:	48 0f 44 c7          	cmove  %rdi,%rax
    6347:	48 8b 8d 70 fc ff ff 	mov    -0x390(%rbp),%rcx
    634e:	48 8d 3c c1          	lea    (%rcx,%rax,8),%rdi
    6352:	48 8b 07             	mov    (%rdi),%rax
    6355:	48 bf ff ff ff ff ff 	movabs $0xffffffffffff,%rdi
    635c:	ff 00 00 
    635f:	49 89 c0             	mov    %rax,%r8
    6362:	49 21 f8             	and    %rdi,%r8
    6365:	31 ff                	xor    %edi,%edi
    6367:	49 39 f8             	cmp    %rdi,%r8
    636a:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    6370:	41 0f 94 c1          	sete   %r9b
    6374:	49 89 f2             	mov    %rsi,%r10
    6377:	49 c1 ea 20          	shr    $0x20,%r10
    637b:	4c 31 d6             	xor    %r10,%rsi
    637e:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
    6384:	4c 21 d6             	and    %r10,%rsi
    6387:	48 83 e6 0f          	and    $0xf,%rsi
    638b:	48 83 c6 30          	add    $0x30,%rsi
    638f:	48 89 f1             	mov    %rsi,%rcx
    6392:	48 d3 e8             	shr    %cl,%rax
    6395:	48 83 e0 01          	and    $0x1,%rax
    6399:	48 83 f8 00          	cmp    $0x0,%rax
    639d:	b8 00 00 00 00       	mov    $0x0,%eax
    63a2:	0f 95 c0             	setne  %al
    63a5:	b9 01 00 00 00       	mov    $0x1,%ecx
    63aa:	48 31 c8             	xor    %rcx,%rax
    63ad:	49 09 c1             	or     %rax,%r9
    63b0:	b8 01 00 00 00       	mov    $0x1,%eax
    63b5:	49 29 c0             	sub    %rax,%r8
    63b8:	b9 18 00 00 00       	mov    $0x18,%ecx
    63bd:	4c 0f af c1          	imul   %rcx,%r8
    63c1:	4c 89 f1             	mov    %r14,%rcx
    63c4:	4c 01 c1             	add    %r8,%rcx
    63c7:	48 89 fe             	mov    %rdi,%rsi
    63ca:	4d 85 c9             	test   %r9,%r9
    63cd:	48 0f 44 f1          	cmove  %rcx,%rsi
    63d1:	48 89 b5 78 fb ff ff 	mov    %rsi,-0x488(%rbp)
    63d8:	e9 f9 00 00 00       	jmp    0x64d6
    63dd:	48 8b 85 f8 fa ff ff 	mov    -0x508(%rbp),%rax
    63e4:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
    63eb:	48 89 c2             	mov    %rax,%rdx
    63ee:	48 29 ca             	sub    %rcx,%rdx
    63f1:	48 8b b5 60 fc ff ff 	mov    -0x3a0(%rbp),%rsi
    63f8:	48 39 f2             	cmp    %rsi,%rdx
    63fb:	0f 82 0e 00 00 00    	jb     0x640f
    6401:	31 ff                	xor    %edi,%edi
    6403:	48 89 bd 78 fb ff ff 	mov    %rdi,-0x488(%rbp)
    640a:	e9 c7 00 00 00       	jmp    0x64d6
    640f:	49 83 fd 02          	cmp    $0x2,%r13
    6413:	48 89 95 18 fb ff ff 	mov    %rdx,-0x4e8(%rbp)
    641a:	0f 85 6a 00 00 00    	jne    0x648a
    6420:	48 89 d7             	mov    %rdx,%rdi
    6423:	48 c1 ef 06          	shr    $0x6,%rdi
    6427:	4c 8b 85 70 fc ff ff 	mov    -0x390(%rbp),%r8
    642e:	4d 8d 0c f8          	lea    (%r8,%rdi,8),%r9
    6432:	49 8b 39             	mov    (%r9),%rdi
    6435:	49 89 d1             	mov    %rdx,%r9
    6438:	49 83 e1 3f          	and    $0x3f,%r9
    643c:	4c 89 c9             	mov    %r9,%rcx
    643f:	48 d3 ef             	shr    %cl,%rdi
    6442:	b9 01 00 00 00       	mov    $0x1,%ecx
    6447:	48 21 cf             	and    %rcx,%rdi
    644a:	45 31 c9             	xor    %r9d,%r9d
    644d:	4c 39 cf             	cmp    %r9,%rdi
    6450:	bf 00 00 00 00       	mov    $0x0,%edi
    6455:	40 0f 95 c7          	setne  %dil
    6459:	41 ba 10 00 00 00    	mov    $0x10,%r10d
    645f:	49 89 d3             	mov    %rdx,%r11
    6462:	4d 0f af da          	imul   %r10,%r11
    6466:	4c 8b 95 80 fc ff ff 	mov    -0x380(%rbp),%r10
    646d:	4c 89 d2             	mov    %r10,%rdx
    6470:	4c 01 da             	add    %r11,%rdx
    6473:	48 83 ea 08          	sub    $0x8,%rdx
    6477:	48 85 ff             	test   %rdi,%rdi
    647a:	49 0f 44 d1          	cmove  %r9,%rdx
    647e:	48 89 95 78 fb ff ff 	mov    %rdx,-0x488(%rbp)
    6485:	e9 4c 00 00 00       	jmp    0x64d6
    648a:	48 8b 85 70 fc ff ff 	mov    -0x390(%rbp),%rax
    6491:	48 8b 8d 18 fb ff ff 	mov    -0x4e8(%rbp),%rcx
    6498:	48 8d 14 88          	lea    (%rax,%rcx,4),%rdx
    649c:	8b 0a                	mov    (%rdx),%ecx
    649e:	ba 01 00 00 00       	mov    $0x1,%edx
    64a3:	48 89 ce             	mov    %rcx,%rsi
    64a6:	48 29 d6             	sub    %rdx,%rsi
    64a9:	bf 18 00 00 00       	mov    $0x18,%edi
    64ae:	48 0f af f7          	imul   %rdi,%rsi
    64b2:	4c 89 f7             	mov    %r14,%rdi
    64b5:	48 01 f7             	add    %rsi,%rdi
    64b8:	31 f6                	xor    %esi,%esi
    64ba:	48 39 f1             	cmp    %rsi,%rcx
    64bd:	b9 00 00 00 00       	mov    $0x0,%ecx
    64c2:	0f 94 c1             	sete   %cl
    64c5:	49 89 f0             	mov    %rsi,%r8
    64c8:	48 85 c9             	test   %rcx,%rcx
    64cb:	4c 0f 44 c7          	cmove  %rdi,%r8
    64cf:	4c 89 85 78 fb ff ff 	mov    %r8,-0x488(%rbp)
    64d6:	49 83 fd 01          	cmp    $0x1,%r13
    64da:	be 00 00 00 00       	mov    $0x0,%esi
    64df:	40 0f 95 c6          	setne  %sil
    64e3:	31 ff                	xor    %edi,%edi
    64e5:	48 8b 85 f0 fb ff ff 	mov    -0x410(%rbp),%rax
    64ec:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
    64f3:	48 8b 85 08 fc ff ff 	mov    -0x3f8(%rbp),%rax
    64fa:	48 89 85 20 fb ff ff 	mov    %rax,-0x4e0(%rbp)
    6501:	48 8b 85 e0 fb ff ff 	mov    -0x420(%rbp),%rax
    6508:	48 89 85 70 fb ff ff 	mov    %rax,-0x490(%rbp)
    650f:	48 8b 85 30 fc ff ff 	mov    -0x3d0(%rbp),%rax
    6516:	48 89 85 e8 fa ff ff 	mov    %rax,-0x518(%rbp)
    651d:	48 8b 85 80 fb ff ff 	mov    -0x480(%rbp),%rax
    6524:	48 89 85 40 fb ff ff 	mov    %rax,-0x4c0(%rbp)
    652b:	48 8b 85 20 fc ff ff 	mov    -0x3e0(%rbp),%rax
    6532:	48 89 85 10 fb ff ff 	mov    %rax,-0x4f0(%rbp)
    6539:	48 8b 85 10 fc ff ff 	mov    -0x3f0(%rbp),%rax
    6540:	48 89 85 e0 fa ff ff 	mov    %rax,-0x520(%rbp)
    6547:	48 8b 85 00 fc ff ff 	mov    -0x400(%rbp),%rax
    654e:	48 89 85 68 fb ff ff 	mov    %rax,-0x498(%rbp)
    6555:	48 8b 85 78 fb ff ff 	mov    -0x488(%rbp),%rax
    655c:	48 85 c0             	test   %rax,%rax
    655f:	0f 85 75 00 00 00    	jne    0x65da
    6565:	48 8b 8d 18 fb ff ff 	mov    -0x4e8(%rbp),%rcx
    656c:	48 89 8d f0 fb ff ff 	mov    %rcx,-0x410(%rbp)
    6573:	48 8b 8d 20 fb ff ff 	mov    -0x4e0(%rbp),%rcx
    657a:	48 89 8d 08 fc ff ff 	mov    %rcx,-0x3f8(%rbp)
    6581:	48 8b 8d 70 fb ff ff 	mov    -0x490(%rbp),%rcx
    6588:	48 89 8d e0 fb ff ff 	mov    %rcx,-0x420(%rbp)
    658f:	48 8b 8d e8 fa ff ff 	mov    -0x518(%rbp),%rcx
    6596:	48 89 8d 30 fc ff ff 	mov    %rcx,-0x3d0(%rbp)
    659d:	48 8b 8d 40 fb ff ff 	mov    -0x4c0(%rbp),%rcx
    65a4:	48 89 8d 80 fb ff ff 	mov    %rcx,-0x480(%rbp)
    65ab:	48 8b 8d 10 fb ff ff 	mov    -0x4f0(%rbp),%rcx
    65b2:	48 89 8d 20 fc ff ff 	mov    %rcx,-0x3e0(%rbp)
    65b9:	48 8b 8d e0 fa ff ff 	mov    -0x520(%rbp),%rcx
    65c0:	48 89 8d 10 fc ff ff 	mov    %rcx,-0x3f0(%rbp)
    65c7:	48 8b 8d 68 fb ff ff 	mov    -0x498(%rbp),%rcx
    65ce:	48 89 8d 00 fc ff ff 	mov    %rcx,-0x400(%rbp)
    65d5:	e9 73 06 00 00       	jmp    0x6c4d
    65da:	48 8b 48 08          	mov    0x8(%rax),%rcx
    65de:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    65e3:	49 89 c8             	mov    %rcx,%r8
    65e6:	49 21 d0             	and    %rdx,%r8
    65e9:	ba 01 00 00 00       	mov    $0x1,%edx
    65ee:	4d 89 c1             	mov    %r8,%r9
    65f1:	49 29 d1             	sub    %rdx,%r9
    65f4:	41 ba 18 00 00 00    	mov    $0x18,%r10d
    65fa:	4d 0f af ca          	imul   %r10,%r9
    65fe:	4d 89 f2             	mov    %r14,%r10
    6601:	4d 01 ca             	add    %r9,%r10
    6604:	45 31 c9             	xor    %r9d,%r9d
    6607:	4d 39 c8             	cmp    %r9,%r8
    660a:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    6610:	41 0f 94 c0          	sete   %r8b
    6614:	4d 89 cb             	mov    %r9,%r11
    6617:	4d 85 c0             	test   %r8,%r8
    661a:	4d 0f 44 da          	cmove  %r10,%r11
    661e:	4c 8b 00             	mov    (%rax),%r8
    6621:	4c 8b 95 f8 fa ff ff 	mov    -0x508(%rbp),%r10
    6628:	4d 39 c2             	cmp    %r8,%r10
    662b:	b8 00 00 00 00       	mov    $0x0,%eax
    6630:	0f 94 c0             	sete   %al
    6633:	48 09 f0             	or     %rsi,%rax
    6636:	49 89 f8             	mov    %rdi,%r8
    6639:	49 01 d0             	add    %rdx,%r8
    663c:	48 85 c0             	test   %rax,%rax
    663f:	0f 85 0c 00 00 00    	jne    0x6651
    6645:	4c 89 9d 78 fb ff ff 	mov    %r11,-0x488(%rbp)
    664c:	e9 04 ff ff ff       	jmp    0x6555
    6651:	48 8b 03             	mov    (%rbx),%rax
    6654:	48 39 c7             	cmp    %rax,%rdi
    6657:	0f 8d 0f 00 00 00    	jge    0x666c
    665d:	4c 89 9d 78 fb ff ff 	mov    %r11,-0x488(%rbp)
    6664:	4c 89 c7             	mov    %r8,%rdi
    6667:	e9 e9 fe ff ff       	jmp    0x6555
    666c:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    6673:	48 8b 70 18          	mov    0x18(%rax),%rsi
    6677:	48 85 f6             	test   %rsi,%rsi
    667a:	48 89 8d f8 fa ff ff 	mov    %rcx,-0x508(%rbp)
    6681:	4c 89 85 38 fc ff ff 	mov    %r8,-0x3c8(%rbp)
    6688:	0f 84 0c 00 00 00    	je     0x669a
    668e:	0f b6 3e             	movzbl (%rsi),%edi
    6691:	48 85 ff             	test   %rdi,%rdi
    6694:	0f 85 cb 05 00 00    	jne    0x6c65
    669a:	48 8b 85 78 fb ff ff 	mov    -0x488(%rbp),%rax
    66a1:	48 8b 48 10          	mov    0x10(%rax),%rcx
    66a5:	48 8b 95 f8 fa ff ff 	mov    -0x508(%rbp),%rdx
    66ac:	48 89 d6             	mov    %rdx,%rsi
    66af:	48 c1 ee 20          	shr    $0x20,%rsi
    66b3:	48 83 e6 01          	and    $0x1,%rsi
    66b7:	48 83 fe 00          	cmp    $0x0,%rsi
    66bb:	be 00 00 00 00       	mov    $0x0,%esi
    66c0:	40 0f 95 c6          	setne  %sil
    66c4:	48 8b bd 38 fc ff ff 	mov    -0x3c8(%rbp),%rdi
    66cb:	48 89 3b             	mov    %rdi,(%rbx)
    66ce:	4c 8b 85 18 fb ff ff 	mov    -0x4e8(%rbp),%r8
    66d5:	4d 89 c1             	mov    %r8,%r9
    66d8:	49 83 c1 01          	add    $0x1,%r9
    66dc:	48 63 c9             	movslq %ecx,%rcx
    66df:	45 31 d2             	xor    %r10d,%r10d
    66e2:	48 85 f6             	test   %rsi,%rsi
    66e5:	4c 0f 44 d1          	cmove  %rcx,%r10
    66e9:	48 8b 8d 20 fb ff ff 	mov    -0x4e0(%rbp),%rcx
    66f0:	4c 39 d1             	cmp    %r10,%rcx
    66f3:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    66f9:	41 0f 94 c3          	sete   %r11b
    66fd:	48 8b 85 70 fb ff ff 	mov    -0x490(%rbp),%rax
    6704:	48 39 f0             	cmp    %rsi,%rax
    6707:	ba 00 00 00 00       	mov    $0x0,%edx
    670c:	0f 94 c2             	sete   %dl
    670f:	49 21 d3             	and    %rdx,%r11
    6712:	4d 85 db             	test   %r11,%r11
    6715:	48 89 b5 40 fc ff ff 	mov    %rsi,-0x3c0(%rbp)
    671c:	4c 89 8d 18 fc ff ff 	mov    %r9,-0x3e8(%rbp)
    6723:	4c 89 95 60 fb ff ff 	mov    %r10,-0x4a0(%rbp)
    672a:	0f 84 69 00 00 00    	je     0x6799
    6730:	48 8b 95 10 fb ff ff 	mov    -0x4f0(%rbp),%rdx
    6737:	49 89 d3             	mov    %rdx,%r11
    673a:	49 83 c3 01          	add    $0x1,%r11
    673e:	48 8b b5 50 fb ff ff 	mov    -0x4b0(%rbp),%rsi
    6745:	4c 63 16             	movslq (%rsi),%r10
    6748:	4c 8b 8d 68 fb ff ff 	mov    -0x498(%rbp),%r9
    674f:	4c 89 ce             	mov    %r9,%rsi
    6752:	48 83 c6 01          	add    $0x1,%rsi
    6756:	4c 8b 8d e0 fa ff ff 	mov    -0x520(%rbp),%r9
    675d:	4c 89 ca             	mov    %r9,%rdx
    6760:	4c 01 d2             	add    %r10,%rdx
    6763:	48 89 8d 08 fc ff ff 	mov    %rcx,-0x3f8(%rbp)
    676a:	48 89 85 e0 fb ff ff 	mov    %rax,-0x420(%rbp)
    6771:	4c 8b 95 e8 fa ff ff 	mov    -0x518(%rbp),%r10
    6778:	4c 89 95 30 fc ff ff 	mov    %r10,-0x3d0(%rbp)
    677f:	4c 89 9d 20 fc ff ff 	mov    %r11,-0x3e0(%rbp)
    6786:	48 89 95 10 fc ff ff 	mov    %rdx,-0x3f0(%rbp)
    678d:	48 89 b5 00 fc ff ff 	mov    %rsi,-0x400(%rbp)
    6794:	e9 9a 04 00 00       	jmp    0x6c33
    6799:	48 8b 85 40 fb ff ff 	mov    -0x4c0(%rbp),%rax
    67a0:	48 85 c0             	test   %rax,%rax
    67a3:	0f 84 04 04 00 00    	je     0x6bad
    67a9:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    67b0:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    67b4:	48 85 d2             	test   %rdx,%rdx
    67b7:	0f 84 40 01 00 00    	je     0x68fd
    67bd:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    67c1:	be 40 00 00 00       	mov    $0x40,%esi
    67c6:	48 29 d6             	sub    %rdx,%rsi
    67c9:	48 8b bd e8 fa ff ff 	mov    -0x518(%rbp),%rdi
    67d0:	48 89 f1             	mov    %rsi,%rcx
    67d3:	49 89 f8             	mov    %rdi,%r8
    67d6:	49 d3 e8             	shr    %cl,%r8
    67d9:	31 c9                	xor    %ecx,%ecx
    67db:	48 39 ca             	cmp    %rcx,%rdx
    67de:	ba 00 00 00 00       	mov    $0x0,%edx
    67e3:	0f 94 c2             	sete   %dl
    67e6:	48 85 d2             	test   %rdx,%rdx
    67e9:	49 0f 44 c8          	cmove  %r8,%rcx
    67ed:	48 8b 95 90 fc ff ff 	mov    -0x370(%rbp),%rdx
    67f4:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    67f8:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    67fc:	49 8b 30             	mov    (%r8),%rsi
    67ff:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    6806:	00 28 00 
    6809:	4c 39 ce             	cmp    %r9,%rsi
    680c:	4c 89 85 98 fb ff ff 	mov    %r8,-0x468(%rbp)
    6813:	0f 82 0c 00 00 00    	jb     0x6825
    6819:	48 89 b5 a8 fb ff ff 	mov    %rsi,-0x458(%rbp)
    6820:	e9 4a 00 00 00       	jmp    0x686f
    6825:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    6829:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    6830:	48 89 b5 90 fb ff ff 	mov    %rsi,-0x470(%rbp)
    6837:	48 89 d6             	mov    %rdx,%rsi
    683a:	48 89 ca             	mov    %rcx,%rdx
    683d:	48 8b 8d 90 fb ff ff 	mov    -0x470(%rbp),%rcx
    6844:	e8 97 98 ff ff       	call   0xe0
    6849:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    6850:	31 d2                	xor    %edx,%edx
    6852:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    6856:	48 83 f8 00          	cmp    $0x0,%rax
    685a:	0f 8f 08 00 00 00    	jg     0x6868
    6860:	49 89 c4             	mov    %rax,%r12
    6863:	e9 03 09 00 00       	jmp    0x716b
    6868:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
    686f:	48 8b 85 a8 fb ff ff 	mov    -0x458(%rbp),%rax
    6876:	48 89 c1             	mov    %rax,%rcx
    6879:	48 83 c1 28          	add    $0x28,%rcx
    687d:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    6884:	00 28 00 
    6887:	48 29 d1             	sub    %rdx,%rcx
    688a:	48 8b 95 98 fb ff ff 	mov    -0x468(%rbp),%rdx
    6891:	48 89 0a             	mov    %rcx,(%rdx)
    6894:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    689b:	ff 00 00 
    689e:	48 21 c8             	and    %rcx,%rax
    68a1:	31 c9                	xor    %ecx,%ecx
    68a3:	48 8b 95 20 fb ff ff 	mov    -0x4e0(%rbp),%rdx
    68aa:	48 89 10             	mov    %rdx,(%rax)
    68ad:	48 8b b5 70 fb ff ff 	mov    -0x490(%rbp),%rsi
    68b4:	48 89 70 08          	mov    %rsi,0x8(%rax)
    68b8:	48 89 48 10          	mov    %rcx,0x10(%rax)
    68bc:	48 89 48 18          	mov    %rcx,0x18(%rax)
    68c0:	48 89 48 20          	mov    %rcx,0x20(%rax)
    68c4:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    68cb:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    68cf:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    68d5:	4c 01 c7             	add    %r8,%rdi
    68d8:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    68dc:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
    68e3:	b8 01 00 00 00       	mov    $0x1,%eax
    68e8:	48 89 85 98 fb ff ff 	mov    %rax,-0x468(%rbp)
    68ef:	31 c0                	xor    %eax,%eax
    68f1:	48 89 85 90 fb ff ff 	mov    %rax,-0x470(%rbp)
    68f8:	e9 a2 01 00 00       	jmp    0x6a9f
    68fd:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    6904:	48 8b 48 10          	mov    0x10(%rax),%rcx
    6908:	48 8b 50 18          	mov    0x18(%rax),%rdx
    690c:	48 89 d6             	mov    %rdx,%rsi
    690f:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    6914:	bf 40 00 00 00       	mov    $0x40,%edi
    6919:	48 29 f7             	sub    %rsi,%rdi
    691c:	48 89 8d b8 fb ff ff 	mov    %rcx,-0x448(%rbp)
    6923:	4c 8b 85 e8 fa ff ff 	mov    -0x518(%rbp),%r8
    692a:	48 89 f9             	mov    %rdi,%rcx
    692d:	4d 89 c1             	mov    %r8,%r9
    6930:	49 d3 e9             	shr    %cl,%r9
    6933:	31 c9                	xor    %ecx,%ecx
    6935:	48 39 ce             	cmp    %rcx,%rsi
    6938:	be 00 00 00 00       	mov    $0x0,%esi
    693d:	40 0f 94 c6          	sete   %sil
    6941:	48 85 f6             	test   %rsi,%rsi
    6944:	49 0f 44 c9          	cmove  %r9,%rcx
    6948:	be 01 00 00 00       	mov    $0x1,%esi
    694d:	48 89 cf             	mov    %rcx,%rdi
    6950:	48 01 f7             	add    %rsi,%rdi
    6953:	48 21 d7             	and    %rdx,%rdi
    6956:	ba 28 00 00 00       	mov    $0x28,%edx
    695b:	48 0f af ca          	imul   %rdx,%rcx
    695f:	48 8b 95 b8 fb ff ff 	mov    -0x448(%rbp),%rdx
    6966:	4c 8d 0c 0a          	lea    (%rdx,%rcx,1),%r9
    696a:	49 8b 49 10          	mov    0x10(%r9),%rcx
    696e:	48 85 c9             	test   %rcx,%rcx
    6971:	0f 84 af 00 00 00    	je     0x6a26
    6977:	49 8b 09             	mov    (%r9),%rcx
    697a:	4d 8b 51 08          	mov    0x8(%r9),%r10
    697e:	4c 8b 9d 20 fb ff ff 	mov    -0x4e0(%rbp),%r11
    6985:	49 39 cb             	cmp    %rcx,%r11
    6988:	ba 00 00 00 00       	mov    $0x0,%edx
    698d:	0f 94 c2             	sete   %dl
    6990:	48 8b 8d 70 fb ff ff 	mov    -0x490(%rbp),%rcx
    6997:	4c 39 d1             	cmp    %r10,%rcx
    699a:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    69a0:	41 0f 94 c0          	sete   %r8b
    69a4:	4c 21 c2             	and    %r8,%rdx
    69a7:	48 85 d2             	test   %rdx,%rdx
    69aa:	0f 84 0c 00 00 00    	je     0x69bc
    69b0:	4c 89 8d a8 fb ff ff 	mov    %r9,-0x458(%rbp)
    69b7:	e9 53 00 00 00       	jmp    0x6a0f
    69bc:	ba 28 00 00 00       	mov    $0x28,%edx
    69c1:	48 0f af fa          	imul   %rdx,%rdi
    69c5:	48 8b 95 b8 fb ff ff 	mov    -0x448(%rbp),%rdx
    69cc:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    69d0:	49 8b 50 10          	mov    0x10(%r8),%rdx
    69d4:	48 85 d2             	test   %rdx,%rdx
    69d7:	0f 84 49 00 00 00    	je     0x6a26
    69dd:	49 8b 10             	mov    (%r8),%rdx
    69e0:	49 8b 78 08          	mov    0x8(%r8),%rdi
    69e4:	49 39 d3             	cmp    %rdx,%r11
    69e7:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    69ed:	41 0f 94 c1          	sete   %r9b
    69f1:	48 39 f9             	cmp    %rdi,%rcx
    69f4:	ba 00 00 00 00       	mov    $0x0,%edx
    69f9:	0f 94 c2             	sete   %dl
    69fc:	49 21 d1             	and    %rdx,%r9
    69ff:	4d 85 c9             	test   %r9,%r9
    6a02:	0f 84 1e 00 00 00    	je     0x6a26
    6a08:	4c 89 85 a8 fb ff ff 	mov    %r8,-0x458(%rbp)
    6a0f:	31 c0                	xor    %eax,%eax
    6a11:	48 89 85 98 fb ff ff 	mov    %rax,-0x468(%rbp)
    6a18:	31 c0                	xor    %eax,%eax
    6a1a:	48 89 85 90 fb ff ff 	mov    %rax,-0x470(%rbp)
    6a21:	e9 79 00 00 00       	jmp    0x6a9f
    6a26:	48 8d 85 20 fd ff ff 	lea    -0x2e0(%rbp),%rax
    6a2d:	48 89 c1             	mov    %rax,%rcx
    6a30:	48 8b 95 20 fb ff ff 	mov    -0x4e0(%rbp),%rdx
    6a37:	48 89 11             	mov    %rdx,(%rcx)
    6a3a:	48 8b b5 70 fb ff ff 	mov    -0x490(%rbp),%rsi
    6a41:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    6a45:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    6a4c:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    6a53:	48 89 ca             	mov    %rcx,%rdx
    6a56:	e8 95 96 ff ff       	call   0xf0
    6a5b:	48 83 f8 00          	cmp    $0x0,%rax
    6a5f:	0f 8d 08 00 00 00    	jge    0x6a6d
    6a65:	49 89 c4             	mov    %rax,%r12
    6a68:	e9 fe 06 00 00       	jmp    0x716b
    6a6d:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    6a74:	48 8b 11             	mov    (%rcx),%rdx
    6a77:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    6a7b:	48 83 e6 01          	and    $0x1,%rsi
    6a7f:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    6a83:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
    6a8a:	b8 01 00 00 00       	mov    $0x1,%eax
    6a8f:	48 89 85 98 fb ff ff 	mov    %rax,-0x468(%rbp)
    6a96:	31 c0                	xor    %eax,%eax
    6a98:	48 89 85 90 fb ff ff 	mov    %rax,-0x470(%rbp)
    6a9f:	48 8b 85 98 fb ff ff 	mov    -0x468(%rbp),%rax
    6aa6:	48 85 c0             	test   %rax,%rax
    6aa9:	0f 84 6b 00 00 00    	je     0x6b1a
    6aaf:	48 8b 85 a8 fb ff ff 	mov    -0x458(%rbp),%rax
    6ab6:	48 8b 8d 10 fb ff ff 	mov    -0x4f0(%rbp),%rcx
    6abd:	48 89 48 10          	mov    %rcx,0x10(%rax)
    6ac1:	31 d2                	xor    %edx,%edx
    6ac3:	48 39 d1             	cmp    %rdx,%rcx
    6ac6:	be 00 00 00 00       	mov    $0x0,%esi
    6acb:	40 0f 95 c6          	setne  %sil
    6acf:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    6ad3:	48 09 f7             	or     %rsi,%rdi
    6ad6:	48 0f be ff          	movsbq %dil,%rdi
    6ada:	40 88 78 20          	mov    %dil,0x20(%rax)
    6ade:	48 8b b5 e0 fa ff ff 	mov    -0x520(%rbp),%rsi
    6ae5:	48 89 70 18          	mov    %rsi,0x18(%rax)
    6ae9:	4c 8b 85 68 fb ff ff 	mov    -0x498(%rbp),%r8
    6af0:	49 39 d0             	cmp    %rdx,%r8
    6af3:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    6af9:	41 0f 95 c1          	setne  %r9b
    6afd:	40 0f b6 ff          	movzbl %dil,%edi
    6b01:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    6b07:	4d 85 c9             	test   %r9,%r9
    6b0a:	4c 0f 44 d2          	cmove  %rdx,%r10
    6b0e:	4c 09 d7             	or     %r10,%rdi
    6b11:	40 88 78 20          	mov    %dil,0x20(%rax)
    6b15:	e9 93 00 00 00       	jmp    0x6bad
    6b1a:	48 8b 85 a8 fb ff ff 	mov    -0x458(%rbp),%rax
    6b21:	48 8b 48 10          	mov    0x10(%rax),%rcx
    6b25:	48 8b 95 10 fb ff ff 	mov    -0x4f0(%rbp),%rdx
    6b2c:	48 01 d1             	add    %rdx,%rcx
    6b2f:	48 89 48 10          	mov    %rcx,0x10(%rax)
    6b33:	31 f6                	xor    %esi,%esi
    6b35:	48 39 f1             	cmp    %rsi,%rcx
    6b38:	b9 00 00 00 00       	mov    $0x0,%ecx
    6b3d:	0f 95 c1             	setne  %cl
    6b40:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    6b44:	48 09 cf             	or     %rcx,%rdi
    6b47:	48 0f be ff          	movsbq %dil,%rdi
    6b4b:	40 88 78 20          	mov    %dil,0x20(%rax)
    6b4f:	48 8b 48 18          	mov    0x18(%rax),%rcx
    6b53:	40 0f b6 ff          	movzbl %dil,%edi
    6b57:	49 89 f8             	mov    %rdi,%r8
    6b5a:	49 83 e0 02          	and    $0x2,%r8
    6b5e:	49 39 f0             	cmp    %rsi,%r8
    6b61:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    6b67:	41 0f 95 c0          	setne  %r8b
    6b6b:	45 31 c9             	xor    %r9d,%r9d
    6b6e:	4d 85 c0             	test   %r8,%r8
    6b71:	49 0f 44 c9          	cmove  %r9,%rcx
    6b75:	4c 8b 8d 68 fb ff ff 	mov    -0x498(%rbp),%r9
    6b7c:	4d 01 c8             	add    %r9,%r8
    6b7f:	4c 8b 95 e0 fa ff ff 	mov    -0x520(%rbp),%r10
    6b86:	4c 01 d1             	add    %r10,%rcx
    6b89:	48 89 48 18          	mov    %rcx,0x18(%rax)
    6b8d:	49 39 f0             	cmp    %rsi,%r8
    6b90:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    6b96:	41 0f 95 c0          	setne  %r8b
    6b9a:	b9 02 00 00 00       	mov    $0x2,%ecx
    6b9f:	4d 85 c0             	test   %r8,%r8
    6ba2:	48 0f 44 ce          	cmove  %rsi,%rcx
    6ba6:	48 09 cf             	or     %rcx,%rdi
    6ba9:	40 88 78 20          	mov    %dil,0x20(%rax)
    6bad:	48 8b 85 50 fb ff ff 	mov    -0x4b0(%rbp),%rax
    6bb4:	48 63 08             	movslq (%rax),%rcx
    6bb7:	48 ba 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rdx
    6bbe:	79 37 9e 
    6bc1:	48 be 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%rsi
    6bc8:	79 37 9e 
    6bcb:	48 8b bd 60 fb ff ff 	mov    -0x4a0(%rbp),%rdi
    6bd2:	48 31 fe             	xor    %rdi,%rsi
    6bd5:	48 0f af f2          	imul   %rdx,%rsi
    6bd9:	49 89 f0             	mov    %rsi,%r8
    6bdc:	49 c1 e8 1d          	shr    $0x1d,%r8
    6be0:	4c 31 c6             	xor    %r8,%rsi
    6be3:	4c 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%r8
    6bea:	4c 31 c6             	xor    %r8,%rsi
    6bed:	48 0f af f2          	imul   %rdx,%rsi
    6bf1:	49 89 f1             	mov    %rsi,%r9
    6bf4:	49 c1 e9 1d          	shr    $0x1d,%r9
    6bf8:	4c 31 ce             	xor    %r9,%rsi
    6bfb:	48 0f af f2          	imul   %rdx,%rsi
    6bff:	48 89 bd 08 fc ff ff 	mov    %rdi,-0x3f8(%rbp)
    6c06:	4c 89 85 e0 fb ff ff 	mov    %r8,-0x420(%rbp)
    6c0d:	48 89 b5 30 fc ff ff 	mov    %rsi,-0x3d0(%rbp)
    6c14:	ba 01 00 00 00       	mov    $0x1,%edx
    6c19:	48 89 95 20 fc ff ff 	mov    %rdx,-0x3e0(%rbp)
    6c20:	48 89 8d 10 fc ff ff 	mov    %rcx,-0x3f0(%rbp)
    6c27:	ba 01 00 00 00       	mov    $0x1,%edx
    6c2c:	48 89 95 00 fc ff ff 	mov    %rdx,-0x400(%rbp)
    6c33:	48 8b 85 18 fc ff ff 	mov    -0x3e8(%rbp),%rax
    6c3a:	48 89 85 f0 fb ff ff 	mov    %rax,-0x410(%rbp)
    6c41:	b8 01 00 00 00       	mov    $0x1,%eax
    6c46:	48 89 85 80 fb ff ff 	mov    %rax,-0x480(%rbp)
    6c4d:	31 c0                	xor    %eax,%eax
    6c4f:	48 89 03             	mov    %rax,(%rbx)
    6c52:	b8 01 00 00 00       	mov    $0x1,%eax
    6c57:	4c 89 f9             	mov    %r15,%rcx
    6c5a:	48 01 c1             	add    %rax,%rcx
    6c5d:	49 89 cf             	mov    %rcx,%r15
    6c60:	e9 a7 f3 ff ff       	jmp    0x600c
    6c65:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    6c6c:	e8 cf 93 ff ff       	call   0x40
    6c71:	48 85 c0             	test   %rax,%rax
    6c74:	0f 84 20 fa ff ff    	je     0x669a
    6c7a:	e9 e5 04 00 00       	jmp    0x7164
    6c7f:	48 8b 85 b0 fb ff ff 	mov    -0x450(%rbp),%rax
    6c86:	48 85 c0             	test   %rax,%rax
    6c89:	0f 84 ac 03 00 00    	je     0x703b
    6c8f:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    6c96:	48 8b 48 68          	mov    0x68(%rax),%rcx
    6c9a:	48 85 c9             	test   %rcx,%rcx
    6c9d:	0f 84 1f 01 00 00    	je     0x6dc2
    6ca3:	48 8b 48 38          	mov    0x38(%rax),%rcx
    6ca7:	ba 40 00 00 00       	mov    $0x40,%edx
    6cac:	48 29 ca             	sub    %rcx,%rdx
    6caf:	48 89 8d b0 fb ff ff 	mov    %rcx,-0x450(%rbp)
    6cb6:	48 8b b5 88 fb ff ff 	mov    -0x478(%rbp),%rsi
    6cbd:	48 89 d1             	mov    %rdx,%rcx
    6cc0:	48 89 f7             	mov    %rsi,%rdi
    6cc3:	48 d3 ef             	shr    %cl,%rdi
    6cc6:	31 c9                	xor    %ecx,%ecx
    6cc8:	48 8b 95 b0 fb ff ff 	mov    -0x450(%rbp),%rdx
    6ccf:	48 39 ca             	cmp    %rcx,%rdx
    6cd2:	ba 00 00 00 00       	mov    $0x0,%edx
    6cd7:	0f 94 c2             	sete   %dl
    6cda:	48 85 d2             	test   %rdx,%rdx
    6cdd:	48 0f 44 cf          	cmove  %rdi,%rcx
    6ce1:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6ce5:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    6ce9:	4c 8b 2f             	mov    (%rdi),%r13
    6cec:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    6cf3:	00 28 00 
    6cf6:	49 39 d5             	cmp    %rdx,%r13
    6cf9:	48 89 bd b0 fb ff ff 	mov    %rdi,-0x450(%rbp)
    6d00:	0f 82 05 00 00 00    	jb     0x6d0b
    6d06:	e9 3b 00 00 00       	jmp    0x6d46
    6d0b:	4c 8b 40 60          	mov    0x60(%rax),%r8
    6d0f:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    6d16:	48 89 c6             	mov    %rax,%rsi
    6d19:	48 89 ca             	mov    %rcx,%rdx
    6d1c:	4c 89 c1             	mov    %r8,%rcx
    6d1f:	e8 bc 93 ff ff       	call   0xe0
    6d24:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    6d2b:	31 d2                	xor    %edx,%edx
    6d2d:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    6d31:	48 83 f8 00          	cmp    $0x0,%rax
    6d35:	0f 8f 08 00 00 00    	jg     0x6d43
    6d3b:	49 89 c4             	mov    %rax,%r12
    6d3e:	e9 28 04 00 00       	jmp    0x716b
    6d43:	49 89 c5             	mov    %rax,%r13
    6d46:	4c 89 e8             	mov    %r13,%rax
    6d49:	48 83 c0 28          	add    $0x28,%rax
    6d4d:	48 b9 00 00 00 00 00 	movabs $0x28000000000000,%rcx
    6d54:	00 28 00 
    6d57:	48 29 c8             	sub    %rcx,%rax
    6d5a:	48 8b 8d b0 fb ff ff 	mov    -0x450(%rbp),%rcx
    6d61:	48 89 01             	mov    %rax,(%rcx)
    6d64:	48 b8 ff ff ff ff ff 	movabs $0xffffffffffff,%rax
    6d6b:	ff 00 00 
    6d6e:	4d 89 ee             	mov    %r13,%r14
    6d71:	49 21 c6             	and    %rax,%r14
    6d74:	31 c0                	xor    %eax,%eax
    6d76:	48 8b 8d 38 fb ff ff 	mov    -0x4c8(%rbp),%rcx
    6d7d:	49 89 0e             	mov    %rcx,(%r14)
    6d80:	48 8b 95 f0 fa ff ff 	mov    -0x510(%rbp),%rdx
    6d87:	49 89 56 08          	mov    %rdx,0x8(%r14)
    6d8b:	49 89 46 10          	mov    %rax,0x10(%r14)
    6d8f:	49 89 46 18          	mov    %rax,0x18(%r14)
    6d93:	49 89 46 20          	mov    %rax,0x20(%r14)
    6d97:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    6d9e:	48 8b 70 60          	mov    0x60(%rax),%rsi
    6da2:	bf 01 00 00 00       	mov    $0x1,%edi
    6da7:	48 01 fe             	add    %rdi,%rsi
    6daa:	48 89 70 60          	mov    %rsi,0x60(%rax)
    6dae:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    6db4:	31 f6                	xor    %esi,%esi
    6db6:	48 89 b5 b0 fb ff ff 	mov    %rsi,-0x450(%rbp)
    6dbd:	e9 83 01 00 00       	jmp    0x6f45
    6dc2:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    6dc9:	48 8b 48 10          	mov    0x10(%rax),%rcx
    6dcd:	48 8b 50 18          	mov    0x18(%rax),%rdx
    6dd1:	48 89 d6             	mov    %rdx,%rsi
    6dd4:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    6dd9:	bf 40 00 00 00       	mov    $0x40,%edi
    6dde:	48 29 f7             	sub    %rsi,%rdi
    6de1:	48 89 8d d8 fb ff ff 	mov    %rcx,-0x428(%rbp)
    6de8:	4c 8b 85 88 fb ff ff 	mov    -0x478(%rbp),%r8
    6def:	48 89 f9             	mov    %rdi,%rcx
    6df2:	49 d3 e8             	shr    %cl,%r8
    6df5:	31 c9                	xor    %ecx,%ecx
    6df7:	48 39 ce             	cmp    %rcx,%rsi
    6dfa:	be 00 00 00 00       	mov    $0x0,%esi
    6dff:	40 0f 94 c6          	sete   %sil
    6e03:	48 85 f6             	test   %rsi,%rsi
    6e06:	49 0f 44 c8          	cmove  %r8,%rcx
    6e0a:	be 01 00 00 00       	mov    $0x1,%esi
    6e0f:	48 89 cf             	mov    %rcx,%rdi
    6e12:	48 01 f7             	add    %rsi,%rdi
    6e15:	48 21 d7             	and    %rdx,%rdi
    6e18:	ba 28 00 00 00       	mov    $0x28,%edx
    6e1d:	48 0f af ca          	imul   %rdx,%rcx
    6e21:	48 8b 95 d8 fb ff ff 	mov    -0x428(%rbp),%rdx
    6e28:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
    6e2c:	49 8b 48 10          	mov    0x10(%r8),%rcx
    6e30:	48 85 c9             	test   %rcx,%rcx
    6e33:	0f 84 9d 00 00 00    	je     0x6ed6
    6e39:	49 8b 08             	mov    (%r8),%rcx
    6e3c:	4d 8b 48 08          	mov    0x8(%r8),%r9
    6e40:	4c 8b 95 38 fb ff ff 	mov    -0x4c8(%rbp),%r10
    6e47:	49 39 ca             	cmp    %rcx,%r10
    6e4a:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    6e50:	41 0f 94 c3          	sete   %r11b
    6e54:	48 8b 8d f0 fa ff ff 	mov    -0x510(%rbp),%rcx
    6e5b:	4c 39 c9             	cmp    %r9,%rcx
    6e5e:	41 bf 00 00 00 00    	mov    $0x0,%r15d
    6e64:	41 0f 94 c7          	sete   %r15b
    6e68:	4d 21 fb             	and    %r15,%r11
    6e6b:	4d 85 db             	test   %r11,%r11
    6e6e:	0f 84 08 00 00 00    	je     0x6e7c
    6e74:	4d 89 c6             	mov    %r8,%r14
    6e77:	e9 49 00 00 00       	jmp    0x6ec5
    6e7c:	41 b8 28 00 00 00    	mov    $0x28,%r8d
    6e82:	49 0f af f8          	imul   %r8,%rdi
    6e86:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    6e8a:	49 8b 50 10          	mov    0x10(%r8),%rdx
    6e8e:	48 85 d2             	test   %rdx,%rdx
    6e91:	0f 84 3f 00 00 00    	je     0x6ed6
    6e97:	49 8b 10             	mov    (%r8),%rdx
    6e9a:	49 8b 78 08          	mov    0x8(%r8),%rdi
    6e9e:	49 39 d2             	cmp    %rdx,%r10
    6ea1:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    6ea7:	41 0f 94 c1          	sete   %r9b
    6eab:	48 39 f9             	cmp    %rdi,%rcx
    6eae:	ba 00 00 00 00       	mov    $0x0,%edx
    6eb3:	0f 94 c2             	sete   %dl
    6eb6:	49 21 d1             	and    %rdx,%r9
    6eb9:	4d 85 c9             	test   %r9,%r9
    6ebc:	0f 84 14 00 00 00    	je     0x6ed6
    6ec2:	4d 89 c6             	mov    %r8,%r14
    6ec5:	45 31 ed             	xor    %r13d,%r13d
    6ec8:	31 c0                	xor    %eax,%eax
    6eca:	48 89 85 b0 fb ff ff 	mov    %rax,-0x450(%rbp)
    6ed1:	e9 6f 00 00 00       	jmp    0x6f45
    6ed6:	48 8d 85 a0 fc ff ff 	lea    -0x360(%rbp),%rax
    6edd:	48 89 c1             	mov    %rax,%rcx
    6ee0:	48 8b 95 38 fb ff ff 	mov    -0x4c8(%rbp),%rdx
    6ee7:	48 89 11             	mov    %rdx,(%rcx)
    6eea:	48 8b 95 f0 fa ff ff 	mov    -0x510(%rbp),%rdx
    6ef1:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    6ef5:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    6efc:	48 8b b5 90 fc ff ff 	mov    -0x370(%rbp),%rsi
    6f03:	48 89 ca             	mov    %rcx,%rdx
    6f06:	e8 e5 91 ff ff       	call   0xf0
    6f0b:	48 83 f8 00          	cmp    $0x0,%rax
    6f0f:	0f 8d 08 00 00 00    	jge    0x6f1d
    6f15:	49 89 c4             	mov    %rax,%r12
    6f18:	e9 4e 02 00 00       	jmp    0x716b
    6f1d:	48 8b 8d 90 fc ff ff 	mov    -0x370(%rbp),%rcx
    6f24:	48 8b 11             	mov    (%rcx),%rdx
    6f27:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    6f2b:	48 83 e6 01          	and    $0x1,%rsi
    6f2f:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    6f33:	49 89 c6             	mov    %rax,%r14
    6f36:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    6f3c:	31 c0                	xor    %eax,%eax
    6f3e:	48 89 85 b0 fb ff ff 	mov    %rax,-0x450(%rbp)
    6f45:	4d 85 ed             	test   %r13,%r13
    6f48:	0f 84 64 00 00 00    	je     0x6fb2
    6f4e:	48 8b 85 a0 fb ff ff 	mov    -0x460(%rbp),%rax
    6f55:	49 89 46 10          	mov    %rax,0x10(%r14)
    6f59:	31 c9                	xor    %ecx,%ecx
    6f5b:	48 39 c8             	cmp    %rcx,%rax
    6f5e:	ba 00 00 00 00       	mov    $0x0,%edx
    6f63:	0f 95 c2             	setne  %dl
    6f66:	41 0f b6 76 20       	movzbl 0x20(%r14),%esi
    6f6b:	48 09 d6             	or     %rdx,%rsi
    6f6e:	48 0f be f6          	movsbq %sil,%rsi
    6f72:	41 88 76 20          	mov    %sil,0x20(%r14)
    6f76:	48 8b 95 28 fb ff ff 	mov    -0x4d8(%rbp),%rdx
    6f7d:	49 89 56 18          	mov    %rdx,0x18(%r14)
    6f81:	48 8b bd 58 fb ff ff 	mov    -0x4a8(%rbp),%rdi
    6f88:	48 39 cf             	cmp    %rcx,%rdi
    6f8b:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    6f91:	41 0f 95 c0          	setne  %r8b
    6f95:	40 0f b6 f6          	movzbl %sil,%esi
    6f99:	41 b9 02 00 00 00    	mov    $0x2,%r9d
    6f9f:	4d 85 c0             	test   %r8,%r8
    6fa2:	4c 0f 44 c9          	cmove  %rcx,%r9
    6fa6:	4c 09 ce             	or     %r9,%rsi
    6fa9:	41 88 76 20          	mov    %sil,0x20(%r14)
    6fad:	e9 89 00 00 00       	jmp    0x703b
    6fb2:	49 8b 46 10          	mov    0x10(%r14),%rax
    6fb6:	48 8b 8d a0 fb ff ff 	mov    -0x460(%rbp),%rcx
    6fbd:	48 01 c8             	add    %rcx,%rax
    6fc0:	49 89 46 10          	mov    %rax,0x10(%r14)
    6fc4:	31 c9                	xor    %ecx,%ecx
    6fc6:	48 39 c8             	cmp    %rcx,%rax
    6fc9:	b8 00 00 00 00       	mov    $0x0,%eax
    6fce:	0f 95 c0             	setne  %al
    6fd1:	41 0f b6 56 20       	movzbl 0x20(%r14),%edx
    6fd6:	48 09 c2             	or     %rax,%rdx
    6fd9:	48 0f be d2          	movsbq %dl,%rdx
    6fdd:	41 88 56 20          	mov    %dl,0x20(%r14)
    6fe1:	49 8b 46 18          	mov    0x18(%r14),%rax
    6fe5:	0f b6 d2             	movzbl %dl,%edx
    6fe8:	48 89 d6             	mov    %rdx,%rsi
    6feb:	48 83 e6 02          	and    $0x2,%rsi
    6fef:	48 39 ce             	cmp    %rcx,%rsi
    6ff2:	be 00 00 00 00       	mov    $0x0,%esi
    6ff7:	40 0f 95 c6          	setne  %sil
    6ffb:	31 ff                	xor    %edi,%edi
    6ffd:	48 85 f6             	test   %rsi,%rsi
    7000:	48 0f 44 c7          	cmove  %rdi,%rax
    7004:	48 8b bd 58 fb ff ff 	mov    -0x4a8(%rbp),%rdi
    700b:	48 01 fe             	add    %rdi,%rsi
    700e:	48 8b bd 28 fb ff ff 	mov    -0x4d8(%rbp),%rdi
    7015:	48 01 f8             	add    %rdi,%rax
    7018:	49 89 46 18          	mov    %rax,0x18(%r14)
    701c:	48 39 ce             	cmp    %rcx,%rsi
    701f:	be 00 00 00 00       	mov    $0x0,%esi
    7024:	40 0f 95 c6          	setne  %sil
    7028:	b8 02 00 00 00       	mov    $0x2,%eax
    702d:	48 85 f6             	test   %rsi,%rsi
    7030:	48 0f 44 c1          	cmove  %rcx,%rax
    7034:	48 09 c2             	or     %rax,%rdx
    7037:	41 88 56 20          	mov    %dl,0x20(%r14)
    703b:	48 8b 85 88 fc ff ff 	mov    -0x378(%rbp),%rax
    7042:	48 89 85 d0 fb ff ff 	mov    %rax,-0x430(%rbp)
    7049:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    7050:	48 8b 88 a8 01 00 00 	mov    0x1a8(%rax),%rcx
    7057:	48 8b 95 d0 fb ff ff 	mov    -0x430(%rbp),%rdx
    705e:	48 01 d1             	add    %rdx,%rcx
    7061:	48 89 88 a8 01 00 00 	mov    %rcx,0x1a8(%rax)
    7068:	48 8b 8d f8 fb ff ff 	mov    -0x408(%rbp),%rcx
    706f:	89 88 c0 01 00 00    	mov    %ecx,0x1c0(%rax)
    7075:	e9 49 a2 ff ff       	jmp    0x12c3
    707a:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    7081:	e8 ba 8f ff ff       	call   0x40
    7086:	48 85 c0             	test   %rax,%rax
    7089:	0f 84 54 a2 ff ff    	je     0x12e3
    708f:	e9 d0 00 00 00       	jmp    0x7164
    7094:	48 8b 85 28 fc ff ff 	mov    -0x3d8(%rbp),%rax
    709b:	48 85 c0             	test   %rax,%rax
    709e:	0f 84 08 00 00 00    	je     0x70ac
    70a4:	49 89 c4             	mov    %rax,%r12
    70a7:	e9 bf 00 00 00       	jmp    0x716b
    70ac:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
    70b3:	48 8b 08             	mov    (%rax),%rcx
    70b6:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    70ba:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
    70be:	0f b6 51 70          	movzbl 0x70(%rcx),%edx
    70c2:	48 85 d2             	test   %rdx,%rdx
    70c5:	0f 84 2b 00 00 00    	je     0x70f6
    70cb:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    70d0:	48 89 c7             	mov    %rax,%rdi
    70d3:	48 89 ce             	mov    %rcx,%rsi
    70d6:	e8 85 8f ff ff       	call   0x60
    70db:	48 83 f8 00          	cmp    $0x0,%rax
    70df:	0f 8d 11 00 00 00    	jge    0x70f6
    70e5:	b8 80 00 00 00       	mov    $0x80,%eax
    70ea:	48 89 85 48 fb ff ff 	mov    %rax,-0x4b8(%rbp)
    70f1:	e9 54 00 00 00       	jmp    0x714a
    70f6:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
    70fd:	48 8b 08             	mov    (%rax),%rcx
    7100:	48 8b 50 60          	mov    0x60(%rax),%rdx
    7104:	48 8b 59 58          	mov    0x58(%rcx),%rbx
    7108:	48 01 d3             	add    %rdx,%rbx
    710b:	48 89 59 58          	mov    %rbx,0x58(%rcx)
    710f:	31 c9                	xor    %ecx,%ecx
    7111:	48 89 48 60          	mov    %rcx,0x60(%rax)
    7115:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    711c:	48 89 c6             	mov    %rax,%rsi
    711f:	e8 dc 8f ff ff       	call   0x100
    7124:	48 83 f8 00          	cmp    $0x0,%rax
    7128:	0f 8d 08 00 00 00    	jge    0x7136
    712e:	49 89 c4             	mov    %rax,%r12
    7131:	e9 35 00 00 00       	jmp    0x716b
    7136:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
    713d:	e8 2e 8f ff ff       	call   0x70
    7142:	49 89 c4             	mov    %rax,%r12
    7145:	e9 21 00 00 00       	jmp    0x716b
    714a:	48 8b 85 48 fb ff ff 	mov    -0x4b8(%rbp),%rax
    7151:	48 c1 e0 08          	shl    $0x8,%rax
    7155:	48 83 c8 03          	or     $0x3,%rax
    7159:	48 f7 d8             	neg    %rax
    715c:	49 89 c4             	mov    %rax,%r12
    715f:	e9 07 00 00 00       	jmp    0x716b
    7164:	49 c7 c4 fe ff ff ff 	mov    $0xfffffffffffffffe,%r12
    716b:	4c 89 e0             	mov    %r12,%rax
    716e:	48 81 c4 38 05 00 00 	add    $0x538,%rsp
    7175:	41 5f                	pop    %r15
    7177:	41 5e                	pop    %r14
    7179:	41 5d                	pop    %r13
    717b:	41 5c                	pop    %r12
    717d:	5b                   	pop    %rbx
    717e:	5d                   	pop    %rbp
    717f:	c3                   	ret
    7180:	55                   	push   %rbp
    7181:	48 89 e5             	mov    %rsp,%rbp
    7184:	53                   	push   %rbx
    7185:	41 54                	push   %r12
    7187:	41 55                	push   %r13
    7189:	41 56                	push   %r14
    718b:	41 57                	push   %r15
    718d:	48 81 ec e8 02 00 00 	sub    $0x2e8,%rsp
    7194:	31 c0                	xor    %eax,%eax
    7196:	b9 01 00 00 00       	mov    $0x1,%ecx
    719b:	48 8b 57 58          	mov    0x58(%rdi),%rdx
    719f:	48 8b 9f 10 02 00 00 	mov    0x210(%rdi),%rbx
    71a6:	48 8d b5 60 ff ff ff 	lea    -0xa0(%rbp),%rsi
    71ad:	49 89 f0             	mov    %rsi,%r8
    71b0:	4c 8b 4f 50          	mov    0x50(%rdi),%r9
    71b4:	4d 85 c9             	test   %r9,%r9
    71b7:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
    71bb:	4c 89 85 58 fe ff ff 	mov    %r8,-0x1a8(%rbp)
    71c2:	0f 85 c1 01 00 00    	jne    0x7389
    71c8:	49 b9 01 00 00 00 00 	movabs $0x4000000000001,%r9
    71cf:	00 04 00 
    71d2:	4c 89 4f 50          	mov    %r9,0x50(%rdi)
    71d6:	45 31 c9             	xor    %r9d,%r9d
    71d9:	4c 89 4b 18          	mov    %r9,0x18(%rbx)
    71dd:	41 b9 99 19 00 00    	mov    $0x1999,%r9d
    71e3:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    71e7:	49 39 c2             	cmp    %rax,%r10
    71ea:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    71f0:	41 0f 94 c3          	sete   %r11b
    71f4:	4d 85 db             	test   %r11,%r11
    71f7:	4d 0f 44 ca          	cmove  %r10,%r9
    71fb:	41 bc 99 19 00 00    	mov    $0x1999,%r12d
    7201:	4d 85 db             	test   %r11,%r11
    7204:	4d 0f 44 e2          	cmove  %r10,%r12
    7208:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
    720e:	4d 39 e1             	cmp    %r12,%r9
    7211:	4d 0f 47 cc          	cmova  %r12,%r9
    7215:	4d 39 d1             	cmp    %r10,%r9
    7218:	4d 0f 47 ca          	cmova  %r10,%r9
    721c:	4c 8d 95 30 ff ff ff 	lea    -0xd0(%rbp),%r10
    7223:	4d 89 d3             	mov    %r10,%r11
    7226:	41 bc 02 02 01 01    	mov    $0x1010202,%r12d
    722c:	4d 89 23             	mov    %r12,(%r11)
    722f:	41 bc 00 00 00 01    	mov    $0x1000000,%r12d
    7235:	4d 89 63 08          	mov    %r12,0x8(%r11)
    7239:	41 bc 00 00 10 18    	mov    $0x18100000,%r12d
    723f:	4d 89 63 10          	mov    %r12,0x10(%r11)
    7243:	49 bc 00 00 28 01 10 	movabs $0x201001280000,%r12
    724a:	20 00 00 
    724d:	4d 89 63 18          	mov    %r12,0x18(%r11)
    7251:	45 31 e4             	xor    %r12d,%r12d
    7254:	4d 89 63 20          	mov    %r12,0x20(%r11)
    7258:	41 bc 99 19 00 00    	mov    $0x1999,%r12d
    725e:	4c 8b 6a 08          	mov    0x8(%rdx),%r13
    7262:	49 39 c5             	cmp    %rax,%r13
    7265:	ba 00 00 00 00       	mov    $0x0,%edx
    726a:	0f 94 c2             	sete   %dl
    726d:	48 85 d2             	test   %rdx,%rdx
    7270:	4d 0f 44 e5          	cmove  %r13,%r12
    7274:	ba cd cc cc 00       	mov    $0xcccccd,%edx
    7279:	49 39 d4             	cmp    %rdx,%r12
    727c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    7282:	41 0f 97 c5          	seta   %r13b
    7286:	4d 85 ed             	test   %r13,%r13
    7289:	49 0f 44 d4          	cmove  %r12,%rdx
    728d:	41 bc 28 00 00 00    	mov    $0x28,%r12d
    7293:	49 0f af d4          	imul   %r12,%rdx
    7297:	48 81 c2 ff ff 03 00 	add    $0x3ffff,%rdx
    729e:	48 c1 ea 12          	shr    $0x12,%rdx
    72a2:	48 83 fa 01          	cmp    $0x1,%rdx
    72a6:	41 bc 00 00 00 00    	mov    $0x0,%r12d
    72ac:	41 0f 97 c4          	seta   %r12b
    72b0:	48 83 ea 01          	sub    $0x1,%rdx
    72b4:	4c 0f bd ea          	bsr    %rdx,%r13
    72b8:	ba 7f 00 00 00       	mov    $0x7f,%edx
    72bd:	49 0f 45 d5          	cmovne %r13,%rdx
    72c1:	83 f2 3f             	xor    $0x3f,%edx
    72c4:	41 bd 40 00 00 00    	mov    $0x40,%r13d
    72ca:	49 29 d5             	sub    %rdx,%r13
    72cd:	ba 0b 00 00 00       	mov    $0xb,%edx
    72d2:	49 39 d5             	cmp    %rdx,%r13
    72d5:	41 be 00 00 00 00    	mov    $0x0,%r14d
    72db:	41 0f 97 c6          	seta   %r14b
    72df:	4d 85 f6             	test   %r14,%r14
    72e2:	49 0f 44 d5          	cmove  %r13,%rdx
    72e6:	45 31 ed             	xor    %r13d,%r13d
    72e9:	4d 85 e4             	test   %r12,%r12
    72ec:	49 0f 44 d5          	cmove  %r13,%rdx
    72f0:	4c 89 c6             	mov    %r8,%rsi
    72f3:	48 89 95 50 fe ff ff 	mov    %rdx,-0x1b0(%rbp)
    72fa:	4c 89 da             	mov    %r11,%rdx
    72fd:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
    7304:	4d 89 c8             	mov    %r9,%r8
    7307:	e8 74 8d ff ff       	call   0x80
    730c:	48 83 f8 00          	cmp    $0x0,%rax
    7310:	0f 8d 08 00 00 00    	jge    0x731e
    7316:	49 89 c4             	mov    %rax,%r12
    7319:	e9 9a 31 00 00       	jmp    0xa4b8
    731e:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    7325:	48 8b 08             	mov    (%rax),%rcx
    7328:	31 d2                	xor    %edx,%edx
    732a:	48 8d 74 11 10       	lea    0x10(%rcx,%rdx,1),%rsi
    732f:	48 89 70 40          	mov    %rsi,0x40(%rax)
    7333:	48 89 50 60          	mov    %rdx,0x60(%rax)
    7337:	48 8b 08             	mov    (%rax),%rcx
    733a:	0f b6 71 0d          	movzbl 0xd(%rcx),%esi
    733e:	48 83 e6 01          	and    $0x1,%rsi
    7342:	48 89 70 68          	mov    %rsi,0x68(%rax)
    7346:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    734b:	31 f6                	xor    %esi,%esi
    734d:	bf 06 00 00 00       	mov    $0x6,%edi
    7352:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    7358:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    735c:	48 89 ce             	mov    %rcx,%rsi
    735f:	31 d2                	xor    %edx,%edx
    7361:	b9 06 00 00 00       	mov    $0x6,%ecx
    7366:	e8 a5 8d ff ff       	call   0x110
    736b:	48 83 f8 00          	cmp    $0x0,%rax
    736f:	0f 8d 0b 00 00 00    	jge    0x7380
    7375:	41 bd 80 00 00 00    	mov    $0x80,%r13d
    737b:	e9 bd 30 00 00       	jmp    0xa43d
    7380:	48 85 c0             	test   %rax,%rax
    7383:	0f 85 da 30 00 00    	jne    0xa463
    7389:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
    738d:	48 8b 48 18          	mov    0x18(%rax),%rcx
    7391:	48 85 c9             	test   %rcx,%rcx
    7394:	0f 84 0c 00 00 00    	je     0x73a6
    739a:	0f b6 11             	movzbl (%rcx),%edx
    739d:	48 85 d2             	test   %rdx,%rdx
    73a0:	0f 85 80 30 00 00    	jne    0xa426
    73a6:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
    73aa:	48 8b 08             	mov    (%rax),%rcx
    73ad:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    73b1:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
    73b5:	44 0f b6 71 0c       	movzbl 0xc(%rcx),%r14d
    73ba:	4d 85 f6             	test   %r14,%r14
    73bd:	0f 84 a0 30 00 00    	je     0xa463
    73c3:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    73c7:	4c 8d 3c 11          	lea    (%rcx,%rdx,1),%r15
    73cb:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    73cf:	48 8d 34 11          	lea    (%rcx,%rdx,1),%rsi
    73d3:	8b 51 30             	mov    0x30(%rcx),%edx
    73d6:	48 8b 79 18          	mov    0x18(%rcx),%rdi
    73da:	4c 8b 41 20          	mov    0x20(%rcx),%r8
    73de:	49 29 f8             	sub    %rdi,%r8
    73e1:	41 b9 01 00 00 00    	mov    $0x1,%r9d
    73e7:	4d 01 c8             	add    %r9,%r8
    73ea:	49 89 ca             	mov    %rcx,%r10
    73ed:	49 81 c2 c0 00 00 00 	add    $0xc0,%r10
    73f4:	49 89 f3             	mov    %rsi,%r11
    73f7:	4d 29 fb             	sub    %r15,%r11
    73fa:	4f 8d 0c 1f          	lea    (%r15,%r11,1),%r9
    73fe:	4b 8d 04 5f          	lea    (%r15,%r11,2),%rax
    7402:	44 0f b6 59 72       	movzbl 0x72(%rcx),%r11d
    7407:	49 83 fe 01          	cmp    $0x1,%r14
    740b:	b9 00 00 00 00       	mov    $0x0,%ecx
    7410:	0f 94 c1             	sete   %cl
    7413:	48 89 8d 50 fe ff ff 	mov    %rcx,-0x1b0(%rbp)
    741a:	31 c9                	xor    %ecx,%ecx
    741c:	48 89 85 48 fe ff ff 	mov    %rax,-0x1b8(%rbp)
    7423:	49 39 cb             	cmp    %rcx,%r11
    7426:	b8 00 00 00 00       	mov    $0x0,%eax
    742b:	0f 95 c0             	setne  %al
    742e:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
    7435:	48 21 c1             	and    %rax,%rcx
    7438:	48 85 c9             	test   %rcx,%rcx
    743b:	48 89 95 50 fe ff ff 	mov    %rdx,-0x1b0(%rbp)
    7442:	48 89 b5 40 fe ff ff 	mov    %rsi,-0x1c0(%rbp)
    7449:	48 89 bd 38 fe ff ff 	mov    %rdi,-0x1c8(%rbp)
    7450:	4c 89 85 30 fe ff ff 	mov    %r8,-0x1d0(%rbp)
    7457:	4c 89 8d 28 fe ff ff 	mov    %r9,-0x1d8(%rbp)
    745e:	4c 89 95 20 fe ff ff 	mov    %r10,-0x1e0(%rbp)
    7465:	4c 89 9d 18 fe ff ff 	mov    %r11,-0x1e8(%rbp)
    746c:	0f 85 20 00 00 00    	jne    0x7492
    7472:	31 c0                	xor    %eax,%eax
    7474:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
    747b:	31 c0                	xor    %eax,%eax
    747d:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
    7484:	31 c0                	xor    %eax,%eax
    7486:	48 89 85 00 fe ff ff 	mov    %rax,-0x200(%rbp)
    748d:	e9 96 01 00 00       	jmp    0x7628
    7492:	b8 08 00 00 00       	mov    $0x8,%eax
    7497:	48 89 d1             	mov    %rdx,%rcx
    749a:	48 d3 e0             	shl    %cl,%rax
    749d:	49 8d 0c 07          	lea    (%r15,%rax,1),%rcx
    74a1:	45 31 db             	xor    %r11d,%r11d
    74a4:	4a 8d 74 19 40       	lea    0x40(%rcx,%r11,1),%rsi
    74a9:	48 3d 00 00 10 00    	cmp    $0x100000,%rax
    74af:	0f 87 1e 00 00 00    	ja     0x74d3
    74b5:	31 c0                	xor    %eax,%eax
    74b7:	48 89 85 00 fe ff ff 	mov    %rax,-0x200(%rbp)
    74be:	48 89 b5 10 fe ff ff 	mov    %rsi,-0x1f0(%rbp)
    74c5:	31 c0                	xor    %eax,%eax
    74c7:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
    74ce:	e9 55 01 00 00       	jmp    0x7628
    74d3:	48 8b 43 20          	mov    0x20(%rbx),%rax
    74d7:	4c 8b 4b 28          	mov    0x28(%rbx),%r9
    74db:	ba 01 00 00 00       	mov    $0x1,%edx
    74e0:	49 01 d1             	add    %rdx,%r9
    74e3:	4c 89 4b 28          	mov    %r9,0x28(%rbx)
    74e7:	48 8b 79 10          	mov    0x10(%rcx),%rdi
    74eb:	48 85 c0             	test   %rax,%rax
    74ee:	48 89 b5 f8 fd ff ff 	mov    %rsi,-0x208(%rbp)
    74f5:	4c 89 8d f0 fd ff ff 	mov    %r9,-0x210(%rbp)
    74fc:	0f 85 0c 00 00 00    	jne    0x750e
    7502:	48 89 bd e8 fd ff ff 	mov    %rdi,-0x218(%rbp)
    7509:	e9 b3 00 00 00       	jmp    0x75c1
    750e:	4c 89 5b 20          	mov    %r11,0x20(%rbx)
    7512:	be ff ff ff ff       	mov    $0xffffffff,%esi
    7517:	49 89 c1             	mov    %rax,%r9
    751a:	49 21 f1             	and    %rsi,%r9
    751d:	48 c1 e8 20          	shr    $0x20,%rax
    7521:	4c 89 ce             	mov    %r9,%rsi
    7524:	48 01 c6             	add    %rax,%rsi
    7527:	48 8b 01             	mov    (%rcx),%rax
    752a:	48 01 f0             	add    %rsi,%rax
    752d:	48 89 01             	mov    %rax,(%rcx)
    7530:	48 8b 71 08          	mov    0x8(%rcx),%rsi
    7534:	4c 01 ce             	add    %r9,%rsi
    7537:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    753b:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    7541:	0f 83 0c 00 00 00    	jae    0x7553
    7547:	48 89 bd e8 fd ff ff 	mov    %rdi,-0x218(%rbp)
    754e:	e9 6e 00 00 00       	jmp    0x75c1
    7553:	41 b9 17 00 00 00    	mov    $0x17,%r9d
    7559:	41 b8 08 00 00 00    	mov    $0x8,%r8d
    755f:	49 89 c2             	mov    %rax,%r10
    7562:	49 29 f2             	sub    %rsi,%r10
    7565:	4d 0f af d1          	imul   %r9,%r10
    7569:	49 0f af c0          	imul   %r8,%rax
    756d:	49 39 c2             	cmp    %rax,%r10
    7570:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    7576:	41 0f 96 c2          	setbe  %r10b
    757a:	49 83 ca 02          	or     $0x2,%r10
    757e:	4c 89 51 10          	mov    %r10,0x10(%rcx)
    7582:	4c 89 19             	mov    %r11,(%rcx)
    7585:	4c 89 59 08          	mov    %r11,0x8(%rcx)
    7589:	4c 31 d7             	xor    %r10,%rdi
    758c:	48 21 d7             	and    %rdx,%rdi
    758f:	48 85 ff             	test   %rdi,%rdi
    7592:	0f 85 0c 00 00 00    	jne    0x75a4
    7598:	4c 89 95 e8 fd ff ff 	mov    %r10,-0x218(%rbp)
    759f:	e9 1d 00 00 00       	jmp    0x75c1
    75a4:	4c 89 d7             	mov    %r10,%rdi
    75a7:	4c 89 95 e0 fd ff ff 	mov    %r10,-0x220(%rbp)
    75ae:	e8 fd 8a ff ff       	call   0xb0
    75b3:	48 8b 85 e0 fd ff ff 	mov    -0x220(%rbp),%rax
    75ba:	48 89 85 e8 fd ff ff 	mov    %rax,-0x218(%rbp)
    75c1:	48 8b 85 f0 fd ff ff 	mov    -0x210(%rbp),%rax
    75c8:	48 83 e0 1f          	and    $0x1f,%rax
    75cc:	31 c9                	xor    %ecx,%ecx
    75ce:	48 39 c8             	cmp    %rcx,%rax
    75d1:	b8 00 00 00 00       	mov    $0x0,%eax
    75d6:	0f 94 c0             	sete   %al
    75d9:	48 8b 95 e8 fd ff ff 	mov    -0x218(%rbp),%rdx
    75e0:	48 89 d6             	mov    %rdx,%rsi
    75e3:	48 83 e6 02          	and    $0x2,%rsi
    75e7:	48 39 ce             	cmp    %rcx,%rsi
    75ea:	be 00 00 00 00       	mov    $0x0,%esi
    75ef:	40 0f 94 c6          	sete   %sil
    75f3:	48 09 c6             	or     %rax,%rsi
    75f6:	b8 01 00 00 00       	mov    $0x1,%eax
    75fb:	48 21 c2             	and    %rax,%rdx
    75fe:	48 39 ca             	cmp    %rcx,%rdx
    7601:	ba 00 00 00 00       	mov    $0x0,%edx
    7606:	0f 94 c2             	sete   %dl
    7609:	48 09 f2             	or     %rsi,%rdx
    760c:	48 89 95 00 fe ff ff 	mov    %rdx,-0x200(%rbp)
    7613:	48 8b 95 f8 fd ff ff 	mov    -0x208(%rbp),%rdx
    761a:	48 89 95 10 fe ff ff 	mov    %rdx,-0x1f0(%rbp)
    7621:	48 89 b5 08 fe ff ff 	mov    %rsi,-0x1f8(%rbp)
    7628:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
    762c:	48 8b 08             	mov    (%rax),%rcx
    762f:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    7633:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
    7637:	31 d2                	xor    %edx,%edx
    7639:	48 8d b4 11 40 fd ff 	lea    -0x2c0(%rcx,%rdx,1),%rsi
    7640:	ff 
    7641:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7645:	48 8b 70 50          	mov    0x50(%rax),%rsi
    7649:	48 bf 01 00 00 00 00 	movabs $0x4000000000001,%rdi
    7650:	00 04 00 
    7653:	48 29 fe             	sub    %rdi,%rsi
    7656:	48 39 ce             	cmp    %rcx,%rsi
    7659:	0f 8d 13 00 00 00    	jge    0x7672
    765f:	48 89 b5 f8 fd ff ff 	mov    %rsi,-0x208(%rbp)
    7666:	48 89 8d e8 fd ff ff 	mov    %rcx,-0x218(%rbp)
    766d:	e9 54 00 00 00       	jmp    0x76c6
    7672:	b9 00 00 00 40       	mov    $0x40000000,%ecx
    7677:	31 f6                	xor    %esi,%esi
    7679:	bf 06 00 00 00       	mov    $0x6,%edi
    767e:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    7684:	48 89 c7             	mov    %rax,%rdi
    7687:	48 89 ce             	mov    %rcx,%rsi
    768a:	31 d2                	xor    %edx,%edx
    768c:	b9 06 00 00 00       	mov    $0x6,%ecx
    7691:	e8 8a 8a ff ff       	call   0x120
    7696:	48 83 f8 00          	cmp    $0x0,%rax
    769a:	0f 8d 0b 00 00 00    	jge    0x76ab
    76a0:	41 bd 80 00 00 00    	mov    $0x80,%r13d
    76a6:	e9 92 2d 00 00       	jmp    0xa43d
    76ab:	48 85 c0             	test   %rax,%rax
    76ae:	0f 84 9c 2d 00 00    	je     0xa450
    76b4:	31 c0                	xor    %eax,%eax
    76b6:	48 89 85 f8 fd ff ff 	mov    %rax,-0x208(%rbp)
    76bd:	31 c0                	xor    %eax,%eax
    76bf:	48 89 85 e8 fd ff ff 	mov    %rax,-0x218(%rbp)
    76c6:	48 8b 85 f8 fd ff ff 	mov    -0x208(%rbp),%rax
    76cd:	48 89 c1             	mov    %rax,%rcx
    76d0:	48 81 c1 00 01 00 00 	add    $0x100,%rcx
    76d7:	48 8b 95 e8 fd ff ff 	mov    -0x218(%rbp),%rdx
    76de:	48 39 d1             	cmp    %rdx,%rcx
    76e1:	be 00 00 00 00       	mov    $0x0,%esi
    76e6:	40 0f 9c c6          	setl   %sil
    76ea:	48 85 f6             	test   %rsi,%rsi
    76ed:	48 0f 44 ca          	cmove  %rdx,%rcx
    76f1:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
    76f5:	48 8b 32             	mov    (%rdx),%rsi
    76f8:	48 8b 7e 28          	mov    0x28(%rsi),%rdi
    76fc:	48 8b 77 08          	mov    0x8(%rdi),%rsi
    7700:	31 ff                	xor    %edi,%edi
    7702:	4c 8d 84 3e 40 fd ff 	lea    -0x2c0(%rsi,%rdi,1),%r8
    7709:	ff 
    770a:	49 8b 70 10          	mov    0x10(%r8),%rsi
    770e:	4d 8b 48 18          	mov    0x18(%r8),%r9
    7712:	49 83 fe 05          	cmp    $0x5,%r14
    7716:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    771c:	41 0f 94 c0          	sete   %r8b
    7720:	49 83 fe 02          	cmp    $0x2,%r14
    7724:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    772a:	41 0f 94 c2          	sete   %r10b
    772e:	4d 09 d0             	or     %r10,%r8
    7731:	4d 85 c0             	test   %r8,%r8
    7734:	48 89 8d e8 fd ff ff 	mov    %rcx,-0x218(%rbp)
    773b:	48 89 b5 f0 fd ff ff 	mov    %rsi,-0x210(%rbp)
    7742:	4c 89 8d e0 fd ff ff 	mov    %r9,-0x220(%rbp)
    7749:	0f 84 c0 0b 00 00    	je     0x830f
    774f:	49 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%r8
    7756:	82 28 52 
    7759:	45 31 d2             	xor    %r10d,%r10d
    775c:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
    7763:	48 89 bd d0 fd ff ff 	mov    %rdi,-0x230(%rbp)
    776a:	48 89 bd c8 fd ff ff 	mov    %rdi,-0x238(%rbp)
    7771:	48 89 bd c0 fd ff ff 	mov    %rdi,-0x240(%rbp)
    7778:	4c 89 85 b8 fd ff ff 	mov    %r8,-0x248(%rbp)
    777f:	48 89 bd b0 fd ff ff 	mov    %rdi,-0x250(%rbp)
    7786:	48 89 bd a8 fd ff ff 	mov    %rdi,-0x258(%rbp)
    778d:	4c 89 95 a0 fd ff ff 	mov    %r10,-0x260(%rbp)
    7794:	48 89 bd 98 fd ff ff 	mov    %rdi,-0x268(%rbp)
    779b:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
    77a2:	48 8b 8d e8 fd ff ff 	mov    -0x218(%rbp),%rcx
    77a9:	48 39 c8             	cmp    %rcx,%rax
    77ac:	0f 8d 3a 07 00 00    	jge    0x7eec
    77b2:	48 8b 95 e0 fd ff ff 	mov    -0x220(%rbp),%rdx
    77b9:	48 8d 34 c2          	lea    (%rdx,%rax,8),%rsi
    77bd:	48 8b 3e             	mov    (%rsi),%rdi
    77c0:	48 8b b5 f0 fd ff ff 	mov    -0x210(%rbp),%rsi
    77c7:	49 89 f0             	mov    %rsi,%r8
    77ca:	49 01 f8             	add    %rdi,%r8
    77cd:	49 8b 78 10          	mov    0x10(%r8),%rdi
    77d1:	4d 8b 48 08          	mov    0x8(%r8),%r9
    77d5:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    77db:	4d 89 cb             	mov    %r9,%r11
    77de:	4d 21 d3             	and    %r10,%r11
    77e1:	49 8b 40 18          	mov    0x18(%r8),%rax
    77e5:	49 d1 e9             	shr    $1,%r9
    77e8:	4d 21 d1             	and    %r10,%r9
    77eb:	45 31 c0             	xor    %r8d,%r8d
    77ee:	4d 39 c1             	cmp    %r8,%r9
    77f1:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    77f7:	41 0f 95 c1          	setne  %r9b
    77fb:	4d 85 db             	test   %r11,%r11
    77fe:	0f 85 ca 06 00 00    	jne    0x7ece
    7804:	48 63 ff             	movslq %edi,%rdi
    7807:	49 89 fb             	mov    %rdi,%r11
    780a:	49 83 fe 05          	cmp    $0x5,%r14
    780e:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
    7815:	4c 89 8d 88 fd ff ff 	mov    %r9,-0x278(%rbp)
    781c:	0f 85 84 00 00 00    	jne    0x78a6
    7822:	48 8b bd 38 fe ff ff 	mov    -0x1c8(%rbp),%rdi
    7829:	4c 89 d8             	mov    %r11,%rax
    782c:	48 29 f8             	sub    %rdi,%rax
    782f:	4c 8b 8d 30 fe ff ff 	mov    -0x1d0(%rbp),%r9
    7836:	4c 39 c8             	cmp    %r9,%rax
    7839:	ba 00 00 00 00       	mov    $0x0,%edx
    783e:	0f 92 c2             	setb   %dl
    7841:	48 85 d2             	test   %rdx,%rdx
    7844:	49 0f 44 c0          	cmove  %r8,%rax
    7848:	48 89 c6             	mov    %rax,%rsi
    784b:	48 c1 ee 06          	shr    $0x6,%rsi
    784f:	48 83 e0 3f          	and    $0x3f,%rax
    7853:	49 8d 3c f7          	lea    (%r15,%rsi,8),%rdi
    7857:	4c 8b 0f             	mov    (%rdi),%r9
    785a:	48 89 c1             	mov    %rax,%rcx
    785d:	49 d3 e9             	shr    %cl,%r9
    7860:	4d 21 d1             	and    %r10,%r9
    7863:	4c 89 cf             	mov    %r9,%rdi
    7866:	48 21 d7             	and    %rdx,%rdi
    7869:	48 8b 8d 28 fe ff ff 	mov    -0x1d8(%rbp),%rcx
    7870:	48 8d 14 f1          	lea    (%rcx,%rsi,8),%rdx
    7874:	4c 8b 0a             	mov    (%rdx),%r9
    7877:	48 89 c1             	mov    %rax,%rcx
    787a:	49 d3 e9             	shr    %cl,%r9
    787d:	4d 21 d1             	and    %r10,%r9
    7880:	48 8b 8d 48 fe ff ff 	mov    -0x1b8(%rbp),%rcx
    7887:	48 8d 14 f1          	lea    (%rcx,%rsi,8),%rdx
    788b:	48 8b 32             	mov    (%rdx),%rsi
    788e:	48 89 c1             	mov    %rax,%rcx
    7891:	48 d3 ee             	shr    %cl,%rsi
    7894:	4c 21 d6             	and    %r10,%rsi
    7897:	4c 89 8d 80 fd ff ff 	mov    %r9,-0x280(%rbp)
    789e:	49 89 f1             	mov    %rsi,%r9
    78a1:	e9 7c 00 00 00       	jmp    0x7922
    78a6:	48 8b 85 38 fe ff ff 	mov    -0x1c8(%rbp),%rax
    78ad:	49 29 c3             	sub    %rax,%r11
    78b0:	48 8b 8d 30 fe ff ff 	mov    -0x1d0(%rbp),%rcx
    78b7:	49 39 cb             	cmp    %rcx,%r11
    78ba:	ba 00 00 00 00       	mov    $0x0,%edx
    78bf:	0f 92 c2             	setb   %dl
    78c2:	31 f6                	xor    %esi,%esi
    78c4:	48 85 d2             	test   %rdx,%rdx
    78c7:	4c 0f 44 de          	cmove  %rsi,%r11
    78cb:	4d 89 d8             	mov    %r11,%r8
    78ce:	49 c1 e8 06          	shr    $0x6,%r8
    78d2:	4d 89 da             	mov    %r11,%r10
    78d5:	49 83 e2 3f          	and    $0x3f,%r10
    78d9:	4b 8d 04 c7          	lea    (%r15,%r8,8),%rax
    78dd:	4c 8b 00             	mov    (%rax),%r8
    78e0:	4c 89 d1             	mov    %r10,%rcx
    78e3:	49 d3 e8             	shr    %cl,%r8
    78e6:	b8 01 00 00 00       	mov    $0x1,%eax
    78eb:	49 21 c0             	and    %rax,%r8
    78ee:	49 21 d0             	and    %rdx,%r8
    78f1:	b9 10 00 00 00       	mov    $0x10,%ecx
    78f6:	4c 0f af d9          	imul   %rcx,%r11
    78fa:	48 8b 8d 40 fe ff ff 	mov    -0x1c0(%rbp),%rcx
    7901:	4a 8d 54 19 f8       	lea    -0x8(%rcx,%r11,1),%rdx
    7906:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    790a:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    790e:	49 c1 ea 20          	shr    $0x20,%r10
    7912:	49 21 c2             	and    %rax,%r10
    7915:	4c 89 c7             	mov    %r8,%rdi
    7918:	4c 89 9d 80 fd ff ff 	mov    %r11,-0x280(%rbp)
    791f:	4d 89 d1             	mov    %r10,%r9
    7922:	48 85 ff             	test   %rdi,%rdi
    7925:	0f 84 a3 05 00 00    	je     0x7ece
    792b:	49 83 f9 00          	cmp    $0x0,%r9
    792f:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    7935:	41 0f 95 c1          	setne  %r9b
    7939:	48 8b 85 d0 fd ff ff 	mov    -0x230(%rbp),%rax
    7940:	48 89 c1             	mov    %rax,%rcx
    7943:	48 83 c1 01          	add    $0x1,%rcx
    7947:	48 8b 95 80 fd ff ff 	mov    -0x280(%rbp),%rdx
    794e:	48 63 d2             	movslq %edx,%rdx
    7951:	31 f6                	xor    %esi,%esi
    7953:	4d 85 c9             	test   %r9,%r9
    7956:	48 0f 44 f2          	cmove  %rdx,%rsi
    795a:	48 8b 95 c8 fd ff ff 	mov    -0x238(%rbp),%rdx
    7961:	48 39 f2             	cmp    %rsi,%rdx
    7964:	bf 00 00 00 00       	mov    $0x0,%edi
    7969:	40 0f 94 c7          	sete   %dil
    796d:	4c 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%r8
    7974:	4d 39 c8             	cmp    %r9,%r8
    7977:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    797d:	41 0f 94 c2          	sete   %r10b
    7981:	4c 21 d7             	and    %r10,%rdi
    7984:	48 85 ff             	test   %rdi,%rdi
    7987:	48 89 8d 80 fd ff ff 	mov    %rcx,-0x280(%rbp)
    798e:	48 89 b5 78 fd ff ff 	mov    %rsi,-0x288(%rbp)
    7995:	4c 89 8d 70 fd ff ff 	mov    %r9,-0x290(%rbp)
    799c:	0f 84 69 00 00 00    	je     0x7a0b
    79a2:	48 8b bd a8 fd ff ff 	mov    -0x258(%rbp),%rdi
    79a9:	49 89 fa             	mov    %rdi,%r10
    79ac:	49 83 c2 01          	add    $0x1,%r10
    79b0:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    79b6:	48 8b b5 88 fd ff ff 	mov    -0x278(%rbp),%rsi
    79bd:	49 89 f1             	mov    %rsi,%r9
    79c0:	4d 31 d9             	xor    %r11,%r9
    79c3:	45 31 db             	xor    %r11d,%r11d
    79c6:	48 8b b5 90 fd ff ff 	mov    -0x270(%rbp),%rsi
    79cd:	48 89 f1             	mov    %rsi,%rcx
    79d0:	4d 85 c9             	test   %r9,%r9
    79d3:	49 0f 44 cb          	cmove  %r11,%rcx
    79d7:	4c 8b 9d 98 fd ff ff 	mov    -0x268(%rbp),%r11
    79de:	4c 89 de             	mov    %r11,%rsi
    79e1:	4c 01 ce             	add    %r9,%rsi
    79e4:	4c 8b 8d a0 fd ff ff 	mov    -0x260(%rbp),%r9
    79eb:	4c 89 ca             	mov    %r9,%rdx
    79ee:	48 01 ca             	add    %rcx,%rdx
    79f1:	4c 89 95 a8 fd ff ff 	mov    %r10,-0x258(%rbp)
    79f8:	48 89 95 a0 fd ff ff 	mov    %rdx,-0x260(%rbp)
    79ff:	48 89 b5 98 fd ff ff 	mov    %rsi,-0x268(%rbp)
    7a06:	e9 a9 04 00 00       	jmp    0x7eb4
    7a0b:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
    7a12:	48 85 c0             	test   %rax,%rax
    7a15:	0f 84 03 04 00 00    	je     0x7e1e
    7a1b:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    7a22:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    7a26:	48 85 d2             	test   %rdx,%rdx
    7a29:	0f 84 3d 01 00 00    	je     0x7b6c
    7a2f:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    7a33:	be 40 00 00 00       	mov    $0x40,%esi
    7a38:	48 29 d6             	sub    %rdx,%rsi
    7a3b:	48 8b bd b8 fd ff ff 	mov    -0x248(%rbp),%rdi
    7a42:	48 89 f1             	mov    %rsi,%rcx
    7a45:	49 89 f8             	mov    %rdi,%r8
    7a48:	49 d3 e8             	shr    %cl,%r8
    7a4b:	31 c9                	xor    %ecx,%ecx
    7a4d:	48 39 ca             	cmp    %rcx,%rdx
    7a50:	ba 00 00 00 00       	mov    $0x0,%edx
    7a55:	0f 94 c2             	sete   %dl
    7a58:	48 85 d2             	test   %rdx,%rdx
    7a5b:	49 0f 44 c8          	cmove  %r8,%rcx
    7a5f:	48 8b 95 58 fe ff ff 	mov    -0x1a8(%rbp),%rdx
    7a66:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    7a6a:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    7a6e:	49 8b 30             	mov    (%r8),%rsi
    7a71:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    7a78:	00 28 00 
    7a7b:	4c 39 ce             	cmp    %r9,%rsi
    7a7e:	4c 89 85 68 fd ff ff 	mov    %r8,-0x298(%rbp)
    7a85:	0f 82 0c 00 00 00    	jb     0x7a97
    7a8b:	48 89 b5 60 fd ff ff 	mov    %rsi,-0x2a0(%rbp)
    7a92:	e9 47 00 00 00       	jmp    0x7ade
    7a97:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    7a9b:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    7a9f:	48 89 b5 58 fd ff ff 	mov    %rsi,-0x2a8(%rbp)
    7aa6:	48 89 d6             	mov    %rdx,%rsi
    7aa9:	48 89 ca             	mov    %rcx,%rdx
    7aac:	48 8b 8d 58 fd ff ff 	mov    -0x2a8(%rbp),%rcx
    7ab3:	e8 28 86 ff ff       	call   0xe0
    7ab8:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    7abf:	31 d2                	xor    %edx,%edx
    7ac1:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    7ac5:	48 83 f8 00          	cmp    $0x0,%rax
    7ac9:	0f 8f 08 00 00 00    	jg     0x7ad7
    7acf:	49 89 c4             	mov    %rax,%r12
    7ad2:	e9 e1 29 00 00       	jmp    0xa4b8
    7ad7:	48 89 85 60 fd ff ff 	mov    %rax,-0x2a0(%rbp)
    7ade:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
    7ae5:	48 89 c1             	mov    %rax,%rcx
    7ae8:	48 83 c1 28          	add    $0x28,%rcx
    7aec:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    7af3:	00 28 00 
    7af6:	48 29 d1             	sub    %rdx,%rcx
    7af9:	48 8b 95 68 fd ff ff 	mov    -0x298(%rbp),%rdx
    7b00:	48 89 0a             	mov    %rcx,(%rdx)
    7b03:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    7b0a:	ff 00 00 
    7b0d:	48 21 c8             	and    %rcx,%rax
    7b10:	31 c9                	xor    %ecx,%ecx
    7b12:	48 8b 95 c8 fd ff ff 	mov    -0x238(%rbp),%rdx
    7b19:	48 89 10             	mov    %rdx,(%rax)
    7b1c:	48 8b b5 c0 fd ff ff 	mov    -0x240(%rbp),%rsi
    7b23:	48 89 70 08          	mov    %rsi,0x8(%rax)
    7b27:	48 89 48 10          	mov    %rcx,0x10(%rax)
    7b2b:	48 89 48 18          	mov    %rcx,0x18(%rax)
    7b2f:	48 89 48 20          	mov    %rcx,0x20(%rax)
    7b33:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    7b3a:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    7b3e:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    7b44:	4c 01 c7             	add    %r8,%rdi
    7b47:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    7b4b:	48 89 85 60 fd ff ff 	mov    %rax,-0x2a0(%rbp)
    7b52:	b8 01 00 00 00       	mov    $0x1,%eax
    7b57:	48 89 85 68 fd ff ff 	mov    %rax,-0x298(%rbp)
    7b5e:	31 c0                	xor    %eax,%eax
    7b60:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
    7b67:	e9 a4 01 00 00       	jmp    0x7d10
    7b6c:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    7b73:	48 8b 70 10          	mov    0x10(%rax),%rsi
    7b77:	48 8b 48 18          	mov    0x18(%rax),%rcx
    7b7b:	48 89 ca             	mov    %rcx,%rdx
    7b7e:	f3 48 0f b8 d2       	popcnt %rdx,%rdx
    7b83:	bf 40 00 00 00       	mov    $0x40,%edi
    7b88:	48 29 d7             	sub    %rdx,%rdi
    7b8b:	48 89 8d 50 fd ff ff 	mov    %rcx,-0x2b0(%rbp)
    7b92:	4c 8b 85 b8 fd ff ff 	mov    -0x248(%rbp),%r8
    7b99:	48 89 f9             	mov    %rdi,%rcx
    7b9c:	4d 89 c1             	mov    %r8,%r9
    7b9f:	49 d3 e9             	shr    %cl,%r9
    7ba2:	31 c9                	xor    %ecx,%ecx
    7ba4:	48 39 ca             	cmp    %rcx,%rdx
    7ba7:	ba 00 00 00 00       	mov    $0x0,%edx
    7bac:	0f 94 c2             	sete   %dl
    7baf:	48 85 d2             	test   %rdx,%rdx
    7bb2:	49 0f 44 c9          	cmove  %r9,%rcx
    7bb6:	ba 01 00 00 00       	mov    $0x1,%edx
    7bbb:	48 89 cf             	mov    %rcx,%rdi
    7bbe:	48 01 d7             	add    %rdx,%rdi
    7bc1:	4c 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%r10
    7bc8:	49 89 f9             	mov    %rdi,%r9
    7bcb:	4d 21 d1             	and    %r10,%r9
    7bce:	bf 28 00 00 00       	mov    $0x28,%edi
    7bd3:	48 0f af cf          	imul   %rdi,%rcx
    7bd7:	48 8d 3c 0e          	lea    (%rsi,%rcx,1),%rdi
    7bdb:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    7bdf:	48 85 c9             	test   %rcx,%rcx
    7be2:	0f 84 b2 00 00 00    	je     0x7c9a
    7be8:	48 8b 0f             	mov    (%rdi),%rcx
    7beb:	4c 8b 57 08          	mov    0x8(%rdi),%r10
    7bef:	4c 8b 9d c8 fd ff ff 	mov    -0x238(%rbp),%r11
    7bf6:	49 39 cb             	cmp    %rcx,%r11
    7bf9:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    7bff:	41 0f 94 c0          	sete   %r8b
    7c03:	48 8b 8d c0 fd ff ff 	mov    -0x240(%rbp),%rcx
    7c0a:	4c 39 d1             	cmp    %r10,%rcx
    7c0d:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    7c13:	41 0f 94 c3          	sete   %r11b
    7c17:	4d 21 d8             	and    %r11,%r8
    7c1a:	4d 85 c0             	test   %r8,%r8
    7c1d:	0f 84 0c 00 00 00    	je     0x7c2f
    7c23:	48 89 bd 60 fd ff ff 	mov    %rdi,-0x2a0(%rbp)
    7c2a:	e9 54 00 00 00       	jmp    0x7c83
    7c2f:	bf 28 00 00 00       	mov    $0x28,%edi
    7c34:	4c 0f af cf          	imul   %rdi,%r9
    7c38:	4a 8d 3c 0e          	lea    (%rsi,%r9,1),%rdi
    7c3c:	48 8b 77 10          	mov    0x10(%rdi),%rsi
    7c40:	48 85 f6             	test   %rsi,%rsi
    7c43:	0f 84 51 00 00 00    	je     0x7c9a
    7c49:	48 8b 37             	mov    (%rdi),%rsi
    7c4c:	4c 8b 47 08          	mov    0x8(%rdi),%r8
    7c50:	4c 8b 8d c8 fd ff ff 	mov    -0x238(%rbp),%r9
    7c57:	49 39 f1             	cmp    %rsi,%r9
    7c5a:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    7c60:	41 0f 94 c2          	sete   %r10b
    7c64:	4c 39 c1             	cmp    %r8,%rcx
    7c67:	be 00 00 00 00       	mov    $0x0,%esi
    7c6c:	40 0f 94 c6          	sete   %sil
    7c70:	49 21 f2             	and    %rsi,%r10
    7c73:	4d 85 d2             	test   %r10,%r10
    7c76:	0f 84 1e 00 00 00    	je     0x7c9a
    7c7c:	48 89 bd 60 fd ff ff 	mov    %rdi,-0x2a0(%rbp)
    7c83:	31 c0                	xor    %eax,%eax
    7c85:	48 89 85 68 fd ff ff 	mov    %rax,-0x298(%rbp)
    7c8c:	31 c0                	xor    %eax,%eax
    7c8e:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
    7c95:	e9 76 00 00 00       	jmp    0x7d10
    7c9a:	48 8d 85 10 ff ff ff 	lea    -0xf0(%rbp),%rax
    7ca1:	48 89 c1             	mov    %rax,%rcx
    7ca4:	48 8b 95 c8 fd ff ff 	mov    -0x238(%rbp),%rdx
    7cab:	48 89 11             	mov    %rdx,(%rcx)
    7cae:	48 8b b5 c0 fd ff ff 	mov    -0x240(%rbp),%rsi
    7cb5:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    7cb9:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    7cbd:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
    7cc4:	48 89 ca             	mov    %rcx,%rdx
    7cc7:	e8 24 84 ff ff       	call   0xf0
    7ccc:	48 83 f8 00          	cmp    $0x0,%rax
    7cd0:	0f 8d 08 00 00 00    	jge    0x7cde
    7cd6:	49 89 c4             	mov    %rax,%r12
    7cd9:	e9 da 27 00 00       	jmp    0xa4b8
    7cde:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    7ce5:	48 8b 11             	mov    (%rcx),%rdx
    7ce8:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    7cec:	48 83 e6 01          	and    $0x1,%rsi
    7cf0:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    7cf4:	48 89 85 60 fd ff ff 	mov    %rax,-0x2a0(%rbp)
    7cfb:	b8 01 00 00 00       	mov    $0x1,%eax
    7d00:	48 89 85 68 fd ff ff 	mov    %rax,-0x298(%rbp)
    7d07:	31 c0                	xor    %eax,%eax
    7d09:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
    7d10:	48 8b 85 68 fd ff ff 	mov    -0x298(%rbp),%rax
    7d17:	48 85 c0             	test   %rax,%rax
    7d1a:	0f 84 6b 00 00 00    	je     0x7d8b
    7d20:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
    7d27:	48 8b 8d a8 fd ff ff 	mov    -0x258(%rbp),%rcx
    7d2e:	48 89 48 10          	mov    %rcx,0x10(%rax)
    7d32:	31 d2                	xor    %edx,%edx
    7d34:	48 39 d1             	cmp    %rdx,%rcx
    7d37:	be 00 00 00 00       	mov    $0x0,%esi
    7d3c:	40 0f 95 c6          	setne  %sil
    7d40:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    7d44:	48 09 f7             	or     %rsi,%rdi
    7d47:	48 0f be ff          	movsbq %dil,%rdi
    7d4b:	40 88 78 20          	mov    %dil,0x20(%rax)
    7d4f:	48 8b b5 a0 fd ff ff 	mov    -0x260(%rbp),%rsi
    7d56:	48 89 70 18          	mov    %rsi,0x18(%rax)
    7d5a:	4c 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%r8
    7d61:	49 39 d0             	cmp    %rdx,%r8
    7d64:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    7d6a:	41 0f 95 c1          	setne  %r9b
    7d6e:	40 0f b6 ff          	movzbl %dil,%edi
    7d72:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    7d78:	4d 85 c9             	test   %r9,%r9
    7d7b:	4c 0f 44 d2          	cmove  %rdx,%r10
    7d7f:	4c 09 d7             	or     %r10,%rdi
    7d82:	40 88 78 20          	mov    %dil,0x20(%rax)
    7d86:	e9 93 00 00 00       	jmp    0x7e1e
    7d8b:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
    7d92:	48 8b 48 10          	mov    0x10(%rax),%rcx
    7d96:	48 8b 95 a8 fd ff ff 	mov    -0x258(%rbp),%rdx
    7d9d:	48 01 d1             	add    %rdx,%rcx
    7da0:	48 89 48 10          	mov    %rcx,0x10(%rax)
    7da4:	31 f6                	xor    %esi,%esi
    7da6:	48 39 f1             	cmp    %rsi,%rcx
    7da9:	b9 00 00 00 00       	mov    $0x0,%ecx
    7dae:	0f 95 c1             	setne  %cl
    7db1:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    7db5:	48 09 cf             	or     %rcx,%rdi
    7db8:	48 0f be ff          	movsbq %dil,%rdi
    7dbc:	40 88 78 20          	mov    %dil,0x20(%rax)
    7dc0:	48 8b 48 18          	mov    0x18(%rax),%rcx
    7dc4:	40 0f b6 ff          	movzbl %dil,%edi
    7dc8:	49 89 f8             	mov    %rdi,%r8
    7dcb:	49 83 e0 02          	and    $0x2,%r8
    7dcf:	49 39 f0             	cmp    %rsi,%r8
    7dd2:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    7dd8:	41 0f 95 c0          	setne  %r8b
    7ddc:	45 31 c9             	xor    %r9d,%r9d
    7ddf:	4d 85 c0             	test   %r8,%r8
    7de2:	49 0f 44 c9          	cmove  %r9,%rcx
    7de6:	4c 8b 8d 98 fd ff ff 	mov    -0x268(%rbp),%r9
    7ded:	4d 01 c8             	add    %r9,%r8
    7df0:	4c 8b 95 a0 fd ff ff 	mov    -0x260(%rbp),%r10
    7df7:	4c 01 d1             	add    %r10,%rcx
    7dfa:	48 89 48 18          	mov    %rcx,0x18(%rax)
    7dfe:	49 39 f0             	cmp    %rsi,%r8
    7e01:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    7e07:	41 0f 95 c0          	setne  %r8b
    7e0b:	b9 02 00 00 00       	mov    $0x2,%ecx
    7e10:	4d 85 c0             	test   %r8,%r8
    7e13:	48 0f 44 ce          	cmove  %rsi,%rcx
    7e17:	48 09 cf             	or     %rcx,%rdi
    7e1a:	40 88 78 20          	mov    %dil,0x20(%rax)
    7e1e:	b8 01 00 00 00       	mov    $0x1,%eax
    7e23:	48 8b 8d 88 fd ff ff 	mov    -0x278(%rbp),%rcx
    7e2a:	48 31 c1             	xor    %rax,%rcx
    7e2d:	31 c0                	xor    %eax,%eax
    7e2f:	48 8b 95 90 fd ff ff 	mov    -0x270(%rbp),%rdx
    7e36:	48 85 c9             	test   %rcx,%rcx
    7e39:	48 0f 44 d0          	cmove  %rax,%rdx
    7e3d:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    7e44:	79 37 9e 
    7e47:	48 be 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%rsi
    7e4e:	79 37 9e 
    7e51:	48 8b bd 78 fd ff ff 	mov    -0x288(%rbp),%rdi
    7e58:	48 31 fe             	xor    %rdi,%rsi
    7e5b:	48 0f af f0          	imul   %rax,%rsi
    7e5f:	49 89 f0             	mov    %rsi,%r8
    7e62:	49 c1 e8 1d          	shr    $0x1d,%r8
    7e66:	4c 31 c6             	xor    %r8,%rsi
    7e69:	4c 8b 85 70 fd ff ff 	mov    -0x290(%rbp),%r8
    7e70:	4c 31 c6             	xor    %r8,%rsi
    7e73:	48 0f af f0          	imul   %rax,%rsi
    7e77:	49 89 f1             	mov    %rsi,%r9
    7e7a:	49 c1 e9 1d          	shr    $0x1d,%r9
    7e7e:	4c 31 ce             	xor    %r9,%rsi
    7e81:	48 0f af f0          	imul   %rax,%rsi
    7e85:	48 89 bd c8 fd ff ff 	mov    %rdi,-0x238(%rbp)
    7e8c:	4c 89 85 c0 fd ff ff 	mov    %r8,-0x240(%rbp)
    7e93:	48 89 b5 b8 fd ff ff 	mov    %rsi,-0x248(%rbp)
    7e9a:	b8 01 00 00 00       	mov    $0x1,%eax
    7e9f:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
    7ea6:	48 89 95 a0 fd ff ff 	mov    %rdx,-0x260(%rbp)
    7ead:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
    7eb4:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
    7ebb:	48 89 85 d0 fd ff ff 	mov    %rax,-0x230(%rbp)
    7ec2:	b8 01 00 00 00       	mov    $0x1,%eax
    7ec7:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
    7ece:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
    7ed5:	b9 01 00 00 00       	mov    $0x1,%ecx
    7eda:	48 89 c2             	mov    %rax,%rdx
    7edd:	48 01 ca             	add    %rcx,%rdx
    7ee0:	48 89 95 d8 fd ff ff 	mov    %rdx,-0x228(%rbp)
    7ee7:	e9 af f8 ff ff       	jmp    0x779b
    7eec:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
    7ef3:	48 85 c0             	test   %rax,%rax
    7ef6:	0f 84 00 04 00 00    	je     0x82fc
    7efc:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    7f03:	48 8b 48 68          	mov    0x68(%rax),%rcx
    7f07:	48 85 c9             	test   %rcx,%rcx
    7f0a:	0f 84 44 01 00 00    	je     0x8054
    7f10:	48 8b 48 38          	mov    0x38(%rax),%rcx
    7f14:	ba 40 00 00 00       	mov    $0x40,%edx
    7f19:	48 29 ca             	sub    %rcx,%rdx
    7f1c:	48 89 8d b0 fd ff ff 	mov    %rcx,-0x250(%rbp)
    7f23:	48 8b b5 b8 fd ff ff 	mov    -0x248(%rbp),%rsi
    7f2a:	48 89 d1             	mov    %rdx,%rcx
    7f2d:	48 89 f7             	mov    %rsi,%rdi
    7f30:	48 d3 ef             	shr    %cl,%rdi
    7f33:	31 c9                	xor    %ecx,%ecx
    7f35:	48 8b 95 b0 fd ff ff 	mov    -0x250(%rbp),%rdx
    7f3c:	48 39 ca             	cmp    %rcx,%rdx
    7f3f:	ba 00 00 00 00       	mov    $0x0,%edx
    7f44:	0f 94 c2             	sete   %dl
    7f47:	48 85 d2             	test   %rdx,%rdx
    7f4a:	48 0f 44 cf          	cmove  %rdi,%rcx
    7f4e:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7f52:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    7f56:	48 8b 17             	mov    (%rdi),%rdx
    7f59:	49 b8 00 00 00 00 00 	movabs $0x28000000000000,%r8
    7f60:	00 28 00 
    7f63:	4c 39 c2             	cmp    %r8,%rdx
    7f66:	48 89 bd b0 fd ff ff 	mov    %rdi,-0x250(%rbp)
    7f6d:	0f 82 0c 00 00 00    	jb     0x7f7f
    7f73:	48 89 95 d8 fd ff ff 	mov    %rdx,-0x228(%rbp)
    7f7a:	e9 47 00 00 00       	jmp    0x7fc6
    7f7f:	48 8b 50 60          	mov    0x60(%rax),%rdx
    7f83:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    7f87:	48 89 c6             	mov    %rax,%rsi
    7f8a:	48 89 95 80 fd ff ff 	mov    %rdx,-0x280(%rbp)
    7f91:	48 89 ca             	mov    %rcx,%rdx
    7f94:	48 8b 8d 80 fd ff ff 	mov    -0x280(%rbp),%rcx
    7f9b:	e8 40 81 ff ff       	call   0xe0
    7fa0:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    7fa7:	31 d2                	xor    %edx,%edx
    7fa9:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    7fad:	48 83 f8 00          	cmp    $0x0,%rax
    7fb1:	0f 8f 08 00 00 00    	jg     0x7fbf
    7fb7:	49 89 c4             	mov    %rax,%r12
    7fba:	e9 f9 24 00 00       	jmp    0xa4b8
    7fbf:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
    7fc6:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
    7fcd:	48 89 c1             	mov    %rax,%rcx
    7fd0:	48 83 c1 28          	add    $0x28,%rcx
    7fd4:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    7fdb:	00 28 00 
    7fde:	48 29 d1             	sub    %rdx,%rcx
    7fe1:	48 8b 95 b0 fd ff ff 	mov    -0x250(%rbp),%rdx
    7fe8:	48 89 0a             	mov    %rcx,(%rdx)
    7feb:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    7ff2:	ff 00 00 
    7ff5:	48 21 c8             	and    %rcx,%rax
    7ff8:	31 c9                	xor    %ecx,%ecx
    7ffa:	48 8b 95 c8 fd ff ff 	mov    -0x238(%rbp),%rdx
    8001:	48 89 10             	mov    %rdx,(%rax)
    8004:	48 8b b5 c0 fd ff ff 	mov    -0x240(%rbp),%rsi
    800b:	48 89 70 08          	mov    %rsi,0x8(%rax)
    800f:	48 89 48 10          	mov    %rcx,0x10(%rax)
    8013:	48 89 48 18          	mov    %rcx,0x18(%rax)
    8017:	48 89 48 20          	mov    %rcx,0x20(%rax)
    801b:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    8022:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    8026:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    802c:	4c 01 c7             	add    %r8,%rdi
    802f:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    8033:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
    803a:	b8 01 00 00 00       	mov    $0x1,%eax
    803f:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
    8046:	31 c0                	xor    %eax,%eax
    8048:	48 89 85 80 fd ff ff 	mov    %rax,-0x280(%rbp)
    804f:	e9 9c 01 00 00       	jmp    0x81f0
    8054:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    805b:	48 8b 48 10          	mov    0x10(%rax),%rcx
    805f:	48 8b 50 18          	mov    0x18(%rax),%rdx
    8063:	48 89 d6             	mov    %rdx,%rsi
    8066:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    806b:	bf 40 00 00 00       	mov    $0x40,%edi
    8070:	48 29 f7             	sub    %rsi,%rdi
    8073:	48 89 8d 70 fd ff ff 	mov    %rcx,-0x290(%rbp)
    807a:	4c 8b 85 b8 fd ff ff 	mov    -0x248(%rbp),%r8
    8081:	48 89 f9             	mov    %rdi,%rcx
    8084:	49 d3 e8             	shr    %cl,%r8
    8087:	31 c9                	xor    %ecx,%ecx
    8089:	48 39 ce             	cmp    %rcx,%rsi
    808c:	be 00 00 00 00       	mov    $0x0,%esi
    8091:	40 0f 94 c6          	sete   %sil
    8095:	48 85 f6             	test   %rsi,%rsi
    8098:	49 0f 44 c8          	cmove  %r8,%rcx
    809c:	be 01 00 00 00       	mov    $0x1,%esi
    80a1:	48 89 cf             	mov    %rcx,%rdi
    80a4:	48 01 f7             	add    %rsi,%rdi
    80a7:	48 21 d7             	and    %rdx,%rdi
    80aa:	ba 28 00 00 00       	mov    $0x28,%edx
    80af:	48 0f af ca          	imul   %rdx,%rcx
    80b3:	48 8b 95 70 fd ff ff 	mov    -0x290(%rbp),%rdx
    80ba:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
    80be:	49 8b 48 10          	mov    0x10(%r8),%rcx
    80c2:	48 85 c9             	test   %rcx,%rcx
    80c5:	0f 84 af 00 00 00    	je     0x817a
    80cb:	49 8b 08             	mov    (%r8),%rcx
    80ce:	4d 8b 48 08          	mov    0x8(%r8),%r9
    80d2:	4c 8b 95 c8 fd ff ff 	mov    -0x238(%rbp),%r10
    80d9:	49 39 ca             	cmp    %rcx,%r10
    80dc:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    80e2:	41 0f 94 c3          	sete   %r11b
    80e6:	48 8b 8d c0 fd ff ff 	mov    -0x240(%rbp),%rcx
    80ed:	4c 39 c9             	cmp    %r9,%rcx
    80f0:	ba 00 00 00 00       	mov    $0x0,%edx
    80f5:	0f 94 c2             	sete   %dl
    80f8:	49 21 d3             	and    %rdx,%r11
    80fb:	4d 85 db             	test   %r11,%r11
    80fe:	0f 84 0c 00 00 00    	je     0x8110
    8104:	4c 89 85 d8 fd ff ff 	mov    %r8,-0x228(%rbp)
    810b:	e9 53 00 00 00       	jmp    0x8163
    8110:	ba 28 00 00 00       	mov    $0x28,%edx
    8115:	48 0f af fa          	imul   %rdx,%rdi
    8119:	48 8b 95 70 fd ff ff 	mov    -0x290(%rbp),%rdx
    8120:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    8124:	49 8b 50 10          	mov    0x10(%r8),%rdx
    8128:	48 85 d2             	test   %rdx,%rdx
    812b:	0f 84 49 00 00 00    	je     0x817a
    8131:	49 8b 10             	mov    (%r8),%rdx
    8134:	49 8b 78 08          	mov    0x8(%r8),%rdi
    8138:	49 39 d2             	cmp    %rdx,%r10
    813b:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    8141:	41 0f 94 c1          	sete   %r9b
    8145:	48 39 f9             	cmp    %rdi,%rcx
    8148:	ba 00 00 00 00       	mov    $0x0,%edx
    814d:	0f 94 c2             	sete   %dl
    8150:	49 21 d1             	and    %rdx,%r9
    8153:	4d 85 c9             	test   %r9,%r9
    8156:	0f 84 1e 00 00 00    	je     0x817a
    815c:	4c 89 85 d8 fd ff ff 	mov    %r8,-0x228(%rbp)
    8163:	31 c0                	xor    %eax,%eax
    8165:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
    816c:	31 c0                	xor    %eax,%eax
    816e:	48 89 85 80 fd ff ff 	mov    %rax,-0x280(%rbp)
    8175:	e9 76 00 00 00       	jmp    0x81f0
    817a:	48 8d 85 00 ff ff ff 	lea    -0x100(%rbp),%rax
    8181:	48 89 c1             	mov    %rax,%rcx
    8184:	48 8b 95 c8 fd ff ff 	mov    -0x238(%rbp),%rdx
    818b:	48 89 11             	mov    %rdx,(%rcx)
    818e:	48 8b 95 c0 fd ff ff 	mov    -0x240(%rbp),%rdx
    8195:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    8199:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    819d:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
    81a4:	48 89 ca             	mov    %rcx,%rdx
    81a7:	e8 44 7f ff ff       	call   0xf0
    81ac:	48 83 f8 00          	cmp    $0x0,%rax
    81b0:	0f 8d 08 00 00 00    	jge    0x81be
    81b6:	49 89 c4             	mov    %rax,%r12
    81b9:	e9 fa 22 00 00       	jmp    0xa4b8
    81be:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    81c5:	48 8b 11             	mov    (%rcx),%rdx
    81c8:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    81cc:	48 83 e6 01          	and    $0x1,%rsi
    81d0:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    81d4:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
    81db:	b8 01 00 00 00       	mov    $0x1,%eax
    81e0:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
    81e7:	31 c0                	xor    %eax,%eax
    81e9:	48 89 85 80 fd ff ff 	mov    %rax,-0x280(%rbp)
    81f0:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
    81f7:	48 85 c0             	test   %rax,%rax
    81fa:	0f 84 6b 00 00 00    	je     0x826b
    8200:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
    8207:	48 8b 8d a8 fd ff ff 	mov    -0x258(%rbp),%rcx
    820e:	48 89 48 10          	mov    %rcx,0x10(%rax)
    8212:	31 d2                	xor    %edx,%edx
    8214:	48 39 d1             	cmp    %rdx,%rcx
    8217:	be 00 00 00 00       	mov    $0x0,%esi
    821c:	40 0f 95 c6          	setne  %sil
    8220:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    8224:	48 09 f7             	or     %rsi,%rdi
    8227:	48 0f be ff          	movsbq %dil,%rdi
    822b:	40 88 78 20          	mov    %dil,0x20(%rax)
    822f:	48 8b b5 a0 fd ff ff 	mov    -0x260(%rbp),%rsi
    8236:	48 89 70 18          	mov    %rsi,0x18(%rax)
    823a:	4c 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%r8
    8241:	49 39 d0             	cmp    %rdx,%r8
    8244:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    824a:	41 0f 95 c1          	setne  %r9b
    824e:	40 0f b6 ff          	movzbl %dil,%edi
    8252:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    8258:	4d 85 c9             	test   %r9,%r9
    825b:	4c 0f 44 d2          	cmove  %rdx,%r10
    825f:	4c 09 d7             	or     %r10,%rdi
    8262:	40 88 78 20          	mov    %dil,0x20(%rax)
    8266:	e9 91 00 00 00       	jmp    0x82fc
    826b:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
    8272:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8276:	48 8b 95 a8 fd ff ff 	mov    -0x258(%rbp),%rdx
    827d:	48 01 d1             	add    %rdx,%rcx
    8280:	48 89 48 10          	mov    %rcx,0x10(%rax)
    8284:	31 d2                	xor    %edx,%edx
    8286:	48 39 d1             	cmp    %rdx,%rcx
    8289:	b9 00 00 00 00       	mov    $0x0,%ecx
    828e:	0f 95 c1             	setne  %cl
    8291:	0f b6 70 20          	movzbl 0x20(%rax),%esi
    8295:	48 09 ce             	or     %rcx,%rsi
    8298:	48 0f be f6          	movsbq %sil,%rsi
    829c:	40 88 70 20          	mov    %sil,0x20(%rax)
    82a0:	48 8b 48 18          	mov    0x18(%rax),%rcx
    82a4:	40 0f b6 f6          	movzbl %sil,%esi
    82a8:	48 89 f7             	mov    %rsi,%rdi
    82ab:	48 83 e7 02          	and    $0x2,%rdi
    82af:	48 39 d7             	cmp    %rdx,%rdi
    82b2:	bf 00 00 00 00       	mov    $0x0,%edi
    82b7:	40 0f 95 c7          	setne  %dil
    82bb:	45 31 c0             	xor    %r8d,%r8d
    82be:	48 85 ff             	test   %rdi,%rdi
    82c1:	49 0f 44 c8          	cmove  %r8,%rcx
    82c5:	4c 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%r8
    82cc:	4c 01 c7             	add    %r8,%rdi
    82cf:	4c 8b 85 a0 fd ff ff 	mov    -0x260(%rbp),%r8
    82d6:	4c 01 c1             	add    %r8,%rcx
    82d9:	48 89 48 18          	mov    %rcx,0x18(%rax)
    82dd:	48 39 d7             	cmp    %rdx,%rdi
    82e0:	bf 00 00 00 00       	mov    $0x0,%edi
    82e5:	40 0f 95 c7          	setne  %dil
    82e9:	b9 02 00 00 00       	mov    $0x2,%ecx
    82ee:	48 85 ff             	test   %rdi,%rdi
    82f1:	48 0f 44 ca          	cmove  %rdx,%rcx
    82f5:	48 09 ce             	or     %rcx,%rsi
    82f8:	40 88 70 20          	mov    %sil,0x20(%rax)
    82fc:	48 8b 85 d0 fd ff ff 	mov    -0x230(%rbp),%rax
    8303:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
    830a:	e9 f6 20 00 00       	jmp    0xa405
    830f:	48 8b 85 00 fe ff ff 	mov    -0x200(%rbp),%rax
    8316:	48 85 c0             	test   %rax,%rax
    8319:	0f 84 b0 11 00 00    	je     0x94cf
    831f:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
    8326:	82 28 52 
    8329:	31 c9                	xor    %ecx,%ecx
    832b:	48 8b 95 f8 fd ff ff 	mov    -0x208(%rbp),%rdx
    8332:	48 89 95 00 fe ff ff 	mov    %rdx,-0x200(%rbp)
    8339:	31 d2                	xor    %edx,%edx
    833b:	48 89 95 d0 fd ff ff 	mov    %rdx,-0x230(%rbp)
    8342:	31 d2                	xor    %edx,%edx
    8344:	48 89 95 a0 fd ff ff 	mov    %rdx,-0x260(%rbp)
    834b:	48 89 85 98 fd ff ff 	mov    %rax,-0x268(%rbp)
    8352:	31 d2                	xor    %edx,%edx
    8354:	48 89 95 a8 fd ff ff 	mov    %rdx,-0x258(%rbp)
    835b:	31 d2                	xor    %edx,%edx
    835d:	48 89 95 b0 fd ff ff 	mov    %rdx,-0x250(%rbp)
    8364:	48 89 8d 80 fd ff ff 	mov    %rcx,-0x280(%rbp)
    836b:	31 d2                	xor    %edx,%edx
    836d:	48 89 95 c0 fd ff ff 	mov    %rdx,-0x240(%rbp)
    8374:	31 d2                	xor    %edx,%edx
    8376:	48 89 95 c8 fd ff ff 	mov    %rdx,-0x238(%rbp)
    837d:	48 8b 85 00 fe ff ff 	mov    -0x200(%rbp),%rax
    8384:	48 8b 8d e8 fd ff ff 	mov    -0x218(%rbp),%rcx
    838b:	48 39 c8             	cmp    %rcx,%rax
    838e:	0f 8d 18 0d 00 00    	jge    0x90ac
    8394:	48 8b 95 e0 fd ff ff 	mov    -0x220(%rbp),%rdx
    839b:	48 8d 34 c2          	lea    (%rdx,%rax,8),%rsi
    839f:	48 8b 3e             	mov    (%rsi),%rdi
    83a2:	48 8b b5 f0 fd ff ff 	mov    -0x210(%rbp),%rsi
    83a9:	49 89 f0             	mov    %rsi,%r8
    83ac:	49 01 f8             	add    %rdi,%r8
    83af:	49 8b 78 10          	mov    0x10(%r8),%rdi
    83b3:	4d 8b 48 08          	mov    0x8(%r8),%r9
    83b7:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    83bd:	4d 89 cb             	mov    %r9,%r11
    83c0:	4d 21 d3             	and    %r10,%r11
    83c3:	49 8b 40 18          	mov    0x18(%r8),%rax
    83c7:	49 d1 e9             	shr    $1,%r9
    83ca:	4d 21 d1             	and    %r10,%r9
    83cd:	45 31 c0             	xor    %r8d,%r8d
    83d0:	4d 39 c1             	cmp    %r8,%r9
    83d3:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    83d9:	41 0f 95 c1          	setne  %r9b
    83dd:	4d 85 db             	test   %r11,%r11
    83e0:	48 89 85 70 fd ff ff 	mov    %rax,-0x290(%rbp)
    83e7:	4c 89 8d b8 fd ff ff 	mov    %r9,-0x248(%rbp)
    83ee:	0f 85 83 0c 00 00    	jne    0x9077
    83f4:	48 63 ff             	movslq %edi,%rdi
    83f7:	49 89 fb             	mov    %rdi,%r11
    83fa:	49 83 fe 05          	cmp    $0x5,%r14
    83fe:	0f 85 ab 00 00 00    	jne    0x84af
    8404:	48 8b bd 38 fe ff ff 	mov    -0x1c8(%rbp),%rdi
    840b:	4c 89 d8             	mov    %r11,%rax
    840e:	48 29 f8             	sub    %rdi,%rax
    8411:	4c 8b 8d 30 fe ff ff 	mov    -0x1d0(%rbp),%r9
    8418:	4c 39 c8             	cmp    %r9,%rax
    841b:	ba 00 00 00 00       	mov    $0x0,%edx
    8420:	0f 92 c2             	setb   %dl
    8423:	48 85 d2             	test   %rdx,%rdx
    8426:	49 0f 44 c0          	cmove  %r8,%rax
    842a:	48 89 c6             	mov    %rax,%rsi
    842d:	48 c1 ee 06          	shr    $0x6,%rsi
    8431:	48 83 e0 3f          	and    $0x3f,%rax
    8435:	49 8d 3c f7          	lea    (%r15,%rsi,8),%rdi
    8439:	4c 8b 0f             	mov    (%rdi),%r9
    843c:	48 89 c1             	mov    %rax,%rcx
    843f:	49 d3 e9             	shr    %cl,%r9
    8442:	4d 21 d1             	and    %r10,%r9
    8445:	49 21 d1             	and    %rdx,%r9
    8448:	48 8b 8d 28 fe ff ff 	mov    -0x1d8(%rbp),%rcx
    844f:	48 8d 14 f1          	lea    (%rcx,%rsi,8),%rdx
    8453:	48 8b 3a             	mov    (%rdx),%rdi
    8456:	48 89 c1             	mov    %rax,%rcx
    8459:	48 d3 ef             	shr    %cl,%rdi
    845c:	4c 21 d7             	and    %r10,%rdi
    845f:	48 8b 8d 48 fe ff ff 	mov    -0x1b8(%rbp),%rcx
    8466:	48 8d 14 f1          	lea    (%rcx,%rsi,8),%rdx
    846a:	48 8b 32             	mov    (%rdx),%rsi
    846d:	48 89 c1             	mov    %rax,%rcx
    8470:	48 d3 ee             	shr    %cl,%rsi
    8473:	4c 21 d6             	and    %r10,%rsi
    8476:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
    847d:	48 89 c1             	mov    %rax,%rcx
    8480:	48 c1 e6 20          	shl    $0x20,%rsi
    8484:	4c 89 19             	mov    %r11,(%rcx)
    8487:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    848b:	48 89 79 10          	mov    %rdi,0x10(%rcx)
    848f:	4d 39 c1             	cmp    %r8,%r9
    8492:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    8498:	41 0f 95 c1          	setne  %r9b
    849c:	4d 85 c9             	test   %r9,%r9
    849f:	49 0f 44 c8          	cmove  %r8,%rcx
    84a3:	48 89 8d 78 fd ff ff 	mov    %rcx,-0x288(%rbp)
    84aa:	e9 1b 04 00 00       	jmp    0x88ca
    84af:	49 83 fe 01          	cmp    $0x1,%r14
    84b3:	0f 85 20 03 00 00    	jne    0x87d9
    84b9:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    84c0:	79 37 9e 
    84c3:	4c 89 d9             	mov    %r11,%rcx
    84c6:	48 c1 e9 2b          	shr    $0x2b,%rcx
    84ca:	4c 89 da             	mov    %r11,%rdx
    84cd:	48 c1 ea 2c          	shr    $0x2c,%rdx
    84d1:	48 31 d1             	xor    %rdx,%rcx
    84d4:	4c 89 da             	mov    %r11,%rdx
    84d7:	48 31 ca             	xor    %rcx,%rdx
    84da:	48 0f af d0          	imul   %rax,%rdx
    84de:	48 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%rax
    84e5:	48 85 c0             	test   %rax,%rax
    84e8:	48 89 95 90 fd ff ff 	mov    %rdx,-0x270(%rbp)
    84ef:	0f 84 27 01 00 00    	je     0x861c
    84f5:	b9 40 00 00 00       	mov    $0x40,%ecx
    84fa:	48 8b b5 18 fe ff ff 	mov    -0x1e8(%rbp),%rsi
    8501:	48 29 f1             	sub    %rsi,%rcx
    8504:	48 89 8d 88 fd ff ff 	mov    %rcx,-0x278(%rbp)
    850b:	48 8b bd 88 fd ff ff 	mov    -0x278(%rbp),%rdi
    8512:	48 89 f9             	mov    %rdi,%rcx
    8515:	49 89 d0             	mov    %rdx,%r8
    8518:	49 d3 e8             	shr    %cl,%r8
    851b:	31 c9                	xor    %ecx,%ecx
    851d:	48 39 ce             	cmp    %rcx,%rsi
    8520:	bf 00 00 00 00       	mov    $0x0,%edi
    8525:	40 0f 94 c7          	sete   %dil
    8529:	48 85 ff             	test   %rdi,%rdi
    852c:	49 0f 44 c8          	cmove  %r8,%rcx
    8530:	48 8b bd 10 fe ff ff 	mov    -0x1f0(%rbp),%rdi
    8537:	4c 8d 04 cf          	lea    (%rdi,%rcx,8),%r8
    853b:	49 8b 08             	mov    (%r8),%rcx
    853e:	49 89 d0             	mov    %rdx,%r8
    8541:	49 c1 e8 20          	shr    $0x20,%r8
    8545:	49 89 d1             	mov    %rdx,%r9
    8548:	4d 31 c1             	xor    %r8,%r9
    854b:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    8551:	4d 21 c1             	and    %r8,%r9
    8554:	4d 89 c8             	mov    %r9,%r8
    8557:	49 83 e0 3f          	and    $0x3f,%r8
    855b:	48 89 8d 88 fd ff ff 	mov    %rcx,-0x278(%rbp)
    8562:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    8568:	4c 89 c1             	mov    %r8,%rcx
    856b:	4c 89 d2             	mov    %r10,%rdx
    856e:	48 d3 e2             	shl    %cl,%rdx
    8571:	4c 89 c9             	mov    %r9,%rcx
    8574:	48 c1 e9 06          	shr    $0x6,%rcx
    8578:	48 83 e1 3f          	and    $0x3f,%rcx
    857c:	48 89 8d 60 fd ff ff 	mov    %rcx,-0x2a0(%rbp)
    8583:	4c 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%r8
    858a:	4c 89 c1             	mov    %r8,%rcx
    858d:	4c 89 d7             	mov    %r10,%rdi
    8590:	48 d3 e7             	shl    %cl,%rdi
    8593:	48 09 fa             	or     %rdi,%rdx
    8596:	4c 89 c9             	mov    %r9,%rcx
    8599:	48 c1 e9 0c          	shr    $0xc,%rcx
    859d:	48 83 e1 3f          	and    $0x3f,%rcx
    85a1:	48 89 8d 60 fd ff ff 	mov    %rcx,-0x2a0(%rbp)
    85a8:	48 8b bd 60 fd ff ff 	mov    -0x2a0(%rbp),%rdi
    85af:	48 89 f9             	mov    %rdi,%rcx
    85b2:	4d 89 d0             	mov    %r10,%r8
    85b5:	49 d3 e0             	shl    %cl,%r8
    85b8:	4c 09 c2             	or     %r8,%rdx
    85bb:	49 c1 e9 12          	shr    $0x12,%r9
    85bf:	49 83 e1 3f          	and    $0x3f,%r9
    85c3:	4c 89 c9             	mov    %r9,%rcx
    85c6:	4c 89 d7             	mov    %r10,%rdi
    85c9:	48 d3 e7             	shl    %cl,%rdi
    85cc:	48 09 fa             	or     %rdi,%rdx
    85cf:	48 8b 8d 88 fd ff ff 	mov    -0x278(%rbp),%rcx
    85d6:	48 21 d1             	and    %rdx,%rcx
    85d9:	48 39 d1             	cmp    %rdx,%rcx
    85dc:	b9 00 00 00 00       	mov    $0x0,%ecx
    85e1:	0f 94 c1             	sete   %cl
    85e4:	ba 01 00 00 00       	mov    $0x1,%edx
    85e9:	48 bf 00 00 00 00 01 	movabs $0x100000000,%rdi
    85f0:	00 00 00 
    85f3:	48 85 c9             	test   %rcx,%rcx
    85f6:	48 0f 44 d7          	cmove  %rdi,%rdx
    85fa:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    85fe:	48 01 d7             	add    %rdx,%rdi
    8601:	48 89 7b 20          	mov    %rdi,0x20(%rbx)
    8605:	48 85 c9             	test   %rcx,%rcx
    8608:	0f 85 fa 00 00 00    	jne    0x8708
    860e:	31 c9                	xor    %ecx,%ecx
    8610:	48 89 8d 78 fd ff ff 	mov    %rcx,-0x288(%rbp)
    8617:	e9 b8 01 00 00       	jmp    0x87d4
    861c:	b8 40 00 00 00       	mov    $0x40,%eax
    8621:	48 8b 8d 18 fe ff ff 	mov    -0x1e8(%rbp),%rcx
    8628:	48 29 c8             	sub    %rcx,%rax
    862b:	48 8b 95 90 fd ff ff 	mov    -0x270(%rbp),%rdx
    8632:	48 89 c1             	mov    %rax,%rcx
    8635:	48 89 d6             	mov    %rdx,%rsi
    8638:	48 d3 ee             	shr    %cl,%rsi
    863b:	31 c0                	xor    %eax,%eax
    863d:	48 8b 8d 18 fe ff ff 	mov    -0x1e8(%rbp),%rcx
    8644:	48 39 c1             	cmp    %rax,%rcx
    8647:	bf 00 00 00 00       	mov    $0x0,%edi
    864c:	40 0f 94 c7          	sete   %dil
    8650:	48 85 ff             	test   %rdi,%rdi
    8653:	48 0f 44 c6          	cmove  %rsi,%rax
    8657:	48 8b b5 10 fe ff ff 	mov    -0x1f0(%rbp),%rsi
    865e:	48 8d 3c c6          	lea    (%rsi,%rax,8),%rdi
    8662:	48 8b 07             	mov    (%rdi),%rax
    8665:	48 89 d7             	mov    %rdx,%rdi
    8668:	48 c1 ef 20          	shr    $0x20,%rdi
    866c:	49 89 d0             	mov    %rdx,%r8
    866f:	49 31 f8             	xor    %rdi,%r8
    8672:	bf ff ff ff ff       	mov    $0xffffffff,%edi
    8677:	49 21 f8             	and    %rdi,%r8
    867a:	4c 89 c7             	mov    %r8,%rdi
    867d:	48 83 e7 3f          	and    $0x3f,%rdi
    8681:	41 b9 01 00 00 00    	mov    $0x1,%r9d
    8687:	48 89 f9             	mov    %rdi,%rcx
    868a:	4d 89 ca             	mov    %r9,%r10
    868d:	49 d3 e2             	shl    %cl,%r10
    8690:	4c 89 c1             	mov    %r8,%rcx
    8693:	48 c1 e9 06          	shr    $0x6,%rcx
    8697:	48 83 e1 3f          	and    $0x3f,%rcx
    869b:	48 89 8d 88 fd ff ff 	mov    %rcx,-0x278(%rbp)
    86a2:	48 8b bd 88 fd ff ff 	mov    -0x278(%rbp),%rdi
    86a9:	48 89 f9             	mov    %rdi,%rcx
    86ac:	4c 89 ca             	mov    %r9,%rdx
    86af:	48 d3 e2             	shl    %cl,%rdx
    86b2:	49 09 d2             	or     %rdx,%r10
    86b5:	4c 89 c1             	mov    %r8,%rcx
    86b8:	48 c1 e9 0c          	shr    $0xc,%rcx
    86bc:	48 83 e1 3f          	and    $0x3f,%rcx
    86c0:	48 89 8d 88 fd ff ff 	mov    %rcx,-0x278(%rbp)
    86c7:	48 8b 95 88 fd ff ff 	mov    -0x278(%rbp),%rdx
    86ce:	48 89 d1             	mov    %rdx,%rcx
    86d1:	4c 89 cf             	mov    %r9,%rdi
    86d4:	48 d3 e7             	shl    %cl,%rdi
    86d7:	49 09 fa             	or     %rdi,%r10
    86da:	49 c1 e8 12          	shr    $0x12,%r8
    86de:	49 83 e0 3f          	and    $0x3f,%r8
    86e2:	4c 89 c1             	mov    %r8,%rcx
    86e5:	4c 89 ca             	mov    %r9,%rdx
    86e8:	48 d3 e2             	shl    %cl,%rdx
    86eb:	49 09 d2             	or     %rdx,%r10
    86ee:	4c 21 d0             	and    %r10,%rax
    86f1:	4c 39 d0             	cmp    %r10,%rax
    86f4:	0f 84 0e 00 00 00    	je     0x8708
    86fa:	31 c0                	xor    %eax,%eax
    86fc:	48 89 85 78 fd ff ff 	mov    %rax,-0x288(%rbp)
    8703:	e9 cc 00 00 00       	jmp    0x87d4
    8708:	b8 40 00 00 00       	mov    $0x40,%eax
    870d:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
    8714:	48 29 c8             	sub    %rcx,%rax
    8717:	48 8b 95 90 fd ff ff 	mov    -0x270(%rbp),%rdx
    871e:	48 89 c1             	mov    %rax,%rcx
    8721:	48 89 d6             	mov    %rdx,%rsi
    8724:	48 d3 ee             	shr    %cl,%rsi
    8727:	31 c0                	xor    %eax,%eax
    8729:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
    8730:	48 39 c1             	cmp    %rax,%rcx
    8733:	bf 00 00 00 00       	mov    $0x0,%edi
    8738:	40 0f 94 c7          	sete   %dil
    873c:	48 85 ff             	test   %rdi,%rdi
    873f:	48 0f 44 c6          	cmove  %rsi,%rax
    8743:	49 8d 34 c7          	lea    (%r15,%rax,8),%rsi
    8747:	48 8b 06             	mov    (%rsi),%rax
    874a:	48 be ff ff ff ff ff 	movabs $0xffffffffffff,%rsi
    8751:	ff 00 00 
    8754:	48 89 c7             	mov    %rax,%rdi
    8757:	48 21 f7             	and    %rsi,%rdi
    875a:	31 f6                	xor    %esi,%esi
    875c:	48 39 f7             	cmp    %rsi,%rdi
    875f:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    8765:	41 0f 94 c0          	sete   %r8b
    8769:	49 89 d1             	mov    %rdx,%r9
    876c:	49 c1 e9 20          	shr    $0x20,%r9
    8770:	4c 31 ca             	xor    %r9,%rdx
    8773:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    8779:	4c 21 ca             	and    %r9,%rdx
    877c:	48 83 e2 0f          	and    $0xf,%rdx
    8780:	48 83 c2 30          	add    $0x30,%rdx
    8784:	48 89 d1             	mov    %rdx,%rcx
    8787:	48 d3 e8             	shr    %cl,%rax
    878a:	48 83 e0 01          	and    $0x1,%rax
    878e:	48 83 f8 00          	cmp    $0x0,%rax
    8792:	b8 00 00 00 00       	mov    $0x0,%eax
    8797:	0f 95 c0             	setne  %al
    879a:	b9 01 00 00 00       	mov    $0x1,%ecx
    879f:	48 31 c8             	xor    %rcx,%rax
    87a2:	49 09 c0             	or     %rax,%r8
    87a5:	b8 01 00 00 00       	mov    $0x1,%eax
    87aa:	48 29 c7             	sub    %rax,%rdi
    87ad:	b9 18 00 00 00       	mov    $0x18,%ecx
    87b2:	48 0f af f9          	imul   %rcx,%rdi
    87b6:	48 8b 8d 20 fe ff ff 	mov    -0x1e0(%rbp),%rcx
    87bd:	48 89 ca             	mov    %rcx,%rdx
    87c0:	48 01 fa             	add    %rdi,%rdx
    87c3:	48 89 f7             	mov    %rsi,%rdi
    87c6:	4d 85 c0             	test   %r8,%r8
    87c9:	48 0f 44 fa          	cmove  %rdx,%rdi
    87cd:	48 89 bd 78 fd ff ff 	mov    %rdi,-0x288(%rbp)
    87d4:	e9 f1 00 00 00       	jmp    0x88ca
    87d9:	48 8b 85 38 fe ff ff 	mov    -0x1c8(%rbp),%rax
    87e0:	4c 89 d9             	mov    %r11,%rcx
    87e3:	48 29 c1             	sub    %rax,%rcx
    87e6:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
    87ed:	48 39 d1             	cmp    %rdx,%rcx
    87f0:	0f 82 0e 00 00 00    	jb     0x8804
    87f6:	31 f6                	xor    %esi,%esi
    87f8:	48 89 b5 78 fd ff ff 	mov    %rsi,-0x288(%rbp)
    87ff:	e9 c6 00 00 00       	jmp    0x88ca
    8804:	49 83 fe 02          	cmp    $0x2,%r14
    8808:	48 89 8d 90 fd ff ff 	mov    %rcx,-0x270(%rbp)
    880f:	0f 85 69 00 00 00    	jne    0x887e
    8815:	48 89 ce             	mov    %rcx,%rsi
    8818:	48 c1 ee 06          	shr    $0x6,%rsi
    881c:	49 8d 3c f7          	lea    (%r15,%rsi,8),%rdi
    8820:	48 8b 37             	mov    (%rdi),%rsi
    8823:	48 89 cf             	mov    %rcx,%rdi
    8826:	48 83 e7 3f          	and    $0x3f,%rdi
    882a:	48 89 f9             	mov    %rdi,%rcx
    882d:	48 d3 ee             	shr    %cl,%rsi
    8830:	b9 01 00 00 00       	mov    $0x1,%ecx
    8835:	48 21 ce             	and    %rcx,%rsi
    8838:	31 ff                	xor    %edi,%edi
    883a:	48 39 fe             	cmp    %rdi,%rsi
    883d:	be 00 00 00 00       	mov    $0x0,%esi
    8842:	40 0f 95 c6          	setne  %sil
    8846:	41 b8 10 00 00 00    	mov    $0x10,%r8d
    884c:	4c 8b 8d 90 fd ff ff 	mov    -0x270(%rbp),%r9
    8853:	4d 89 ca             	mov    %r9,%r10
    8856:	4d 0f af d0          	imul   %r8,%r10
    885a:	4c 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%r8
    8861:	4d 89 c1             	mov    %r8,%r9
    8864:	4d 01 d1             	add    %r10,%r9
    8867:	49 83 e9 08          	sub    $0x8,%r9
    886b:	48 85 f6             	test   %rsi,%rsi
    886e:	4c 0f 44 cf          	cmove  %rdi,%r9
    8872:	4c 89 8d 78 fd ff ff 	mov    %r9,-0x288(%rbp)
    8879:	e9 4c 00 00 00       	jmp    0x88ca
    887e:	48 8b 85 90 fd ff ff 	mov    -0x270(%rbp),%rax
    8885:	49 8d 0c 87          	lea    (%r15,%rax,4),%rcx
    8889:	8b 01                	mov    (%rcx),%eax
    888b:	b9 01 00 00 00       	mov    $0x1,%ecx
    8890:	48 89 c2             	mov    %rax,%rdx
    8893:	48 29 ca             	sub    %rcx,%rdx
    8896:	be 18 00 00 00       	mov    $0x18,%esi
    889b:	48 0f af d6          	imul   %rsi,%rdx
    889f:	48 8b b5 20 fe ff ff 	mov    -0x1e0(%rbp),%rsi
    88a6:	48 89 f7             	mov    %rsi,%rdi
    88a9:	48 01 d7             	add    %rdx,%rdi
    88ac:	31 d2                	xor    %edx,%edx
    88ae:	48 39 d0             	cmp    %rdx,%rax
    88b1:	b8 00 00 00 00       	mov    $0x0,%eax
    88b6:	0f 94 c0             	sete   %al
    88b9:	49 89 d0             	mov    %rdx,%r8
    88bc:	48 85 c0             	test   %rax,%rax
    88bf:	4c 0f 44 c7          	cmove  %rdi,%r8
    88c3:	4c 89 85 78 fd ff ff 	mov    %r8,-0x288(%rbp)
    88ca:	49 83 fe 01          	cmp    $0x1,%r14
    88ce:	be 00 00 00 00       	mov    $0x0,%esi
    88d3:	40 0f 95 c6          	setne  %sil
    88d7:	31 ff                	xor    %edi,%edi
    88d9:	48 8b 85 c8 fd ff ff 	mov    -0x238(%rbp),%rax
    88e0:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
    88e7:	48 8b 85 d0 fd ff ff 	mov    -0x230(%rbp),%rax
    88ee:	48 89 85 88 fd ff ff 	mov    %rax,-0x278(%rbp)
    88f5:	48 8b 85 a0 fd ff ff 	mov    -0x260(%rbp),%rax
    88fc:	48 89 85 60 fd ff ff 	mov    %rax,-0x2a0(%rbp)
    8903:	48 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%rax
    890a:	48 89 85 68 fd ff ff 	mov    %rax,-0x298(%rbp)
    8911:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
    8918:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
    891f:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
    8926:	48 89 85 50 fd ff ff 	mov    %rax,-0x2b0(%rbp)
    892d:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
    8934:	48 89 85 48 fd ff ff 	mov    %rax,-0x2b8(%rbp)
    893b:	48 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%rax
    8942:	48 89 85 40 fd ff ff 	mov    %rax,-0x2c0(%rbp)
    8949:	48 8b 85 78 fd ff ff 	mov    -0x288(%rbp),%rax
    8950:	48 85 c0             	test   %rax,%rax
    8953:	0f 85 75 00 00 00    	jne    0x89ce
    8959:	48 8b 8d 90 fd ff ff 	mov    -0x270(%rbp),%rcx
    8960:	48 89 8d c8 fd ff ff 	mov    %rcx,-0x238(%rbp)
    8967:	48 8b 8d 88 fd ff ff 	mov    -0x278(%rbp),%rcx
    896e:	48 89 8d d0 fd ff ff 	mov    %rcx,-0x230(%rbp)
    8975:	48 8b 8d 60 fd ff ff 	mov    -0x2a0(%rbp),%rcx
    897c:	48 89 8d a0 fd ff ff 	mov    %rcx,-0x260(%rbp)
    8983:	48 8b 8d 68 fd ff ff 	mov    -0x298(%rbp),%rcx
    898a:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
    8991:	48 8b 8d 58 fd ff ff 	mov    -0x2a8(%rbp),%rcx
    8998:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
    899f:	48 8b 8d 50 fd ff ff 	mov    -0x2b0(%rbp),%rcx
    89a6:	48 89 8d b0 fd ff ff 	mov    %rcx,-0x250(%rbp)
    89ad:	48 8b 8d 48 fd ff ff 	mov    -0x2b8(%rbp),%rcx
    89b4:	48 89 8d 80 fd ff ff 	mov    %rcx,-0x280(%rbp)
    89bb:	48 8b 8d 40 fd ff ff 	mov    -0x2c0(%rbp),%rcx
    89c2:	48 89 8d c0 fd ff ff 	mov    %rcx,-0x240(%rbp)
    89c9:	e9 a3 06 00 00       	jmp    0x9071
    89ce:	48 8b 48 08          	mov    0x8(%rax),%rcx
    89d2:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    89d7:	49 89 c8             	mov    %rcx,%r8
    89da:	49 21 d0             	and    %rdx,%r8
    89dd:	ba 01 00 00 00       	mov    $0x1,%edx
    89e2:	4d 89 c1             	mov    %r8,%r9
    89e5:	49 29 d1             	sub    %rdx,%r9
    89e8:	41 ba 18 00 00 00    	mov    $0x18,%r10d
    89ee:	4d 0f af ca          	imul   %r10,%r9
    89f2:	4c 8b 95 20 fe ff ff 	mov    -0x1e0(%rbp),%r10
    89f9:	4c 89 d0             	mov    %r10,%rax
    89fc:	4c 01 c8             	add    %r9,%rax
    89ff:	45 31 c9             	xor    %r9d,%r9d
    8a02:	4d 39 c8             	cmp    %r9,%r8
    8a05:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    8a0b:	41 0f 94 c0          	sete   %r8b
    8a0f:	4d 89 ca             	mov    %r9,%r10
    8a12:	4d 85 c0             	test   %r8,%r8
    8a15:	4c 0f 44 d0          	cmove  %rax,%r10
    8a19:	48 8b 85 78 fd ff ff 	mov    -0x288(%rbp),%rax
    8a20:	4c 8b 00             	mov    (%rax),%r8
    8a23:	4d 39 c3             	cmp    %r8,%r11
    8a26:	b8 00 00 00 00       	mov    $0x0,%eax
    8a2b:	0f 94 c0             	sete   %al
    8a2e:	48 09 f0             	or     %rsi,%rax
    8a31:	49 89 f8             	mov    %rdi,%r8
    8a34:	49 01 d0             	add    %rdx,%r8
    8a37:	48 85 c0             	test   %rax,%rax
    8a3a:	0f 85 0c 00 00 00    	jne    0x8a4c
    8a40:	4c 89 95 78 fd ff ff 	mov    %r10,-0x288(%rbp)
    8a47:	e9 fd fe ff ff       	jmp    0x8949
    8a4c:	48 8b 43 18          	mov    0x18(%rbx),%rax
    8a50:	48 39 c7             	cmp    %rax,%rdi
    8a53:	0f 8d 0f 00 00 00    	jge    0x8a68
    8a59:	4c 89 95 78 fd ff ff 	mov    %r10,-0x288(%rbp)
    8a60:	4c 89 c7             	mov    %r8,%rdi
    8a63:	e9 e1 fe ff ff       	jmp    0x8949
    8a68:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
    8a6c:	48 8b 70 18          	mov    0x18(%rax),%rsi
    8a70:	48 85 f6             	test   %rsi,%rsi
    8a73:	48 89 8d 38 fd ff ff 	mov    %rcx,-0x2c8(%rbp)
    8a7a:	4c 89 85 30 fd ff ff 	mov    %r8,-0x2d0(%rbp)
    8a81:	0f 84 0c 00 00 00    	je     0x8a93
    8a87:	0f b6 3e             	movzbl (%rsi),%edi
    8a8a:	48 85 ff             	test   %rdi,%rdi
    8a8d:	0f 85 02 06 00 00    	jne    0x9095
    8a93:	48 8b 85 78 fd ff ff 	mov    -0x288(%rbp),%rax
    8a9a:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8a9e:	48 8b 95 38 fd ff ff 	mov    -0x2c8(%rbp),%rdx
    8aa5:	48 89 d6             	mov    %rdx,%rsi
    8aa8:	48 c1 ee 20          	shr    $0x20,%rsi
    8aac:	48 83 e6 01          	and    $0x1,%rsi
    8ab0:	48 83 fe 00          	cmp    $0x0,%rsi
    8ab4:	be 00 00 00 00       	mov    $0x0,%esi
    8ab9:	40 0f 95 c6          	setne  %sil
    8abd:	48 8b bd 30 fd ff ff 	mov    -0x2d0(%rbp),%rdi
    8ac4:	48 89 7b 18          	mov    %rdi,0x18(%rbx)
    8ac8:	4c 8b 85 90 fd ff ff 	mov    -0x270(%rbp),%r8
    8acf:	4d 89 c1             	mov    %r8,%r9
    8ad2:	49 83 c1 01          	add    $0x1,%r9
    8ad6:	48 63 c9             	movslq %ecx,%rcx
    8ad9:	45 31 d2             	xor    %r10d,%r10d
    8adc:	48 85 f6             	test   %rsi,%rsi
    8adf:	4c 0f 44 d1          	cmove  %rcx,%r10
    8ae3:	48 8b 8d 88 fd ff ff 	mov    -0x278(%rbp),%rcx
    8aea:	4c 39 d1             	cmp    %r10,%rcx
    8aed:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    8af3:	41 0f 94 c3          	sete   %r11b
    8af7:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
    8afe:	48 39 f0             	cmp    %rsi,%rax
    8b01:	ba 00 00 00 00       	mov    $0x0,%edx
    8b06:	0f 94 c2             	sete   %dl
    8b09:	49 21 d3             	and    %rdx,%r11
    8b0c:	4d 85 db             	test   %r11,%r11
    8b0f:	48 89 b5 28 fd ff ff 	mov    %rsi,-0x2d8(%rbp)
    8b16:	4c 89 8d 20 fd ff ff 	mov    %r9,-0x2e0(%rbp)
    8b1d:	4c 89 95 18 fd ff ff 	mov    %r10,-0x2e8(%rbp)
    8b24:	0f 84 83 00 00 00    	je     0x8bad
    8b2a:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
    8b31:	49 89 d3             	mov    %rdx,%r11
    8b34:	49 83 c3 01          	add    $0x1,%r11
    8b38:	be 01 00 00 00       	mov    $0x1,%esi
    8b3d:	4c 8b 95 b8 fd ff ff 	mov    -0x248(%rbp),%r10
    8b44:	4d 89 d1             	mov    %r10,%r9
    8b47:	49 31 f1             	xor    %rsi,%r9
    8b4a:	31 f6                	xor    %esi,%esi
    8b4c:	4c 8b 95 70 fd ff ff 	mov    -0x290(%rbp),%r10
    8b53:	4c 89 d2             	mov    %r10,%rdx
    8b56:	4d 85 c9             	test   %r9,%r9
    8b59:	48 0f 44 d6          	cmove  %rsi,%rdx
    8b5d:	48 8b b5 40 fd ff ff 	mov    -0x2c0(%rbp),%rsi
    8b64:	49 89 f2             	mov    %rsi,%r10
    8b67:	4d 01 ca             	add    %r9,%r10
    8b6a:	4c 8b 8d 48 fd ff ff 	mov    -0x2b8(%rbp),%r9
    8b71:	4c 89 ce             	mov    %r9,%rsi
    8b74:	48 01 d6             	add    %rdx,%rsi
    8b77:	48 89 8d d0 fd ff ff 	mov    %rcx,-0x230(%rbp)
    8b7e:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
    8b85:	48 8b 95 68 fd ff ff 	mov    -0x298(%rbp),%rdx
    8b8c:	48 89 95 98 fd ff ff 	mov    %rdx,-0x268(%rbp)
    8b93:	4c 89 9d b0 fd ff ff 	mov    %r11,-0x250(%rbp)
    8b9a:	48 89 b5 80 fd ff ff 	mov    %rsi,-0x280(%rbp)
    8ba1:	4c 89 95 c0 fd ff ff 	mov    %r10,-0x240(%rbp)
    8ba8:	e9 aa 04 00 00       	jmp    0x9057
    8bad:	48 8b 85 58 fd ff ff 	mov    -0x2a8(%rbp),%rax
    8bb4:	48 85 c0             	test   %rax,%rax
    8bb7:	0f 84 fe 03 00 00    	je     0x8fbb
    8bbd:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    8bc4:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    8bc8:	48 85 d2             	test   %rdx,%rdx
    8bcb:	0f 84 3d 01 00 00    	je     0x8d0e
    8bd1:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    8bd5:	be 40 00 00 00       	mov    $0x40,%esi
    8bda:	48 29 d6             	sub    %rdx,%rsi
    8bdd:	48 8b bd 68 fd ff ff 	mov    -0x298(%rbp),%rdi
    8be4:	48 89 f1             	mov    %rsi,%rcx
    8be7:	49 89 f8             	mov    %rdi,%r8
    8bea:	49 d3 e8             	shr    %cl,%r8
    8bed:	31 c9                	xor    %ecx,%ecx
    8bef:	48 39 ca             	cmp    %rcx,%rdx
    8bf2:	ba 00 00 00 00       	mov    $0x0,%edx
    8bf7:	0f 94 c2             	sete   %dl
    8bfa:	48 85 d2             	test   %rdx,%rdx
    8bfd:	49 0f 44 c8          	cmove  %r8,%rcx
    8c01:	48 8b 95 58 fe ff ff 	mov    -0x1a8(%rbp),%rdx
    8c08:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    8c0c:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    8c10:	49 8b 30             	mov    (%r8),%rsi
    8c13:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    8c1a:	00 28 00 
    8c1d:	4c 39 ce             	cmp    %r9,%rsi
    8c20:	4c 89 85 10 fd ff ff 	mov    %r8,-0x2f0(%rbp)
    8c27:	0f 82 0c 00 00 00    	jb     0x8c39
    8c2d:	48 89 b5 08 fd ff ff 	mov    %rsi,-0x2f8(%rbp)
    8c34:	e9 47 00 00 00       	jmp    0x8c80
    8c39:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    8c3d:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    8c41:	48 89 b5 00 fd ff ff 	mov    %rsi,-0x300(%rbp)
    8c48:	48 89 d6             	mov    %rdx,%rsi
    8c4b:	48 89 ca             	mov    %rcx,%rdx
    8c4e:	48 8b 8d 00 fd ff ff 	mov    -0x300(%rbp),%rcx
    8c55:	e8 86 74 ff ff       	call   0xe0
    8c5a:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    8c61:	31 d2                	xor    %edx,%edx
    8c63:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    8c67:	48 83 f8 00          	cmp    $0x0,%rax
    8c6b:	0f 8f 08 00 00 00    	jg     0x8c79
    8c71:	49 89 c4             	mov    %rax,%r12
    8c74:	e9 3f 18 00 00       	jmp    0xa4b8
    8c79:	48 89 85 08 fd ff ff 	mov    %rax,-0x2f8(%rbp)
    8c80:	48 8b 85 08 fd ff ff 	mov    -0x2f8(%rbp),%rax
    8c87:	48 89 c1             	mov    %rax,%rcx
    8c8a:	48 83 c1 28          	add    $0x28,%rcx
    8c8e:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    8c95:	00 28 00 
    8c98:	48 29 d1             	sub    %rdx,%rcx
    8c9b:	48 8b 95 10 fd ff ff 	mov    -0x2f0(%rbp),%rdx
    8ca2:	48 89 0a             	mov    %rcx,(%rdx)
    8ca5:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    8cac:	ff 00 00 
    8caf:	48 21 c8             	and    %rcx,%rax
    8cb2:	31 c9                	xor    %ecx,%ecx
    8cb4:	48 8b 95 88 fd ff ff 	mov    -0x278(%rbp),%rdx
    8cbb:	48 89 10             	mov    %rdx,(%rax)
    8cbe:	48 8b b5 60 fd ff ff 	mov    -0x2a0(%rbp),%rsi
    8cc5:	48 89 70 08          	mov    %rsi,0x8(%rax)
    8cc9:	48 89 48 10          	mov    %rcx,0x10(%rax)
    8ccd:	48 89 48 18          	mov    %rcx,0x18(%rax)
    8cd1:	48 89 48 20          	mov    %rcx,0x20(%rax)
    8cd5:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    8cdc:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    8ce0:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    8ce6:	4c 01 c7             	add    %r8,%rdi
    8ce9:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    8ced:	48 89 85 08 fd ff ff 	mov    %rax,-0x2f8(%rbp)
    8cf4:	b8 01 00 00 00       	mov    $0x1,%eax
    8cf9:	48 89 85 10 fd ff ff 	mov    %rax,-0x2f0(%rbp)
    8d00:	31 c0                	xor    %eax,%eax
    8d02:	48 89 85 00 fd ff ff 	mov    %rax,-0x300(%rbp)
    8d09:	e9 9f 01 00 00       	jmp    0x8ead
    8d0e:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    8d15:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8d19:	48 8b 50 18          	mov    0x18(%rax),%rdx
    8d1d:	48 89 d6             	mov    %rdx,%rsi
    8d20:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    8d25:	bf 40 00 00 00       	mov    $0x40,%edi
    8d2a:	48 29 f7             	sub    %rsi,%rdi
    8d2d:	48 89 8d f8 fc ff ff 	mov    %rcx,-0x308(%rbp)
    8d34:	4c 8b 85 68 fd ff ff 	mov    -0x298(%rbp),%r8
    8d3b:	48 89 f9             	mov    %rdi,%rcx
    8d3e:	4d 89 c1             	mov    %r8,%r9
    8d41:	49 d3 e9             	shr    %cl,%r9
    8d44:	31 c9                	xor    %ecx,%ecx
    8d46:	48 39 ce             	cmp    %rcx,%rsi
    8d49:	be 00 00 00 00       	mov    $0x0,%esi
    8d4e:	40 0f 94 c6          	sete   %sil
    8d52:	48 85 f6             	test   %rsi,%rsi
    8d55:	49 0f 44 c9          	cmove  %r9,%rcx
    8d59:	be 01 00 00 00       	mov    $0x1,%esi
    8d5e:	48 89 cf             	mov    %rcx,%rdi
    8d61:	48 01 f7             	add    %rsi,%rdi
    8d64:	48 21 d7             	and    %rdx,%rdi
    8d67:	ba 28 00 00 00       	mov    $0x28,%edx
    8d6c:	48 0f af ca          	imul   %rdx,%rcx
    8d70:	48 8b 95 f8 fc ff ff 	mov    -0x308(%rbp),%rdx
    8d77:	4c 8d 0c 0a          	lea    (%rdx,%rcx,1),%r9
    8d7b:	49 8b 49 10          	mov    0x10(%r9),%rcx
    8d7f:	48 85 c9             	test   %rcx,%rcx
    8d82:	0f 84 af 00 00 00    	je     0x8e37
    8d88:	49 8b 09             	mov    (%r9),%rcx
    8d8b:	4d 8b 51 08          	mov    0x8(%r9),%r10
    8d8f:	4c 8b 9d 88 fd ff ff 	mov    -0x278(%rbp),%r11
    8d96:	49 39 cb             	cmp    %rcx,%r11
    8d99:	ba 00 00 00 00       	mov    $0x0,%edx
    8d9e:	0f 94 c2             	sete   %dl
    8da1:	48 8b 8d 60 fd ff ff 	mov    -0x2a0(%rbp),%rcx
    8da8:	4c 39 d1             	cmp    %r10,%rcx
    8dab:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    8db1:	41 0f 94 c0          	sete   %r8b
    8db5:	4c 21 c2             	and    %r8,%rdx
    8db8:	48 85 d2             	test   %rdx,%rdx
    8dbb:	0f 84 0c 00 00 00    	je     0x8dcd
    8dc1:	4c 89 8d 08 fd ff ff 	mov    %r9,-0x2f8(%rbp)
    8dc8:	e9 53 00 00 00       	jmp    0x8e20
    8dcd:	ba 28 00 00 00       	mov    $0x28,%edx
    8dd2:	48 0f af fa          	imul   %rdx,%rdi
    8dd6:	48 8b 95 f8 fc ff ff 	mov    -0x308(%rbp),%rdx
    8ddd:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    8de1:	49 8b 50 10          	mov    0x10(%r8),%rdx
    8de5:	48 85 d2             	test   %rdx,%rdx
    8de8:	0f 84 49 00 00 00    	je     0x8e37
    8dee:	49 8b 10             	mov    (%r8),%rdx
    8df1:	49 8b 78 08          	mov    0x8(%r8),%rdi
    8df5:	49 39 d3             	cmp    %rdx,%r11
    8df8:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    8dfe:	41 0f 94 c1          	sete   %r9b
    8e02:	48 39 f9             	cmp    %rdi,%rcx
    8e05:	ba 00 00 00 00       	mov    $0x0,%edx
    8e0a:	0f 94 c2             	sete   %dl
    8e0d:	49 21 d1             	and    %rdx,%r9
    8e10:	4d 85 c9             	test   %r9,%r9
    8e13:	0f 84 1e 00 00 00    	je     0x8e37
    8e19:	4c 89 85 08 fd ff ff 	mov    %r8,-0x2f8(%rbp)
    8e20:	31 c0                	xor    %eax,%eax
    8e22:	48 89 85 10 fd ff ff 	mov    %rax,-0x2f0(%rbp)
    8e29:	31 c0                	xor    %eax,%eax
    8e2b:	48 89 85 00 fd ff ff 	mov    %rax,-0x300(%rbp)
    8e32:	e9 76 00 00 00       	jmp    0x8ead
    8e37:	48 8d 85 c0 fe ff ff 	lea    -0x140(%rbp),%rax
    8e3e:	48 89 c1             	mov    %rax,%rcx
    8e41:	48 8b 95 88 fd ff ff 	mov    -0x278(%rbp),%rdx
    8e48:	48 89 11             	mov    %rdx,(%rcx)
    8e4b:	48 8b b5 60 fd ff ff 	mov    -0x2a0(%rbp),%rsi
    8e52:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    8e56:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    8e5a:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
    8e61:	48 89 ca             	mov    %rcx,%rdx
    8e64:	e8 87 72 ff ff       	call   0xf0
    8e69:	48 83 f8 00          	cmp    $0x0,%rax
    8e6d:	0f 8d 08 00 00 00    	jge    0x8e7b
    8e73:	49 89 c4             	mov    %rax,%r12
    8e76:	e9 3d 16 00 00       	jmp    0xa4b8
    8e7b:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    8e82:	48 8b 11             	mov    (%rcx),%rdx
    8e85:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    8e89:	48 83 e6 01          	and    $0x1,%rsi
    8e8d:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    8e91:	48 89 85 08 fd ff ff 	mov    %rax,-0x2f8(%rbp)
    8e98:	b8 01 00 00 00       	mov    $0x1,%eax
    8e9d:	48 89 85 10 fd ff ff 	mov    %rax,-0x2f0(%rbp)
    8ea4:	31 c0                	xor    %eax,%eax
    8ea6:	48 89 85 00 fd ff ff 	mov    %rax,-0x300(%rbp)
    8ead:	48 8b 85 10 fd ff ff 	mov    -0x2f0(%rbp),%rax
    8eb4:	48 85 c0             	test   %rax,%rax
    8eb7:	0f 84 6b 00 00 00    	je     0x8f28
    8ebd:	48 8b 85 08 fd ff ff 	mov    -0x2f8(%rbp),%rax
    8ec4:	48 8b 8d 50 fd ff ff 	mov    -0x2b0(%rbp),%rcx
    8ecb:	48 89 48 10          	mov    %rcx,0x10(%rax)
    8ecf:	31 d2                	xor    %edx,%edx
    8ed1:	48 39 d1             	cmp    %rdx,%rcx
    8ed4:	be 00 00 00 00       	mov    $0x0,%esi
    8ed9:	40 0f 95 c6          	setne  %sil
    8edd:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    8ee1:	48 09 f7             	or     %rsi,%rdi
    8ee4:	48 0f be ff          	movsbq %dil,%rdi
    8ee8:	40 88 78 20          	mov    %dil,0x20(%rax)
    8eec:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
    8ef3:	48 89 70 18          	mov    %rsi,0x18(%rax)
    8ef7:	4c 8b 85 40 fd ff ff 	mov    -0x2c0(%rbp),%r8
    8efe:	49 39 d0             	cmp    %rdx,%r8
    8f01:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    8f07:	41 0f 95 c1          	setne  %r9b
    8f0b:	40 0f b6 ff          	movzbl %dil,%edi
    8f0f:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    8f15:	4d 85 c9             	test   %r9,%r9
    8f18:	4c 0f 44 d2          	cmove  %rdx,%r10
    8f1c:	4c 09 d7             	or     %r10,%rdi
    8f1f:	40 88 78 20          	mov    %dil,0x20(%rax)
    8f23:	e9 93 00 00 00       	jmp    0x8fbb
    8f28:	48 8b 85 08 fd ff ff 	mov    -0x2f8(%rbp),%rax
    8f2f:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8f33:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
    8f3a:	48 01 d1             	add    %rdx,%rcx
    8f3d:	48 89 48 10          	mov    %rcx,0x10(%rax)
    8f41:	31 f6                	xor    %esi,%esi
    8f43:	48 39 f1             	cmp    %rsi,%rcx
    8f46:	b9 00 00 00 00       	mov    $0x0,%ecx
    8f4b:	0f 95 c1             	setne  %cl
    8f4e:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    8f52:	48 09 cf             	or     %rcx,%rdi
    8f55:	48 0f be ff          	movsbq %dil,%rdi
    8f59:	40 88 78 20          	mov    %dil,0x20(%rax)
    8f5d:	48 8b 48 18          	mov    0x18(%rax),%rcx
    8f61:	40 0f b6 ff          	movzbl %dil,%edi
    8f65:	49 89 f8             	mov    %rdi,%r8
    8f68:	49 83 e0 02          	and    $0x2,%r8
    8f6c:	49 39 f0             	cmp    %rsi,%r8
    8f6f:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    8f75:	41 0f 95 c0          	setne  %r8b
    8f79:	45 31 c9             	xor    %r9d,%r9d
    8f7c:	4d 85 c0             	test   %r8,%r8
    8f7f:	49 0f 44 c9          	cmove  %r9,%rcx
    8f83:	4c 8b 8d 40 fd ff ff 	mov    -0x2c0(%rbp),%r9
    8f8a:	4d 01 c8             	add    %r9,%r8
    8f8d:	4c 8b 95 48 fd ff ff 	mov    -0x2b8(%rbp),%r10
    8f94:	4c 01 d1             	add    %r10,%rcx
    8f97:	48 89 48 18          	mov    %rcx,0x18(%rax)
    8f9b:	49 39 f0             	cmp    %rsi,%r8
    8f9e:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    8fa4:	41 0f 95 c0          	setne  %r8b
    8fa8:	b9 02 00 00 00       	mov    $0x2,%ecx
    8fad:	4d 85 c0             	test   %r8,%r8
    8fb0:	48 0f 44 ce          	cmove  %rsi,%rcx
    8fb4:	48 09 cf             	or     %rcx,%rdi
    8fb7:	40 88 78 20          	mov    %dil,0x20(%rax)
    8fbb:	b8 01 00 00 00       	mov    $0x1,%eax
    8fc0:	48 8b 8d b8 fd ff ff 	mov    -0x248(%rbp),%rcx
    8fc7:	48 89 ca             	mov    %rcx,%rdx
    8fca:	48 31 c2             	xor    %rax,%rdx
    8fcd:	31 c0                	xor    %eax,%eax
    8fcf:	48 8b b5 70 fd ff ff 	mov    -0x290(%rbp),%rsi
    8fd6:	48 89 f7             	mov    %rsi,%rdi
    8fd9:	48 85 d2             	test   %rdx,%rdx
    8fdc:	48 0f 44 f8          	cmove  %rax,%rdi
    8fe0:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    8fe7:	79 37 9e 
    8fea:	49 b8 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%r8
    8ff1:	79 37 9e 
    8ff4:	4c 8b 8d 18 fd ff ff 	mov    -0x2e8(%rbp),%r9
    8ffb:	4d 31 c8             	xor    %r9,%r8
    8ffe:	4c 0f af c0          	imul   %rax,%r8
    9002:	4d 89 c2             	mov    %r8,%r10
    9005:	49 c1 ea 1d          	shr    $0x1d,%r10
    9009:	4d 31 d0             	xor    %r10,%r8
    900c:	4c 8b 95 28 fd ff ff 	mov    -0x2d8(%rbp),%r10
    9013:	4d 31 d0             	xor    %r10,%r8
    9016:	4c 0f af c0          	imul   %rax,%r8
    901a:	4d 89 c3             	mov    %r8,%r11
    901d:	49 c1 eb 1d          	shr    $0x1d,%r11
    9021:	4d 31 d8             	xor    %r11,%r8
    9024:	4c 0f af c0          	imul   %rax,%r8
    9028:	4c 89 8d d0 fd ff ff 	mov    %r9,-0x230(%rbp)
    902f:	4c 89 95 a0 fd ff ff 	mov    %r10,-0x260(%rbp)
    9036:	4c 89 85 98 fd ff ff 	mov    %r8,-0x268(%rbp)
    903d:	b8 01 00 00 00       	mov    $0x1,%eax
    9042:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
    9049:	48 89 bd 80 fd ff ff 	mov    %rdi,-0x280(%rbp)
    9050:	48 89 95 c0 fd ff ff 	mov    %rdx,-0x240(%rbp)
    9057:	48 8b 85 20 fd ff ff 	mov    -0x2e0(%rbp),%rax
    905e:	48 89 85 c8 fd ff ff 	mov    %rax,-0x238(%rbp)
    9065:	b8 01 00 00 00       	mov    $0x1,%eax
    906a:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
    9071:	31 c0                	xor    %eax,%eax
    9073:	48 89 43 18          	mov    %rax,0x18(%rbx)
    9077:	48 8b 85 00 fe ff ff 	mov    -0x200(%rbp),%rax
    907e:	b9 01 00 00 00       	mov    $0x1,%ecx
    9083:	48 89 c2             	mov    %rax,%rdx
    9086:	48 01 ca             	add    %rcx,%rdx
    9089:	48 89 95 00 fe ff ff 	mov    %rdx,-0x200(%rbp)
    9090:	e9 e8 f2 ff ff       	jmp    0x837d
    9095:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    9099:	e8 a2 6f ff ff       	call   0x40
    909e:	48 85 c0             	test   %rax,%rax
    90a1:	0f 84 ec f9 ff ff    	je     0x8a93
    90a7:	e9 05 14 00 00       	jmp    0xa4b1
    90ac:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
    90b3:	48 85 c0             	test   %rax,%rax
    90b6:	0f 84 00 04 00 00    	je     0x94bc
    90bc:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    90c3:	48 8b 48 68          	mov    0x68(%rax),%rcx
    90c7:	48 85 c9             	test   %rcx,%rcx
    90ca:	0f 84 44 01 00 00    	je     0x9214
    90d0:	48 8b 48 38          	mov    0x38(%rax),%rcx
    90d4:	ba 40 00 00 00       	mov    $0x40,%edx
    90d9:	48 29 ca             	sub    %rcx,%rdx
    90dc:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
    90e3:	48 8b b5 98 fd ff ff 	mov    -0x268(%rbp),%rsi
    90ea:	48 89 d1             	mov    %rdx,%rcx
    90ed:	48 89 f7             	mov    %rsi,%rdi
    90f0:	48 d3 ef             	shr    %cl,%rdi
    90f3:	31 c9                	xor    %ecx,%ecx
    90f5:	48 8b 95 a8 fd ff ff 	mov    -0x258(%rbp),%rdx
    90fc:	48 39 ca             	cmp    %rcx,%rdx
    90ff:	ba 00 00 00 00       	mov    $0x0,%edx
    9104:	0f 94 c2             	sete   %dl
    9107:	48 85 d2             	test   %rdx,%rdx
    910a:	48 0f 44 cf          	cmove  %rdi,%rcx
    910e:	48 8b 50 08          	mov    0x8(%rax),%rdx
    9112:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    9116:	48 8b 17             	mov    (%rdi),%rdx
    9119:	49 b8 00 00 00 00 00 	movabs $0x28000000000000,%r8
    9120:	00 28 00 
    9123:	4c 39 c2             	cmp    %r8,%rdx
    9126:	48 89 bd a8 fd ff ff 	mov    %rdi,-0x258(%rbp)
    912d:	0f 82 0c 00 00 00    	jb     0x913f
    9133:	48 89 95 08 fe ff ff 	mov    %rdx,-0x1f8(%rbp)
    913a:	e9 47 00 00 00       	jmp    0x9186
    913f:	48 8b 50 60          	mov    0x60(%rax),%rdx
    9143:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    9147:	48 89 c6             	mov    %rax,%rsi
    914a:	48 89 95 18 fe ff ff 	mov    %rdx,-0x1e8(%rbp)
    9151:	48 89 ca             	mov    %rcx,%rdx
    9154:	48 8b 8d 18 fe ff ff 	mov    -0x1e8(%rbp),%rcx
    915b:	e8 80 6f ff ff       	call   0xe0
    9160:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    9167:	31 d2                	xor    %edx,%edx
    9169:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    916d:	48 83 f8 00          	cmp    $0x0,%rax
    9171:	0f 8f 08 00 00 00    	jg     0x917f
    9177:	49 89 c4             	mov    %rax,%r12
    917a:	e9 39 13 00 00       	jmp    0xa4b8
    917f:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
    9186:	48 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%rax
    918d:	48 89 c1             	mov    %rax,%rcx
    9190:	48 83 c1 28          	add    $0x28,%rcx
    9194:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    919b:	00 28 00 
    919e:	48 29 d1             	sub    %rdx,%rcx
    91a1:	48 8b 95 a8 fd ff ff 	mov    -0x258(%rbp),%rdx
    91a8:	48 89 0a             	mov    %rcx,(%rdx)
    91ab:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    91b2:	ff 00 00 
    91b5:	48 21 c8             	and    %rcx,%rax
    91b8:	31 c9                	xor    %ecx,%ecx
    91ba:	48 8b 95 d0 fd ff ff 	mov    -0x230(%rbp),%rdx
    91c1:	48 89 10             	mov    %rdx,(%rax)
    91c4:	48 8b b5 a0 fd ff ff 	mov    -0x260(%rbp),%rsi
    91cb:	48 89 70 08          	mov    %rsi,0x8(%rax)
    91cf:	48 89 48 10          	mov    %rcx,0x10(%rax)
    91d3:	48 89 48 18          	mov    %rcx,0x18(%rax)
    91d7:	48 89 48 20          	mov    %rcx,0x20(%rax)
    91db:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    91e2:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    91e6:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    91ec:	4c 01 c7             	add    %r8,%rdi
    91ef:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    91f3:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
    91fa:	b8 01 00 00 00       	mov    $0x1,%eax
    91ff:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
    9206:	31 c0                	xor    %eax,%eax
    9208:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
    920f:	e9 9c 01 00 00       	jmp    0x93b0
    9214:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    921b:	48 8b 48 10          	mov    0x10(%rax),%rcx
    921f:	48 8b 50 18          	mov    0x18(%rax),%rdx
    9223:	48 89 d6             	mov    %rdx,%rsi
    9226:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    922b:	bf 40 00 00 00       	mov    $0x40,%edi
    9230:	48 29 f7             	sub    %rsi,%rdi
    9233:	48 89 8d 10 fe ff ff 	mov    %rcx,-0x1f0(%rbp)
    923a:	4c 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%r8
    9241:	48 89 f9             	mov    %rdi,%rcx
    9244:	49 d3 e8             	shr    %cl,%r8
    9247:	31 c9                	xor    %ecx,%ecx
    9249:	48 39 ce             	cmp    %rcx,%rsi
    924c:	be 00 00 00 00       	mov    $0x0,%esi
    9251:	40 0f 94 c6          	sete   %sil
    9255:	48 85 f6             	test   %rsi,%rsi
    9258:	49 0f 44 c8          	cmove  %r8,%rcx
    925c:	be 01 00 00 00       	mov    $0x1,%esi
    9261:	48 89 cf             	mov    %rcx,%rdi
    9264:	48 01 f7             	add    %rsi,%rdi
    9267:	48 21 d7             	and    %rdx,%rdi
    926a:	ba 28 00 00 00       	mov    $0x28,%edx
    926f:	48 0f af ca          	imul   %rdx,%rcx
    9273:	48 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%rdx
    927a:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
    927e:	49 8b 48 10          	mov    0x10(%r8),%rcx
    9282:	48 85 c9             	test   %rcx,%rcx
    9285:	0f 84 af 00 00 00    	je     0x933a
    928b:	49 8b 08             	mov    (%r8),%rcx
    928e:	4d 8b 48 08          	mov    0x8(%r8),%r9
    9292:	4c 8b 95 d0 fd ff ff 	mov    -0x230(%rbp),%r10
    9299:	49 39 ca             	cmp    %rcx,%r10
    929c:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    92a2:	41 0f 94 c3          	sete   %r11b
    92a6:	48 8b 8d a0 fd ff ff 	mov    -0x260(%rbp),%rcx
    92ad:	4c 39 c9             	cmp    %r9,%rcx
    92b0:	ba 00 00 00 00       	mov    $0x0,%edx
    92b5:	0f 94 c2             	sete   %dl
    92b8:	49 21 d3             	and    %rdx,%r11
    92bb:	4d 85 db             	test   %r11,%r11
    92be:	0f 84 0c 00 00 00    	je     0x92d0
    92c4:	4c 89 85 08 fe ff ff 	mov    %r8,-0x1f8(%rbp)
    92cb:	e9 53 00 00 00       	jmp    0x9323
    92d0:	ba 28 00 00 00       	mov    $0x28,%edx
    92d5:	48 0f af fa          	imul   %rdx,%rdi
    92d9:	48 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%rdx
    92e0:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    92e4:	49 8b 50 10          	mov    0x10(%r8),%rdx
    92e8:	48 85 d2             	test   %rdx,%rdx
    92eb:	0f 84 49 00 00 00    	je     0x933a
    92f1:	49 8b 10             	mov    (%r8),%rdx
    92f4:	49 8b 78 08          	mov    0x8(%r8),%rdi
    92f8:	49 39 d2             	cmp    %rdx,%r10
    92fb:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    9301:	41 0f 94 c1          	sete   %r9b
    9305:	48 39 f9             	cmp    %rdi,%rcx
    9308:	ba 00 00 00 00       	mov    $0x0,%edx
    930d:	0f 94 c2             	sete   %dl
    9310:	49 21 d1             	and    %rdx,%r9
    9313:	4d 85 c9             	test   %r9,%r9
    9316:	0f 84 1e 00 00 00    	je     0x933a
    931c:	4c 89 85 08 fe ff ff 	mov    %r8,-0x1f8(%rbp)
    9323:	31 c0                	xor    %eax,%eax
    9325:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
    932c:	31 c0                	xor    %eax,%eax
    932e:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
    9335:	e9 76 00 00 00       	jmp    0x93b0
    933a:	48 8d 85 b0 fe ff ff 	lea    -0x150(%rbp),%rax
    9341:	48 89 c1             	mov    %rax,%rcx
    9344:	48 8b 95 d0 fd ff ff 	mov    -0x230(%rbp),%rdx
    934b:	48 89 11             	mov    %rdx,(%rcx)
    934e:	48 8b 95 a0 fd ff ff 	mov    -0x260(%rbp),%rdx
    9355:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    9359:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    935d:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
    9364:	48 89 ca             	mov    %rcx,%rdx
    9367:	e8 84 6d ff ff       	call   0xf0
    936c:	48 83 f8 00          	cmp    $0x0,%rax
    9370:	0f 8d 08 00 00 00    	jge    0x937e
    9376:	49 89 c4             	mov    %rax,%r12
    9379:	e9 3a 11 00 00       	jmp    0xa4b8
    937e:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    9385:	48 8b 11             	mov    (%rcx),%rdx
    9388:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    938c:	48 83 e6 01          	and    $0x1,%rsi
    9390:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    9394:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
    939b:	b8 01 00 00 00       	mov    $0x1,%eax
    93a0:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
    93a7:	31 c0                	xor    %eax,%eax
    93a9:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
    93b0:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
    93b7:	48 85 c0             	test   %rax,%rax
    93ba:	0f 84 6b 00 00 00    	je     0x942b
    93c0:	48 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%rax
    93c7:	48 8b 8d b0 fd ff ff 	mov    -0x250(%rbp),%rcx
    93ce:	48 89 48 10          	mov    %rcx,0x10(%rax)
    93d2:	31 d2                	xor    %edx,%edx
    93d4:	48 39 d1             	cmp    %rdx,%rcx
    93d7:	be 00 00 00 00       	mov    $0x0,%esi
    93dc:	40 0f 95 c6          	setne  %sil
    93e0:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    93e4:	48 09 f7             	or     %rsi,%rdi
    93e7:	48 0f be ff          	movsbq %dil,%rdi
    93eb:	40 88 78 20          	mov    %dil,0x20(%rax)
    93ef:	48 8b b5 80 fd ff ff 	mov    -0x280(%rbp),%rsi
    93f6:	48 89 70 18          	mov    %rsi,0x18(%rax)
    93fa:	4c 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%r8
    9401:	49 39 d0             	cmp    %rdx,%r8
    9404:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    940a:	41 0f 95 c1          	setne  %r9b
    940e:	40 0f b6 ff          	movzbl %dil,%edi
    9412:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    9418:	4d 85 c9             	test   %r9,%r9
    941b:	4c 0f 44 d2          	cmove  %rdx,%r10
    941f:	4c 09 d7             	or     %r10,%rdi
    9422:	40 88 78 20          	mov    %dil,0x20(%rax)
    9426:	e9 91 00 00 00       	jmp    0x94bc
    942b:	48 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%rax
    9432:	48 8b 48 10          	mov    0x10(%rax),%rcx
    9436:	48 8b 95 b0 fd ff ff 	mov    -0x250(%rbp),%rdx
    943d:	48 01 d1             	add    %rdx,%rcx
    9440:	48 89 48 10          	mov    %rcx,0x10(%rax)
    9444:	31 d2                	xor    %edx,%edx
    9446:	48 39 d1             	cmp    %rdx,%rcx
    9449:	b9 00 00 00 00       	mov    $0x0,%ecx
    944e:	0f 95 c1             	setne  %cl
    9451:	0f b6 70 20          	movzbl 0x20(%rax),%esi
    9455:	48 09 ce             	or     %rcx,%rsi
    9458:	48 0f be f6          	movsbq %sil,%rsi
    945c:	40 88 70 20          	mov    %sil,0x20(%rax)
    9460:	48 8b 48 18          	mov    0x18(%rax),%rcx
    9464:	40 0f b6 f6          	movzbl %sil,%esi
    9468:	48 89 f7             	mov    %rsi,%rdi
    946b:	48 83 e7 02          	and    $0x2,%rdi
    946f:	48 39 d7             	cmp    %rdx,%rdi
    9472:	bf 00 00 00 00       	mov    $0x0,%edi
    9477:	40 0f 95 c7          	setne  %dil
    947b:	45 31 c0             	xor    %r8d,%r8d
    947e:	48 85 ff             	test   %rdi,%rdi
    9481:	49 0f 44 c8          	cmove  %r8,%rcx
    9485:	4c 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%r8
    948c:	4c 01 c7             	add    %r8,%rdi
    948f:	4c 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%r8
    9496:	4c 01 c1             	add    %r8,%rcx
    9499:	48 89 48 18          	mov    %rcx,0x18(%rax)
    949d:	48 39 d7             	cmp    %rdx,%rdi
    94a0:	bf 00 00 00 00       	mov    $0x0,%edi
    94a5:	40 0f 95 c7          	setne  %dil
    94a9:	b9 02 00 00 00       	mov    $0x2,%ecx
    94ae:	48 85 ff             	test   %rdi,%rdi
    94b1:	48 0f 44 ca          	cmove  %rdx,%rcx
    94b5:	48 09 ce             	or     %rcx,%rsi
    94b8:	40 88 70 20          	mov    %sil,0x20(%rax)
    94bc:	48 8b 85 c8 fd ff ff 	mov    -0x238(%rbp),%rax
    94c3:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
    94ca:	e9 36 0f 00 00       	jmp    0xa405
    94cf:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
    94d6:	82 28 52 
    94d9:	31 c9                	xor    %ecx,%ecx
    94db:	48 8b 95 f8 fd ff ff 	mov    -0x208(%rbp),%rdx
    94e2:	48 89 95 c8 fd ff ff 	mov    %rdx,-0x238(%rbp)
    94e9:	31 d2                	xor    %edx,%edx
    94eb:	48 89 95 f8 fd ff ff 	mov    %rdx,-0x208(%rbp)
    94f2:	31 d2                	xor    %edx,%edx
    94f4:	48 89 95 08 fe ff ff 	mov    %rdx,-0x1f8(%rbp)
    94fb:	48 89 85 80 fd ff ff 	mov    %rax,-0x280(%rbp)
    9502:	31 d2                	xor    %edx,%edx
    9504:	48 89 95 c0 fd ff ff 	mov    %rdx,-0x240(%rbp)
    950b:	31 d2                	xor    %edx,%edx
    950d:	48 89 95 b0 fd ff ff 	mov    %rdx,-0x250(%rbp)
    9514:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
    951b:	31 d2                	xor    %edx,%edx
    951d:	48 89 95 18 fe ff ff 	mov    %rdx,-0x1e8(%rbp)
    9524:	31 d2                	xor    %edx,%edx
    9526:	48 89 95 a0 fd ff ff 	mov    %rdx,-0x260(%rbp)
    952d:	48 8b 85 c8 fd ff ff 	mov    -0x238(%rbp),%rax
    9534:	48 8b 8d e8 fd ff ff 	mov    -0x218(%rbp),%rcx
    953b:	48 39 c8             	cmp    %rcx,%rax
    953e:	0f 8d e7 0a 00 00    	jge    0xa02b
    9544:	48 8b 95 e0 fd ff ff 	mov    -0x220(%rbp),%rdx
    954b:	48 8d 34 c2          	lea    (%rdx,%rax,8),%rsi
    954f:	48 8b 3e             	mov    (%rsi),%rdi
    9552:	48 8b b5 f0 fd ff ff 	mov    -0x210(%rbp),%rsi
    9559:	49 89 f0             	mov    %rsi,%r8
    955c:	49 01 f8             	add    %rdi,%r8
    955f:	49 8b 78 10          	mov    0x10(%r8),%rdi
    9563:	4d 8b 48 08          	mov    0x8(%r8),%r9
    9567:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    956d:	4d 89 cb             	mov    %r9,%r11
    9570:	4d 21 d3             	and    %r10,%r11
    9573:	49 8b 50 18          	mov    0x18(%r8),%rdx
    9577:	49 d1 e9             	shr    $1,%r9
    957a:	4d 21 d1             	and    %r10,%r9
    957d:	45 31 c0             	xor    %r8d,%r8d
    9580:	4d 39 c1             	cmp    %r8,%r9
    9583:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    9589:	41 0f 95 c1          	setne  %r9b
    958d:	4d 85 db             	test   %r11,%r11
    9590:	48 89 95 d0 fd ff ff 	mov    %rdx,-0x230(%rbp)
    9597:	4c 89 8d 10 fe ff ff 	mov    %r9,-0x1f0(%rbp)
    959e:	0f 85 52 0a 00 00    	jne    0x9ff6
    95a4:	48 63 ff             	movslq %edi,%rdi
    95a7:	49 89 fb             	mov    %rdi,%r11
    95aa:	49 83 fe 05          	cmp    $0x5,%r14
    95ae:	0f 85 ab 00 00 00    	jne    0x965f
    95b4:	48 8b bd 38 fe ff ff 	mov    -0x1c8(%rbp),%rdi
    95bb:	4c 89 de             	mov    %r11,%rsi
    95be:	48 29 fe             	sub    %rdi,%rsi
    95c1:	48 8b bd 30 fe ff ff 	mov    -0x1d0(%rbp),%rdi
    95c8:	48 39 fe             	cmp    %rdi,%rsi
    95cb:	b8 00 00 00 00       	mov    $0x0,%eax
    95d0:	0f 92 c0             	setb   %al
    95d3:	48 85 c0             	test   %rax,%rax
    95d6:	49 0f 44 f0          	cmove  %r8,%rsi
    95da:	48 89 f7             	mov    %rsi,%rdi
    95dd:	48 c1 ef 06          	shr    $0x6,%rdi
    95e1:	48 83 e6 3f          	and    $0x3f,%rsi
    95e5:	49 8d 14 ff          	lea    (%r15,%rdi,8),%rdx
    95e9:	4c 8b 0a             	mov    (%rdx),%r9
    95ec:	48 89 f1             	mov    %rsi,%rcx
    95ef:	49 d3 e9             	shr    %cl,%r9
    95f2:	4d 21 d1             	and    %r10,%r9
    95f5:	49 21 c1             	and    %rax,%r9
    95f8:	48 8b 85 28 fe ff ff 	mov    -0x1d8(%rbp),%rax
    95ff:	48 8d 0c f8          	lea    (%rax,%rdi,8),%rcx
    9603:	48 8b 11             	mov    (%rcx),%rdx
    9606:	48 89 f1             	mov    %rsi,%rcx
    9609:	48 d3 ea             	shr    %cl,%rdx
    960c:	4c 21 d2             	and    %r10,%rdx
    960f:	48 8b 8d 48 fe ff ff 	mov    -0x1b8(%rbp),%rcx
    9616:	48 8d 04 f9          	lea    (%rcx,%rdi,8),%rax
    961a:	48 8b 38             	mov    (%rax),%rdi
    961d:	48 89 f1             	mov    %rsi,%rcx
    9620:	48 d3 ef             	shr    %cl,%rdi
    9623:	4c 21 d7             	and    %r10,%rdi
    9626:	48 8d 85 90 fe ff ff 	lea    -0x170(%rbp),%rax
    962d:	48 89 c1             	mov    %rax,%rcx
    9630:	48 c1 e7 20          	shl    $0x20,%rdi
    9634:	4c 89 19             	mov    %r11,(%rcx)
    9637:	48 89 79 08          	mov    %rdi,0x8(%rcx)
    963b:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    963f:	4d 39 c1             	cmp    %r8,%r9
    9642:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    9648:	41 0f 95 c1          	setne  %r9b
    964c:	4d 85 c9             	test   %r9,%r9
    964f:	49 0f 44 c8          	cmove  %r8,%rcx
    9653:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
    965a:	e9 ea 01 00 00       	jmp    0x9849
    965f:	49 83 fe 01          	cmp    $0x1,%r14
    9663:	0f 85 ef 00 00 00    	jne    0x9758
    9669:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    9670:	79 37 9e 
    9673:	4c 89 d9             	mov    %r11,%rcx
    9676:	48 c1 e9 2b          	shr    $0x2b,%rcx
    967a:	4c 89 da             	mov    %r11,%rdx
    967d:	48 c1 ea 2c          	shr    $0x2c,%rdx
    9681:	48 31 d1             	xor    %rdx,%rcx
    9684:	4c 89 da             	mov    %r11,%rdx
    9687:	48 31 ca             	xor    %rcx,%rdx
    968a:	48 0f af d0          	imul   %rax,%rdx
    968e:	b8 40 00 00 00       	mov    $0x40,%eax
    9693:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
    969a:	48 29 c8             	sub    %rcx,%rax
    969d:	48 89 c1             	mov    %rax,%rcx
    96a0:	48 89 d6             	mov    %rdx,%rsi
    96a3:	48 d3 ee             	shr    %cl,%rsi
    96a6:	31 c0                	xor    %eax,%eax
    96a8:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
    96af:	48 39 c1             	cmp    %rax,%rcx
    96b2:	bf 00 00 00 00       	mov    $0x0,%edi
    96b7:	40 0f 94 c7          	sete   %dil
    96bb:	48 85 ff             	test   %rdi,%rdi
    96be:	48 0f 44 c6          	cmove  %rsi,%rax
    96c2:	49 8d 34 c7          	lea    (%r15,%rax,8),%rsi
    96c6:	48 8b 06             	mov    (%rsi),%rax
    96c9:	48 be ff ff ff ff ff 	movabs $0xffffffffffff,%rsi
    96d0:	ff 00 00 
    96d3:	48 89 c7             	mov    %rax,%rdi
    96d6:	48 21 f7             	and    %rsi,%rdi
    96d9:	31 f6                	xor    %esi,%esi
    96db:	48 39 f7             	cmp    %rsi,%rdi
    96de:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    96e4:	41 0f 94 c0          	sete   %r8b
    96e8:	49 89 d1             	mov    %rdx,%r9
    96eb:	49 c1 e9 20          	shr    $0x20,%r9
    96ef:	4c 31 ca             	xor    %r9,%rdx
    96f2:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    96f8:	4c 21 ca             	and    %r9,%rdx
    96fb:	48 83 e2 0f          	and    $0xf,%rdx
    96ff:	48 83 c2 30          	add    $0x30,%rdx
    9703:	48 89 d1             	mov    %rdx,%rcx
    9706:	48 d3 e8             	shr    %cl,%rax
    9709:	48 83 e0 01          	and    $0x1,%rax
    970d:	48 83 f8 00          	cmp    $0x0,%rax
    9711:	b8 00 00 00 00       	mov    $0x0,%eax
    9716:	0f 95 c0             	setne  %al
    9719:	b9 01 00 00 00       	mov    $0x1,%ecx
    971e:	48 31 c8             	xor    %rcx,%rax
    9721:	49 09 c0             	or     %rax,%r8
    9724:	b8 01 00 00 00       	mov    $0x1,%eax
    9729:	48 29 c7             	sub    %rax,%rdi
    972c:	b9 18 00 00 00       	mov    $0x18,%ecx
    9731:	48 0f af f9          	imul   %rcx,%rdi
    9735:	48 8b 8d 20 fe ff ff 	mov    -0x1e0(%rbp),%rcx
    973c:	48 89 ca             	mov    %rcx,%rdx
    973f:	48 01 fa             	add    %rdi,%rdx
    9742:	48 89 f7             	mov    %rsi,%rdi
    9745:	4d 85 c0             	test   %r8,%r8
    9748:	48 0f 44 fa          	cmove  %rdx,%rdi
    974c:	48 89 bd 98 fd ff ff 	mov    %rdi,-0x268(%rbp)
    9753:	e9 f1 00 00 00       	jmp    0x9849
    9758:	48 8b 85 38 fe ff ff 	mov    -0x1c8(%rbp),%rax
    975f:	4c 89 d9             	mov    %r11,%rcx
    9762:	48 29 c1             	sub    %rax,%rcx
    9765:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
    976c:	48 39 d1             	cmp    %rdx,%rcx
    976f:	0f 82 0e 00 00 00    	jb     0x9783
    9775:	31 f6                	xor    %esi,%esi
    9777:	48 89 b5 98 fd ff ff 	mov    %rsi,-0x268(%rbp)
    977e:	e9 c6 00 00 00       	jmp    0x9849
    9783:	49 83 fe 02          	cmp    $0x2,%r14
    9787:	48 89 8d 78 fd ff ff 	mov    %rcx,-0x288(%rbp)
    978e:	0f 85 69 00 00 00    	jne    0x97fd
    9794:	48 89 ce             	mov    %rcx,%rsi
    9797:	48 c1 ee 06          	shr    $0x6,%rsi
    979b:	49 8d 3c f7          	lea    (%r15,%rsi,8),%rdi
    979f:	48 8b 37             	mov    (%rdi),%rsi
    97a2:	48 89 cf             	mov    %rcx,%rdi
    97a5:	48 83 e7 3f          	and    $0x3f,%rdi
    97a9:	48 89 f9             	mov    %rdi,%rcx
    97ac:	48 d3 ee             	shr    %cl,%rsi
    97af:	b9 01 00 00 00       	mov    $0x1,%ecx
    97b4:	48 21 ce             	and    %rcx,%rsi
    97b7:	31 ff                	xor    %edi,%edi
    97b9:	48 39 fe             	cmp    %rdi,%rsi
    97bc:	be 00 00 00 00       	mov    $0x0,%esi
    97c1:	40 0f 95 c6          	setne  %sil
    97c5:	41 b8 10 00 00 00    	mov    $0x10,%r8d
    97cb:	4c 8b 8d 78 fd ff ff 	mov    -0x288(%rbp),%r9
    97d2:	4d 89 ca             	mov    %r9,%r10
    97d5:	4d 0f af d0          	imul   %r8,%r10
    97d9:	4c 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%r8
    97e0:	4d 89 c1             	mov    %r8,%r9
    97e3:	4d 01 d1             	add    %r10,%r9
    97e6:	49 83 e9 08          	sub    $0x8,%r9
    97ea:	48 85 f6             	test   %rsi,%rsi
    97ed:	4c 0f 44 cf          	cmove  %rdi,%r9
    97f1:	4c 89 8d 98 fd ff ff 	mov    %r9,-0x268(%rbp)
    97f8:	e9 4c 00 00 00       	jmp    0x9849
    97fd:	48 8b 85 78 fd ff ff 	mov    -0x288(%rbp),%rax
    9804:	49 8d 0c 87          	lea    (%r15,%rax,4),%rcx
    9808:	8b 01                	mov    (%rcx),%eax
    980a:	b9 01 00 00 00       	mov    $0x1,%ecx
    980f:	48 89 c2             	mov    %rax,%rdx
    9812:	48 29 ca             	sub    %rcx,%rdx
    9815:	be 18 00 00 00       	mov    $0x18,%esi
    981a:	48 0f af d6          	imul   %rsi,%rdx
    981e:	48 8b b5 20 fe ff ff 	mov    -0x1e0(%rbp),%rsi
    9825:	48 89 f7             	mov    %rsi,%rdi
    9828:	48 01 d7             	add    %rdx,%rdi
    982b:	31 d2                	xor    %edx,%edx
    982d:	48 39 d0             	cmp    %rdx,%rax
    9830:	b8 00 00 00 00       	mov    $0x0,%eax
    9835:	0f 94 c0             	sete   %al
    9838:	49 89 d0             	mov    %rdx,%r8
    983b:	48 85 c0             	test   %rax,%rax
    983e:	4c 0f 44 c7          	cmove  %rdi,%r8
    9842:	4c 89 85 98 fd ff ff 	mov    %r8,-0x268(%rbp)
    9849:	49 83 fe 01          	cmp    $0x1,%r14
    984d:	be 00 00 00 00       	mov    $0x0,%esi
    9852:	40 0f 95 c6          	setne  %sil
    9856:	31 ff                	xor    %edi,%edi
    9858:	48 8b 85 a0 fd ff ff 	mov    -0x260(%rbp),%rax
    985f:	48 89 85 78 fd ff ff 	mov    %rax,-0x288(%rbp)
    9866:	48 8b 85 f8 fd ff ff 	mov    -0x208(%rbp),%rax
    986d:	48 89 85 38 fd ff ff 	mov    %rax,-0x2c8(%rbp)
    9874:	48 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%rax
    987b:	48 89 85 30 fd ff ff 	mov    %rax,-0x2d0(%rbp)
    9882:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
    9889:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
    9890:	48 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%rax
    9897:	48 89 85 58 fd ff ff 	mov    %rax,-0x2a8(%rbp)
    989e:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
    98a5:	48 89 85 68 fd ff ff 	mov    %rax,-0x298(%rbp)
    98ac:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
    98b3:	48 89 85 88 fd ff ff 	mov    %rax,-0x278(%rbp)
    98ba:	48 8b 85 18 fe ff ff 	mov    -0x1e8(%rbp),%rax
    98c1:	48 89 85 60 fd ff ff 	mov    %rax,-0x2a0(%rbp)
    98c8:	48 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%rax
    98cf:	48 85 c0             	test   %rax,%rax
    98d2:	0f 85 75 00 00 00    	jne    0x994d
    98d8:	48 8b 8d 78 fd ff ff 	mov    -0x288(%rbp),%rcx
    98df:	48 89 8d a0 fd ff ff 	mov    %rcx,-0x260(%rbp)
    98e6:	48 8b 8d 38 fd ff ff 	mov    -0x2c8(%rbp),%rcx
    98ed:	48 89 8d f8 fd ff ff 	mov    %rcx,-0x208(%rbp)
    98f4:	48 8b 8d 30 fd ff ff 	mov    -0x2d0(%rbp),%rcx
    98fb:	48 89 8d 08 fe ff ff 	mov    %rcx,-0x1f8(%rbp)
    9902:	48 8b 8d 90 fd ff ff 	mov    -0x270(%rbp),%rcx
    9909:	48 89 8d 80 fd ff ff 	mov    %rcx,-0x280(%rbp)
    9910:	48 8b 8d 58 fd ff ff 	mov    -0x2a8(%rbp),%rcx
    9917:	48 89 8d c0 fd ff ff 	mov    %rcx,-0x240(%rbp)
    991e:	48 8b 8d 68 fd ff ff 	mov    -0x298(%rbp),%rcx
    9925:	48 89 8d b0 fd ff ff 	mov    %rcx,-0x250(%rbp)
    992c:	48 8b 8d 88 fd ff ff 	mov    -0x278(%rbp),%rcx
    9933:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
    993a:	48 8b 8d 60 fd ff ff 	mov    -0x2a0(%rbp),%rcx
    9941:	48 89 8d 18 fe ff ff 	mov    %rcx,-0x1e8(%rbp)
    9948:	e9 a3 06 00 00       	jmp    0x9ff0
    994d:	48 8b 48 08          	mov    0x8(%rax),%rcx
    9951:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    9956:	49 89 c8             	mov    %rcx,%r8
    9959:	49 21 d0             	and    %rdx,%r8
    995c:	ba 01 00 00 00       	mov    $0x1,%edx
    9961:	4d 89 c1             	mov    %r8,%r9
    9964:	49 29 d1             	sub    %rdx,%r9
    9967:	41 ba 18 00 00 00    	mov    $0x18,%r10d
    996d:	4d 0f af ca          	imul   %r10,%r9
    9971:	4c 8b 95 20 fe ff ff 	mov    -0x1e0(%rbp),%r10
    9978:	4c 89 d0             	mov    %r10,%rax
    997b:	4c 01 c8             	add    %r9,%rax
    997e:	45 31 c9             	xor    %r9d,%r9d
    9981:	4d 39 c8             	cmp    %r9,%r8
    9984:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    998a:	41 0f 94 c0          	sete   %r8b
    998e:	4d 89 ca             	mov    %r9,%r10
    9991:	4d 85 c0             	test   %r8,%r8
    9994:	4c 0f 44 d0          	cmove  %rax,%r10
    9998:	48 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%rax
    999f:	4c 8b 00             	mov    (%rax),%r8
    99a2:	4d 39 c3             	cmp    %r8,%r11
    99a5:	b8 00 00 00 00       	mov    $0x0,%eax
    99aa:	0f 94 c0             	sete   %al
    99ad:	48 09 f0             	or     %rsi,%rax
    99b0:	49 89 f8             	mov    %rdi,%r8
    99b3:	49 01 d0             	add    %rdx,%r8
    99b6:	48 85 c0             	test   %rax,%rax
    99b9:	0f 85 0c 00 00 00    	jne    0x99cb
    99bf:	4c 89 95 98 fd ff ff 	mov    %r10,-0x268(%rbp)
    99c6:	e9 fd fe ff ff       	jmp    0x98c8
    99cb:	48 8b 43 18          	mov    0x18(%rbx),%rax
    99cf:	48 39 c7             	cmp    %rax,%rdi
    99d2:	0f 8d 0f 00 00 00    	jge    0x99e7
    99d8:	4c 89 95 98 fd ff ff 	mov    %r10,-0x268(%rbp)
    99df:	4c 89 c7             	mov    %r8,%rdi
    99e2:	e9 e1 fe ff ff       	jmp    0x98c8
    99e7:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
    99eb:	48 8b 70 18          	mov    0x18(%rax),%rsi
    99ef:	48 85 f6             	test   %rsi,%rsi
    99f2:	48 89 8d 50 fd ff ff 	mov    %rcx,-0x2b0(%rbp)
    99f9:	4c 89 85 40 fd ff ff 	mov    %r8,-0x2c0(%rbp)
    9a00:	0f 84 0c 00 00 00    	je     0x9a12
    9a06:	0f b6 3e             	movzbl (%rsi),%edi
    9a09:	48 85 ff             	test   %rdi,%rdi
    9a0c:	0f 85 02 06 00 00    	jne    0xa014
    9a12:	48 8b 85 98 fd ff ff 	mov    -0x268(%rbp),%rax
    9a19:	48 8b 48 10          	mov    0x10(%rax),%rcx
    9a1d:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
    9a24:	48 89 d6             	mov    %rdx,%rsi
    9a27:	48 c1 ee 20          	shr    $0x20,%rsi
    9a2b:	48 83 e6 01          	and    $0x1,%rsi
    9a2f:	48 83 fe 00          	cmp    $0x0,%rsi
    9a33:	be 00 00 00 00       	mov    $0x0,%esi
    9a38:	40 0f 95 c6          	setne  %sil
    9a3c:	48 8b bd 40 fd ff ff 	mov    -0x2c0(%rbp),%rdi
    9a43:	48 89 7b 18          	mov    %rdi,0x18(%rbx)
    9a47:	4c 8b 85 78 fd ff ff 	mov    -0x288(%rbp),%r8
    9a4e:	4d 89 c1             	mov    %r8,%r9
    9a51:	49 83 c1 01          	add    $0x1,%r9
    9a55:	48 63 c9             	movslq %ecx,%rcx
    9a58:	45 31 d2             	xor    %r10d,%r10d
    9a5b:	48 85 f6             	test   %rsi,%rsi
    9a5e:	4c 0f 44 d1          	cmove  %rcx,%r10
    9a62:	48 8b 8d 38 fd ff ff 	mov    -0x2c8(%rbp),%rcx
    9a69:	4c 39 d1             	cmp    %r10,%rcx
    9a6c:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    9a72:	41 0f 94 c3          	sete   %r11b
    9a76:	48 8b 85 30 fd ff ff 	mov    -0x2d0(%rbp),%rax
    9a7d:	48 39 f0             	cmp    %rsi,%rax
    9a80:	ba 00 00 00 00       	mov    $0x0,%edx
    9a85:	0f 94 c2             	sete   %dl
    9a88:	49 21 d3             	and    %rdx,%r11
    9a8b:	4d 85 db             	test   %r11,%r11
    9a8e:	48 89 b5 48 fd ff ff 	mov    %rsi,-0x2b8(%rbp)
    9a95:	4c 89 8d b8 fd ff ff 	mov    %r9,-0x248(%rbp)
    9a9c:	4c 89 95 70 fd ff ff 	mov    %r10,-0x290(%rbp)
    9aa3:	0f 84 83 00 00 00    	je     0x9b2c
    9aa9:	48 8b 95 68 fd ff ff 	mov    -0x298(%rbp),%rdx
    9ab0:	49 89 d3             	mov    %rdx,%r11
    9ab3:	49 83 c3 01          	add    $0x1,%r11
    9ab7:	be 01 00 00 00       	mov    $0x1,%esi
    9abc:	4c 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%r10
    9ac3:	4d 89 d1             	mov    %r10,%r9
    9ac6:	49 31 f1             	xor    %rsi,%r9
    9ac9:	31 f6                	xor    %esi,%esi
    9acb:	4c 8b 95 d0 fd ff ff 	mov    -0x230(%rbp),%r10
    9ad2:	4c 89 d2             	mov    %r10,%rdx
    9ad5:	4d 85 c9             	test   %r9,%r9
    9ad8:	48 0f 44 d6          	cmove  %rsi,%rdx
    9adc:	48 8b b5 60 fd ff ff 	mov    -0x2a0(%rbp),%rsi
    9ae3:	49 89 f2             	mov    %rsi,%r10
    9ae6:	4d 01 ca             	add    %r9,%r10
    9ae9:	4c 8b 8d 88 fd ff ff 	mov    -0x278(%rbp),%r9
    9af0:	4c 89 ce             	mov    %r9,%rsi
    9af3:	48 01 d6             	add    %rdx,%rsi
    9af6:	48 89 8d f8 fd ff ff 	mov    %rcx,-0x208(%rbp)
    9afd:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
    9b04:	48 8b 95 90 fd ff ff 	mov    -0x270(%rbp),%rdx
    9b0b:	48 89 95 80 fd ff ff 	mov    %rdx,-0x280(%rbp)
    9b12:	4c 89 9d b0 fd ff ff 	mov    %r11,-0x250(%rbp)
    9b19:	48 89 b5 a8 fd ff ff 	mov    %rsi,-0x258(%rbp)
    9b20:	4c 89 95 18 fe ff ff 	mov    %r10,-0x1e8(%rbp)
    9b27:	e9 aa 04 00 00       	jmp    0x9fd6
    9b2c:	48 8b 85 58 fd ff ff 	mov    -0x2a8(%rbp),%rax
    9b33:	48 85 c0             	test   %rax,%rax
    9b36:	0f 84 fe 03 00 00    	je     0x9f3a
    9b3c:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    9b43:	48 8b 51 68          	mov    0x68(%rcx),%rdx
    9b47:	48 85 d2             	test   %rdx,%rdx
    9b4a:	0f 84 3d 01 00 00    	je     0x9c8d
    9b50:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    9b54:	be 40 00 00 00       	mov    $0x40,%esi
    9b59:	48 29 d6             	sub    %rdx,%rsi
    9b5c:	48 8b bd 90 fd ff ff 	mov    -0x270(%rbp),%rdi
    9b63:	48 89 f1             	mov    %rsi,%rcx
    9b66:	49 89 f8             	mov    %rdi,%r8
    9b69:	49 d3 e8             	shr    %cl,%r8
    9b6c:	31 c9                	xor    %ecx,%ecx
    9b6e:	48 39 ca             	cmp    %rcx,%rdx
    9b71:	ba 00 00 00 00       	mov    $0x0,%edx
    9b76:	0f 94 c2             	sete   %dl
    9b79:	48 85 d2             	test   %rdx,%rdx
    9b7c:	49 0f 44 c8          	cmove  %r8,%rcx
    9b80:	48 8b 95 58 fe ff ff 	mov    -0x1a8(%rbp),%rdx
    9b87:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    9b8b:	4c 8d 04 ce          	lea    (%rsi,%rcx,8),%r8
    9b8f:	49 8b 30             	mov    (%r8),%rsi
    9b92:	49 b9 00 00 00 00 00 	movabs $0x28000000000000,%r9
    9b99:	00 28 00 
    9b9c:	4c 39 ce             	cmp    %r9,%rsi
    9b9f:	4c 89 85 00 fe ff ff 	mov    %r8,-0x200(%rbp)
    9ba6:	0f 82 0c 00 00 00    	jb     0x9bb8
    9bac:	48 89 b5 20 fd ff ff 	mov    %rsi,-0x2e0(%rbp)
    9bb3:	e9 47 00 00 00       	jmp    0x9bff
    9bb8:	48 8b 72 60          	mov    0x60(%rdx),%rsi
    9bbc:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    9bc0:	48 89 b5 28 fd ff ff 	mov    %rsi,-0x2d8(%rbp)
    9bc7:	48 89 d6             	mov    %rdx,%rsi
    9bca:	48 89 ca             	mov    %rcx,%rdx
    9bcd:	48 8b 8d 28 fd ff ff 	mov    -0x2d8(%rbp),%rcx
    9bd4:	e8 07 65 ff ff       	call   0xe0
    9bd9:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    9be0:	31 d2                	xor    %edx,%edx
    9be2:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    9be6:	48 83 f8 00          	cmp    $0x0,%rax
    9bea:	0f 8f 08 00 00 00    	jg     0x9bf8
    9bf0:	49 89 c4             	mov    %rax,%r12
    9bf3:	e9 c0 08 00 00       	jmp    0xa4b8
    9bf8:	48 89 85 20 fd ff ff 	mov    %rax,-0x2e0(%rbp)
    9bff:	48 8b 85 20 fd ff ff 	mov    -0x2e0(%rbp),%rax
    9c06:	48 89 c1             	mov    %rax,%rcx
    9c09:	48 83 c1 28          	add    $0x28,%rcx
    9c0d:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    9c14:	00 28 00 
    9c17:	48 29 d1             	sub    %rdx,%rcx
    9c1a:	48 8b 95 00 fe ff ff 	mov    -0x200(%rbp),%rdx
    9c21:	48 89 0a             	mov    %rcx,(%rdx)
    9c24:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    9c2b:	ff 00 00 
    9c2e:	48 21 c8             	and    %rcx,%rax
    9c31:	31 c9                	xor    %ecx,%ecx
    9c33:	48 8b 95 38 fd ff ff 	mov    -0x2c8(%rbp),%rdx
    9c3a:	48 89 10             	mov    %rdx,(%rax)
    9c3d:	48 8b b5 30 fd ff ff 	mov    -0x2d0(%rbp),%rsi
    9c44:	48 89 70 08          	mov    %rsi,0x8(%rax)
    9c48:	48 89 48 10          	mov    %rcx,0x10(%rax)
    9c4c:	48 89 48 18          	mov    %rcx,0x18(%rax)
    9c50:	48 89 48 20          	mov    %rcx,0x20(%rax)
    9c54:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    9c5b:	48 8b 79 60          	mov    0x60(%rcx),%rdi
    9c5f:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    9c65:	4c 01 c7             	add    %r8,%rdi
    9c68:	48 89 79 60          	mov    %rdi,0x60(%rcx)
    9c6c:	48 89 85 20 fd ff ff 	mov    %rax,-0x2e0(%rbp)
    9c73:	b8 01 00 00 00       	mov    $0x1,%eax
    9c78:	48 89 85 00 fe ff ff 	mov    %rax,-0x200(%rbp)
    9c7f:	31 c0                	xor    %eax,%eax
    9c81:	48 89 85 28 fd ff ff 	mov    %rax,-0x2d8(%rbp)
    9c88:	e9 9f 01 00 00       	jmp    0x9e2c
    9c8d:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    9c94:	48 8b 48 10          	mov    0x10(%rax),%rcx
    9c98:	48 8b 50 18          	mov    0x18(%rax),%rdx
    9c9c:	48 89 d6             	mov    %rdx,%rsi
    9c9f:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    9ca4:	bf 40 00 00 00       	mov    $0x40,%edi
    9ca9:	48 29 f7             	sub    %rsi,%rdi
    9cac:	48 89 8d 18 fd ff ff 	mov    %rcx,-0x2e8(%rbp)
    9cb3:	4c 8b 85 90 fd ff ff 	mov    -0x270(%rbp),%r8
    9cba:	48 89 f9             	mov    %rdi,%rcx
    9cbd:	4d 89 c1             	mov    %r8,%r9
    9cc0:	49 d3 e9             	shr    %cl,%r9
    9cc3:	31 c9                	xor    %ecx,%ecx
    9cc5:	48 39 ce             	cmp    %rcx,%rsi
    9cc8:	be 00 00 00 00       	mov    $0x0,%esi
    9ccd:	40 0f 94 c6          	sete   %sil
    9cd1:	48 85 f6             	test   %rsi,%rsi
    9cd4:	49 0f 44 c9          	cmove  %r9,%rcx
    9cd8:	be 01 00 00 00       	mov    $0x1,%esi
    9cdd:	48 89 cf             	mov    %rcx,%rdi
    9ce0:	48 01 f7             	add    %rsi,%rdi
    9ce3:	48 21 d7             	and    %rdx,%rdi
    9ce6:	ba 28 00 00 00       	mov    $0x28,%edx
    9ceb:	48 0f af ca          	imul   %rdx,%rcx
    9cef:	48 8b 95 18 fd ff ff 	mov    -0x2e8(%rbp),%rdx
    9cf6:	4c 8d 0c 0a          	lea    (%rdx,%rcx,1),%r9
    9cfa:	49 8b 49 10          	mov    0x10(%r9),%rcx
    9cfe:	48 85 c9             	test   %rcx,%rcx
    9d01:	0f 84 af 00 00 00    	je     0x9db6
    9d07:	49 8b 09             	mov    (%r9),%rcx
    9d0a:	4d 8b 51 08          	mov    0x8(%r9),%r10
    9d0e:	4c 8b 9d 38 fd ff ff 	mov    -0x2c8(%rbp),%r11
    9d15:	49 39 cb             	cmp    %rcx,%r11
    9d18:	ba 00 00 00 00       	mov    $0x0,%edx
    9d1d:	0f 94 c2             	sete   %dl
    9d20:	48 8b 8d 30 fd ff ff 	mov    -0x2d0(%rbp),%rcx
    9d27:	4c 39 d1             	cmp    %r10,%rcx
    9d2a:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    9d30:	41 0f 94 c0          	sete   %r8b
    9d34:	4c 21 c2             	and    %r8,%rdx
    9d37:	48 85 d2             	test   %rdx,%rdx
    9d3a:	0f 84 0c 00 00 00    	je     0x9d4c
    9d40:	4c 89 8d 20 fd ff ff 	mov    %r9,-0x2e0(%rbp)
    9d47:	e9 53 00 00 00       	jmp    0x9d9f
    9d4c:	ba 28 00 00 00       	mov    $0x28,%edx
    9d51:	48 0f af fa          	imul   %rdx,%rdi
    9d55:	48 8b 95 18 fd ff ff 	mov    -0x2e8(%rbp),%rdx
    9d5c:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    9d60:	49 8b 50 10          	mov    0x10(%r8),%rdx
    9d64:	48 85 d2             	test   %rdx,%rdx
    9d67:	0f 84 49 00 00 00    	je     0x9db6
    9d6d:	49 8b 10             	mov    (%r8),%rdx
    9d70:	49 8b 78 08          	mov    0x8(%r8),%rdi
    9d74:	49 39 d3             	cmp    %rdx,%r11
    9d77:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    9d7d:	41 0f 94 c1          	sete   %r9b
    9d81:	48 39 f9             	cmp    %rdi,%rcx
    9d84:	ba 00 00 00 00       	mov    $0x0,%edx
    9d89:	0f 94 c2             	sete   %dl
    9d8c:	49 21 d1             	and    %rdx,%r9
    9d8f:	4d 85 c9             	test   %r9,%r9
    9d92:	0f 84 1e 00 00 00    	je     0x9db6
    9d98:	4c 89 85 20 fd ff ff 	mov    %r8,-0x2e0(%rbp)
    9d9f:	31 c0                	xor    %eax,%eax
    9da1:	48 89 85 00 fe ff ff 	mov    %rax,-0x200(%rbp)
    9da8:	31 c0                	xor    %eax,%eax
    9daa:	48 89 85 28 fd ff ff 	mov    %rax,-0x2d8(%rbp)
    9db1:	e9 76 00 00 00       	jmp    0x9e2c
    9db6:	48 8d 85 70 fe ff ff 	lea    -0x190(%rbp),%rax
    9dbd:	48 89 c1             	mov    %rax,%rcx
    9dc0:	48 8b 95 38 fd ff ff 	mov    -0x2c8(%rbp),%rdx
    9dc7:	48 89 11             	mov    %rdx,(%rcx)
    9dca:	48 8b b5 30 fd ff ff 	mov    -0x2d0(%rbp),%rsi
    9dd1:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    9dd5:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    9dd9:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
    9de0:	48 89 ca             	mov    %rcx,%rdx
    9de3:	e8 08 63 ff ff       	call   0xf0
    9de8:	48 83 f8 00          	cmp    $0x0,%rax
    9dec:	0f 8d 08 00 00 00    	jge    0x9dfa
    9df2:	49 89 c4             	mov    %rax,%r12
    9df5:	e9 be 06 00 00       	jmp    0xa4b8
    9dfa:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    9e01:	48 8b 11             	mov    (%rcx),%rdx
    9e04:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    9e08:	48 83 e6 01          	and    $0x1,%rsi
    9e0c:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    9e10:	48 89 85 20 fd ff ff 	mov    %rax,-0x2e0(%rbp)
    9e17:	b8 01 00 00 00       	mov    $0x1,%eax
    9e1c:	48 89 85 00 fe ff ff 	mov    %rax,-0x200(%rbp)
    9e23:	31 c0                	xor    %eax,%eax
    9e25:	48 89 85 28 fd ff ff 	mov    %rax,-0x2d8(%rbp)
    9e2c:	48 8b 85 00 fe ff ff 	mov    -0x200(%rbp),%rax
    9e33:	48 85 c0             	test   %rax,%rax
    9e36:	0f 84 6b 00 00 00    	je     0x9ea7
    9e3c:	48 8b 85 20 fd ff ff 	mov    -0x2e0(%rbp),%rax
    9e43:	48 8b 8d 68 fd ff ff 	mov    -0x298(%rbp),%rcx
    9e4a:	48 89 48 10          	mov    %rcx,0x10(%rax)
    9e4e:	31 d2                	xor    %edx,%edx
    9e50:	48 39 d1             	cmp    %rdx,%rcx
    9e53:	be 00 00 00 00       	mov    $0x0,%esi
    9e58:	40 0f 95 c6          	setne  %sil
    9e5c:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    9e60:	48 09 f7             	or     %rsi,%rdi
    9e63:	48 0f be ff          	movsbq %dil,%rdi
    9e67:	40 88 78 20          	mov    %dil,0x20(%rax)
    9e6b:	48 8b b5 88 fd ff ff 	mov    -0x278(%rbp),%rsi
    9e72:	48 89 70 18          	mov    %rsi,0x18(%rax)
    9e76:	4c 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%r8
    9e7d:	49 39 d0             	cmp    %rdx,%r8
    9e80:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    9e86:	41 0f 95 c1          	setne  %r9b
    9e8a:	40 0f b6 ff          	movzbl %dil,%edi
    9e8e:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    9e94:	4d 85 c9             	test   %r9,%r9
    9e97:	4c 0f 44 d2          	cmove  %rdx,%r10
    9e9b:	4c 09 d7             	or     %r10,%rdi
    9e9e:	40 88 78 20          	mov    %dil,0x20(%rax)
    9ea2:	e9 93 00 00 00       	jmp    0x9f3a
    9ea7:	48 8b 85 20 fd ff ff 	mov    -0x2e0(%rbp),%rax
    9eae:	48 8b 48 10          	mov    0x10(%rax),%rcx
    9eb2:	48 8b 95 68 fd ff ff 	mov    -0x298(%rbp),%rdx
    9eb9:	48 01 d1             	add    %rdx,%rcx
    9ebc:	48 89 48 10          	mov    %rcx,0x10(%rax)
    9ec0:	31 f6                	xor    %esi,%esi
    9ec2:	48 39 f1             	cmp    %rsi,%rcx
    9ec5:	b9 00 00 00 00       	mov    $0x0,%ecx
    9eca:	0f 95 c1             	setne  %cl
    9ecd:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    9ed1:	48 09 cf             	or     %rcx,%rdi
    9ed4:	48 0f be ff          	movsbq %dil,%rdi
    9ed8:	40 88 78 20          	mov    %dil,0x20(%rax)
    9edc:	48 8b 48 18          	mov    0x18(%rax),%rcx
    9ee0:	40 0f b6 ff          	movzbl %dil,%edi
    9ee4:	49 89 f8             	mov    %rdi,%r8
    9ee7:	49 83 e0 02          	and    $0x2,%r8
    9eeb:	49 39 f0             	cmp    %rsi,%r8
    9eee:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    9ef4:	41 0f 95 c0          	setne  %r8b
    9ef8:	45 31 c9             	xor    %r9d,%r9d
    9efb:	4d 85 c0             	test   %r8,%r8
    9efe:	49 0f 44 c9          	cmove  %r9,%rcx
    9f02:	4c 8b 8d 60 fd ff ff 	mov    -0x2a0(%rbp),%r9
    9f09:	4d 01 c8             	add    %r9,%r8
    9f0c:	4c 8b 95 88 fd ff ff 	mov    -0x278(%rbp),%r10
    9f13:	4c 01 d1             	add    %r10,%rcx
    9f16:	48 89 48 18          	mov    %rcx,0x18(%rax)
    9f1a:	49 39 f0             	cmp    %rsi,%r8
    9f1d:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    9f23:	41 0f 95 c0          	setne  %r8b
    9f27:	b9 02 00 00 00       	mov    $0x2,%ecx
    9f2c:	4d 85 c0             	test   %r8,%r8
    9f2f:	48 0f 44 ce          	cmove  %rsi,%rcx
    9f33:	48 09 cf             	or     %rcx,%rdi
    9f36:	40 88 78 20          	mov    %dil,0x20(%rax)
    9f3a:	b8 01 00 00 00       	mov    $0x1,%eax
    9f3f:	48 8b 8d 10 fe ff ff 	mov    -0x1f0(%rbp),%rcx
    9f46:	48 89 ca             	mov    %rcx,%rdx
    9f49:	48 31 c2             	xor    %rax,%rdx
    9f4c:	31 c0                	xor    %eax,%eax
    9f4e:	48 8b b5 d0 fd ff ff 	mov    -0x230(%rbp),%rsi
    9f55:	48 89 f7             	mov    %rsi,%rdi
    9f58:	48 85 d2             	test   %rdx,%rdx
    9f5b:	48 0f 44 f8          	cmove  %rax,%rdi
    9f5f:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    9f66:	79 37 9e 
    9f69:	49 b8 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%r8
    9f70:	79 37 9e 
    9f73:	4c 8b 8d 70 fd ff ff 	mov    -0x290(%rbp),%r9
    9f7a:	4d 31 c8             	xor    %r9,%r8
    9f7d:	4c 0f af c0          	imul   %rax,%r8
    9f81:	4d 89 c2             	mov    %r8,%r10
    9f84:	49 c1 ea 1d          	shr    $0x1d,%r10
    9f88:	4d 31 d0             	xor    %r10,%r8
    9f8b:	4c 8b 95 48 fd ff ff 	mov    -0x2b8(%rbp),%r10
    9f92:	4d 31 d0             	xor    %r10,%r8
    9f95:	4c 0f af c0          	imul   %rax,%r8
    9f99:	4d 89 c3             	mov    %r8,%r11
    9f9c:	49 c1 eb 1d          	shr    $0x1d,%r11
    9fa0:	4d 31 d8             	xor    %r11,%r8
    9fa3:	4c 0f af c0          	imul   %rax,%r8
    9fa7:	4c 89 8d f8 fd ff ff 	mov    %r9,-0x208(%rbp)
    9fae:	4c 89 95 08 fe ff ff 	mov    %r10,-0x1f8(%rbp)
    9fb5:	4c 89 85 80 fd ff ff 	mov    %r8,-0x280(%rbp)
    9fbc:	b8 01 00 00 00       	mov    $0x1,%eax
    9fc1:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
    9fc8:	48 89 bd a8 fd ff ff 	mov    %rdi,-0x258(%rbp)
    9fcf:	48 89 95 18 fe ff ff 	mov    %rdx,-0x1e8(%rbp)
    9fd6:	48 8b 85 b8 fd ff ff 	mov    -0x248(%rbp),%rax
    9fdd:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
    9fe4:	b8 01 00 00 00       	mov    $0x1,%eax
    9fe9:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
    9ff0:	31 c0                	xor    %eax,%eax
    9ff2:	48 89 43 18          	mov    %rax,0x18(%rbx)
    9ff6:	48 8b 85 c8 fd ff ff 	mov    -0x238(%rbp),%rax
    9ffd:	b9 01 00 00 00       	mov    $0x1,%ecx
    a002:	48 89 c2             	mov    %rax,%rdx
    a005:	48 01 ca             	add    %rcx,%rdx
    a008:	48 89 95 c8 fd ff ff 	mov    %rdx,-0x238(%rbp)
    a00f:	e9 19 f5 ff ff       	jmp    0x952d
    a014:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    a018:	e8 23 60 ff ff       	call   0x40
    a01d:	48 85 c0             	test   %rax,%rax
    a020:	0f 84 ec f9 ff ff    	je     0x9a12
    a026:	e9 86 04 00 00       	jmp    0xa4b1
    a02b:	48 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%rax
    a032:	48 85 c0             	test   %rax,%rax
    a035:	0f 84 bc 03 00 00    	je     0xa3f7
    a03b:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    a042:	48 8b 48 68          	mov    0x68(%rax),%rcx
    a046:	48 85 c9             	test   %rcx,%rcx
    a049:	0f 84 1f 01 00 00    	je     0xa16e
    a04f:	48 8b 48 38          	mov    0x38(%rax),%rcx
    a053:	ba 40 00 00 00       	mov    $0x40,%edx
    a058:	48 29 ca             	sub    %rcx,%rdx
    a05b:	48 89 8d c0 fd ff ff 	mov    %rcx,-0x240(%rbp)
    a062:	48 8b b5 80 fd ff ff 	mov    -0x280(%rbp),%rsi
    a069:	48 89 d1             	mov    %rdx,%rcx
    a06c:	48 89 f7             	mov    %rsi,%rdi
    a06f:	48 d3 ef             	shr    %cl,%rdi
    a072:	31 c9                	xor    %ecx,%ecx
    a074:	48 8b 95 c0 fd ff ff 	mov    -0x240(%rbp),%rdx
    a07b:	48 39 ca             	cmp    %rcx,%rdx
    a07e:	ba 00 00 00 00       	mov    $0x0,%edx
    a083:	0f 94 c2             	sete   %dl
    a086:	48 85 d2             	test   %rdx,%rdx
    a089:	48 0f 44 cf          	cmove  %rdi,%rcx
    a08d:	48 8b 50 08          	mov    0x8(%rax),%rdx
    a091:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    a095:	4c 8b 37             	mov    (%rdi),%r14
    a098:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    a09f:	00 28 00 
    a0a2:	49 39 d6             	cmp    %rdx,%r14
    a0a5:	48 89 bd c0 fd ff ff 	mov    %rdi,-0x240(%rbp)
    a0ac:	0f 82 05 00 00 00    	jb     0xa0b7
    a0b2:	e9 38 00 00 00       	jmp    0xa0ef
    a0b7:	4c 8b 40 60          	mov    0x60(%rax),%r8
    a0bb:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    a0bf:	48 89 c6             	mov    %rax,%rsi
    a0c2:	48 89 ca             	mov    %rcx,%rdx
    a0c5:	4c 89 c1             	mov    %r8,%rcx
    a0c8:	e8 13 60 ff ff       	call   0xe0
    a0cd:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    a0d4:	31 d2                	xor    %edx,%edx
    a0d6:	48 89 51 60          	mov    %rdx,0x60(%rcx)
    a0da:	48 83 f8 00          	cmp    $0x0,%rax
    a0de:	0f 8f 08 00 00 00    	jg     0xa0ec
    a0e4:	49 89 c4             	mov    %rax,%r12
    a0e7:	e9 cc 03 00 00       	jmp    0xa4b8
    a0ec:	49 89 c6             	mov    %rax,%r14
    a0ef:	4c 89 f0             	mov    %r14,%rax
    a0f2:	48 83 c0 28          	add    $0x28,%rax
    a0f6:	48 b9 00 00 00 00 00 	movabs $0x28000000000000,%rcx
    a0fd:	00 28 00 
    a100:	48 29 c8             	sub    %rcx,%rax
    a103:	48 8b 8d c0 fd ff ff 	mov    -0x240(%rbp),%rcx
    a10a:	48 89 01             	mov    %rax,(%rcx)
    a10d:	48 b8 ff ff ff ff ff 	movabs $0xffffffffffff,%rax
    a114:	ff 00 00 
    a117:	49 21 c6             	and    %rax,%r14
    a11a:	31 c0                	xor    %eax,%eax
    a11c:	48 8b 8d f8 fd ff ff 	mov    -0x208(%rbp),%rcx
    a123:	49 89 0e             	mov    %rcx,(%r14)
    a126:	48 8b 95 08 fe ff ff 	mov    -0x1f8(%rbp),%rdx
    a12d:	49 89 56 08          	mov    %rdx,0x8(%r14)
    a131:	49 89 46 10          	mov    %rax,0x10(%r14)
    a135:	49 89 46 18          	mov    %rax,0x18(%r14)
    a139:	49 89 46 20          	mov    %rax,0x20(%r14)
    a13d:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    a144:	48 8b 70 60          	mov    0x60(%rax),%rsi
    a148:	bf 01 00 00 00       	mov    $0x1,%edi
    a14d:	48 01 fe             	add    %rdi,%rsi
    a150:	48 89 70 60          	mov    %rsi,0x60(%rax)
    a154:	be 01 00 00 00       	mov    $0x1,%esi
    a159:	48 89 b5 c0 fd ff ff 	mov    %rsi,-0x240(%rbp)
    a160:	31 f6                	xor    %esi,%esi
    a162:	48 89 b5 e0 fd ff ff 	mov    %rsi,-0x220(%rbp)
    a169:	e9 8c 01 00 00       	jmp    0xa2fa
    a16e:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    a175:	48 8b 48 10          	mov    0x10(%rax),%rcx
    a179:	48 8b 50 18          	mov    0x18(%rax),%rdx
    a17d:	48 89 d6             	mov    %rdx,%rsi
    a180:	f3 48 0f b8 f6       	popcnt %rsi,%rsi
    a185:	bf 40 00 00 00       	mov    $0x40,%edi
    a18a:	48 29 f7             	sub    %rsi,%rdi
    a18d:	48 89 8d f0 fd ff ff 	mov    %rcx,-0x210(%rbp)
    a194:	4c 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%r8
    a19b:	48 89 f9             	mov    %rdi,%rcx
    a19e:	49 d3 e8             	shr    %cl,%r8
    a1a1:	31 c9                	xor    %ecx,%ecx
    a1a3:	48 39 ce             	cmp    %rcx,%rsi
    a1a6:	be 00 00 00 00       	mov    $0x0,%esi
    a1ab:	40 0f 94 c6          	sete   %sil
    a1af:	48 85 f6             	test   %rsi,%rsi
    a1b2:	49 0f 44 c8          	cmove  %r8,%rcx
    a1b6:	be 01 00 00 00       	mov    $0x1,%esi
    a1bb:	48 89 cf             	mov    %rcx,%rdi
    a1be:	48 01 f7             	add    %rsi,%rdi
    a1c1:	48 21 d7             	and    %rdx,%rdi
    a1c4:	ba 28 00 00 00       	mov    $0x28,%edx
    a1c9:	48 0f af ca          	imul   %rdx,%rcx
    a1cd:	48 8b 95 f0 fd ff ff 	mov    -0x210(%rbp),%rdx
    a1d4:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
    a1d8:	49 8b 48 10          	mov    0x10(%r8),%rcx
    a1dc:	48 85 c9             	test   %rcx,%rcx
    a1df:	0f 84 a3 00 00 00    	je     0xa288
    a1e5:	49 8b 08             	mov    (%r8),%rcx
    a1e8:	4d 8b 48 08          	mov    0x8(%r8),%r9
    a1ec:	4c 8b 95 f8 fd ff ff 	mov    -0x208(%rbp),%r10
    a1f3:	49 39 ca             	cmp    %rcx,%r10
    a1f6:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    a1fc:	41 0f 94 c3          	sete   %r11b
    a200:	48 8b 8d 08 fe ff ff 	mov    -0x1f8(%rbp),%rcx
    a207:	4c 39 c9             	cmp    %r9,%rcx
    a20a:	41 bf 00 00 00 00    	mov    $0x0,%r15d
    a210:	41 0f 94 c7          	sete   %r15b
    a214:	4d 21 fb             	and    %r15,%r11
    a217:	4d 85 db             	test   %r11,%r11
    a21a:	0f 84 08 00 00 00    	je     0xa228
    a220:	4d 89 c6             	mov    %r8,%r14
    a223:	e9 49 00 00 00       	jmp    0xa271
    a228:	41 b8 28 00 00 00    	mov    $0x28,%r8d
    a22e:	49 0f af f8          	imul   %r8,%rdi
    a232:	4c 8d 04 3a          	lea    (%rdx,%rdi,1),%r8
    a236:	49 8b 50 10          	mov    0x10(%r8),%rdx
    a23a:	48 85 d2             	test   %rdx,%rdx
    a23d:	0f 84 45 00 00 00    	je     0xa288
    a243:	49 8b 10             	mov    (%r8),%rdx
    a246:	49 8b 78 08          	mov    0x8(%r8),%rdi
    a24a:	49 39 d2             	cmp    %rdx,%r10
    a24d:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    a253:	41 0f 94 c1          	sete   %r9b
    a257:	48 39 f9             	cmp    %rdi,%rcx
    a25a:	ba 00 00 00 00       	mov    $0x0,%edx
    a25f:	0f 94 c2             	sete   %dl
    a262:	49 21 d1             	and    %rdx,%r9
    a265:	4d 85 c9             	test   %r9,%r9
    a268:	0f 84 1a 00 00 00    	je     0xa288
    a26e:	4d 89 c6             	mov    %r8,%r14
    a271:	31 c0                	xor    %eax,%eax
    a273:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
    a27a:	31 c0                	xor    %eax,%eax
    a27c:	48 89 85 e0 fd ff ff 	mov    %rax,-0x220(%rbp)
    a283:	e9 72 00 00 00       	jmp    0xa2fa
    a288:	48 8d 85 60 fe ff ff 	lea    -0x1a0(%rbp),%rax
    a28f:	48 89 c1             	mov    %rax,%rcx
    a292:	48 8b 95 f8 fd ff ff 	mov    -0x208(%rbp),%rdx
    a299:	48 89 11             	mov    %rdx,(%rcx)
    a29c:	48 8b 95 08 fe ff ff 	mov    -0x1f8(%rbp),%rdx
    a2a3:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    a2a7:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    a2ab:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
    a2b2:	48 89 ca             	mov    %rcx,%rdx
    a2b5:	e8 36 5e ff ff       	call   0xf0
    a2ba:	48 83 f8 00          	cmp    $0x0,%rax
    a2be:	0f 8d 08 00 00 00    	jge    0xa2cc
    a2c4:	49 89 c4             	mov    %rax,%r12
    a2c7:	e9 ec 01 00 00       	jmp    0xa4b8
    a2cc:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
    a2d3:	48 8b 11             	mov    (%rcx),%rdx
    a2d6:	0f b6 72 0d          	movzbl 0xd(%rdx),%esi
    a2da:	48 83 e6 01          	and    $0x1,%rsi
    a2de:	48 89 71 68          	mov    %rsi,0x68(%rcx)
    a2e2:	49 89 c6             	mov    %rax,%r14
    a2e5:	b8 01 00 00 00       	mov    $0x1,%eax
    a2ea:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
    a2f1:	31 c0                	xor    %eax,%eax
    a2f3:	48 89 85 e0 fd ff ff 	mov    %rax,-0x220(%rbp)
    a2fa:	48 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%rax
    a301:	48 85 c0             	test   %rax,%rax
    a304:	0f 84 64 00 00 00    	je     0xa36e
    a30a:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
    a311:	49 89 46 10          	mov    %rax,0x10(%r14)
    a315:	31 c9                	xor    %ecx,%ecx
    a317:	48 39 c8             	cmp    %rcx,%rax
    a31a:	ba 00 00 00 00       	mov    $0x0,%edx
    a31f:	0f 95 c2             	setne  %dl
    a322:	41 0f b6 76 20       	movzbl 0x20(%r14),%esi
    a327:	48 09 d6             	or     %rdx,%rsi
    a32a:	48 0f be f6          	movsbq %sil,%rsi
    a32e:	41 88 76 20          	mov    %sil,0x20(%r14)
    a332:	48 8b 95 a8 fd ff ff 	mov    -0x258(%rbp),%rdx
    a339:	49 89 56 18          	mov    %rdx,0x18(%r14)
    a33d:	48 8b bd 18 fe ff ff 	mov    -0x1e8(%rbp),%rdi
    a344:	48 39 cf             	cmp    %rcx,%rdi
    a347:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    a34d:	41 0f 95 c0          	setne  %r8b
    a351:	40 0f b6 f6          	movzbl %sil,%esi
    a355:	41 b9 02 00 00 00    	mov    $0x2,%r9d
    a35b:	4d 85 c0             	test   %r8,%r8
    a35e:	4c 0f 44 c9          	cmove  %rcx,%r9
    a362:	4c 09 ce             	or     %r9,%rsi
    a365:	41 88 76 20          	mov    %sil,0x20(%r14)
    a369:	e9 89 00 00 00       	jmp    0xa3f7
    a36e:	49 8b 46 10          	mov    0x10(%r14),%rax
    a372:	48 8b 8d b0 fd ff ff 	mov    -0x250(%rbp),%rcx
    a379:	48 01 c8             	add    %rcx,%rax
    a37c:	49 89 46 10          	mov    %rax,0x10(%r14)
    a380:	31 c9                	xor    %ecx,%ecx
    a382:	48 39 c8             	cmp    %rcx,%rax
    a385:	b8 00 00 00 00       	mov    $0x0,%eax
    a38a:	0f 95 c0             	setne  %al
    a38d:	41 0f b6 56 20       	movzbl 0x20(%r14),%edx
    a392:	48 09 c2             	or     %rax,%rdx
    a395:	48 0f be d2          	movsbq %dl,%rdx
    a399:	41 88 56 20          	mov    %dl,0x20(%r14)
    a39d:	49 8b 46 18          	mov    0x18(%r14),%rax
    a3a1:	0f b6 d2             	movzbl %dl,%edx
    a3a4:	48 89 d6             	mov    %rdx,%rsi
    a3a7:	48 83 e6 02          	and    $0x2,%rsi
    a3ab:	48 39 ce             	cmp    %rcx,%rsi
    a3ae:	be 00 00 00 00       	mov    $0x0,%esi
    a3b3:	40 0f 95 c6          	setne  %sil
    a3b7:	31 ff                	xor    %edi,%edi
    a3b9:	48 85 f6             	test   %rsi,%rsi
    a3bc:	48 0f 44 c7          	cmove  %rdi,%rax
    a3c0:	48 8b bd 18 fe ff ff 	mov    -0x1e8(%rbp),%rdi
    a3c7:	48 01 fe             	add    %rdi,%rsi
    a3ca:	48 8b bd a8 fd ff ff 	mov    -0x258(%rbp),%rdi
    a3d1:	48 01 f8             	add    %rdi,%rax
    a3d4:	49 89 46 18          	mov    %rax,0x18(%r14)
    a3d8:	48 39 ce             	cmp    %rcx,%rsi
    a3db:	be 00 00 00 00       	mov    $0x0,%esi
    a3e0:	40 0f 95 c6          	setne  %sil
    a3e4:	b8 02 00 00 00       	mov    $0x2,%eax
    a3e9:	48 85 f6             	test   %rsi,%rsi
    a3ec:	48 0f 44 c1          	cmove  %rcx,%rax
    a3f0:	48 09 c2             	or     %rax,%rdx
    a3f3:	41 88 56 20          	mov    %dl,0x20(%r14)
    a3f7:	48 8b 85 a0 fd ff ff 	mov    -0x260(%rbp),%rax
    a3fe:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
    a405:	48 b8 01 00 00 00 00 	movabs $0x4000000000001,%rax
    a40c:	00 04 00 
    a40f:	48 8b 8d e8 fd ff ff 	mov    -0x218(%rbp),%rcx
    a416:	48 01 c1             	add    %rax,%rcx
    a419:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
    a41d:	48 89 48 50          	mov    %rcx,0x50(%rax)
    a421:	e9 63 cf ff ff       	jmp    0x7389
    a426:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    a42a:	e8 11 5c ff ff       	call   0x40
    a42f:	48 85 c0             	test   %rax,%rax
    a432:	0f 84 6e cf ff ff    	je     0x73a6
    a438:	e9 74 00 00 00       	jmp    0xa4b1
    a43d:	49 c1 e5 08          	shl    $0x8,%r13
    a441:	49 83 cd 03          	or     $0x3,%r13
    a445:	49 f7 dd             	neg    %r13
    a448:	4d 89 ec             	mov    %r13,%r12
    a44b:	e9 68 00 00 00       	jmp    0xa4b8
    a450:	31 c0                	xor    %eax,%eax
    a452:	48 85 c0             	test   %rax,%rax
    a455:	0f 84 08 00 00 00    	je     0xa463
    a45b:	49 89 c4             	mov    %rax,%r12
    a45e:	e9 55 00 00 00       	jmp    0xa4b8
    a463:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
    a46a:	48 8b 08             	mov    (%rax),%rcx
    a46d:	48 8b 50 60          	mov    0x60(%rax),%rdx
    a471:	48 8b 59 58          	mov    0x58(%rcx),%rbx
    a475:	48 01 d3             	add    %rdx,%rbx
    a478:	48 89 59 58          	mov    %rbx,0x58(%rcx)
    a47c:	31 c9                	xor    %ecx,%ecx
    a47e:	48 89 48 60          	mov    %rcx,0x60(%rax)
    a482:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    a486:	48 89 c6             	mov    %rax,%rsi
    a489:	e8 72 5c ff ff       	call   0x100
    a48e:	48 83 f8 00          	cmp    $0x0,%rax
    a492:	0f 8d 08 00 00 00    	jge    0xa4a0
    a498:	49 89 c4             	mov    %rax,%r12
    a49b:	e9 18 00 00 00       	jmp    0xa4b8
    a4a0:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
    a4a4:	e8 c7 5b ff ff       	call   0x70
    a4a9:	49 89 c4             	mov    %rax,%r12
    a4ac:	e9 07 00 00 00       	jmp    0xa4b8
    a4b1:	49 c7 c4 fe ff ff ff 	mov    $0xfffffffffffffffe,%r12
    a4b8:	4c 89 e0             	mov    %r12,%rax
    a4bb:	48 81 c4 e8 02 00 00 	add    $0x2e8,%rsp
    a4c2:	41 5f                	pop    %r15
    a4c4:	41 5e                	pop    %r14
    a4c6:	41 5d                	pop    %r13
    a4c8:	41 5c                	pop    %r12
    a4ca:	5b                   	pop    %rbx
    a4cb:	5d                   	pop    %rbp
    a4cc:	c3                   	ret
    a4cd:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a4d4:	00 00 
    a4d6:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a4dd:	00 00 
    a4df:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a4e6:	00 00 
    a4e8:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a4ef:	00 00 
    a4f1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a4f8:	00 00 
    a4fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a500:	55                   	push   %rbp
    a501:	48 89 e5             	mov    %rsp,%rbp
    a504:	53                   	push   %rbx
    a505:	41 54                	push   %r12
    a507:	41 55                	push   %r13
    a509:	41 56                	push   %r14
    a50b:	41 57                	push   %r15
    a50d:	48 81 ec d8 01 00 00 	sub    $0x1d8,%rsp
    a514:	48 89 fb             	mov    %rdi,%rbx
    a517:	31 c0                	xor    %eax,%eax
    a519:	48 8b 4b 58          	mov    0x58(%rbx),%rcx
    a51d:	4c 8b a3 10 02 00 00 	mov    0x210(%rbx),%r12
    a524:	48 8b 53 50          	mov    0x50(%rbx),%rdx
    a528:	48 85 d2             	test   %rdx,%rdx
    a52b:	48 89 4d d0          	mov    %rcx,-0x30(%rbp)
    a52f:	0f 85 d3 01 00 00    	jne    0xa708
    a535:	48 ba 01 00 00 00 00 	movabs $0x4000000000001,%rdx
    a53c:	00 04 00 
    a53f:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    a543:	31 d2                	xor    %edx,%edx
    a545:	49 89 54 24 30       	mov    %rdx,0x30(%r12)
    a54a:	31 d2                	xor    %edx,%edx
    a54c:	49 89 54 24 38       	mov    %rdx,0x38(%r12)
    a551:	31 d2                	xor    %edx,%edx
    a553:	49 89 54 24 40       	mov    %rdx,0x40(%r12)
    a558:	31 d2                	xor    %edx,%edx
    a55a:	49 89 54 24 48       	mov    %rdx,0x48(%r12)
    a55f:	31 d2                	xor    %edx,%edx
    a561:	49 89 54 24 50       	mov    %rdx,0x50(%r12)
    a566:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    a56a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    a56e:	0f 85 84 00 00 00    	jne    0xa5f8
    a574:	48 8d 95 10 ff ff ff 	lea    -0xf0(%rbp),%rdx
    a57b:	48 89 d6             	mov    %rdx,%rsi
    a57e:	bf 02 02 01 01       	mov    $0x1010202,%edi
    a583:	48 89 3e             	mov    %rdi,(%rsi)
    a586:	bf 00 00 00 01       	mov    $0x1000000,%edi
    a58b:	48 89 7e 08          	mov    %rdi,0x8(%rsi)
    a58f:	bf 00 00 10 18       	mov    $0x18100000,%edi
    a594:	48 89 7e 10          	mov    %rdi,0x10(%rsi)
    a598:	48 bf 00 00 28 01 10 	movabs $0x201001280000,%rdi
    a59f:	20 00 00 
    a5a2:	48 89 7e 18          	mov    %rdi,0x18(%rsi)
    a5a6:	31 ff                	xor    %edi,%edi
    a5a8:	48 89 7e 20          	mov    %rdi,0x20(%rsi)
    a5ac:	48 bf 00 00 00 00 02 	movabs $0x200000000,%rdi
    a5b3:	00 00 00 
    a5b6:	48 89 7e 28          	mov    %rdi,0x28(%rsi)
    a5ba:	bf 01 00 00 00       	mov    $0x1,%edi
    a5bf:	48 89 7e 30          	mov    %rdi,0x30(%rsi)
    a5c3:	bf 00 00 01 00       	mov    $0x10000,%edi
    a5c8:	48 89 7e 38          	mov    %rdi,0x38(%rsi)
    a5cc:	48 8b 79 18          	mov    0x18(%rcx),%rdi
    a5d0:	48 89 bd 18 fe ff ff 	mov    %rdi,-0x1e8(%rbp)
    a5d7:	48 89 df             	mov    %rbx,%rdi
    a5da:	48 8b 95 18 fe ff ff 	mov    -0x1e8(%rbp),%rdx
    a5e1:	e8 4a 5b ff ff       	call   0x130
    a5e6:	48 83 f8 00          	cmp    $0x0,%rax
    a5ea:	0f 8d 08 00 00 00    	jge    0xa5f8
    a5f0:	49 89 c5             	mov    %rax,%r13
    a5f3:	e9 8e 02 00 00       	jmp    0xa886
    a5f8:	48 8d 85 50 fe ff ff 	lea    -0x1b0(%rbp),%rax
    a5ff:	48 89 c1             	mov    %rax,%rcx
    a602:	ba 02 02 01 01       	mov    $0x1010202,%edx
    a607:	48 89 11             	mov    %rdx,(%rcx)
    a60a:	ba 00 00 00 01       	mov    $0x1000000,%edx
    a60f:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    a613:	ba 00 00 10 18       	mov    $0x18100000,%edx
    a618:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    a61c:	48 ba 00 00 28 01 10 	movabs $0x201001280000,%rdx
    a623:	20 00 00 
    a626:	48 89 51 18          	mov    %rdx,0x18(%rcx)
    a62a:	31 d2                	xor    %edx,%edx
    a62c:	48 89 51 20          	mov    %rdx,0x20(%rcx)
    a630:	48 ba 00 00 00 00 02 	movabs $0x200000000,%rdx
    a637:	00 00 00 
    a63a:	48 89 51 28          	mov    %rdx,0x28(%rcx)
    a63e:	ba 01 00 00 00       	mov    $0x1,%edx
    a643:	48 89 51 30          	mov    %rdx,0x30(%rcx)
    a647:	ba 00 00 01 00       	mov    $0x10000,%edx
    a64c:	48 89 51 38          	mov    %rdx,0x38(%rcx)
    a650:	31 d2                	xor    %edx,%edx
    a652:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    a656:	48 89 df             	mov    %rbx,%rdi
    a659:	48 89 ce             	mov    %rcx,%rsi
    a65c:	48 89 8d 18 fe ff ff 	mov    %rcx,-0x1e8(%rbp)
    a663:	e8 d8 5a ff ff       	call   0x140
    a668:	48 b9 01 00 00 00 00 	movabs $0x4000000000001,%rcx
    a66f:	00 04 00 
    a672:	48 89 4b 50          	mov    %rcx,0x50(%rbx)
    a676:	48 85 c0             	test   %rax,%rax
    a679:	0f 85 0c 00 00 00    	jne    0xa68b
    a67f:	49 c7 c6 fa fd ff ff 	mov    $0xfffffffffffffdfa,%r14
    a686:	e9 6b 00 00 00       	jmp    0xa6f6
    a68b:	48 8b 08             	mov    (%rax),%rcx
    a68e:	48 8b 50 10          	mov    0x10(%rax),%rdx
    a692:	48 89 50 10          	mov    %rdx,0x10(%rax)
    a696:	48 89 df             	mov    %rbx,%rdi
    a699:	48 89 c6             	mov    %rax,%rsi
    a69c:	48 89 95 10 fe ff ff 	mov    %rdx,-0x1f0(%rbp)
    a6a3:	48 8b 95 18 fe ff ff 	mov    -0x1e8(%rbp),%rdx
    a6aa:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
    a6b1:	48 89 8d 08 fe ff ff 	mov    %rcx,-0x1f8(%rbp)
    a6b8:	e8 93 5a ff ff       	call   0x150
    a6bd:	48 83 f8 00          	cmp    $0x0,%rax
    a6c1:	0f 8d 08 00 00 00    	jge    0xa6cf
    a6c7:	49 89 c6             	mov    %rax,%r14
    a6ca:	e9 27 00 00 00       	jmp    0xa6f6
    a6cf:	48 8b 85 18 fe ff ff 	mov    -0x1e8(%rbp),%rax
    a6d6:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    a6db:	48 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%rax
    a6e2:	49 89 44 24 38       	mov    %rax,0x38(%r12)
    a6e7:	48 8b 85 10 fe ff ff 	mov    -0x1f0(%rbp),%rax
    a6ee:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    a6f3:	45 31 f6             	xor    %r14d,%r14d
    a6f6:	49 83 fe 00          	cmp    $0x0,%r14
    a6fa:	0f 8d 08 00 00 00    	jge    0xa708
    a700:	4d 89 f5             	mov    %r14,%r13
    a703:	e9 7e 01 00 00       	jmp    0xa886
    a708:	48 8b 43 18          	mov    0x18(%rbx),%rax
    a70c:	48 85 c0             	test   %rax,%rax
    a70f:	0f 84 0c 00 00 00    	je     0xa721
    a715:	0f b6 08             	movzbl (%rax),%ecx
    a718:	48 85 c9             	test   %rcx,%rcx
    a71b:	0f 85 eb 00 00 00    	jne    0xa80c
    a721:	49 8b 44 24 40       	mov    0x40(%r12),%rax
    a726:	49 8b 74 24 30       	mov    0x30(%r12),%rsi
    a72b:	48 39 c6             	cmp    %rax,%rsi
    a72e:	0f 8d f5 00 00 00    	jge    0xa829
    a734:	48 89 f1             	mov    %rsi,%rcx
    a737:	48 81 c1 00 10 00 00 	add    $0x1000,%rcx
    a73e:	48 39 c1             	cmp    %rax,%rcx
    a741:	ba 00 00 00 00       	mov    $0x0,%edx
    a746:	0f 9f c2             	setg   %dl
    a749:	48 89 c7             	mov    %rax,%rdi
    a74c:	48 85 d2             	test   %rdx,%rdx
    a74f:	48 0f 44 f9          	cmove  %rcx,%rdi
    a753:	45 31 c0             	xor    %r8d,%r8d
    a756:	48 39 fe             	cmp    %rdi,%rsi
    a759:	0f 8d a3 00 00 00    	jge    0xa802
    a75f:	48 89 f0             	mov    %rsi,%rax
    a762:	48 83 c0 01          	add    $0x1,%rax
    a766:	49 8b 4c 24 38       	mov    0x38(%r12),%rcx
    a76b:	48 8d 14 f1          	lea    (%rcx,%rsi,8),%rdx
    a76f:	48 8b 0a             	mov    (%rdx),%rcx
    a772:	48 8d 95 20 fe ff ff 	lea    -0x1e0(%rbp),%rdx
    a779:	49 89 d1             	mov    %rdx,%r9
    a77c:	49 89 49 20          	mov    %rcx,0x20(%r9)
    a780:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    a784:	4d 89 11             	mov    %r10,(%r9)
    a787:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    a78d:	4d 89 51 08          	mov    %r10,0x8(%r9)
    a791:	4c 8b 51 18          	mov    0x18(%rcx),%r10
    a795:	44 0f b6 59 20       	movzbl 0x20(%rcx),%r11d
    a79a:	49 83 e3 02          	and    $0x2,%r11
    a79e:	45 31 f6             	xor    %r14d,%r14d
    a7a1:	4d 39 f3             	cmp    %r14,%r11
    a7a4:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    a7aa:	41 0f 95 c3          	setne  %r11b
    a7ae:	45 31 ff             	xor    %r15d,%r15d
    a7b1:	4d 85 db             	test   %r11,%r11
    a7b4:	4d 0f 44 d7          	cmove  %r15,%r10
    a7b8:	4d 39 f3             	cmp    %r14,%r11
    a7bb:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    a7c1:	41 0f 94 c3          	sete   %r11b
    a7c5:	4d 89 51 10          	mov    %r10,0x10(%r9)
    a7c9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    a7cf:	4d 31 d3             	xor    %r10,%r11
    a7d2:	4d 89 59 18          	mov    %r11,0x18(%r9)
    a7d6:	4d 8b 4c 24 50       	mov    0x50(%r12),%r9
    a7db:	4d 8b 54 24 38       	mov    0x38(%r12),%r10
    a7e0:	4f 8d 1c ca          	lea    (%r10,%r9,8),%r11
    a7e4:	49 89 0b             	mov    %rcx,(%r11)
    a7e7:	49 83 c1 01          	add    $0x1,%r9
    a7eb:	4d 89 4c 24 50       	mov    %r9,0x50(%r12)
    a7f0:	4c 89 c1             	mov    %r8,%rcx
    a7f3:	48 83 c1 01          	add    $0x1,%rcx
    a7f7:	48 89 c6             	mov    %rax,%rsi
    a7fa:	49 89 c8             	mov    %rcx,%r8
    a7fd:	e9 54 ff ff ff       	jmp    0xa756
    a802:	49 89 7c 24 30       	mov    %rdi,0x30(%r12)
    a807:	e9 fc fe ff ff       	jmp    0xa708
    a80c:	48 89 df             	mov    %rbx,%rdi
    a80f:	e8 2c 58 ff ff       	call   0x40
    a814:	48 85 c0             	test   %rax,%rax
    a817:	0f 84 04 ff ff ff    	je     0xa721
    a81d:	49 c7 c5 fe ff ff ff 	mov    $0xfffffffffffffffe,%r13
    a824:	e9 5d 00 00 00       	jmp    0xa886
    a829:	31 c0                	xor    %eax,%eax
    a82b:	48 85 c0             	test   %rax,%rax
    a82e:	0f 84 08 00 00 00    	je     0xa83c
    a834:	49 89 c5             	mov    %rax,%r13
    a837:	e9 4a 00 00 00       	jmp    0xa886
    a83c:	49 8b 44 24 48       	mov    0x48(%r12),%rax
    a841:	49 8b 4c 24 50       	mov    0x50(%r12),%rcx
    a846:	48 85 c0             	test   %rax,%rax
    a849:	0f 84 2c 00 00 00    	je     0xa87b
    a84f:	48 89 48 10          	mov    %rcx,0x10(%rax)
    a853:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    a857:	48 83 fa 40          	cmp    $0x40,%rdx
    a85b:	0f 83 1a 00 00 00    	jae    0xa87b
    a861:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
    a865:	48 8b 7e 18          	mov    0x18(%rsi),%rdi
    a869:	48 6b f2 10          	imul   $0x10,%rdx,%rsi
    a86d:	48 8d 34 37          	lea    (%rdi,%rsi,1),%rsi
    a871:	48 8b 10             	mov    (%rax),%rdx
    a874:	48 89 16             	mov    %rdx,(%rsi)
    a877:	48 89 4e 08          	mov    %rcx,0x8(%rsi)
    a87b:	48 89 df             	mov    %rbx,%rdi
    a87e:	e8 ed 57 ff ff       	call   0x70
    a883:	49 89 c5             	mov    %rax,%r13
    a886:	4c 89 e8             	mov    %r13,%rax
    a889:	48 81 c4 d8 01 00 00 	add    $0x1d8,%rsp
    a890:	41 5f                	pop    %r15
    a892:	41 5e                	pop    %r14
    a894:	41 5d                	pop    %r13
    a896:	41 5c                	pop    %r12
    a898:	5b                   	pop    %rbx
    a899:	5d                   	pop    %rbp
    a89a:	c3                   	ret
    a89b:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a8a2:	00 00 
    a8a4:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a8ab:	00 00 
    a8ad:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a8b4:	00 00 
    a8b6:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a8bd:	00 00 
    a8bf:	90                   	nop
    a8c0:	55                   	push   %rbp
    a8c1:	48 89 e5             	mov    %rsp,%rbp
    a8c4:	53                   	push   %rbx
    a8c5:	41 54                	push   %r12
    a8c7:	41 55                	push   %r13
    a8c9:	41 56                	push   %r14
    a8cb:	41 57                	push   %r15
    a8cd:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    a8d4:	48 89 fb             	mov    %rdi,%rbx
    a8d7:	31 c0                	xor    %eax,%eax
    a8d9:	48 8b 4b 58          	mov    0x58(%rbx),%rcx
    a8dd:	4c 8b a3 10 02 00 00 	mov    0x210(%rbx),%r12
    a8e4:	48 8b 53 50          	mov    0x50(%rbx),%rdx
    a8e8:	48 85 d2             	test   %rdx,%rdx
    a8eb:	0f 85 f4 00 00 00    	jne    0xa9e5
    a8f1:	48 ba 01 00 00 00 00 	movabs $0x4000000000001,%rdx
    a8f8:	00 04 00 
    a8fb:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    a8ff:	31 d2                	xor    %edx,%edx
    a901:	49 89 54 24 58       	mov    %rdx,0x58(%r12)
    a906:	31 d2                	xor    %edx,%edx
    a908:	49 89 54 24 60       	mov    %rdx,0x60(%r12)
    a90d:	31 d2                	xor    %edx,%edx
    a90f:	49 89 54 24 68       	mov    %rdx,0x68(%r12)
    a914:	31 d2                	xor    %edx,%edx
    a916:	49 89 54 24 70       	mov    %rdx,0x70(%r12)
    a91b:	48 8d 95 10 ff ff ff 	lea    -0xf0(%rbp),%rdx
    a922:	48 89 d6             	mov    %rdx,%rsi
    a925:	bf 02 02 01 01       	mov    $0x1010202,%edi
    a92a:	48 89 3e             	mov    %rdi,(%rsi)
    a92d:	bf 00 00 00 01       	mov    $0x1000000,%edi
    a932:	48 89 7e 08          	mov    %rdi,0x8(%rsi)
    a936:	bf 00 00 10 18       	mov    $0x18100000,%edi
    a93b:	48 89 7e 10          	mov    %rdi,0x10(%rsi)
    a93f:	48 bf 00 00 28 01 10 	movabs $0x201001280000,%rdi
    a946:	20 00 00 
    a949:	48 89 7e 18          	mov    %rdi,0x18(%rsi)
    a94d:	31 ff                	xor    %edi,%edi
    a94f:	48 89 7e 20          	mov    %rdi,0x20(%rsi)
    a953:	48 bf 00 00 00 00 02 	movabs $0x200000000,%rdi
    a95a:	00 00 00 
    a95d:	48 89 7e 28          	mov    %rdi,0x28(%rsi)
    a961:	bf 01 00 00 00       	mov    $0x1,%edi
    a966:	48 89 7e 30          	mov    %rdi,0x30(%rsi)
    a96a:	bf 00 00 01 00       	mov    $0x10000,%edi
    a96f:	48 89 7e 38          	mov    %rdi,0x38(%rsi)
    a973:	48 8b 79 18          	mov    0x18(%rcx),%rdi
    a977:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    a97e:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
    a982:	48 89 df             	mov    %rbx,%rdi
    a985:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
    a989:	e8 d2 57 ff ff       	call   0x160
    a98e:	49 89 c5             	mov    %rax,%r13
    a991:	49 83 fd 00          	cmp    $0x0,%r13
    a995:	0f 8d 08 00 00 00    	jge    0xa9a3
    a99b:	4d 89 ee             	mov    %r13,%r14
    a99e:	e9 33 00 00 00       	jmp    0xa9d6
    a9a3:	4d 85 ed             	test   %r13,%r13
    a9a6:	0f 85 0c 00 00 00    	jne    0xa9b8
    a9ac:	49 c7 c6 fa fd ff ff 	mov    $0xfffffffffffffdfa,%r14
    a9b3:	e9 1e 00 00 00       	jmp    0xa9d6
    a9b8:	49 8b 45 00          	mov    0x0(%r13),%rax
    a9bc:	49 8b 4d 10          	mov    0x10(%r13),%rcx
    a9c0:	49 89 4d 10          	mov    %rcx,0x10(%r13)
    a9c4:	4d 89 6c 24 70       	mov    %r13,0x70(%r12)
    a9c9:	49 89 44 24 60       	mov    %rax,0x60(%r12)
    a9ce:	49 89 4c 24 68       	mov    %rcx,0x68(%r12)
    a9d3:	45 31 f6             	xor    %r14d,%r14d
    a9d6:	49 83 fe 00          	cmp    $0x0,%r14
    a9da:	0f 8d 05 00 00 00    	jge    0xa9e5
    a9e0:	e9 75 02 00 00       	jmp    0xac5a
    a9e5:	48 8b 43 18          	mov    0x18(%rbx),%rax
    a9e9:	48 85 c0             	test   %rax,%rax
    a9ec:	0f 84 0c 00 00 00    	je     0xa9fe
    a9f2:	0f b6 08             	movzbl (%rax),%ecx
    a9f5:	48 85 c9             	test   %rcx,%rcx
    a9f8:	0f 85 ec 01 00 00    	jne    0xabea
    a9fe:	49 8b 44 24 68       	mov    0x68(%r12),%rax
    aa03:	49 8b 74 24 58       	mov    0x58(%r12),%rsi
    aa08:	48 39 c6             	cmp    %rax,%rsi
    aa0b:	0f 8d f6 01 00 00    	jge    0xac07
    aa11:	48 89 f1             	mov    %rsi,%rcx
    aa14:	48 81 c1 00 10 00 00 	add    $0x1000,%rcx
    aa1b:	48 39 c1             	cmp    %rax,%rcx
    aa1e:	ba 00 00 00 00       	mov    $0x0,%edx
    aa23:	0f 9f c2             	setg   %dl
    aa26:	49 89 c5             	mov    %rax,%r13
    aa29:	48 85 d2             	test   %rdx,%rdx
    aa2c:	4c 0f 44 e9          	cmove  %rcx,%r13
    aa30:	49 89 f7             	mov    %rsi,%r15
    aa33:	31 c0                	xor    %eax,%eax
    aa35:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
    aa39:	4d 39 ef             	cmp    %r13,%r15
    aa3c:	0f 8d 9e 01 00 00    	jge    0xabe0
    aa42:	4c 89 f8             	mov    %r15,%rax
    aa45:	48 83 c0 01          	add    $0x1,%rax
    aa49:	49 8b 4c 24 60       	mov    0x60(%r12),%rcx
    aa4e:	4a 8d 14 f9          	lea    (%rcx,%r15,8),%rdx
    aa52:	48 8b 0a             	mov    (%rdx),%rcx
    aa55:	48 8b 51 08          	mov    0x8(%rcx),%rdx
    aa59:	48 83 e2 01          	and    $0x1,%rdx
    aa5d:	31 f6                	xor    %esi,%esi
    aa5f:	48 39 f2             	cmp    %rsi,%rdx
    aa62:	ba 00 00 00 00       	mov    $0x0,%edx
    aa67:	0f 95 c2             	setne  %dl
    aa6a:	48 8b 39             	mov    (%rcx),%rdi
    aa6d:	4c 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%r8
    aa74:	4d 89 c1             	mov    %r8,%r9
    aa77:	49 89 49 20          	mov    %rcx,0x20(%r9)
    aa7b:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    aa7f:	4d 89 11             	mov    %r10,(%r9)
    aa82:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    aa88:	4d 89 59 08          	mov    %r11,0x8(%r9)
    aa8c:	4c 8b 41 18          	mov    0x18(%rcx),%r8
    aa90:	0f b6 71 20          	movzbl 0x20(%rcx),%esi
    aa94:	48 83 e6 02          	and    $0x2,%rsi
    aa98:	31 c9                	xor    %ecx,%ecx
    aa9a:	48 39 ce             	cmp    %rcx,%rsi
    aa9d:	be 00 00 00 00       	mov    $0x0,%esi
    aaa2:	40 0f 95 c6          	setne  %sil
    aaa6:	31 c9                	xor    %ecx,%ecx
    aaa8:	48 85 f6             	test   %rsi,%rsi
    aaab:	4c 0f 44 c1          	cmove  %rcx,%r8
    aaaf:	31 c9                	xor    %ecx,%ecx
    aab1:	48 39 ce             	cmp    %rcx,%rsi
    aab4:	be 00 00 00 00       	mov    $0x0,%esi
    aab9:	40 0f 94 c6          	sete   %sil
    aabd:	4d 89 41 10          	mov    %r8,0x10(%r9)
    aac1:	b9 01 00 00 00       	mov    $0x1,%ecx
    aac6:	48 31 ce             	xor    %rcx,%rsi
    aac9:	49 89 71 18          	mov    %rsi,0x18(%r9)
    aacd:	b9 01 00 00 00       	mov    $0x1,%ecx
    aad2:	49 83 fb 00          	cmp    $0x0,%r11
    aad6:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    aadc:	41 0f 95 c3          	setne  %r11b
    aae0:	49 31 cb             	xor    %rcx,%r11
    aae3:	48 83 fe 00          	cmp    $0x0,%rsi
    aae7:	be 00 00 00 00       	mov    $0x0,%esi
    aaec:	40 0f 95 c6          	setne  %sil
    aaf0:	48 31 ce             	xor    %rcx,%rsi
    aaf3:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    aaf7:	4c 8b 49 10          	mov    0x10(%rcx),%r9
    aafb:	48 89 95 d8 fe ff ff 	mov    %rdx,-0x128(%rbp)
    ab02:	48 8b 11             	mov    (%rcx),%rdx
    ab05:	48 89 95 d0 fe ff ff 	mov    %rdx,-0x130(%rbp)
    ab0c:	48 8b 51 08          	mov    0x8(%rcx),%rdx
    ab10:	48 89 95 c8 fe ff ff 	mov    %rdx,-0x138(%rbp)
    ab17:	ba 03 00 00 00       	mov    $0x3,%edx
    ab1c:	48 89 b5 c0 fe ff ff 	mov    %rsi,-0x140(%rbp)
    ab23:	4c 89 ce             	mov    %r9,%rsi
    ab26:	48 0f af f2          	imul   %rdx,%rsi
    ab2a:	48 8b 95 d0 fe ff ff 	mov    -0x130(%rbp),%rdx
    ab31:	48 89 bd b8 fe ff ff 	mov    %rdi,-0x148(%rbp)
    ab38:	48 8d 3c f2          	lea    (%rdx,%rsi,8),%rdi
    ab3c:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
    ab43:	4c 89 85 d0 fe ff ff 	mov    %r8,-0x130(%rbp)
    ab4a:	4c 8d 04 32          	lea    (%rdx,%rsi,1),%r8
    ab4e:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
    ab55:	48 89 17             	mov    %rdx,(%rdi)
    ab58:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
    ab5f:	41 88 10             	mov    %dl,(%r8)
    ab62:	4c 89 57 08          	mov    %r10,0x8(%rdi)
    ab66:	45 88 58 01          	mov    %r11b,0x1(%r8)
    ab6a:	48 8b 95 d0 fe ff ff 	mov    -0x130(%rbp),%rdx
    ab71:	48 89 57 10          	mov    %rdx,0x10(%rdi)
    ab75:	48 8b 95 c0 fe ff ff 	mov    -0x140(%rbp),%rdx
    ab7c:	41 88 50 02          	mov    %dl,0x2(%r8)
    ab80:	49 83 c1 01          	add    $0x1,%r9
    ab84:	4c 89 49 10          	mov    %r9,0x10(%rcx)
    ab88:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
    ab8c:	48 89 d6             	mov    %rdx,%rsi
    ab8f:	48 83 c6 01          	add    $0x1,%rsi
    ab93:	48 8b 79 18          	mov    0x18(%rcx),%rdi
    ab97:	49 39 f9             	cmp    %rdi,%r9
    ab9a:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
    aba1:	48 89 b5 d0 fe ff ff 	mov    %rsi,-0x130(%rbp)
    aba8:	0f 8c 18 00 00 00    	jl     0xabc6
    abae:	48 89 df             	mov    %rbx,%rdi
    abb1:	e8 ba 55 ff ff       	call   0x170
    abb6:	48 85 c0             	test   %rax,%rax
    abb9:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
    abc0:	0f 85 64 00 00 00    	jne    0xac2a
    abc6:	4c 89 f8             	mov    %r15,%rax
    abc9:	48 83 c0 01          	add    $0x1,%rax
    abcd:	49 89 c7             	mov    %rax,%r15
    abd0:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
    abd7:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
    abdb:	e9 59 fe ff ff       	jmp    0xaa39
    abe0:	4d 89 6c 24 58       	mov    %r13,0x58(%r12)
    abe5:	e9 fb fd ff ff       	jmp    0xa9e5
    abea:	48 89 df             	mov    %rbx,%rdi
    abed:	e8 4e 54 ff ff       	call   0x40
    abf2:	48 85 c0             	test   %rax,%rax
    abf5:	0f 84 03 fe ff ff    	je     0xa9fe
    abfb:	49 c7 c6 fe ff ff ff 	mov    $0xfffffffffffffffe,%r14
    ac02:	e9 53 00 00 00       	jmp    0xac5a
    ac07:	31 c0                	xor    %eax,%eax
    ac09:	48 85 c0             	test   %rax,%rax
    ac0c:	0f 84 08 00 00 00    	je     0xac1a
    ac12:	49 89 c6             	mov    %rax,%r14
    ac15:	e9 40 00 00 00       	jmp    0xac5a
    ac1a:	48 89 df             	mov    %rbx,%rdi
    ac1d:	e8 4e 54 ff ff       	call   0x70
    ac22:	49 89 c6             	mov    %rax,%r14
    ac25:	e9 30 00 00 00       	jmp    0xac5a
    ac2a:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
    ac31:	49 89 44 24 58       	mov    %rax,0x58(%r12)
    ac36:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    ac3d:	48 83 f8 00          	cmp    $0x0,%rax
    ac41:	0f 8d 08 00 00 00    	jge    0xac4f
    ac47:	49 89 c6             	mov    %rax,%r14
    ac4a:	e9 0b 00 00 00       	jmp    0xac5a
    ac4f:	48 89 df             	mov    %rbx,%rdi
    ac52:	e8 29 55 ff ff       	call   0x180
    ac57:	49 89 c6             	mov    %rax,%r14
    ac5a:	4c 89 f0             	mov    %r14,%rax
    ac5d:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    ac64:	41 5f                	pop    %r15
    ac66:	41 5e                	pop    %r14
    ac68:	41 5d                	pop    %r13
    ac6a:	41 5c                	pop    %r12
    ac6c:	5b                   	pop    %rbx
    ac6d:	5d                   	pop    %rbp
    ac6e:	c3                   	ret
	...
    afff:	00 14 00             	add    %dl,(%rax,%rax,1)
    b002:	00 00                	add    %al,(%rax)
    b004:	00 00                	add    %al,(%rax)
    b006:	00 00                	add    %al,(%rax)
    b008:	01 7a 52             	add    %edi,0x52(%rdx)
    b00b:	00 01                	add    %al,(%rcx)
    b00d:	78 10                	js     0xb01f
    b00f:	01 1b                	add    %ebx,(%rbx)
    b011:	0c 07                	or     $0x7,%al
    b013:	08 90 01 00 00 28    	or     %dl,0x28000001(%rax)
    b019:	00 00                	add    %al,(%rax)
    b01b:	00 1c 00             	add    %bl,(%rax,%rax,1)
    b01e:	00 00                	add    %al,(%rax)
    b020:	20 52 ff             	and    %dl,-0x1(%rdx)
    b023:	ff 85 0d 00 00 00    	incl   0xd(%rbp)
    b029:	0a 41 0e             	or     0xe(%rcx),%al
    b02c:	10 86 02 43 0d 06    	adc    %al,0x60d4302(%rsi)
    b032:	50                   	push   %rax
    b033:	83 03 8c             	addl   $0xffffff8c,(%rbx)
    b036:	04 8d                	add    $0x8d,%al
    b038:	05 8e 06 8f 07       	add    $0x78f068e,%eax
    b03d:	03 70 0d             	add    0xd(%rax),%esi
    b040:	0b 00                	or     (%rax),%eax
    b042:	00 00                	add    %al,(%rax)
    b044:	28 00                	sub    %al,(%rax)
    b046:	00 00                	add    %al,(%rax)
    b048:	48 00 00             	rex.W add %al,(%rax)
    b04b:	00 b4 5f ff ff 80 61 	add    %dh,0x6180ffff(%rdi,%rbx,2)
    b052:	00 00                	add    %al,(%rax)
    b054:	00 0a                	add    %cl,(%rdx)
    b056:	41 0e                	rex.B (bad)
    b058:	10 86 02 43 0d 06    	adc    %al,0x60d4302(%rsi)
    b05e:	50                   	push   %rax
    b05f:	83 03 8c             	addl   $0xffffff8c,(%rbx)
    b062:	04 8d                	add    $0x8d,%al
    b064:	05 8e 06 8f 07       	add    $0x78f068e,%eax
    b069:	03 6b 61             	add    0x61(%rbx),%ebp
    b06c:	0b 00                	or     (%rax),%eax
    b06e:	00 00                	add    %al,(%rax)
    b070:	28 00                	sub    %al,(%rax)
    b072:	00 00                	add    %al,(%rax)
    b074:	74 00                	je     0xb076
    b076:	00 00                	add    %al,(%rax)
    b078:	08 c1                	or     %al,%cl
    b07a:	ff                   	(bad)
    b07b:	ff 4d 33             	decl   0x33(%rbp)
    b07e:	00 00                	add    %al,(%rax)
    b080:	00 0a                	add    %cl,(%rdx)
    b082:	41 0e                	rex.B (bad)
    b084:	10 86 02 43 0d 06    	adc    %al,0x60d4302(%rsi)
    b08a:	50                   	push   %rax
    b08b:	83 03 8c             	addl   $0xffffff8c,(%rbx)
    b08e:	04 8d                	add    $0x8d,%al
    b090:	05 8e 06 8f 07       	add    $0x78f068e,%eax
    b095:	03 38                	add    (%rax),%edi
    b097:	33 0b                	xor    (%rbx),%ecx
    b099:	00 00                	add    %al,(%rax)
    b09b:	00 28                	add    %ch,(%rax)
    b09d:	00 00                	add    %al,(%rax)
    b09f:	00 a0 00 00 00 5c    	add    %ah,0x5c000000(%rax)
    b0a5:	f4                   	hlt
    b0a6:	ff                   	(bad)
    b0a7:	ff 9b 03 00 00 00    	lcall  *0x3(%rbx)
    b0ad:	0a 41 0e             	or     0xe(%rcx),%al
    b0b0:	10 86 02 43 0d 06    	adc    %al,0x60d4302(%rsi)
    b0b6:	50                   	push   %rax
    b0b7:	83 03 8c             	addl   $0xffffff8c,(%rbx)
    b0ba:	04 8d                	add    $0x8d,%al
    b0bc:	05 8e 06 8f 07       	add    $0x78f068e,%eax
    b0c1:	03 86 03 0b 00 00    	add    0xb03(%rsi),%eax
    b0c7:	00 2c 00             	add    %ch,(%rax,%rax,1)
    b0ca:	00 00                	add    %al,(%rax)
    b0cc:	cc                   	int3
    b0cd:	00 00                	add    %al,(%rax)
    b0cf:	00 f0                	add    %dh,%al
    b0d1:	f7 ff                	idiv   %edi
    b0d3:	ff af 03 00 00 00    	ljmp   *0x3(%rdi)
    b0d9:	0a 41 0e             	or     0xe(%rcx),%al
    b0dc:	10 86 02 43 0d 06    	adc    %al,0x60d4302(%rsi)
    b0e2:	50                   	push   %rax
    b0e3:	83 03 8c             	addl   $0xffffff8c,(%rbx)
    b0e6:	04 8d                	add    $0x8d,%al
    b0e8:	05 8e 06 8f 07       	add    $0x78f068e,%eax
    b0ed:	03 9a 03 0b 00 00    	add    0xb03(%rdx),%ebx
	...
