
/home/rustsql/profile-candidate-20261030e/jit/96b1d1674ae3c02b094d3e9f5bcf3b18.x86_64.bin:     file format binary


Disassembly of section .data:

0000000000000180 <.data+0x180>:
     180:	55                   	push   %rbp
     181:	48 89 e5             	mov    %rsp,%rbp
     184:	53                   	push   %rbx
     185:	41 54                	push   %r12
     187:	41 55                	push   %r13
     189:	41 56                	push   %r14
     18b:	41 57                	push   %r15
     18d:	48 81 ec 38 02 00 00 	sub    $0x238,%rsp
     194:	48 89 fb             	mov    %rdi,%rbx
     197:	31 c0                	xor    %eax,%eax
     199:	b9 01 00 00 00       	mov    $0x1,%ecx
     19e:	48 8b 53 58          	mov    0x58(%rbx),%rdx
     1a2:	48 8d b5 40 ff ff ff 	lea    -0xc0(%rbp),%rsi
     1a9:	49 89 f4             	mov    %rsi,%r12
     1ac:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
     1b0:	48 85 ff             	test   %rdi,%rdi
     1b3:	0f 85 53 02 00 00    	jne    0x40c
     1b9:	48 bf 01 00 00 00 00 	movabs $0x4000000000001,%rdi
     1c0:	00 04 00 
     1c3:	48 89 7b 50          	mov    %rdi,0x50(%rbx)
     1c7:	48 8b 7a 18          	mov    0x18(%rdx),%rdi
     1cb:	4c 8b 42 20          	mov    0x20(%rdx),%r8
     1cf:	4d 89 c1             	mov    %r8,%r9
     1d2:	49 29 f9             	sub    %rdi,%r9
     1d5:	49 01 c9             	add    %rcx,%r9
     1d8:	49 39 f8             	cmp    %rdi,%r8
     1db:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     1e1:	41 0f 9c c0          	setl   %r8b
     1e5:	49 89 c2             	mov    %rax,%r10
     1e8:	4d 85 c0             	test   %r8,%r8
     1eb:	4d 0f 44 d1          	cmove  %r9,%r10
     1ef:	41 b8 99 19 00 00    	mov    $0x1999,%r8d
     1f5:	4c 8b 4a 28          	mov    0x28(%rdx),%r9
     1f9:	49 39 c1             	cmp    %rax,%r9
     1fc:	41 bb 00 00 00 00    	mov    $0x0,%r11d
     202:	41 0f 94 c3          	sete   %r11b
     206:	4d 85 db             	test   %r11,%r11
     209:	4d 0f 44 c1          	cmove  %r9,%r8
     20d:	49 39 c2             	cmp    %rax,%r10
     210:	41 bd 00 00 00 00    	mov    $0x0,%r13d
     216:	41 0f 94 c5          	sete   %r13b
     21a:	4d 89 d6             	mov    %r10,%r14
     21d:	49 01 ce             	add    %rcx,%r14
     220:	49 89 c7             	mov    %rax,%r15
     223:	4d 85 ed             	test   %r13,%r13
     226:	4d 0f 44 fe          	cmove  %r14,%r15
     22a:	4d 85 ed             	test   %r13,%r13
     22d:	4d 0f 44 c7          	cmove  %r15,%r8
     231:	41 bd 99 19 00 00    	mov    $0x1999,%r13d
     237:	4d 85 db             	test   %r11,%r11
     23a:	4d 0f 44 e9          	cmove  %r9,%r13
     23e:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
     244:	4d 39 e8             	cmp    %r13,%r8
     247:	4d 0f 47 c5          	cmova  %r13,%r8
     24b:	4d 39 c8             	cmp    %r9,%r8
     24e:	4d 0f 47 c1          	cmova  %r9,%r8
     252:	4c 8d 8d 10 ff ff ff 	lea    -0xf0(%rbp),%r9
     259:	4d 89 cb             	mov    %r9,%r11
     25c:	41 bd 02 02 01 01    	mov    $0x1010202,%r13d
     262:	4d 89 2b             	mov    %r13,(%r11)
     265:	41 bd 00 00 00 01    	mov    $0x1000000,%r13d
     26b:	4d 89 6b 08          	mov    %r13,0x8(%r11)
     26f:	41 bd 00 00 10 18    	mov    $0x18100000,%r13d
     275:	4d 89 6b 10          	mov    %r13,0x10(%r11)
     279:	49 bd 00 00 28 01 10 	movabs $0x201001280000,%r13
     280:	20 00 00 
     283:	4d 89 6b 18          	mov    %r13,0x18(%r11)
     287:	45 31 ed             	xor    %r13d,%r13d
     28a:	4d 89 6b 20          	mov    %r13,0x20(%r11)
     28e:	41 bd 99 19 00 00    	mov    $0x1999,%r13d
     294:	4c 8b 72 28          	mov    0x28(%rdx),%r14
     298:	49 39 c6             	cmp    %rax,%r14
     29b:	ba 00 00 00 00       	mov    $0x0,%edx
     2a0:	0f 94 c2             	sete   %dl
     2a3:	48 85 d2             	test   %rdx,%rdx
     2a6:	4d 0f 44 ee          	cmove  %r14,%r13
     2aa:	ba cd cc cc 00       	mov    $0xcccccd,%edx
     2af:	49 39 d5             	cmp    %rdx,%r13
     2b2:	41 be 00 00 00 00    	mov    $0x0,%r14d
     2b8:	41 0f 97 c6          	seta   %r14b
     2bc:	4d 85 f6             	test   %r14,%r14
     2bf:	49 0f 44 d5          	cmove  %r13,%rdx
     2c3:	41 bd 28 00 00 00    	mov    $0x28,%r13d
     2c9:	49 0f af d5          	imul   %r13,%rdx
     2cd:	48 81 c2 ff ff 03 00 	add    $0x3ffff,%rdx
     2d4:	48 c1 ea 12          	shr    $0x12,%rdx
     2d8:	48 83 fa 01          	cmp    $0x1,%rdx
     2dc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
     2e2:	41 0f 97 c5          	seta   %r13b
     2e6:	48 83 ea 01          	sub    $0x1,%rdx
     2ea:	4c 0f bd f2          	bsr    %rdx,%r14
     2ee:	ba 7f 00 00 00       	mov    $0x7f,%edx
     2f3:	49 0f 45 d6          	cmovne %r14,%rdx
     2f7:	83 f2 3f             	xor    $0x3f,%edx
     2fa:	41 be 40 00 00 00    	mov    $0x40,%r14d
     300:	49 29 d6             	sub    %rdx,%r14
     303:	ba 0b 00 00 00       	mov    $0xb,%edx
     308:	49 39 d6             	cmp    %rdx,%r14
     30b:	be 00 00 00 00       	mov    $0x0,%esi
     310:	40 0f 97 c6          	seta   %sil
     314:	48 85 f6             	test   %rsi,%rsi
     317:	49 0f 44 d6          	cmove  %r14,%rdx
     31b:	31 f6                	xor    %esi,%esi
     31d:	4d 85 ed             	test   %r13,%r13
     320:	48 0f 44 d6          	cmove  %rsi,%rdx
     324:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
     328:	48 89 df             	mov    %rbx,%rdi
     32b:	4c 89 e6             	mov    %r12,%rsi
     32e:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
     335:	4c 89 da             	mov    %r11,%rdx
     338:	48 8b 8d b8 fe ff ff 	mov    -0x148(%rbp),%rcx
     33f:	4c 89 95 b0 fe ff ff 	mov    %r10,-0x150(%rbp)
     346:	4c 89 9d a8 fe ff ff 	mov    %r11,-0x158(%rbp)
     34d:	e8 ae fc ff ff       	call   0x0
     352:	48 83 f8 00          	cmp    $0x0,%rax
     356:	0f 8d 08 00 00 00    	jge    0x364
     35c:	49 89 c5             	mov    %rax,%r13
     35f:	e9 90 1a 00 00       	jmp    0x1df4
     364:	31 c0                	xor    %eax,%eax
     366:	48 89 df             	mov    %rbx,%rdi
     369:	48 89 c6             	mov    %rax,%rsi
     36c:	48 8b 95 a8 fe ff ff 	mov    -0x158(%rbp),%rdx
     373:	48 8b 8d b8 fe ff ff 	mov    -0x148(%rbp),%rcx
     37a:	e8 91 fc ff ff       	call   0x10
     37f:	49 8b 04 24          	mov    (%r12),%rax
     383:	31 c9                	xor    %ecx,%ecx
     385:	48 8d 54 08 10       	lea    0x10(%rax,%rcx,1),%rdx
     38a:	49 89 54 24 40       	mov    %rdx,0x40(%r12)
     38f:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
     394:	49 8b 04 24          	mov    (%r12),%rax
     398:	0f b6 50 0d          	movzbl 0xd(%rax),%edx
     39c:	48 83 e2 01          	and    $0x1,%rdx
     3a0:	49 89 54 24 68       	mov    %rdx,0x68(%r12)
     3a5:	49 8b 04 24          	mov    (%r12),%rax
     3a9:	8b 30                	mov    (%rax),%esi
     3ab:	b8 01 00 00 00       	mov    $0x1,%eax
     3b0:	49 29 c7             	sub    %rax,%r15
     3b3:	49 39 f7             	cmp    %rsi,%r15
     3b6:	41 bf 00 00 00 00    	mov    $0x0,%r15d
     3bc:	41 0f 92 c7          	setb   %r15b
     3c0:	48 39 ca             	cmp    %rcx,%rdx
     3c3:	ba 00 00 00 00       	mov    $0x0,%edx
     3c8:	0f 94 c2             	sete   %dl
     3cb:	4d 85 ff             	test   %r15,%r15
     3ce:	48 0f 44 d1          	cmove  %rcx,%rdx
     3d2:	49 8d 74 0c 70       	lea    0x70(%r12,%rcx,1),%rsi
     3d7:	48 89 16             	mov    %rdx,(%rsi)
     3da:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
     3de:	48 89 56 08          	mov    %rdx,0x8(%rsi)
     3e2:	48 8b 95 b0 fe ff ff 	mov    -0x150(%rbp),%rdx
     3e9:	48 89 56 10          	mov    %rdx,0x10(%rsi)
     3ed:	31 d2                	xor    %edx,%edx
     3ef:	48 89 df             	mov    %rbx,%rdi
     3f2:	48 89 d6             	mov    %rdx,%rsi
     3f5:	e8 26 fc ff ff       	call   0x20
     3fa:	48 83 f8 00          	cmp    $0x0,%rax
     3fe:	0f 8d 08 00 00 00    	jge    0x40c
     404:	49 89 c5             	mov    %rax,%r13
     407:	e9 e8 19 00 00       	jmp    0x1df4
     40c:	48 8b 43 18          	mov    0x18(%rbx),%rax
     410:	48 85 c0             	test   %rax,%rax
     413:	0f 84 0c 00 00 00    	je     0x425
     419:	0f b6 08             	movzbl (%rax),%ecx
     41c:	48 85 c9             	test   %rcx,%rcx
     41f:	0f 85 57 19 00 00    	jne    0x1d7c
     425:	31 c0                	xor    %eax,%eax
     427:	48 89 df             	mov    %rbx,%rdi
     42a:	48 89 c6             	mov    %rax,%rsi
     42d:	e8 fe fb ff ff       	call   0x30
     432:	48 83 f8 00          	cmp    $0x0,%rax
     436:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
     43d:	0f 8e 56 19 00 00    	jle    0x1d99
     443:	8b 8b 00 01 00 00    	mov    0x100(%rbx),%ecx
     449:	8b 93 fc 00 00 00    	mov    0xfc(%rbx),%edx
     44f:	4c 8b b3 d0 00 00 00 	mov    0xd0(%rbx),%r14
     456:	31 f6                	xor    %esi,%esi
     458:	49 39 f6             	cmp    %rsi,%r14
     45b:	41 bf 00 00 00 00    	mov    $0x0,%r15d
     461:	41 0f 94 c7          	sete   %r15b
     465:	8b bb 04 01 00 00    	mov    0x104(%rbx),%edi
     46b:	4d 85 ff             	test   %r15,%r15
     46e:	48 0f 44 d7          	cmove  %rdi,%rdx
     472:	48 8b bb a0 00 00 00 	mov    0xa0(%rbx),%rdi
     479:	4c 8b 07             	mov    (%rdi),%r8
     47c:	4c 8b 4f 08          	mov    0x8(%rdi),%r9
     480:	49 39 f1             	cmp    %rsi,%r9
     483:	41 ba 00 00 00 00    	mov    $0x0,%r10d
     489:	41 0f 94 c2          	sete   %r10b
     48d:	4c 8b 5f 20          	mov    0x20(%rdi),%r11
     491:	48 8b 47 28          	mov    0x28(%rdi),%rax
     495:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
     499:	48 39 f0             	cmp    %rsi,%rax
     49c:	bf 00 00 00 00       	mov    $0x0,%edi
     4a1:	40 0f 94 c7          	sete   %dil
     4a5:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
     4a9:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
     4b0:	8b 46 1c             	mov    0x1c(%rsi),%eax
     4b3:	31 f6                	xor    %esi,%esi
     4b5:	48 39 f0             	cmp    %rsi,%rax
     4b8:	b8 00 00 00 00       	mov    $0x0,%eax
     4bd:	0f 95 c0             	setne  %al
     4c0:	48 85 c0             	test   %rax,%rax
     4c3:	48 89 85 a8 fe ff ff 	mov    %rax,-0x158(%rbp)
     4ca:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
     4d1:	48 89 95 98 fe ff ff 	mov    %rdx,-0x168(%rbp)
     4d8:	48 89 bd 90 fe ff ff 	mov    %rdi,-0x170(%rbp)
     4df:	4c 89 85 88 fe ff ff 	mov    %r8,-0x178(%rbp)
     4e6:	4c 89 8d 80 fe ff ff 	mov    %r9,-0x180(%rbp)
     4ed:	4c 89 95 78 fe ff ff 	mov    %r10,-0x188(%rbp)
     4f4:	4c 89 9d 70 fe ff ff 	mov    %r11,-0x190(%rbp)
     4fb:	0f 85 08 00 00 00    	jne    0x509
     501:	48 89 f7             	mov    %rsi,%rdi
     504:	e9 0d 00 00 00       	jmp    0x516
     509:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
     50d:	4d 8b 11             	mov    (%r9),%r10
     510:	4d 63 0a             	movslq (%r10),%r9
     513:	4c 89 cf             	mov    %r9,%rdi
     516:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
     51d:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
     524:	48 89 c2             	mov    %rax,%rdx
     527:	48 21 ca             	and    %rcx,%rdx
     52a:	48 be df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rsi
     531:	82 28 52 
     534:	31 ff                	xor    %edi,%edi
     536:	4c 21 fa             	and    %r15,%rdx
     539:	48 85 d2             	test   %rdx,%rdx
     53c:	0f 85 c0 09 00 00    	jne    0xf02
     542:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
     549:	48 89 55 d0          	mov    %rdx,-0x30(%rbp)
     54d:	31 d2                	xor    %edx,%edx
     54f:	48 89 95 68 fe ff ff 	mov    %rdx,-0x198(%rbp)
     556:	31 d2                	xor    %edx,%edx
     558:	48 89 95 60 fe ff ff 	mov    %rdx,-0x1a0(%rbp)
     55f:	31 d2                	xor    %edx,%edx
     561:	48 89 95 58 fe ff ff 	mov    %rdx,-0x1a8(%rbp)
     568:	48 89 b5 50 fe ff ff 	mov    %rsi,-0x1b0(%rbp)
     56f:	31 d2                	xor    %edx,%edx
     571:	48 89 95 48 fe ff ff 	mov    %rdx,-0x1b8(%rbp)
     578:	31 d2                	xor    %edx,%edx
     57a:	48 89 95 40 fe ff ff 	mov    %rdx,-0x1c0(%rbp)
     581:	48 89 bd 38 fe ff ff 	mov    %rdi,-0x1c8(%rbp)
     588:	31 d2                	xor    %edx,%edx
     58a:	48 89 95 30 fe ff ff 	mov    %rdx,-0x1d0(%rbp)
     591:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
     595:	48 8b 8d 98 fe ff ff 	mov    -0x168(%rbp),%rcx
     59c:	48 39 c8             	cmp    %rcx,%rax
     59f:	0f 8c 75 00 00 00    	jl     0x61a
     5a5:	48 8b 95 68 fe ff ff 	mov    -0x198(%rbp),%rdx
     5ac:	48 89 95 28 fe ff ff 	mov    %rdx,-0x1d8(%rbp)
     5b3:	48 8b 95 48 fe ff ff 	mov    -0x1b8(%rbp),%rdx
     5ba:	48 89 95 20 fe ff ff 	mov    %rdx,-0x1e0(%rbp)
     5c1:	48 8b 95 40 fe ff ff 	mov    -0x1c0(%rbp),%rdx
     5c8:	48 89 95 18 fe ff ff 	mov    %rdx,-0x1e8(%rbp)
     5cf:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
     5d6:	48 89 95 10 fe ff ff 	mov    %rdx,-0x1f0(%rbp)
     5dd:	48 8b 95 58 fe ff ff 	mov    -0x1a8(%rbp),%rdx
     5e4:	48 89 95 08 fe ff ff 	mov    %rdx,-0x1f8(%rbp)
     5eb:	48 8b 95 38 fe ff ff 	mov    -0x1c8(%rbp),%rdx
     5f2:	48 89 95 00 fe ff ff 	mov    %rdx,-0x200(%rbp)
     5f9:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
     600:	48 89 95 f8 fd ff ff 	mov    %rdx,-0x208(%rbp)
     607:	48 8b 95 50 fe ff ff 	mov    -0x1b0(%rbp),%rdx
     60e:	48 89 95 f0 fd ff ff 	mov    %rdx,-0x210(%rbp)
     615:	e9 53 11 00 00       	jmp    0x176d
     61a:	4d 85 ff             	test   %r15,%r15
     61d:	0f 84 08 00 00 00    	je     0x62b
     623:	48 89 c6             	mov    %rax,%rsi
     626:	e9 09 00 00 00       	jmp    0x634
     62b:	49 8d 14 86          	lea    (%r14,%rax,4),%rdx
     62f:	8b 3a                	mov    (%rdx),%edi
     631:	48 89 fe             	mov    %rdi,%rsi
     634:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
     63b:	48 8d 0c b0          	lea    (%rax,%rsi,4),%rcx
     63f:	48 89 f2             	mov    %rsi,%rdx
     642:	48 c1 ea 06          	shr    $0x6,%rdx
     646:	48 8b bd 80 fe ff ff 	mov    -0x180(%rbp),%rdi
     64d:	4c 8d 04 d7          	lea    (%rdi,%rdx,8),%r8
     651:	48 8b 95 78 fe ff ff 	mov    -0x188(%rbp),%rdx
     658:	49 89 d9             	mov    %rbx,%r9
     65b:	48 85 d2             	test   %rdx,%rdx
     65e:	4d 0f 44 c8          	cmove  %r8,%r9
     662:	4d 8b 01             	mov    (%r9),%r8
     665:	49 89 f1             	mov    %rsi,%r9
     668:	49 83 e1 3f          	and    $0x3f,%r9
     66c:	48 89 8d e8 fd ff ff 	mov    %rcx,-0x218(%rbp)
     673:	4c 89 c9             	mov    %r9,%rcx
     676:	49 d3 e8             	shr    %cl,%r8
     679:	b9 01 00 00 00       	mov    $0x1,%ecx
     67e:	49 21 c8             	and    %rcx,%r8
     681:	45 31 c9             	xor    %r9d,%r9d
     684:	4d 39 c8             	cmp    %r9,%r8
     687:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     68d:	41 0f 94 c0          	sete   %r8b
     691:	41 ba 01 00 00 00    	mov    $0x1,%r10d
     697:	49 89 d3             	mov    %rdx,%r11
     69a:	4d 31 d3             	xor    %r10,%r11
     69d:	4d 21 d8             	and    %r11,%r8
     6a0:	4c 8b 95 70 fe ff ff 	mov    -0x190(%rbp),%r10
     6a7:	4d 8d 1c b2          	lea    (%r10,%rsi,4),%r11
     6ab:	48 89 f2             	mov    %rsi,%rdx
     6ae:	48 c1 ea 06          	shr    $0x6,%rdx
     6b2:	48 8b bd b8 fe ff ff 	mov    -0x148(%rbp),%rdi
     6b9:	48 8d 04 d7          	lea    (%rdi,%rdx,8),%rax
     6bd:	48 8b 95 90 fe ff ff 	mov    -0x170(%rbp),%rdx
     6c4:	48 89 df             	mov    %rbx,%rdi
     6c7:	48 85 d2             	test   %rdx,%rdx
     6ca:	48 0f 44 f8          	cmove  %rax,%rdi
     6ce:	48 8b 07             	mov    (%rdi),%rax
     6d1:	48 83 e6 3f          	and    $0x3f,%rsi
     6d5:	48 89 f1             	mov    %rsi,%rcx
     6d8:	48 d3 e8             	shr    %cl,%rax
     6db:	b9 01 00 00 00       	mov    $0x1,%ecx
     6e0:	48 21 c8             	and    %rcx,%rax
     6e3:	4c 39 c8             	cmp    %r9,%rax
     6e6:	b8 00 00 00 00       	mov    $0x0,%eax
     6eb:	0f 94 c0             	sete   %al
     6ee:	be 01 00 00 00       	mov    $0x1,%esi
     6f3:	48 89 d7             	mov    %rdx,%rdi
     6f6:	48 31 f7             	xor    %rsi,%rdi
     6f9:	48 21 f8             	and    %rdi,%rax
     6fc:	48 8b b5 68 fe ff ff 	mov    -0x198(%rbp),%rsi
     703:	48 89 f7             	mov    %rsi,%rdi
     706:	48 83 c7 01          	add    $0x1,%rdi
     70a:	48 8b 95 e8 fd ff ff 	mov    -0x218(%rbp),%rdx
     711:	48 63 32             	movslq (%rdx),%rsi
     714:	31 d2                	xor    %edx,%edx
     716:	4d 85 c0             	test   %r8,%r8
     719:	48 0f 44 d6          	cmove  %rsi,%rdx
     71d:	48 8b b5 a8 fe ff ff 	mov    -0x158(%rbp),%rsi
     724:	48 85 f6             	test   %rsi,%rsi
     727:	48 89 85 e8 fd ff ff 	mov    %rax,-0x218(%rbp)
     72e:	48 89 95 e0 fd ff ff 	mov    %rdx,-0x220(%rbp)
     735:	48 89 bd d8 fd ff ff 	mov    %rdi,-0x228(%rbp)
     73c:	4c 89 85 d0 fd ff ff 	mov    %r8,-0x230(%rbp)
     743:	4c 89 9d c8 fd ff ff 	mov    %r11,-0x238(%rbp)
     74a:	0f 84 10 00 00 00    	je     0x760
     750:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
     757:	48 85 c0             	test   %rax,%rax
     75a:	0f 85 40 00 00 00    	jne    0x7a0
     760:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
     767:	48 8b 8d e0 fd ff ff 	mov    -0x220(%rbp),%rcx
     76e:	48 39 c8             	cmp    %rcx,%rax
     771:	ba 00 00 00 00       	mov    $0x0,%edx
     776:	0f 94 c2             	sete   %dl
     779:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
     780:	48 8b bd d0 fd ff ff 	mov    -0x230(%rbp),%rdi
     787:	48 39 fe             	cmp    %rdi,%rsi
     78a:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     790:	41 0f 94 c0          	sete   %r8b
     794:	4c 21 c2             	and    %r8,%rdx
     797:	48 85 d2             	test   %rdx,%rdx
     79a:	0f 84 67 00 00 00    	je     0x807
     7a0:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
     7a7:	48 89 c1             	mov    %rax,%rcx
     7aa:	48 83 c1 01          	add    $0x1,%rcx
     7ae:	ba 01 00 00 00       	mov    $0x1,%edx
     7b3:	48 8b b5 c8 fd ff ff 	mov    -0x238(%rbp),%rsi
     7ba:	48 63 3e             	movslq (%rsi),%rdi
     7bd:	4c 8b 85 e8 fd ff ff 	mov    -0x218(%rbp),%r8
     7c4:	4d 89 c1             	mov    %r8,%r9
     7c7:	49 31 d1             	xor    %rdx,%r9
     7ca:	31 d2                	xor    %edx,%edx
     7cc:	4d 85 c9             	test   %r9,%r9
     7cf:	48 0f 44 fa          	cmove  %rdx,%rdi
     7d3:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
     7da:	49 89 d2             	mov    %rdx,%r10
     7dd:	4d 01 ca             	add    %r9,%r10
     7e0:	4c 8b 8d 38 fe ff ff 	mov    -0x1c8(%rbp),%r9
     7e7:	4d 89 cb             	mov    %r9,%r11
     7ea:	49 01 fb             	add    %rdi,%r11
     7ed:	48 89 8d 40 fe ff ff 	mov    %rcx,-0x1c0(%rbp)
     7f4:	4c 89 9d 38 fe ff ff 	mov    %r11,-0x1c8(%rbp)
     7fb:	4c 89 95 30 fe ff ff 	mov    %r10,-0x1d0(%rbp)
     802:	e9 ce 06 00 00       	jmp    0xed5
     807:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
     80e:	48 85 c0             	test   %rax,%rax
     811:	0f 84 25 06 00 00    	je     0xe3c
     817:	31 c9                	xor    %ecx,%ecx
     819:	49 8d 54 0c 70       	lea    0x70(%r12,%rcx,1),%rdx
     81e:	48 8b 32             	mov    (%rdx),%rsi
     821:	48 85 f6             	test   %rsi,%rsi
     824:	0f 84 3d 02 00 00    	je     0xa67
     82a:	49 8d 54 0c 70       	lea    0x70(%r12,%rcx,1),%rdx
     82f:	48 8b 72 08          	mov    0x8(%rdx),%rsi
     833:	49 8b 3c 24          	mov    (%r12),%rdi
     837:	44 8b 07             	mov    (%rdi),%r8d
     83a:	48 8b bd 60 fe ff ff 	mov    -0x1a0(%rbp),%rdi
     841:	49 89 f9             	mov    %rdi,%r9
     844:	49 29 f1             	sub    %rsi,%r9
     847:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
     84e:	48 39 ce             	cmp    %rcx,%rsi
     851:	41 ba 00 00 00 00    	mov    $0x0,%r10d
     857:	41 0f 95 c2          	setne  %r10b
     85b:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
     85f:	4c 89 da             	mov    %r11,%rdx
     862:	4d 85 d2             	test   %r10,%r10
     865:	49 0f 44 d1          	cmove  %r9,%rdx
     869:	4d 85 d2             	test   %r10,%r10
     86c:	4d 0f 44 c3          	cmove  %r11,%r8
     870:	4d 8b 4c 24 10       	mov    0x10(%r12),%r9
     875:	41 ba 28 00 00 00    	mov    $0x28,%r10d
     87b:	49 89 d3             	mov    %rdx,%r11
     87e:	4d 0f af da          	imul   %r10,%r11
     882:	4f 8d 14 19          	lea    (%r9,%r11,1),%r10
     886:	4c 39 c2             	cmp    %r8,%rdx
     889:	0f 83 b2 00 00 00    	jae    0x941
     88f:	4d 8b 42 10          	mov    0x10(%r10),%r8
     893:	4d 85 c0             	test   %r8,%r8
     896:	0f 84 16 00 00 00    	je     0x8b2
     89c:	4c 89 95 c0 fd ff ff 	mov    %r10,-0x240(%rbp)
     8a3:	45 31 c0             	xor    %r8d,%r8d
     8a6:	4c 89 85 b8 fd ff ff 	mov    %r8,-0x248(%rbp)
     8ad:	e9 7c 04 00 00       	jmp    0xd2e
     8b2:	45 31 c0             	xor    %r8d,%r8d
     8b5:	49 89 3a             	mov    %rdi,(%r10)
     8b8:	49 89 72 08          	mov    %rsi,0x8(%r10)
     8bc:	4d 89 42 10          	mov    %r8,0x10(%r10)
     8c0:	4d 89 42 18          	mov    %r8,0x18(%r10)
     8c4:	4d 89 42 20          	mov    %r8,0x20(%r10)
     8c8:	4d 8b 04 24          	mov    (%r12),%r8
     8cc:	45 8b 48 04          	mov    0x4(%r8),%r9d
     8d0:	41 bb 01 00 00 00    	mov    $0x1,%r11d
     8d6:	4d 01 d9             	add    %r11,%r9
     8d9:	45 89 48 04          	mov    %r9d,0x4(%r8)
     8dd:	4d 8b 4c 24 38       	mov    0x38(%r12),%r9
     8e2:	b8 40 00 00 00       	mov    $0x40,%eax
     8e7:	4c 29 c8             	sub    %r9,%rax
     8ea:	48 8b b5 50 fe ff ff 	mov    -0x1b0(%rbp),%rsi
     8f1:	48 89 c1             	mov    %rax,%rcx
     8f4:	48 89 f7             	mov    %rsi,%rdi
     8f7:	48 d3 ef             	shr    %cl,%rdi
     8fa:	31 c0                	xor    %eax,%eax
     8fc:	49 39 c1             	cmp    %rax,%r9
     8ff:	41 b9 00 00 00 00    	mov    $0x0,%r9d
     905:	41 0f 94 c1          	sete   %r9b
     909:	4d 85 c9             	test   %r9,%r9
     90c:	48 0f 44 c7          	cmove  %rdi,%rax
     910:	41 8b 48 4c          	mov    0x4c(%r8),%ecx
     914:	49 8d 3c 08          	lea    (%r8,%rcx,1),%rdi
     918:	48 8d 0c 97          	lea    (%rdi,%rdx,4),%rcx
     91c:	89 01                	mov    %eax,(%rcx)
     91e:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
     925:	41 89 40 50          	mov    %eax,0x50(%r8)
     929:	4c 89 95 c0 fd ff ff 	mov    %r10,-0x240(%rbp)
     930:	b8 01 00 00 00       	mov    $0x1,%eax
     935:	48 89 85 b8 fd ff ff 	mov    %rax,-0x248(%rbp)
     93c:	e9 ed 03 00 00       	jmp    0xd2e
     941:	49 8b 44 24 38       	mov    0x38(%r12),%rax
     946:	b9 40 00 00 00       	mov    $0x40,%ecx
     94b:	48 29 c1             	sub    %rax,%rcx
     94e:	48 89 8d b0 fd ff ff 	mov    %rcx,-0x250(%rbp)
     955:	48 8b 95 50 fe ff ff 	mov    -0x1b0(%rbp),%rdx
     95c:	48 8b b5 b0 fd ff ff 	mov    -0x250(%rbp),%rsi
     963:	48 89 f1             	mov    %rsi,%rcx
     966:	48 89 d7             	mov    %rdx,%rdi
     969:	48 d3 ef             	shr    %cl,%rdi
     96c:	31 c9                	xor    %ecx,%ecx
     96e:	48 39 c8             	cmp    %rcx,%rax
     971:	b8 00 00 00 00       	mov    $0x0,%eax
     976:	0f 94 c0             	sete   %al
     979:	48 85 c0             	test   %rax,%rax
     97c:	48 0f 44 cf          	cmove  %rdi,%rcx
     980:	49 8b 44 24 08       	mov    0x8(%r12),%rax
     985:	48 8d 34 c8          	lea    (%rax,%rcx,8),%rsi
     989:	48 8b 06             	mov    (%rsi),%rax
     98c:	48 bf 00 00 00 00 00 	movabs $0x28000000000000,%rdi
     993:	00 28 00 
     996:	48 39 f8             	cmp    %rdi,%rax
     999:	48 89 b5 b0 fd ff ff 	mov    %rsi,-0x250(%rbp)
     9a0:	0f 82 0c 00 00 00    	jb     0x9b2
     9a6:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
     9ad:	e9 36 00 00 00       	jmp    0x9e8
     9b2:	49 8b 44 24 60       	mov    0x60(%r12),%rax
     9b7:	48 89 df             	mov    %rbx,%rdi
     9ba:	4c 89 e6             	mov    %r12,%rsi
     9bd:	48 89 ca             	mov    %rcx,%rdx
     9c0:	48 89 c1             	mov    %rax,%rcx
     9c3:	e8 78 f6 ff ff       	call   0x40
     9c8:	31 c9                	xor    %ecx,%ecx
     9ca:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
     9cf:	48 83 f8 00          	cmp    $0x0,%rax
     9d3:	0f 8f 08 00 00 00    	jg     0x9e1
     9d9:	49 89 c5             	mov    %rax,%r13
     9dc:	e9 13 14 00 00       	jmp    0x1df4
     9e1:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
     9e8:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
     9ef:	48 89 c1             	mov    %rax,%rcx
     9f2:	48 83 c1 28          	add    $0x28,%rcx
     9f6:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
     9fd:	00 28 00 
     a00:	48 29 d1             	sub    %rdx,%rcx
     a03:	48 8b 95 b0 fd ff ff 	mov    -0x250(%rbp),%rdx
     a0a:	48 89 0a             	mov    %rcx,(%rdx)
     a0d:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
     a14:	ff 00 00 
     a17:	48 21 c8             	and    %rcx,%rax
     a1a:	31 c9                	xor    %ecx,%ecx
     a1c:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
     a23:	48 89 10             	mov    %rdx,(%rax)
     a26:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
     a2d:	48 89 70 08          	mov    %rsi,0x8(%rax)
     a31:	48 89 48 10          	mov    %rcx,0x10(%rax)
     a35:	48 89 48 18          	mov    %rcx,0x18(%rax)
     a39:	48 89 48 20          	mov    %rcx,0x20(%rax)
     a3d:	49 8b 4c 24 60       	mov    0x60(%r12),%rcx
     a42:	bf 01 00 00 00       	mov    $0x1,%edi
     a47:	48 01 f9             	add    %rdi,%rcx
     a4a:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
     a4f:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
     a56:	b8 01 00 00 00       	mov    $0x1,%eax
     a5b:	48 89 85 b8 fd ff ff 	mov    %rax,-0x248(%rbp)
     a62:	e9 c7 02 00 00       	jmp    0xd2e
     a67:	49 8b 44 24 68       	mov    0x68(%r12),%rax
     a6c:	48 85 c0             	test   %rax,%rax
     a6f:	0f 84 2f 01 00 00    	je     0xba4
     a75:	49 8b 44 24 38       	mov    0x38(%r12),%rax
     a7a:	b9 40 00 00 00       	mov    $0x40,%ecx
     a7f:	48 29 c1             	sub    %rax,%rcx
     a82:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
     a89:	48 8b 95 50 fe ff ff 	mov    -0x1b0(%rbp),%rdx
     a90:	48 8b b5 a8 fd ff ff 	mov    -0x258(%rbp),%rsi
     a97:	48 89 f1             	mov    %rsi,%rcx
     a9a:	48 89 d7             	mov    %rdx,%rdi
     a9d:	48 d3 ef             	shr    %cl,%rdi
     aa0:	31 c9                	xor    %ecx,%ecx
     aa2:	48 39 c8             	cmp    %rcx,%rax
     aa5:	b8 00 00 00 00       	mov    $0x0,%eax
     aaa:	0f 94 c0             	sete   %al
     aad:	48 85 c0             	test   %rax,%rax
     ab0:	48 0f 44 cf          	cmove  %rdi,%rcx
     ab4:	49 8b 44 24 08       	mov    0x8(%r12),%rax
     ab9:	48 8d 34 c8          	lea    (%rax,%rcx,8),%rsi
     abd:	48 8b 06             	mov    (%rsi),%rax
     ac0:	48 bf 00 00 00 00 00 	movabs $0x28000000000000,%rdi
     ac7:	00 28 00 
     aca:	48 39 f8             	cmp    %rdi,%rax
     acd:	48 89 b5 a8 fd ff ff 	mov    %rsi,-0x258(%rbp)
     ad4:	0f 82 0c 00 00 00    	jb     0xae6
     ada:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
     ae1:	e9 36 00 00 00       	jmp    0xb1c
     ae6:	49 8b 44 24 60       	mov    0x60(%r12),%rax
     aeb:	48 89 df             	mov    %rbx,%rdi
     aee:	4c 89 e6             	mov    %r12,%rsi
     af1:	48 89 ca             	mov    %rcx,%rdx
     af4:	48 89 c1             	mov    %rax,%rcx
     af7:	e8 44 f5 ff ff       	call   0x40
     afc:	31 c9                	xor    %ecx,%ecx
     afe:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
     b03:	48 83 f8 00          	cmp    $0x0,%rax
     b07:	0f 8f 08 00 00 00    	jg     0xb15
     b0d:	49 89 c5             	mov    %rax,%r13
     b10:	e9 df 12 00 00       	jmp    0x1df4
     b15:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
     b1c:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
     b23:	48 89 c1             	mov    %rax,%rcx
     b26:	48 83 c1 28          	add    $0x28,%rcx
     b2a:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
     b31:	00 28 00 
     b34:	48 29 d1             	sub    %rdx,%rcx
     b37:	48 8b 95 a8 fd ff ff 	mov    -0x258(%rbp),%rdx
     b3e:	48 89 0a             	mov    %rcx,(%rdx)
     b41:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
     b48:	ff 00 00 
     b4b:	48 21 c8             	and    %rcx,%rax
     b4e:	31 c9                	xor    %ecx,%ecx
     b50:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
     b57:	48 89 10             	mov    %rdx,(%rax)
     b5a:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
     b61:	48 89 70 08          	mov    %rsi,0x8(%rax)
     b65:	48 89 48 10          	mov    %rcx,0x10(%rax)
     b69:	48 89 48 18          	mov    %rcx,0x18(%rax)
     b6d:	48 89 48 20          	mov    %rcx,0x20(%rax)
     b71:	49 8b 4c 24 60       	mov    0x60(%r12),%rcx
     b76:	bf 01 00 00 00       	mov    $0x1,%edi
     b7b:	48 01 f9             	add    %rdi,%rcx
     b7e:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
     b83:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
     b8a:	b8 01 00 00 00       	mov    $0x1,%eax
     b8f:	48 89 85 b8 fd ff ff 	mov    %rax,-0x248(%rbp)
     b96:	31 c0                	xor    %eax,%eax
     b98:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
     b9f:	e9 8a 01 00 00       	jmp    0xd2e
     ba4:	49 8b 74 24 10       	mov    0x10(%r12),%rsi
     ba9:	49 8b 44 24 18       	mov    0x18(%r12),%rax
     bae:	48 89 c1             	mov    %rax,%rcx
     bb1:	f3 48 0f b8 c9       	popcnt %rcx,%rcx
     bb6:	ba 40 00 00 00       	mov    $0x40,%edx
     bbb:	48 29 ca             	sub    %rcx,%rdx
     bbe:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
     bc5:	48 8b bd 50 fe ff ff 	mov    -0x1b0(%rbp),%rdi
     bcc:	48 89 d1             	mov    %rdx,%rcx
     bcf:	49 89 f8             	mov    %rdi,%r8
     bd2:	49 d3 e8             	shr    %cl,%r8
     bd5:	31 c9                	xor    %ecx,%ecx
     bd7:	48 8b 95 a8 fd ff ff 	mov    -0x258(%rbp),%rdx
     bde:	48 39 ca             	cmp    %rcx,%rdx
     be1:	ba 00 00 00 00       	mov    $0x0,%edx
     be6:	0f 94 c2             	sete   %dl
     be9:	48 85 d2             	test   %rdx,%rdx
     bec:	49 0f 44 c8          	cmove  %r8,%rcx
     bf0:	ba 01 00 00 00       	mov    $0x1,%edx
     bf5:	49 89 c8             	mov    %rcx,%r8
     bf8:	49 01 d0             	add    %rdx,%r8
     bfb:	49 21 c0             	and    %rax,%r8
     bfe:	b8 28 00 00 00       	mov    $0x28,%eax
     c03:	48 0f af c8          	imul   %rax,%rcx
     c07:	48 8d 04 0e          	lea    (%rsi,%rcx,1),%rax
     c0b:	48 8b 48 10          	mov    0x10(%rax),%rcx
     c0f:	48 85 c9             	test   %rcx,%rcx
     c12:	0f 84 aa 00 00 00    	je     0xcc2
     c18:	48 8b 08             	mov    (%rax),%rcx
     c1b:	4c 8b 48 08          	mov    0x8(%rax),%r9
     c1f:	4c 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%r10
     c26:	49 39 ca             	cmp    %rcx,%r10
     c29:	41 bb 00 00 00 00    	mov    $0x0,%r11d
     c2f:	41 0f 94 c3          	sete   %r11b
     c33:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
     c3a:	4c 39 c9             	cmp    %r9,%rcx
     c3d:	bf 00 00 00 00       	mov    $0x0,%edi
     c42:	40 0f 94 c7          	sete   %dil
     c46:	49 21 fb             	and    %rdi,%r11
     c49:	4d 85 db             	test   %r11,%r11
     c4c:	0f 84 0c 00 00 00    	je     0xc5e
     c52:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
     c59:	e9 4d 00 00 00       	jmp    0xcab
     c5e:	b8 28 00 00 00       	mov    $0x28,%eax
     c63:	4c 0f af c0          	imul   %rax,%r8
     c67:	4a 8d 04 06          	lea    (%rsi,%r8,1),%rax
     c6b:	48 8b 70 10          	mov    0x10(%rax),%rsi
     c6f:	48 85 f6             	test   %rsi,%rsi
     c72:	0f 84 4a 00 00 00    	je     0xcc2
     c78:	48 8b 30             	mov    (%rax),%rsi
     c7b:	48 8b 78 08          	mov    0x8(%rax),%rdi
     c7f:	49 39 f2             	cmp    %rsi,%r10
     c82:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     c88:	41 0f 94 c0          	sete   %r8b
     c8c:	48 39 f9             	cmp    %rdi,%rcx
     c8f:	be 00 00 00 00       	mov    $0x0,%esi
     c94:	40 0f 94 c6          	sete   %sil
     c98:	49 21 f0             	and    %rsi,%r8
     c9b:	4d 85 c0             	test   %r8,%r8
     c9e:	0f 84 1e 00 00 00    	je     0xcc2
     ca4:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
     cab:	31 c0                	xor    %eax,%eax
     cad:	48 89 85 b8 fd ff ff 	mov    %rax,-0x248(%rbp)
     cb4:	31 c0                	xor    %eax,%eax
     cb6:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
     cbd:	e9 6c 00 00 00       	jmp    0xd2e
     cc2:	48 8d 85 d0 fe ff ff 	lea    -0x130(%rbp),%rax
     cc9:	48 89 c1             	mov    %rax,%rcx
     ccc:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
     cd3:	48 89 11             	mov    %rdx,(%rcx)
     cd6:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
     cdd:	48 89 71 08          	mov    %rsi,0x8(%rcx)
     ce1:	48 89 df             	mov    %rbx,%rdi
     ce4:	4c 89 e6             	mov    %r12,%rsi
     ce7:	48 89 ca             	mov    %rcx,%rdx
     cea:	e8 61 f3 ff ff       	call   0x50
     cef:	48 83 f8 00          	cmp    $0x0,%rax
     cf3:	0f 8d 08 00 00 00    	jge    0xd01
     cf9:	49 89 c5             	mov    %rax,%r13
     cfc:	e9 f3 10 00 00       	jmp    0x1df4
     d01:	49 8b 0c 24          	mov    (%r12),%rcx
     d05:	0f b6 51 0d          	movzbl 0xd(%rcx),%edx
     d09:	48 83 e2 01          	and    $0x1,%rdx
     d0d:	49 89 54 24 68       	mov    %rdx,0x68(%r12)
     d12:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
     d19:	b8 01 00 00 00       	mov    $0x1,%eax
     d1e:	48 89 85 b8 fd ff ff 	mov    %rax,-0x248(%rbp)
     d25:	31 c0                	xor    %eax,%eax
     d27:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
     d2e:	48 8b 85 b8 fd ff ff 	mov    -0x248(%rbp),%rax
     d35:	48 85 c0             	test   %rax,%rax
     d38:	0f 84 6b 00 00 00    	je     0xda9
     d3e:	48 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%rax
     d45:	48 8b 8d 40 fe ff ff 	mov    -0x1c0(%rbp),%rcx
     d4c:	48 89 48 10          	mov    %rcx,0x10(%rax)
     d50:	31 d2                	xor    %edx,%edx
     d52:	48 39 d1             	cmp    %rdx,%rcx
     d55:	be 00 00 00 00       	mov    $0x0,%esi
     d5a:	40 0f 95 c6          	setne  %sil
     d5e:	0f b6 78 20          	movzbl 0x20(%rax),%edi
     d62:	48 09 f7             	or     %rsi,%rdi
     d65:	48 0f be ff          	movsbq %dil,%rdi
     d69:	40 88 78 20          	mov    %dil,0x20(%rax)
     d6d:	48 8b b5 38 fe ff ff 	mov    -0x1c8(%rbp),%rsi
     d74:	48 89 70 18          	mov    %rsi,0x18(%rax)
     d78:	4c 8b 85 30 fe ff ff 	mov    -0x1d0(%rbp),%r8
     d7f:	49 39 d0             	cmp    %rdx,%r8
     d82:	41 b9 00 00 00 00    	mov    $0x0,%r9d
     d88:	41 0f 95 c1          	setne  %r9b
     d8c:	40 0f b6 ff          	movzbl %dil,%edi
     d90:	41 ba 02 00 00 00    	mov    $0x2,%r10d
     d96:	4d 85 c9             	test   %r9,%r9
     d99:	4c 0f 44 d2          	cmove  %rdx,%r10
     d9d:	4c 09 d7             	or     %r10,%rdi
     da0:	40 88 78 20          	mov    %dil,0x20(%rax)
     da4:	e9 93 00 00 00       	jmp    0xe3c
     da9:	48 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%rax
     db0:	48 8b 48 10          	mov    0x10(%rax),%rcx
     db4:	48 8b 95 40 fe ff ff 	mov    -0x1c0(%rbp),%rdx
     dbb:	48 01 d1             	add    %rdx,%rcx
     dbe:	48 89 48 10          	mov    %rcx,0x10(%rax)
     dc2:	31 f6                	xor    %esi,%esi
     dc4:	48 39 f1             	cmp    %rsi,%rcx
     dc7:	b9 00 00 00 00       	mov    $0x0,%ecx
     dcc:	0f 95 c1             	setne  %cl
     dcf:	0f b6 78 20          	movzbl 0x20(%rax),%edi
     dd3:	48 09 cf             	or     %rcx,%rdi
     dd6:	48 0f be ff          	movsbq %dil,%rdi
     dda:	40 88 78 20          	mov    %dil,0x20(%rax)
     dde:	48 8b 48 18          	mov    0x18(%rax),%rcx
     de2:	40 0f b6 ff          	movzbl %dil,%edi
     de6:	49 89 f8             	mov    %rdi,%r8
     de9:	49 83 e0 02          	and    $0x2,%r8
     ded:	49 39 f0             	cmp    %rsi,%r8
     df0:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     df6:	41 0f 95 c0          	setne  %r8b
     dfa:	45 31 c9             	xor    %r9d,%r9d
     dfd:	4d 85 c0             	test   %r8,%r8
     e00:	49 0f 44 c9          	cmove  %r9,%rcx
     e04:	4c 8b 8d 30 fe ff ff 	mov    -0x1d0(%rbp),%r9
     e0b:	4d 01 c8             	add    %r9,%r8
     e0e:	4c 8b 95 38 fe ff ff 	mov    -0x1c8(%rbp),%r10
     e15:	4c 01 d1             	add    %r10,%rcx
     e18:	48 89 48 18          	mov    %rcx,0x18(%rax)
     e1c:	49 39 f0             	cmp    %rsi,%r8
     e1f:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     e25:	41 0f 95 c0          	setne  %r8b
     e29:	b9 02 00 00 00       	mov    $0x2,%ecx
     e2e:	4d 85 c0             	test   %r8,%r8
     e31:	48 0f 44 ce          	cmove  %rsi,%rcx
     e35:	48 09 cf             	or     %rcx,%rdi
     e38:	40 88 78 20          	mov    %dil,0x20(%rax)
     e3c:	b8 01 00 00 00       	mov    $0x1,%eax
     e41:	48 8b 8d c8 fd ff ff 	mov    -0x238(%rbp),%rcx
     e48:	48 63 11             	movslq (%rcx),%rdx
     e4b:	48 8b 8d e8 fd ff ff 	mov    -0x218(%rbp),%rcx
     e52:	48 31 c1             	xor    %rax,%rcx
     e55:	31 c0                	xor    %eax,%eax
     e57:	48 85 c9             	test   %rcx,%rcx
     e5a:	48 0f 44 d0          	cmove  %rax,%rdx
     e5e:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
     e65:	79 37 9e 
     e68:	48 be 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%rsi
     e6f:	79 37 9e 
     e72:	48 8b bd e0 fd ff ff 	mov    -0x220(%rbp),%rdi
     e79:	48 31 fe             	xor    %rdi,%rsi
     e7c:	48 0f af f0          	imul   %rax,%rsi
     e80:	49 89 f0             	mov    %rsi,%r8
     e83:	49 c1 e8 1d          	shr    $0x1d,%r8
     e87:	4c 31 c6             	xor    %r8,%rsi
     e8a:	4c 8b 85 d0 fd ff ff 	mov    -0x230(%rbp),%r8
     e91:	4c 31 c6             	xor    %r8,%rsi
     e94:	48 0f af f0          	imul   %rax,%rsi
     e98:	49 89 f1             	mov    %rsi,%r9
     e9b:	49 c1 e9 1d          	shr    $0x1d,%r9
     e9f:	4c 31 ce             	xor    %r9,%rsi
     ea2:	48 0f af f0          	imul   %rax,%rsi
     ea6:	48 89 bd 60 fe ff ff 	mov    %rdi,-0x1a0(%rbp)
     ead:	4c 89 85 58 fe ff ff 	mov    %r8,-0x1a8(%rbp)
     eb4:	48 89 b5 50 fe ff ff 	mov    %rsi,-0x1b0(%rbp)
     ebb:	b8 01 00 00 00       	mov    $0x1,%eax
     ec0:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
     ec7:	48 89 95 38 fe ff ff 	mov    %rdx,-0x1c8(%rbp)
     ece:	48 89 8d 30 fe ff ff 	mov    %rcx,-0x1d0(%rbp)
     ed5:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
     ed9:	b9 01 00 00 00       	mov    $0x1,%ecx
     ede:	48 89 c2             	mov    %rax,%rdx
     ee1:	48 01 ca             	add    %rcx,%rdx
     ee4:	48 89 55 d0          	mov    %rdx,-0x30(%rbp)
     ee8:	48 8b 95 d8 fd ff ff 	mov    -0x228(%rbp),%rdx
     eef:	48 89 95 68 fe ff ff 	mov    %rdx,-0x198(%rbp)
     ef6:	48 89 8d 48 fe ff ff 	mov    %rcx,-0x1b8(%rbp)
     efd:	e9 8f f6 ff ff       	jmp    0x591
     f02:	4c 8b b5 a0 fe ff ff 	mov    -0x160(%rbp),%r14
     f09:	45 31 ff             	xor    %r15d,%r15d
     f0c:	31 c0                	xor    %eax,%eax
     f0e:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
     f15:	31 c0                	xor    %eax,%eax
     f17:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
     f1e:	48 b8 df a3 df 2e ad 	movabs $0x522882ad2edfa3df,%rax
     f25:	82 28 52 
     f28:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
     f2f:	31 c0                	xor    %eax,%eax
     f31:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
     f38:	31 c0                	xor    %eax,%eax
     f3a:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
     f41:	31 c0                	xor    %eax,%eax
     f43:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
     f47:	31 c0                	xor    %eax,%eax
     f49:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
     f50:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
     f57:	49 39 c6             	cmp    %rax,%r14
     f5a:	0f 8c 6b 00 00 00    	jl     0xfcb
     f60:	4c 89 bd 28 fe ff ff 	mov    %r15,-0x1d8(%rbp)
     f67:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
     f6e:	48 89 8d 10 fe ff ff 	mov    %rcx,-0x1f0(%rbp)
     f75:	48 8b 8d 80 fe ff ff 	mov    -0x180(%rbp),%rcx
     f7c:	48 89 8d 08 fe ff ff 	mov    %rcx,-0x1f8(%rbp)
     f83:	48 8b 8d 78 fe ff ff 	mov    -0x188(%rbp),%rcx
     f8a:	48 89 8d f0 fd ff ff 	mov    %rcx,-0x210(%rbp)
     f91:	48 8b 8d b8 fe ff ff 	mov    -0x148(%rbp),%rcx
     f98:	48 89 8d 20 fe ff ff 	mov    %rcx,-0x1e0(%rbp)
     f9f:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
     fa6:	48 89 8d 18 fe ff ff 	mov    %rcx,-0x1e8(%rbp)
     fad:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
     fb1:	48 89 8d 00 fe ff ff 	mov    %rcx,-0x200(%rbp)
     fb8:	48 8b 8d 68 fe ff ff 	mov    -0x198(%rbp),%rcx
     fbf:	48 89 8d f8 fd ff ff 	mov    %rcx,-0x208(%rbp)
     fc6:	e9 a2 07 00 00       	jmp    0x176d
     fcb:	48 8b 8d 88 fe ff ff 	mov    -0x178(%rbp),%rcx
     fd2:	4a 8d 14 b1          	lea    (%rcx,%r14,4),%rdx
     fd6:	48 8b b5 70 fe ff ff 	mov    -0x190(%rbp),%rsi
     fdd:	4a 8d 3c b6          	lea    (%rsi,%r14,4),%rdi
     fe1:	4d 89 f8             	mov    %r15,%r8
     fe4:	49 83 c0 01          	add    $0x1,%r8
     fe8:	4c 63 0a             	movslq (%rdx),%r9
     feb:	48 8b 95 a8 fe ff ff 	mov    -0x158(%rbp),%rdx
     ff2:	48 85 d2             	test   %rdx,%rdx
     ff5:	48 89 bd 60 fe ff ff 	mov    %rdi,-0x1a0(%rbp)
     ffc:	4c 89 85 58 fe ff ff 	mov    %r8,-0x1a8(%rbp)
    1003:	4c 89 8d 50 fe ff ff 	mov    %r9,-0x1b0(%rbp)
    100a:	0f 84 10 00 00 00    	je     0x1020
    1010:	4c 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%r10
    1017:	4d 85 d2             	test   %r10,%r10
    101a:	0f 85 39 00 00 00    	jne    0x1059
    1020:	48 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%rax
    1027:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
    102e:	48 39 c8             	cmp    %rcx,%rax
    1031:	ba 00 00 00 00       	mov    $0x0,%edx
    1036:	0f 94 c2             	sete   %dl
    1039:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
    1040:	48 83 fe 00          	cmp    $0x0,%rsi
    1044:	bf 00 00 00 00       	mov    $0x0,%edi
    1049:	40 0f 94 c7          	sete   %dil
    104d:	48 21 fa             	and    %rdi,%rdx
    1050:	48 85 d2             	test   %rdx,%rdx
    1053:	0f 84 47 00 00 00    	je     0x10a0
    1059:	48 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%rax
    1060:	48 89 c1             	mov    %rax,%rcx
    1063:	48 83 c1 01          	add    $0x1,%rcx
    1067:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
    106e:	48 63 32             	movslq (%rdx),%rsi
    1071:	48 8b bd 68 fe ff ff 	mov    -0x198(%rbp),%rdi
    1078:	49 89 f8             	mov    %rdi,%r8
    107b:	49 83 c0 01          	add    $0x1,%r8
    107f:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
    1083:	4d 89 ca             	mov    %r9,%r10
    1086:	49 01 f2             	add    %rsi,%r10
    1089:	48 89 8d 90 fe ff ff 	mov    %rcx,-0x170(%rbp)
    1090:	4c 89 55 d0          	mov    %r10,-0x30(%rbp)
    1094:	4c 89 85 68 fe ff ff 	mov    %r8,-0x198(%rbp)
    109b:	e9 ac 06 00 00       	jmp    0x174c
    10a0:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
    10a7:	48 85 c0             	test   %rax,%rax
    10aa:	0f 84 21 06 00 00    	je     0x16d1
    10b0:	31 c9                	xor    %ecx,%ecx
    10b2:	49 8d 54 0c 70       	lea    0x70(%r12,%rcx,1),%rdx
    10b7:	48 8b 32             	mov    (%rdx),%rsi
    10ba:	48 85 f6             	test   %rsi,%rsi
    10bd:	0f 84 3d 02 00 00    	je     0x1300
    10c3:	49 8d 54 0c 70       	lea    0x70(%r12,%rcx,1),%rdx
    10c8:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    10cc:	49 8b 3c 24          	mov    (%r12),%rdi
    10d0:	44 8b 07             	mov    (%rdi),%r8d
    10d3:	48 8b bd a0 fe ff ff 	mov    -0x160(%rbp),%rdi
    10da:	49 89 f9             	mov    %rdi,%r9
    10dd:	49 29 f1             	sub    %rsi,%r9
    10e0:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
    10e7:	48 39 ce             	cmp    %rcx,%rsi
    10ea:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    10f0:	41 0f 95 c2          	setne  %r10b
    10f4:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    10f8:	4c 89 da             	mov    %r11,%rdx
    10fb:	4d 85 d2             	test   %r10,%r10
    10fe:	49 0f 44 d1          	cmove  %r9,%rdx
    1102:	4d 85 d2             	test   %r10,%r10
    1105:	4d 0f 44 c3          	cmove  %r11,%r8
    1109:	4d 8b 4c 24 10       	mov    0x10(%r12),%r9
    110e:	41 ba 28 00 00 00    	mov    $0x28,%r10d
    1114:	49 89 d3             	mov    %rdx,%r11
    1117:	4d 0f af da          	imul   %r10,%r11
    111b:	4f 8d 14 19          	lea    (%r9,%r11,1),%r10
    111f:	4c 39 c2             	cmp    %r8,%rdx
    1122:	0f 83 b2 00 00 00    	jae    0x11da
    1128:	4d 8b 42 10          	mov    0x10(%r10),%r8
    112c:	4d 85 c0             	test   %r8,%r8
    112f:	0f 84 16 00 00 00    	je     0x114b
    1135:	4c 89 95 48 fe ff ff 	mov    %r10,-0x1b8(%rbp)
    113c:	45 31 c0             	xor    %r8d,%r8d
    113f:	4c 89 85 40 fe ff ff 	mov    %r8,-0x1c0(%rbp)
    1146:	e9 7e 04 00 00       	jmp    0x15c9
    114b:	45 31 c0             	xor    %r8d,%r8d
    114e:	49 89 3a             	mov    %rdi,(%r10)
    1151:	49 89 72 08          	mov    %rsi,0x8(%r10)
    1155:	4d 89 42 10          	mov    %r8,0x10(%r10)
    1159:	4d 89 42 18          	mov    %r8,0x18(%r10)
    115d:	4d 89 42 20          	mov    %r8,0x20(%r10)
    1161:	4d 8b 04 24          	mov    (%r12),%r8
    1165:	45 8b 48 04          	mov    0x4(%r8),%r9d
    1169:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    116f:	4d 01 d9             	add    %r11,%r9
    1172:	45 89 48 04          	mov    %r9d,0x4(%r8)
    1176:	4d 8b 4c 24 38       	mov    0x38(%r12),%r9
    117b:	b8 40 00 00 00       	mov    $0x40,%eax
    1180:	4c 29 c8             	sub    %r9,%rax
    1183:	48 8b b5 78 fe ff ff 	mov    -0x188(%rbp),%rsi
    118a:	48 89 c1             	mov    %rax,%rcx
    118d:	48 89 f7             	mov    %rsi,%rdi
    1190:	48 d3 ef             	shr    %cl,%rdi
    1193:	31 c0                	xor    %eax,%eax
    1195:	49 39 c1             	cmp    %rax,%r9
    1198:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    119e:	41 0f 94 c1          	sete   %r9b
    11a2:	4d 85 c9             	test   %r9,%r9
    11a5:	48 0f 44 c7          	cmove  %rdi,%rax
    11a9:	41 8b 48 4c          	mov    0x4c(%r8),%ecx
    11ad:	49 8d 3c 08          	lea    (%r8,%rcx,1),%rdi
    11b1:	48 8d 0c 97          	lea    (%rdi,%rdx,4),%rcx
    11b5:	89 01                	mov    %eax,(%rcx)
    11b7:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    11be:	41 89 40 50          	mov    %eax,0x50(%r8)
    11c2:	4c 89 95 48 fe ff ff 	mov    %r10,-0x1b8(%rbp)
    11c9:	b8 01 00 00 00       	mov    $0x1,%eax
    11ce:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
    11d5:	e9 ef 03 00 00       	jmp    0x15c9
    11da:	49 8b 44 24 38       	mov    0x38(%r12),%rax
    11df:	b9 40 00 00 00       	mov    $0x40,%ecx
    11e4:	48 29 c1             	sub    %rax,%rcx
    11e7:	48 89 8d 38 fe ff ff 	mov    %rcx,-0x1c8(%rbp)
    11ee:	48 8b 95 78 fe ff ff 	mov    -0x188(%rbp),%rdx
    11f5:	48 8b b5 38 fe ff ff 	mov    -0x1c8(%rbp),%rsi
    11fc:	48 89 f1             	mov    %rsi,%rcx
    11ff:	48 89 d7             	mov    %rdx,%rdi
    1202:	48 d3 ef             	shr    %cl,%rdi
    1205:	31 c9                	xor    %ecx,%ecx
    1207:	48 39 c8             	cmp    %rcx,%rax
    120a:	b8 00 00 00 00       	mov    $0x0,%eax
    120f:	0f 94 c0             	sete   %al
    1212:	48 85 c0             	test   %rax,%rax
    1215:	48 0f 44 cf          	cmove  %rdi,%rcx
    1219:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    121e:	48 8d 34 c8          	lea    (%rax,%rcx,8),%rsi
    1222:	48 8b 06             	mov    (%rsi),%rax
    1225:	48 bf 00 00 00 00 00 	movabs $0x28000000000000,%rdi
    122c:	00 28 00 
    122f:	48 39 f8             	cmp    %rdi,%rax
    1232:	48 89 b5 38 fe ff ff 	mov    %rsi,-0x1c8(%rbp)
    1239:	0f 82 0c 00 00 00    	jb     0x124b
    123f:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
    1246:	e9 36 00 00 00       	jmp    0x1281
    124b:	49 8b 44 24 60       	mov    0x60(%r12),%rax
    1250:	48 89 df             	mov    %rbx,%rdi
    1253:	4c 89 e6             	mov    %r12,%rsi
    1256:	48 89 ca             	mov    %rcx,%rdx
    1259:	48 89 c1             	mov    %rax,%rcx
    125c:	e8 df ed ff ff       	call   0x40
    1261:	31 c9                	xor    %ecx,%ecx
    1263:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
    1268:	48 83 f8 00          	cmp    $0x0,%rax
    126c:	0f 8f 08 00 00 00    	jg     0x127a
    1272:	49 89 c5             	mov    %rax,%r13
    1275:	e9 7a 0b 00 00       	jmp    0x1df4
    127a:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
    1281:	48 8b 85 30 fe ff ff 	mov    -0x1d0(%rbp),%rax
    1288:	48 89 c1             	mov    %rax,%rcx
    128b:	48 83 c1 28          	add    $0x28,%rcx
    128f:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    1296:	00 28 00 
    1299:	48 29 d1             	sub    %rdx,%rcx
    129c:	48 8b 95 38 fe ff ff 	mov    -0x1c8(%rbp),%rdx
    12a3:	48 89 0a             	mov    %rcx,(%rdx)
    12a6:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    12ad:	ff 00 00 
    12b0:	48 21 c8             	and    %rcx,%rax
    12b3:	31 c9                	xor    %ecx,%ecx
    12b5:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
    12bc:	48 89 10             	mov    %rdx,(%rax)
    12bf:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
    12c6:	48 89 70 08          	mov    %rsi,0x8(%rax)
    12ca:	48 89 48 10          	mov    %rcx,0x10(%rax)
    12ce:	48 89 48 18          	mov    %rcx,0x18(%rax)
    12d2:	48 89 48 20          	mov    %rcx,0x20(%rax)
    12d6:	49 8b 4c 24 60       	mov    0x60(%r12),%rcx
    12db:	bf 01 00 00 00       	mov    $0x1,%edi
    12e0:	48 01 f9             	add    %rdi,%rcx
    12e3:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
    12e8:	48 89 85 48 fe ff ff 	mov    %rax,-0x1b8(%rbp)
    12ef:	b8 01 00 00 00       	mov    $0x1,%eax
    12f4:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
    12fb:	e9 c9 02 00 00       	jmp    0x15c9
    1300:	49 8b 44 24 68       	mov    0x68(%r12),%rax
    1305:	48 85 c0             	test   %rax,%rax
    1308:	0f 84 2f 01 00 00    	je     0x143d
    130e:	49 8b 44 24 38       	mov    0x38(%r12),%rax
    1313:	b9 40 00 00 00       	mov    $0x40,%ecx
    1318:	48 29 c1             	sub    %rax,%rcx
    131b:	48 89 8d 30 fe ff ff 	mov    %rcx,-0x1d0(%rbp)
    1322:	48 8b 95 78 fe ff ff 	mov    -0x188(%rbp),%rdx
    1329:	48 8b b5 30 fe ff ff 	mov    -0x1d0(%rbp),%rsi
    1330:	48 89 f1             	mov    %rsi,%rcx
    1333:	48 89 d7             	mov    %rdx,%rdi
    1336:	48 d3 ef             	shr    %cl,%rdi
    1339:	31 c9                	xor    %ecx,%ecx
    133b:	48 39 c8             	cmp    %rcx,%rax
    133e:	b8 00 00 00 00       	mov    $0x0,%eax
    1343:	0f 94 c0             	sete   %al
    1346:	48 85 c0             	test   %rax,%rax
    1349:	48 0f 44 cf          	cmove  %rdi,%rcx
    134d:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    1352:	48 8d 34 c8          	lea    (%rax,%rcx,8),%rsi
    1356:	48 8b 06             	mov    (%rsi),%rax
    1359:	48 bf 00 00 00 00 00 	movabs $0x28000000000000,%rdi
    1360:	00 28 00 
    1363:	48 39 f8             	cmp    %rdi,%rax
    1366:	48 89 b5 30 fe ff ff 	mov    %rsi,-0x1d0(%rbp)
    136d:	0f 82 0c 00 00 00    	jb     0x137f
    1373:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
    137a:	e9 36 00 00 00       	jmp    0x13b5
    137f:	49 8b 44 24 60       	mov    0x60(%r12),%rax
    1384:	48 89 df             	mov    %rbx,%rdi
    1387:	4c 89 e6             	mov    %r12,%rsi
    138a:	48 89 ca             	mov    %rcx,%rdx
    138d:	48 89 c1             	mov    %rax,%rcx
    1390:	e8 ab ec ff ff       	call   0x40
    1395:	31 c9                	xor    %ecx,%ecx
    1397:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
    139c:	48 83 f8 00          	cmp    $0x0,%rax
    13a0:	0f 8f 08 00 00 00    	jg     0x13ae
    13a6:	49 89 c5             	mov    %rax,%r13
    13a9:	e9 46 0a 00 00       	jmp    0x1df4
    13ae:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
    13b5:	48 8b 85 38 fe ff ff 	mov    -0x1c8(%rbp),%rax
    13bc:	48 89 c1             	mov    %rax,%rcx
    13bf:	48 83 c1 28          	add    $0x28,%rcx
    13c3:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    13ca:	00 28 00 
    13cd:	48 29 d1             	sub    %rdx,%rcx
    13d0:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
    13d7:	48 89 0a             	mov    %rcx,(%rdx)
    13da:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    13e1:	ff 00 00 
    13e4:	48 21 c8             	and    %rcx,%rax
    13e7:	31 c9                	xor    %ecx,%ecx
    13e9:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
    13f0:	48 89 10             	mov    %rdx,(%rax)
    13f3:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
    13fa:	48 89 70 08          	mov    %rsi,0x8(%rax)
    13fe:	48 89 48 10          	mov    %rcx,0x10(%rax)
    1402:	48 89 48 18          	mov    %rcx,0x18(%rax)
    1406:	48 89 48 20          	mov    %rcx,0x20(%rax)
    140a:	49 8b 4c 24 60       	mov    0x60(%r12),%rcx
    140f:	bf 01 00 00 00       	mov    $0x1,%edi
    1414:	48 01 f9             	add    %rdi,%rcx
    1417:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
    141c:	48 89 85 48 fe ff ff 	mov    %rax,-0x1b8(%rbp)
    1423:	b8 01 00 00 00       	mov    $0x1,%eax
    1428:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
    142f:	31 c0                	xor    %eax,%eax
    1431:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
    1438:	e9 8c 01 00 00       	jmp    0x15c9
    143d:	49 8b 74 24 10       	mov    0x10(%r12),%rsi
    1442:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    1447:	48 89 c1             	mov    %rax,%rcx
    144a:	f3 48 0f b8 c9       	popcnt %rcx,%rcx
    144f:	ba 40 00 00 00       	mov    $0x40,%edx
    1454:	48 29 ca             	sub    %rcx,%rdx
    1457:	48 89 8d 30 fe ff ff 	mov    %rcx,-0x1d0(%rbp)
    145e:	48 8b bd 78 fe ff ff 	mov    -0x188(%rbp),%rdi
    1465:	48 89 d1             	mov    %rdx,%rcx
    1468:	49 89 f8             	mov    %rdi,%r8
    146b:	49 d3 e8             	shr    %cl,%r8
    146e:	31 c9                	xor    %ecx,%ecx
    1470:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
    1477:	48 39 ca             	cmp    %rcx,%rdx
    147a:	ba 00 00 00 00       	mov    $0x0,%edx
    147f:	0f 94 c2             	sete   %dl
    1482:	48 85 d2             	test   %rdx,%rdx
    1485:	49 0f 44 c8          	cmove  %r8,%rcx
    1489:	ba 01 00 00 00       	mov    $0x1,%edx
    148e:	49 89 c8             	mov    %rcx,%r8
    1491:	49 01 d0             	add    %rdx,%r8
    1494:	4d 89 c1             	mov    %r8,%r9
    1497:	49 21 c1             	and    %rax,%r9
    149a:	b8 28 00 00 00       	mov    $0x28,%eax
    149f:	48 0f af c8          	imul   %rax,%rcx
    14a3:	4c 8d 04 0e          	lea    (%rsi,%rcx,1),%r8
    14a7:	49 8b 40 10          	mov    0x10(%r8),%rax
    14ab:	48 85 c0             	test   %rax,%rax
    14ae:	0f 84 a9 00 00 00    	je     0x155d
    14b4:	49 8b 00             	mov    (%r8),%rax
    14b7:	49 8b 48 08          	mov    0x8(%r8),%rcx
    14bb:	4c 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%r10
    14c2:	49 39 c2             	cmp    %rax,%r10
    14c5:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    14cb:	41 0f 94 c3          	sete   %r11b
    14cf:	48 8b 85 80 fe ff ff 	mov    -0x180(%rbp),%rax
    14d6:	48 39 c8             	cmp    %rcx,%rax
    14d9:	bf 00 00 00 00       	mov    $0x0,%edi
    14de:	40 0f 94 c7          	sete   %dil
    14e2:	49 21 fb             	and    %rdi,%r11
    14e5:	4d 85 db             	test   %r11,%r11
    14e8:	0f 84 0c 00 00 00    	je     0x14fa
    14ee:	4c 89 85 48 fe ff ff 	mov    %r8,-0x1b8(%rbp)
    14f5:	e9 4c 00 00 00       	jmp    0x1546
    14fa:	b9 28 00 00 00       	mov    $0x28,%ecx
    14ff:	4c 0f af c9          	imul   %rcx,%r9
    1503:	4a 8d 3c 0e          	lea    (%rsi,%r9,1),%rdi
    1507:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    150b:	48 85 c9             	test   %rcx,%rcx
    150e:	0f 84 49 00 00 00    	je     0x155d
    1514:	48 8b 0f             	mov    (%rdi),%rcx
    1517:	48 8b 77 08          	mov    0x8(%rdi),%rsi
    151b:	49 39 ca             	cmp    %rcx,%r10
    151e:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1524:	41 0f 94 c0          	sete   %r8b
    1528:	48 39 f0             	cmp    %rsi,%rax
    152b:	b9 00 00 00 00       	mov    $0x0,%ecx
    1530:	0f 94 c1             	sete   %cl
    1533:	49 21 c8             	and    %rcx,%r8
    1536:	4d 85 c0             	test   %r8,%r8
    1539:	0f 84 1e 00 00 00    	je     0x155d
    153f:	48 89 bd 48 fe ff ff 	mov    %rdi,-0x1b8(%rbp)
    1546:	31 c0                	xor    %eax,%eax
    1548:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
    154f:	31 c0                	xor    %eax,%eax
    1551:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
    1558:	e9 6c 00 00 00       	jmp    0x15c9
    155d:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
    1564:	48 89 c1             	mov    %rax,%rcx
    1567:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
    156e:	48 89 11             	mov    %rdx,(%rcx)
    1571:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
    1578:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    157c:	48 89 df             	mov    %rbx,%rdi
    157f:	4c 89 e6             	mov    %r12,%rsi
    1582:	48 89 ca             	mov    %rcx,%rdx
    1585:	e8 c6 ea ff ff       	call   0x50
    158a:	48 83 f8 00          	cmp    $0x0,%rax
    158e:	0f 8d 08 00 00 00    	jge    0x159c
    1594:	49 89 c5             	mov    %rax,%r13
    1597:	e9 58 08 00 00       	jmp    0x1df4
    159c:	49 8b 0c 24          	mov    (%r12),%rcx
    15a0:	0f b6 51 0d          	movzbl 0xd(%rcx),%edx
    15a4:	48 83 e2 01          	and    $0x1,%rdx
    15a8:	49 89 54 24 68       	mov    %rdx,0x68(%r12)
    15ad:	48 89 85 48 fe ff ff 	mov    %rax,-0x1b8(%rbp)
    15b4:	b8 01 00 00 00       	mov    $0x1,%eax
    15b9:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
    15c0:	31 c0                	xor    %eax,%eax
    15c2:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
    15c9:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
    15d0:	48 85 c0             	test   %rax,%rax
    15d3:	0f 84 68 00 00 00    	je     0x1641
    15d9:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
    15e0:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
    15e7:	48 89 48 10          	mov    %rcx,0x10(%rax)
    15eb:	31 d2                	xor    %edx,%edx
    15ed:	48 39 d1             	cmp    %rdx,%rcx
    15f0:	be 00 00 00 00       	mov    $0x0,%esi
    15f5:	40 0f 95 c6          	setne  %sil
    15f9:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    15fd:	48 09 f7             	or     %rsi,%rdi
    1600:	48 0f be ff          	movsbq %dil,%rdi
    1604:	40 88 78 20          	mov    %dil,0x20(%rax)
    1608:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
    160c:	48 89 70 18          	mov    %rsi,0x18(%rax)
    1610:	4c 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%r8
    1617:	49 39 d0             	cmp    %rdx,%r8
    161a:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    1620:	41 0f 95 c1          	setne  %r9b
    1624:	40 0f b6 ff          	movzbl %dil,%edi
    1628:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    162e:	4d 85 c9             	test   %r9,%r9
    1631:	4c 0f 44 d2          	cmove  %rdx,%r10
    1635:	4c 09 d7             	or     %r10,%rdi
    1638:	40 88 78 20          	mov    %dil,0x20(%rax)
    163c:	e9 90 00 00 00       	jmp    0x16d1
    1641:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
    1648:	48 8b 48 10          	mov    0x10(%rax),%rcx
    164c:	48 8b 95 90 fe ff ff 	mov    -0x170(%rbp),%rdx
    1653:	48 01 d1             	add    %rdx,%rcx
    1656:	48 89 48 10          	mov    %rcx,0x10(%rax)
    165a:	31 f6                	xor    %esi,%esi
    165c:	48 39 f1             	cmp    %rsi,%rcx
    165f:	b9 00 00 00 00       	mov    $0x0,%ecx
    1664:	0f 95 c1             	setne  %cl
    1667:	0f b6 78 20          	movzbl 0x20(%rax),%edi
    166b:	48 09 cf             	or     %rcx,%rdi
    166e:	48 0f be ff          	movsbq %dil,%rdi
    1672:	40 88 78 20          	mov    %dil,0x20(%rax)
    1676:	48 8b 48 18          	mov    0x18(%rax),%rcx
    167a:	40 0f b6 ff          	movzbl %dil,%edi
    167e:	49 89 f8             	mov    %rdi,%r8
    1681:	49 83 e0 02          	and    $0x2,%r8
    1685:	49 39 f0             	cmp    %rsi,%r8
    1688:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    168e:	41 0f 95 c0          	setne  %r8b
    1692:	45 31 c9             	xor    %r9d,%r9d
    1695:	4d 85 c0             	test   %r8,%r8
    1698:	49 0f 44 c9          	cmove  %r9,%rcx
    169c:	4c 8b 8d 68 fe ff ff 	mov    -0x198(%rbp),%r9
    16a3:	4d 01 c8             	add    %r9,%r8
    16a6:	4c 8b 55 d0          	mov    -0x30(%rbp),%r10
    16aa:	4c 01 d1             	add    %r10,%rcx
    16ad:	48 89 48 18          	mov    %rcx,0x18(%rax)
    16b1:	49 39 f0             	cmp    %rsi,%r8
    16b4:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    16ba:	41 0f 95 c0          	setne  %r8b
    16be:	b9 02 00 00 00       	mov    $0x2,%ecx
    16c3:	4d 85 c0             	test   %r8,%r8
    16c6:	48 0f 44 ce          	cmove  %rsi,%rcx
    16ca:	48 09 cf             	or     %rcx,%rdi
    16cd:	40 88 78 20          	mov    %dil,0x20(%rax)
    16d1:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
    16d8:	48 63 08             	movslq (%rax),%rcx
    16db:	48 b8 15 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c15,%rax
    16e2:	79 37 9e 
    16e5:	48 ba 17 7c 4a 7f b9 	movabs $0x9e3779b97f4a7c17,%rdx
    16ec:	79 37 9e 
    16ef:	48 8b b5 50 fe ff ff 	mov    -0x1b0(%rbp),%rsi
    16f6:	48 31 f2             	xor    %rsi,%rdx
    16f9:	48 0f af d0          	imul   %rax,%rdx
    16fd:	48 89 d7             	mov    %rdx,%rdi
    1700:	48 c1 ef 1d          	shr    $0x1d,%rdi
    1704:	48 31 fa             	xor    %rdi,%rdx
    1707:	48 0f af d0          	imul   %rax,%rdx
    170b:	48 89 d7             	mov    %rdx,%rdi
    170e:	48 c1 ef 1d          	shr    $0x1d,%rdi
    1712:	48 31 fa             	xor    %rdi,%rdx
    1715:	48 0f af d0          	imul   %rax,%rdx
    1719:	48 89 b5 a0 fe ff ff 	mov    %rsi,-0x160(%rbp)
    1720:	31 c0                	xor    %eax,%eax
    1722:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
    1729:	48 89 95 78 fe ff ff 	mov    %rdx,-0x188(%rbp)
    1730:	b8 01 00 00 00       	mov    $0x1,%eax
    1735:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
    173c:	48 89 4d d0          	mov    %rcx,-0x30(%rbp)
    1740:	b8 01 00 00 00       	mov    $0x1,%eax
    1745:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
    174c:	b8 01 00 00 00       	mov    $0x1,%eax
    1751:	4c 89 f1             	mov    %r14,%rcx
    1754:	48 01 c1             	add    %rax,%rcx
    1757:	49 89 ce             	mov    %rcx,%r14
    175a:	4c 8b bd 58 fe ff ff 	mov    -0x1a8(%rbp),%r15
    1761:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
    1768:	e9 e3 f7 ff ff       	jmp    0xf50
    176d:	48 8b 85 20 fe ff ff 	mov    -0x1e0(%rbp),%rax
    1774:	48 85 c0             	test   %rax,%rax
    1777:	0f 84 d5 05 00 00    	je     0x1d52
    177d:	31 c0                	xor    %eax,%eax
    177f:	49 8d 4c 04 70       	lea    0x70(%r12,%rax,1),%rcx
    1784:	48 8b 11             	mov    (%rcx),%rdx
    1787:	48 85 d2             	test   %rdx,%rdx
    178a:	0f 84 2a 02 00 00    	je     0x19ba
    1790:	49 8d 4c 04 70       	lea    0x70(%r12,%rax,1),%rcx
    1795:	48 8b 51 08          	mov    0x8(%rcx),%rdx
    1799:	49 8b 34 24          	mov    (%r12),%rsi
    179d:	8b 3e                	mov    (%rsi),%edi
    179f:	48 8b b5 10 fe ff ff 	mov    -0x1f0(%rbp),%rsi
    17a6:	49 89 f0             	mov    %rsi,%r8
    17a9:	49 29 d0             	sub    %rdx,%r8
    17ac:	48 8b 95 08 fe ff ff 	mov    -0x1f8(%rbp),%rdx
    17b3:	48 39 c2             	cmp    %rax,%rdx
    17b6:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    17bc:	41 0f 95 c1          	setne  %r9b
    17c0:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    17c4:	4c 89 d1             	mov    %r10,%rcx
    17c7:	4d 85 c9             	test   %r9,%r9
    17ca:	49 0f 44 c8          	cmove  %r8,%rcx
    17ce:	4d 85 c9             	test   %r9,%r9
    17d1:	49 0f 44 fa          	cmove  %r10,%rdi
    17d5:	4d 8b 44 24 10       	mov    0x10(%r12),%r8
    17da:	41 b9 28 00 00 00    	mov    $0x28,%r9d
    17e0:	49 89 ca             	mov    %rcx,%r10
    17e3:	4d 0f af d1          	imul   %r9,%r10
    17e7:	4f 8d 0c 10          	lea    (%r8,%r10,1),%r9
    17eb:	48 39 f9             	cmp    %rdi,%rcx
    17ee:	0f 83 aa 00 00 00    	jae    0x189e
    17f4:	49 8b 79 10          	mov    0x10(%r9),%rdi
    17f8:	48 85 ff             	test   %rdi,%rdi
    17fb:	0f 84 0b 00 00 00    	je     0x180c
    1801:	4d 89 ce             	mov    %r9,%r14
    1804:	45 31 ff             	xor    %r15d,%r15d
    1807:	e9 50 04 00 00       	jmp    0x1c5c
    180c:	31 ff                	xor    %edi,%edi
    180e:	49 89 31             	mov    %rsi,(%r9)
    1811:	49 89 51 08          	mov    %rdx,0x8(%r9)
    1815:	49 89 79 10          	mov    %rdi,0x10(%r9)
    1819:	49 89 79 18          	mov    %rdi,0x18(%r9)
    181d:	49 89 79 20          	mov    %rdi,0x20(%r9)
    1821:	49 8b 3c 24          	mov    (%r12),%rdi
    1825:	44 8b 47 04          	mov    0x4(%rdi),%r8d
    1829:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    182f:	4d 01 d0             	add    %r10,%r8
    1832:	44 89 47 04          	mov    %r8d,0x4(%rdi)
    1836:	4d 8b 44 24 38       	mov    0x38(%r12),%r8
    183b:	41 bb 40 00 00 00    	mov    $0x40,%r11d
    1841:	4d 29 c3             	sub    %r8,%r11
    1844:	48 89 8d 20 fe ff ff 	mov    %rcx,-0x1e0(%rbp)
    184b:	48 8b 95 f0 fd ff ff 	mov    -0x210(%rbp),%rdx
    1852:	4c 89 d9             	mov    %r11,%rcx
    1855:	48 89 d6             	mov    %rdx,%rsi
    1858:	48 d3 ee             	shr    %cl,%rsi
    185b:	31 c9                	xor    %ecx,%ecx
    185d:	49 39 c8             	cmp    %rcx,%r8
    1860:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1866:	41 0f 94 c0          	sete   %r8b
    186a:	4d 85 c0             	test   %r8,%r8
    186d:	48 0f 44 ce          	cmove  %rsi,%rcx
    1871:	8b 77 4c             	mov    0x4c(%rdi),%esi
    1874:	4c 8d 04 37          	lea    (%rdi,%rsi,1),%r8
    1878:	48 8b b5 20 fe ff ff 	mov    -0x1e0(%rbp),%rsi
    187f:	4d 8d 1c b0          	lea    (%r8,%rsi,4),%r11
    1883:	41 89 0b             	mov    %ecx,(%r11)
    1886:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    188d:	89 4f 50             	mov    %ecx,0x50(%rdi)
    1890:	4d 89 ce             	mov    %r9,%r14
    1893:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    1899:	e9 be 03 00 00       	jmp    0x1c5c
    189e:	49 8b 44 24 38       	mov    0x38(%r12),%rax
    18a3:	b9 40 00 00 00       	mov    $0x40,%ecx
    18a8:	48 29 c1             	sub    %rax,%rcx
    18ab:	48 89 8d 20 fe ff ff 	mov    %rcx,-0x1e0(%rbp)
    18b2:	48 8b 95 f0 fd ff ff 	mov    -0x210(%rbp),%rdx
    18b9:	48 8b b5 20 fe ff ff 	mov    -0x1e0(%rbp),%rsi
    18c0:	48 89 f1             	mov    %rsi,%rcx
    18c3:	48 89 d7             	mov    %rdx,%rdi
    18c6:	48 d3 ef             	shr    %cl,%rdi
    18c9:	31 c9                	xor    %ecx,%ecx
    18cb:	48 39 c8             	cmp    %rcx,%rax
    18ce:	b8 00 00 00 00       	mov    $0x0,%eax
    18d3:	0f 94 c0             	sete   %al
    18d6:	48 85 c0             	test   %rax,%rax
    18d9:	48 0f 44 cf          	cmove  %rdi,%rcx
    18dd:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    18e2:	48 8d 34 c8          	lea    (%rax,%rcx,8),%rsi
    18e6:	48 8b 06             	mov    (%rsi),%rax
    18e9:	48 bf 00 00 00 00 00 	movabs $0x28000000000000,%rdi
    18f0:	00 28 00 
    18f3:	48 39 f8             	cmp    %rdi,%rax
    18f6:	48 89 b5 20 fe ff ff 	mov    %rsi,-0x1e0(%rbp)
    18fd:	0f 82 0c 00 00 00    	jb     0x190f
    1903:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
    190a:	e9 36 00 00 00       	jmp    0x1945
    190f:	49 8b 44 24 60       	mov    0x60(%r12),%rax
    1914:	48 89 df             	mov    %rbx,%rdi
    1917:	4c 89 e6             	mov    %r12,%rsi
    191a:	48 89 ca             	mov    %rcx,%rdx
    191d:	48 89 c1             	mov    %rax,%rcx
    1920:	e8 1b e7 ff ff       	call   0x40
    1925:	31 c9                	xor    %ecx,%ecx
    1927:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
    192c:	48 83 f8 00          	cmp    $0x0,%rax
    1930:	0f 8f 08 00 00 00    	jg     0x193e
    1936:	49 89 c5             	mov    %rax,%r13
    1939:	e9 b6 04 00 00       	jmp    0x1df4
    193e:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
    1945:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
    194c:	48 89 c1             	mov    %rax,%rcx
    194f:	48 83 c1 28          	add    $0x28,%rcx
    1953:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    195a:	00 28 00 
    195d:	48 29 d1             	sub    %rdx,%rcx
    1960:	48 8b 95 20 fe ff ff 	mov    -0x1e0(%rbp),%rdx
    1967:	48 89 0a             	mov    %rcx,(%rdx)
    196a:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    1971:	ff 00 00 
    1974:	48 21 c8             	and    %rcx,%rax
    1977:	31 c9                	xor    %ecx,%ecx
    1979:	48 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%rdx
    1980:	48 89 10             	mov    %rdx,(%rax)
    1983:	48 8b b5 08 fe ff ff 	mov    -0x1f8(%rbp),%rsi
    198a:	48 89 70 08          	mov    %rsi,0x8(%rax)
    198e:	48 89 48 10          	mov    %rcx,0x10(%rax)
    1992:	48 89 48 18          	mov    %rcx,0x18(%rax)
    1996:	48 89 48 20          	mov    %rcx,0x20(%rax)
    199a:	49 8b 4c 24 60       	mov    0x60(%r12),%rcx
    199f:	bf 01 00 00 00       	mov    $0x1,%edi
    19a4:	48 01 f9             	add    %rdi,%rcx
    19a7:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
    19ac:	49 89 c6             	mov    %rax,%r14
    19af:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    19b5:	e9 a2 02 00 00       	jmp    0x1c5c
    19ba:	49 8b 44 24 68       	mov    0x68(%r12),%rax
    19bf:	48 85 c0             	test   %rax,%rax
    19c2:	0f 84 25 01 00 00    	je     0x1aed
    19c8:	49 8b 44 24 38       	mov    0x38(%r12),%rax
    19cd:	b9 40 00 00 00       	mov    $0x40,%ecx
    19d2:	48 29 c1             	sub    %rax,%rcx
    19d5:	48 89 8d 88 fe ff ff 	mov    %rcx,-0x178(%rbp)
    19dc:	48 8b 95 f0 fd ff ff 	mov    -0x210(%rbp),%rdx
    19e3:	48 8b b5 88 fe ff ff 	mov    -0x178(%rbp),%rsi
    19ea:	48 89 f1             	mov    %rsi,%rcx
    19ed:	48 89 d7             	mov    %rdx,%rdi
    19f0:	48 d3 ef             	shr    %cl,%rdi
    19f3:	31 c9                	xor    %ecx,%ecx
    19f5:	48 39 c8             	cmp    %rcx,%rax
    19f8:	b8 00 00 00 00       	mov    $0x0,%eax
    19fd:	0f 94 c0             	sete   %al
    1a00:	48 85 c0             	test   %rax,%rax
    1a03:	48 0f 44 cf          	cmove  %rdi,%rcx
    1a07:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    1a0c:	48 8d 34 c8          	lea    (%rax,%rcx,8),%rsi
    1a10:	48 8b 06             	mov    (%rsi),%rax
    1a13:	48 bf 00 00 00 00 00 	movabs $0x28000000000000,%rdi
    1a1a:	00 28 00 
    1a1d:	48 39 f8             	cmp    %rdi,%rax
    1a20:	48 89 b5 88 fe ff ff 	mov    %rsi,-0x178(%rbp)
    1a27:	0f 82 0c 00 00 00    	jb     0x1a39
    1a2d:	48 89 85 20 fe ff ff 	mov    %rax,-0x1e0(%rbp)
    1a34:	e9 36 00 00 00       	jmp    0x1a6f
    1a39:	49 8b 44 24 60       	mov    0x60(%r12),%rax
    1a3e:	48 89 df             	mov    %rbx,%rdi
    1a41:	4c 89 e6             	mov    %r12,%rsi
    1a44:	48 89 ca             	mov    %rcx,%rdx
    1a47:	48 89 c1             	mov    %rax,%rcx
    1a4a:	e8 f1 e5 ff ff       	call   0x40
    1a4f:	31 c9                	xor    %ecx,%ecx
    1a51:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
    1a56:	48 83 f8 00          	cmp    $0x0,%rax
    1a5a:	0f 8f 08 00 00 00    	jg     0x1a68
    1a60:	49 89 c5             	mov    %rax,%r13
    1a63:	e9 8c 03 00 00       	jmp    0x1df4
    1a68:	48 89 85 20 fe ff ff 	mov    %rax,-0x1e0(%rbp)
    1a6f:	48 8b 85 20 fe ff ff 	mov    -0x1e0(%rbp),%rax
    1a76:	48 89 c1             	mov    %rax,%rcx
    1a79:	48 83 c1 28          	add    $0x28,%rcx
    1a7d:	48 ba 00 00 00 00 00 	movabs $0x28000000000000,%rdx
    1a84:	00 28 00 
    1a87:	48 29 d1             	sub    %rdx,%rcx
    1a8a:	48 8b 95 88 fe ff ff 	mov    -0x178(%rbp),%rdx
    1a91:	48 89 0a             	mov    %rcx,(%rdx)
    1a94:	48 b9 ff ff ff ff ff 	movabs $0xffffffffffff,%rcx
    1a9b:	ff 00 00 
    1a9e:	48 21 c8             	and    %rcx,%rax
    1aa1:	31 c9                	xor    %ecx,%ecx
    1aa3:	48 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%rdx
    1aaa:	48 89 10             	mov    %rdx,(%rax)
    1aad:	48 8b b5 08 fe ff ff 	mov    -0x1f8(%rbp),%rsi
    1ab4:	48 89 70 08          	mov    %rsi,0x8(%rax)
    1ab8:	48 89 48 10          	mov    %rcx,0x10(%rax)
    1abc:	48 89 48 18          	mov    %rcx,0x18(%rax)
    1ac0:	48 89 48 20          	mov    %rcx,0x20(%rax)
    1ac4:	49 8b 4c 24 60       	mov    0x60(%r12),%rcx
    1ac9:	bf 01 00 00 00       	mov    $0x1,%edi
    1ace:	48 01 f9             	add    %rdi,%rcx
    1ad1:	49 89 4c 24 60       	mov    %rcx,0x60(%r12)
    1ad6:	49 89 c6             	mov    %rax,%r14
    1ad9:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    1adf:	31 c0                	xor    %eax,%eax
    1ae1:	48 89 85 20 fe ff ff 	mov    %rax,-0x1e0(%rbp)
    1ae8:	e9 6f 01 00 00       	jmp    0x1c5c
    1aed:	49 8b 44 24 10       	mov    0x10(%r12),%rax
    1af2:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    1af7:	48 89 ca             	mov    %rcx,%rdx
    1afa:	f3 48 0f b8 d2       	popcnt %rdx,%rdx
    1aff:	be 40 00 00 00       	mov    $0x40,%esi
    1b04:	48 29 d6             	sub    %rdx,%rsi
    1b07:	48 89 8d 88 fe ff ff 	mov    %rcx,-0x178(%rbp)
    1b0e:	48 8b bd f0 fd ff ff 	mov    -0x210(%rbp),%rdi
    1b15:	48 89 f1             	mov    %rsi,%rcx
    1b18:	48 d3 ef             	shr    %cl,%rdi
    1b1b:	31 c9                	xor    %ecx,%ecx
    1b1d:	48 39 ca             	cmp    %rcx,%rdx
    1b20:	ba 00 00 00 00       	mov    $0x0,%edx
    1b25:	0f 94 c2             	sete   %dl
    1b28:	48 85 d2             	test   %rdx,%rdx
    1b2b:	48 0f 44 cf          	cmove  %rdi,%rcx
    1b2f:	ba 01 00 00 00       	mov    $0x1,%edx
    1b34:	48 89 ce             	mov    %rcx,%rsi
    1b37:	48 01 d6             	add    %rdx,%rsi
    1b3a:	48 8b bd 88 fe ff ff 	mov    -0x178(%rbp),%rdi
    1b41:	48 21 fe             	and    %rdi,%rsi
    1b44:	bf 28 00 00 00       	mov    $0x28,%edi
    1b49:	48 0f af cf          	imul   %rdi,%rcx
    1b4d:	48 8d 3c 08          	lea    (%rax,%rcx,1),%rdi
    1b51:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    1b55:	48 85 c9             	test   %rcx,%rcx
    1b58:	0f 84 9c 00 00 00    	je     0x1bfa
    1b5e:	48 8b 0f             	mov    (%rdi),%rcx
    1b61:	4c 8b 47 08          	mov    0x8(%rdi),%r8
    1b65:	4c 8b 8d 10 fe ff ff 	mov    -0x1f0(%rbp),%r9
    1b6c:	49 39 c9             	cmp    %rcx,%r9
    1b6f:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    1b75:	41 0f 94 c2          	sete   %r10b
    1b79:	48 8b 8d 08 fe ff ff 	mov    -0x1f8(%rbp),%rcx
    1b80:	4c 39 c1             	cmp    %r8,%rcx
    1b83:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    1b89:	41 0f 94 c3          	sete   %r11b
    1b8d:	4d 21 da             	and    %r11,%r10
    1b90:	4d 85 d2             	test   %r10,%r10
    1b93:	0f 84 08 00 00 00    	je     0x1ba1
    1b99:	49 89 fe             	mov    %rdi,%r14
    1b9c:	e9 48 00 00 00       	jmp    0x1be9
    1ba1:	bf 28 00 00 00       	mov    $0x28,%edi
    1ba6:	48 0f af f7          	imul   %rdi,%rsi
    1baa:	48 8d 3c 30          	lea    (%rax,%rsi,1),%rdi
    1bae:	48 8b 47 10          	mov    0x10(%rdi),%rax
    1bb2:	48 85 c0             	test   %rax,%rax
    1bb5:	0f 84 3f 00 00 00    	je     0x1bfa
    1bbb:	48 8b 07             	mov    (%rdi),%rax
    1bbe:	48 8b 77 08          	mov    0x8(%rdi),%rsi
    1bc2:	49 39 c1             	cmp    %rax,%r9
    1bc5:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1bcb:	41 0f 94 c0          	sete   %r8b
    1bcf:	48 39 f1             	cmp    %rsi,%rcx
    1bd2:	b8 00 00 00 00       	mov    $0x0,%eax
    1bd7:	0f 94 c0             	sete   %al
    1bda:	49 21 c0             	and    %rax,%r8
    1bdd:	4d 85 c0             	test   %r8,%r8
    1be0:	0f 84 14 00 00 00    	je     0x1bfa
    1be6:	49 89 fe             	mov    %rdi,%r14
    1be9:	45 31 ff             	xor    %r15d,%r15d
    1bec:	31 c0                	xor    %eax,%eax
    1bee:	48 89 85 20 fe ff ff 	mov    %rax,-0x1e0(%rbp)
    1bf5:	e9 62 00 00 00       	jmp    0x1c5c
    1bfa:	48 8d 85 c0 fe ff ff 	lea    -0x140(%rbp),%rax
    1c01:	48 89 c1             	mov    %rax,%rcx
    1c04:	48 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%rdx
    1c0b:	48 89 11             	mov    %rdx,(%rcx)
    1c0e:	48 8b 95 08 fe ff ff 	mov    -0x1f8(%rbp),%rdx
    1c15:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    1c19:	48 89 df             	mov    %rbx,%rdi
    1c1c:	4c 89 e6             	mov    %r12,%rsi
    1c1f:	48 89 ca             	mov    %rcx,%rdx
    1c22:	e8 29 e4 ff ff       	call   0x50
    1c27:	48 83 f8 00          	cmp    $0x0,%rax
    1c2b:	0f 8d 08 00 00 00    	jge    0x1c39
    1c31:	49 89 c5             	mov    %rax,%r13
    1c34:	e9 bb 01 00 00       	jmp    0x1df4
    1c39:	49 8b 0c 24          	mov    (%r12),%rcx
    1c3d:	0f b6 51 0d          	movzbl 0xd(%rcx),%edx
    1c41:	48 83 e2 01          	and    $0x1,%rdx
    1c45:	49 89 54 24 68       	mov    %rdx,0x68(%r12)
    1c4a:	49 89 c6             	mov    %rax,%r14
    1c4d:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    1c53:	31 c0                	xor    %eax,%eax
    1c55:	48 89 85 20 fe ff ff 	mov    %rax,-0x1e0(%rbp)
    1c5c:	4d 85 ff             	test   %r15,%r15
    1c5f:	0f 84 64 00 00 00    	je     0x1cc9
    1c65:	48 8b 85 18 fe ff ff 	mov    -0x1e8(%rbp),%rax
    1c6c:	49 89 46 10          	mov    %rax,0x10(%r14)
    1c70:	31 c9                	xor    %ecx,%ecx
    1c72:	48 39 c8             	cmp    %rcx,%rax
    1c75:	ba 00 00 00 00       	mov    $0x0,%edx
    1c7a:	0f 95 c2             	setne  %dl
    1c7d:	41 0f b6 76 20       	movzbl 0x20(%r14),%esi
    1c82:	48 09 d6             	or     %rdx,%rsi
    1c85:	48 0f be f6          	movsbq %sil,%rsi
    1c89:	41 88 76 20          	mov    %sil,0x20(%r14)
    1c8d:	48 8b 95 00 fe ff ff 	mov    -0x200(%rbp),%rdx
    1c94:	49 89 56 18          	mov    %rdx,0x18(%r14)
    1c98:	48 8b bd f8 fd ff ff 	mov    -0x208(%rbp),%rdi
    1c9f:	48 39 cf             	cmp    %rcx,%rdi
    1ca2:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1ca8:	41 0f 95 c0          	setne  %r8b
    1cac:	40 0f b6 f6          	movzbl %sil,%esi
    1cb0:	41 b9 02 00 00 00    	mov    $0x2,%r9d
    1cb6:	4d 85 c0             	test   %r8,%r8
    1cb9:	4c 0f 44 c9          	cmove  %rcx,%r9
    1cbd:	4c 09 ce             	or     %r9,%rsi
    1cc0:	41 88 76 20          	mov    %sil,0x20(%r14)
    1cc4:	e9 89 00 00 00       	jmp    0x1d52
    1cc9:	49 8b 46 10          	mov    0x10(%r14),%rax
    1ccd:	48 8b 8d 18 fe ff ff 	mov    -0x1e8(%rbp),%rcx
    1cd4:	48 01 c8             	add    %rcx,%rax
    1cd7:	49 89 46 10          	mov    %rax,0x10(%r14)
    1cdb:	31 c9                	xor    %ecx,%ecx
    1cdd:	48 39 c8             	cmp    %rcx,%rax
    1ce0:	b8 00 00 00 00       	mov    $0x0,%eax
    1ce5:	0f 95 c0             	setne  %al
    1ce8:	41 0f b6 56 20       	movzbl 0x20(%r14),%edx
    1ced:	48 09 c2             	or     %rax,%rdx
    1cf0:	48 0f be d2          	movsbq %dl,%rdx
    1cf4:	41 88 56 20          	mov    %dl,0x20(%r14)
    1cf8:	49 8b 46 18          	mov    0x18(%r14),%rax
    1cfc:	0f b6 d2             	movzbl %dl,%edx
    1cff:	48 89 d6             	mov    %rdx,%rsi
    1d02:	48 83 e6 02          	and    $0x2,%rsi
    1d06:	48 39 ce             	cmp    %rcx,%rsi
    1d09:	be 00 00 00 00       	mov    $0x0,%esi
    1d0e:	40 0f 95 c6          	setne  %sil
    1d12:	31 ff                	xor    %edi,%edi
    1d14:	48 85 f6             	test   %rsi,%rsi
    1d17:	48 0f 44 c7          	cmove  %rdi,%rax
    1d1b:	48 8b bd f8 fd ff ff 	mov    -0x208(%rbp),%rdi
    1d22:	48 01 fe             	add    %rdi,%rsi
    1d25:	48 8b bd 00 fe ff ff 	mov    -0x200(%rbp),%rdi
    1d2c:	48 01 f8             	add    %rdi,%rax
    1d2f:	49 89 46 18          	mov    %rax,0x18(%r14)
    1d33:	48 39 ce             	cmp    %rcx,%rsi
    1d36:	be 00 00 00 00       	mov    $0x0,%esi
    1d3b:	40 0f 95 c6          	setne  %sil
    1d3f:	b8 02 00 00 00       	mov    $0x2,%eax
    1d44:	48 85 f6             	test   %rsi,%rsi
    1d47:	48 0f 44 c1          	cmove  %rcx,%rax
    1d4b:	48 09 c2             	or     %rax,%rdx
    1d4e:	41 88 56 20          	mov    %dl,0x20(%r14)
    1d52:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    1d59:	48 8b 8d 28 fe ff ff 	mov    -0x1d8(%rbp),%rcx
    1d60:	48 01 c8             	add    %rcx,%rax
    1d63:	48 89 83 e8 00 00 00 	mov    %rax,0xe8(%rbx)
    1d6a:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
    1d71:	89 83 00 01 00 00    	mov    %eax,0x100(%rbx)
    1d77:	e9 90 e6 ff ff       	jmp    0x40c
    1d7c:	48 89 df             	mov    %rbx,%rdi
    1d7f:	e8 dc e2 ff ff       	call   0x60
    1d84:	48 85 c0             	test   %rax,%rax
    1d87:	0f 84 98 e6 ff ff    	je     0x425
    1d8d:	49 c7 c5 fe ff ff ff 	mov    $0xfffffffffffffffe,%r13
    1d94:	e9 5b 00 00 00       	jmp    0x1df4
    1d99:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
    1da0:	48 85 c0             	test   %rax,%rax
    1da3:	0f 84 08 00 00 00    	je     0x1db1
    1da9:	49 89 c5             	mov    %rax,%r13
    1dac:	e9 43 00 00 00       	jmp    0x1df4
    1db1:	49 8b 04 24          	mov    (%r12),%rax
    1db5:	49 8b 4c 24 60       	mov    0x60(%r12),%rcx
    1dba:	48 8b 50 58          	mov    0x58(%rax),%rdx
    1dbe:	48 01 ca             	add    %rcx,%rdx
    1dc1:	48 89 50 58          	mov    %rdx,0x58(%rax)
    1dc5:	31 c0                	xor    %eax,%eax
    1dc7:	49 89 44 24 60       	mov    %rax,0x60(%r12)
    1dcc:	48 89 df             	mov    %rbx,%rdi
    1dcf:	4c 89 e6             	mov    %r12,%rsi
    1dd2:	e8 99 e2 ff ff       	call   0x70
    1dd7:	48 83 f8 00          	cmp    $0x0,%rax
    1ddb:	0f 8d 08 00 00 00    	jge    0x1de9
    1de1:	49 89 c5             	mov    %rax,%r13
    1de4:	e9 0b 00 00 00       	jmp    0x1df4
    1de9:	48 89 df             	mov    %rbx,%rdi
    1dec:	e8 8f e2 ff ff       	call   0x80
    1df1:	49 89 c5             	mov    %rax,%r13
    1df4:	4c 89 e8             	mov    %r13,%rax
    1df7:	48 81 c4 38 02 00 00 	add    $0x238,%rsp
    1dfe:	41 5f                	pop    %r15
    1e00:	41 5e                	pop    %r14
    1e02:	41 5d                	pop    %r13
    1e04:	41 5c                	pop    %r12
    1e06:	5b                   	pop    %rbx
    1e07:	5d                   	pop    %rbp
    1e08:	c3                   	ret
    1e09:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    1e10:	00 00 
    1e12:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    1e19:	00 00 
    1e1b:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    1e22:	00 00 
    1e24:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    1e2b:	00 00 
    1e2d:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    1e34:	00 00 
    1e36:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    1e3d:	00 00 
    1e3f:	90                   	nop
    1e40:	55                   	push   %rbp
    1e41:	48 89 e5             	mov    %rsp,%rbp
    1e44:	53                   	push   %rbx
    1e45:	41 54                	push   %r12
    1e47:	41 55                	push   %r13
    1e49:	41 56                	push   %r14
    1e4b:	41 57                	push   %r15
    1e4d:	48 81 ec d8 01 00 00 	sub    $0x1d8,%rsp
    1e54:	48 89 fb             	mov    %rdi,%rbx
    1e57:	31 c0                	xor    %eax,%eax
    1e59:	48 8b 4b 58          	mov    0x58(%rbx),%rcx
    1e5d:	4c 8b a3 50 01 00 00 	mov    0x150(%rbx),%r12
    1e64:	48 8b 53 50          	mov    0x50(%rbx),%rdx
    1e68:	48 85 d2             	test   %rdx,%rdx
    1e6b:	48 89 4d d0          	mov    %rcx,-0x30(%rbp)
    1e6f:	0f 85 d2 01 00 00    	jne    0x2047
    1e75:	48 ba 01 00 00 00 00 	movabs $0x4000000000001,%rdx
    1e7c:	00 04 00 
    1e7f:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    1e83:	31 d2                	xor    %edx,%edx
    1e85:	49 89 14 24          	mov    %rdx,(%r12)
    1e89:	31 d2                	xor    %edx,%edx
    1e8b:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    1e90:	31 d2                	xor    %edx,%edx
    1e92:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    1e97:	31 d2                	xor    %edx,%edx
    1e99:	49 89 54 24 18       	mov    %rdx,0x18(%r12)
    1e9e:	31 d2                	xor    %edx,%edx
    1ea0:	49 89 54 24 20       	mov    %rdx,0x20(%r12)
    1ea5:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    1ea9:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    1ead:	0f 85 84 00 00 00    	jne    0x1f37
    1eb3:	48 8d 95 10 ff ff ff 	lea    -0xf0(%rbp),%rdx
    1eba:	48 89 d6             	mov    %rdx,%rsi
    1ebd:	bf 02 02 01 01       	mov    $0x1010202,%edi
    1ec2:	48 89 3e             	mov    %rdi,(%rsi)
    1ec5:	bf 00 00 00 01       	mov    $0x1000000,%edi
    1eca:	48 89 7e 08          	mov    %rdi,0x8(%rsi)
    1ece:	bf 00 00 10 18       	mov    $0x18100000,%edi
    1ed3:	48 89 7e 10          	mov    %rdi,0x10(%rsi)
    1ed7:	48 bf 00 00 28 01 10 	movabs $0x201001280000,%rdi
    1ede:	20 00 00 
    1ee1:	48 89 7e 18          	mov    %rdi,0x18(%rsi)
    1ee5:	31 ff                	xor    %edi,%edi
    1ee7:	48 89 7e 20          	mov    %rdi,0x20(%rsi)
    1eeb:	48 bf 00 00 00 00 02 	movabs $0x200000000,%rdi
    1ef2:	00 00 00 
    1ef5:	48 89 7e 28          	mov    %rdi,0x28(%rsi)
    1ef9:	bf 01 00 00 00       	mov    $0x1,%edi
    1efe:	48 89 7e 30          	mov    %rdi,0x30(%rsi)
    1f02:	bf 00 00 01 00       	mov    $0x10000,%edi
    1f07:	48 89 7e 38          	mov    %rdi,0x38(%rsi)
    1f0b:	48 8b 79 30          	mov    0x30(%rcx),%rdi
    1f0f:	48 89 bd 18 fe ff ff 	mov    %rdi,-0x1e8(%rbp)
    1f16:	48 89 df             	mov    %rbx,%rdi
    1f19:	48 8b 95 18 fe ff ff 	mov    -0x1e8(%rbp),%rdx
    1f20:	e8 6b e1 ff ff       	call   0x90
    1f25:	48 83 f8 00          	cmp    $0x0,%rax
    1f29:	0f 8d 08 00 00 00    	jge    0x1f37
    1f2f:	49 89 c5             	mov    %rax,%r13
    1f32:	e9 8c 02 00 00       	jmp    0x21c3
    1f37:	48 8d 85 50 fe ff ff 	lea    -0x1b0(%rbp),%rax
    1f3e:	48 89 c1             	mov    %rax,%rcx
    1f41:	ba 02 02 01 01       	mov    $0x1010202,%edx
    1f46:	48 89 11             	mov    %rdx,(%rcx)
    1f49:	ba 00 00 00 01       	mov    $0x1000000,%edx
    1f4e:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    1f52:	ba 00 00 10 18       	mov    $0x18100000,%edx
    1f57:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    1f5b:	48 ba 00 00 28 01 10 	movabs $0x201001280000,%rdx
    1f62:	20 00 00 
    1f65:	48 89 51 18          	mov    %rdx,0x18(%rcx)
    1f69:	31 d2                	xor    %edx,%edx
    1f6b:	48 89 51 20          	mov    %rdx,0x20(%rcx)
    1f6f:	48 ba 00 00 00 00 02 	movabs $0x200000000,%rdx
    1f76:	00 00 00 
    1f79:	48 89 51 28          	mov    %rdx,0x28(%rcx)
    1f7d:	ba 01 00 00 00       	mov    $0x1,%edx
    1f82:	48 89 51 30          	mov    %rdx,0x30(%rcx)
    1f86:	ba 00 00 01 00       	mov    $0x10000,%edx
    1f8b:	48 89 51 38          	mov    %rdx,0x38(%rcx)
    1f8f:	31 d2                	xor    %edx,%edx
    1f91:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    1f95:	48 89 df             	mov    %rbx,%rdi
    1f98:	48 89 ce             	mov    %rcx,%rsi
    1f9b:	48 89 8d 18 fe ff ff 	mov    %rcx,-0x1e8(%rbp)
    1fa2:	e8 f9 e0 ff ff       	call   0xa0
    1fa7:	48 b9 01 00 00 00 00 	movabs $0x4000000000001,%rcx
    1fae:	00 04 00 
    1fb1:	48 89 4b 50          	mov    %rcx,0x50(%rbx)
    1fb5:	48 85 c0             	test   %rax,%rax
    1fb8:	0f 85 0c 00 00 00    	jne    0x1fca
    1fbe:	49 c7 c6 fa fd ff ff 	mov    $0xfffffffffffffdfa,%r14
    1fc5:	e9 6b 00 00 00       	jmp    0x2035
    1fca:	48 8b 08             	mov    (%rax),%rcx
    1fcd:	48 8b 50 10          	mov    0x10(%rax),%rdx
    1fd1:	48 89 50 10          	mov    %rdx,0x10(%rax)
    1fd5:	48 89 df             	mov    %rbx,%rdi
    1fd8:	48 89 c6             	mov    %rax,%rsi
    1fdb:	48 89 95 10 fe ff ff 	mov    %rdx,-0x1f0(%rbp)
    1fe2:	48 8b 95 18 fe ff ff 	mov    -0x1e8(%rbp),%rdx
    1fe9:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
    1ff0:	48 89 8d 08 fe ff ff 	mov    %rcx,-0x1f8(%rbp)
    1ff7:	e8 b4 e0 ff ff       	call   0xb0
    1ffc:	48 83 f8 00          	cmp    $0x0,%rax
    2000:	0f 8d 08 00 00 00    	jge    0x200e
    2006:	49 89 c6             	mov    %rax,%r14
    2009:	e9 27 00 00 00       	jmp    0x2035
    200e:	48 8b 85 18 fe ff ff 	mov    -0x1e8(%rbp),%rax
    2015:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    201a:	48 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%rax
    2021:	49 89 44 24 08       	mov    %rax,0x8(%r12)
    2026:	48 8b 85 10 fe ff ff 	mov    -0x1f0(%rbp),%rax
    202d:	49 89 44 24 10       	mov    %rax,0x10(%r12)
    2032:	45 31 f6             	xor    %r14d,%r14d
    2035:	49 83 fe 00          	cmp    $0x0,%r14
    2039:	0f 8d 08 00 00 00    	jge    0x2047
    203f:	4d 89 f5             	mov    %r14,%r13
    2042:	e9 7c 01 00 00       	jmp    0x21c3
    2047:	48 8b 43 18          	mov    0x18(%rbx),%rax
    204b:	48 85 c0             	test   %rax,%rax
    204e:	0f 84 0c 00 00 00    	je     0x2060
    2054:	0f b6 08             	movzbl (%rax),%ecx
    2057:	48 85 c9             	test   %rcx,%rcx
    205a:	0f 85 e9 00 00 00    	jne    0x2149
    2060:	49 8b 44 24 10       	mov    0x10(%r12),%rax
    2065:	49 8b 34 24          	mov    (%r12),%rsi
    2069:	48 39 c6             	cmp    %rax,%rsi
    206c:	0f 8d f4 00 00 00    	jge    0x2166
    2072:	48 89 f1             	mov    %rsi,%rcx
    2075:	48 81 c1 00 10 00 00 	add    $0x1000,%rcx
    207c:	48 39 c1             	cmp    %rax,%rcx
    207f:	ba 00 00 00 00       	mov    $0x0,%edx
    2084:	0f 9f c2             	setg   %dl
    2087:	48 89 c7             	mov    %rax,%rdi
    208a:	48 85 d2             	test   %rdx,%rdx
    208d:	48 0f 44 f9          	cmove  %rcx,%rdi
    2091:	45 31 c0             	xor    %r8d,%r8d
    2094:	48 39 fe             	cmp    %rdi,%rsi
    2097:	0f 8d a3 00 00 00    	jge    0x2140
    209d:	48 89 f0             	mov    %rsi,%rax
    20a0:	48 83 c0 01          	add    $0x1,%rax
    20a4:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
    20a9:	48 8d 14 f1          	lea    (%rcx,%rsi,8),%rdx
    20ad:	48 8b 0a             	mov    (%rdx),%rcx
    20b0:	48 8d 95 20 fe ff ff 	lea    -0x1e0(%rbp),%rdx
    20b7:	49 89 d1             	mov    %rdx,%r9
    20ba:	49 89 49 20          	mov    %rcx,0x20(%r9)
    20be:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    20c2:	4d 89 11             	mov    %r10,(%r9)
    20c5:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    20cb:	4d 89 51 08          	mov    %r10,0x8(%r9)
    20cf:	4c 8b 51 18          	mov    0x18(%rcx),%r10
    20d3:	44 0f b6 59 20       	movzbl 0x20(%rcx),%r11d
    20d8:	49 83 e3 02          	and    $0x2,%r11
    20dc:	45 31 f6             	xor    %r14d,%r14d
    20df:	4d 39 f3             	cmp    %r14,%r11
    20e2:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    20e8:	41 0f 95 c3          	setne  %r11b
    20ec:	45 31 ff             	xor    %r15d,%r15d
    20ef:	4d 85 db             	test   %r11,%r11
    20f2:	4d 0f 44 d7          	cmove  %r15,%r10
    20f6:	4d 39 f3             	cmp    %r14,%r11
    20f9:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    20ff:	41 0f 94 c3          	sete   %r11b
    2103:	4d 89 51 10          	mov    %r10,0x10(%r9)
    2107:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    210d:	4d 31 d3             	xor    %r10,%r11
    2110:	4d 89 59 18          	mov    %r11,0x18(%r9)
    2114:	4d 8b 4c 24 20       	mov    0x20(%r12),%r9
    2119:	4d 8b 54 24 08       	mov    0x8(%r12),%r10
    211e:	4f 8d 1c ca          	lea    (%r10,%r9,8),%r11
    2122:	49 89 0b             	mov    %rcx,(%r11)
    2125:	49 83 c1 01          	add    $0x1,%r9
    2129:	4d 89 4c 24 20       	mov    %r9,0x20(%r12)
    212e:	4c 89 c1             	mov    %r8,%rcx
    2131:	48 83 c1 01          	add    $0x1,%rcx
    2135:	48 89 c6             	mov    %rax,%rsi
    2138:	49 89 c8             	mov    %rcx,%r8
    213b:	e9 54 ff ff ff       	jmp    0x2094
    2140:	49 89 3c 24          	mov    %rdi,(%r12)
    2144:	e9 fe fe ff ff       	jmp    0x2047
    2149:	48 89 df             	mov    %rbx,%rdi
    214c:	e8 0f df ff ff       	call   0x60
    2151:	48 85 c0             	test   %rax,%rax
    2154:	0f 84 06 ff ff ff    	je     0x2060
    215a:	49 c7 c5 fe ff ff ff 	mov    $0xfffffffffffffffe,%r13
    2161:	e9 5d 00 00 00       	jmp    0x21c3
    2166:	31 c0                	xor    %eax,%eax
    2168:	48 85 c0             	test   %rax,%rax
    216b:	0f 84 08 00 00 00    	je     0x2179
    2171:	49 89 c5             	mov    %rax,%r13
    2174:	e9 4a 00 00 00       	jmp    0x21c3
    2179:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    217e:	49 8b 4c 24 20       	mov    0x20(%r12),%rcx
    2183:	48 85 c0             	test   %rax,%rax
    2186:	0f 84 2c 00 00 00    	je     0x21b8
    218c:	48 89 48 10          	mov    %rcx,0x10(%rax)
    2190:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    2194:	48 83 fa 40          	cmp    $0x40,%rdx
    2198:	0f 83 1a 00 00 00    	jae    0x21b8
    219e:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
    21a2:	48 8b 7e 30          	mov    0x30(%rsi),%rdi
    21a6:	48 6b f2 10          	imul   $0x10,%rdx,%rsi
    21aa:	48 8d 34 37          	lea    (%rdi,%rsi,1),%rsi
    21ae:	48 8b 10             	mov    (%rax),%rdx
    21b1:	48 89 16             	mov    %rdx,(%rsi)
    21b4:	48 89 4e 08          	mov    %rcx,0x8(%rsi)
    21b8:	48 89 df             	mov    %rbx,%rdi
    21bb:	e8 c0 de ff ff       	call   0x80
    21c0:	49 89 c5             	mov    %rax,%r13
    21c3:	4c 89 e8             	mov    %r13,%rax
    21c6:	48 81 c4 d8 01 00 00 	add    $0x1d8,%rsp
    21cd:	41 5f                	pop    %r15
    21cf:	41 5e                	pop    %r14
    21d1:	41 5d                	pop    %r13
    21d3:	41 5c                	pop    %r12
    21d5:	5b                   	pop    %rbx
    21d6:	5d                   	pop    %rbp
    21d7:	c3                   	ret
    21d8:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    21df:	00 00 
    21e1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    21e8:	00 00 
    21ea:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    21f1:	00 00 
    21f3:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    21fa:	00 00 
    21fc:	0f 1f 40 00          	nopl   0x0(%rax)
    2200:	55                   	push   %rbp
    2201:	48 89 e5             	mov    %rsp,%rbp
    2204:	53                   	push   %rbx
    2205:	41 54                	push   %r12
    2207:	41 55                	push   %r13
    2209:	41 56                	push   %r14
    220b:	41 57                	push   %r15
    220d:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    2214:	48 89 fb             	mov    %rdi,%rbx
    2217:	31 c0                	xor    %eax,%eax
    2219:	48 8b 4b 58          	mov    0x58(%rbx),%rcx
    221d:	4c 8b a3 50 01 00 00 	mov    0x150(%rbx),%r12
    2224:	48 8b 53 50          	mov    0x50(%rbx),%rdx
    2228:	48 85 d2             	test   %rdx,%rdx
    222b:	0f 85 f4 00 00 00    	jne    0x2325
    2231:	48 ba 01 00 00 00 00 	movabs $0x4000000000001,%rdx
    2238:	00 04 00 
    223b:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    223f:	31 d2                	xor    %edx,%edx
    2241:	49 89 54 24 28       	mov    %rdx,0x28(%r12)
    2246:	31 d2                	xor    %edx,%edx
    2248:	49 89 54 24 30       	mov    %rdx,0x30(%r12)
    224d:	31 d2                	xor    %edx,%edx
    224f:	49 89 54 24 38       	mov    %rdx,0x38(%r12)
    2254:	31 d2                	xor    %edx,%edx
    2256:	49 89 54 24 40       	mov    %rdx,0x40(%r12)
    225b:	48 8d 95 10 ff ff ff 	lea    -0xf0(%rbp),%rdx
    2262:	48 89 d6             	mov    %rdx,%rsi
    2265:	bf 02 02 01 01       	mov    $0x1010202,%edi
    226a:	48 89 3e             	mov    %rdi,(%rsi)
    226d:	bf 00 00 00 01       	mov    $0x1000000,%edi
    2272:	48 89 7e 08          	mov    %rdi,0x8(%rsi)
    2276:	bf 00 00 10 18       	mov    $0x18100000,%edi
    227b:	48 89 7e 10          	mov    %rdi,0x10(%rsi)
    227f:	48 bf 00 00 28 01 10 	movabs $0x201001280000,%rdi
    2286:	20 00 00 
    2289:	48 89 7e 18          	mov    %rdi,0x18(%rsi)
    228d:	31 ff                	xor    %edi,%edi
    228f:	48 89 7e 20          	mov    %rdi,0x20(%rsi)
    2293:	48 bf 00 00 00 00 02 	movabs $0x200000000,%rdi
    229a:	00 00 00 
    229d:	48 89 7e 28          	mov    %rdi,0x28(%rsi)
    22a1:	bf 01 00 00 00       	mov    $0x1,%edi
    22a6:	48 89 7e 30          	mov    %rdi,0x30(%rsi)
    22aa:	bf 00 00 01 00       	mov    $0x10000,%edi
    22af:	48 89 7e 38          	mov    %rdi,0x38(%rsi)
    22b3:	48 8b 79 30          	mov    0x30(%rcx),%rdi
    22b7:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    22be:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
    22c2:	48 89 df             	mov    %rbx,%rdi
    22c5:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
    22c9:	e8 f2 dd ff ff       	call   0xc0
    22ce:	49 89 c5             	mov    %rax,%r13
    22d1:	49 83 fd 00          	cmp    $0x0,%r13
    22d5:	0f 8d 08 00 00 00    	jge    0x22e3
    22db:	4d 89 ee             	mov    %r13,%r14
    22de:	e9 33 00 00 00       	jmp    0x2316
    22e3:	4d 85 ed             	test   %r13,%r13
    22e6:	0f 85 0c 00 00 00    	jne    0x22f8
    22ec:	49 c7 c6 fa fd ff ff 	mov    $0xfffffffffffffdfa,%r14
    22f3:	e9 1e 00 00 00       	jmp    0x2316
    22f8:	49 8b 45 00          	mov    0x0(%r13),%rax
    22fc:	49 8b 4d 10          	mov    0x10(%r13),%rcx
    2300:	49 89 4d 10          	mov    %rcx,0x10(%r13)
    2304:	4d 89 6c 24 40       	mov    %r13,0x40(%r12)
    2309:	49 89 44 24 30       	mov    %rax,0x30(%r12)
    230e:	49 89 4c 24 38       	mov    %rcx,0x38(%r12)
    2313:	45 31 f6             	xor    %r14d,%r14d
    2316:	49 83 fe 00          	cmp    $0x0,%r14
    231a:	0f 8d 05 00 00 00    	jge    0x2325
    2320:	e9 75 02 00 00       	jmp    0x259a
    2325:	48 8b 43 18          	mov    0x18(%rbx),%rax
    2329:	48 85 c0             	test   %rax,%rax
    232c:	0f 84 0c 00 00 00    	je     0x233e
    2332:	0f b6 08             	movzbl (%rax),%ecx
    2335:	48 85 c9             	test   %rcx,%rcx
    2338:	0f 85 ec 01 00 00    	jne    0x252a
    233e:	49 8b 44 24 38       	mov    0x38(%r12),%rax
    2343:	49 8b 74 24 28       	mov    0x28(%r12),%rsi
    2348:	48 39 c6             	cmp    %rax,%rsi
    234b:	0f 8d f6 01 00 00    	jge    0x2547
    2351:	48 89 f1             	mov    %rsi,%rcx
    2354:	48 81 c1 00 10 00 00 	add    $0x1000,%rcx
    235b:	48 39 c1             	cmp    %rax,%rcx
    235e:	ba 00 00 00 00       	mov    $0x0,%edx
    2363:	0f 9f c2             	setg   %dl
    2366:	49 89 c5             	mov    %rax,%r13
    2369:	48 85 d2             	test   %rdx,%rdx
    236c:	4c 0f 44 e9          	cmove  %rcx,%r13
    2370:	49 89 f7             	mov    %rsi,%r15
    2373:	31 c0                	xor    %eax,%eax
    2375:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
    2379:	4d 39 ef             	cmp    %r13,%r15
    237c:	0f 8d 9e 01 00 00    	jge    0x2520
    2382:	4c 89 f8             	mov    %r15,%rax
    2385:	48 83 c0 01          	add    $0x1,%rax
    2389:	49 8b 4c 24 30       	mov    0x30(%r12),%rcx
    238e:	4a 8d 14 f9          	lea    (%rcx,%r15,8),%rdx
    2392:	48 8b 0a             	mov    (%rdx),%rcx
    2395:	48 8b 51 08          	mov    0x8(%rcx),%rdx
    2399:	48 83 e2 01          	and    $0x1,%rdx
    239d:	31 f6                	xor    %esi,%esi
    239f:	48 39 f2             	cmp    %rsi,%rdx
    23a2:	ba 00 00 00 00       	mov    $0x0,%edx
    23a7:	0f 95 c2             	setne  %dl
    23aa:	48 8b 39             	mov    (%rcx),%rdi
    23ad:	4c 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%r8
    23b4:	4d 89 c1             	mov    %r8,%r9
    23b7:	49 89 49 20          	mov    %rcx,0x20(%r9)
    23bb:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    23bf:	4d 89 11             	mov    %r10,(%r9)
    23c2:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    23c8:	4d 89 59 08          	mov    %r11,0x8(%r9)
    23cc:	4c 8b 41 18          	mov    0x18(%rcx),%r8
    23d0:	0f b6 71 20          	movzbl 0x20(%rcx),%esi
    23d4:	48 83 e6 02          	and    $0x2,%rsi
    23d8:	31 c9                	xor    %ecx,%ecx
    23da:	48 39 ce             	cmp    %rcx,%rsi
    23dd:	be 00 00 00 00       	mov    $0x0,%esi
    23e2:	40 0f 95 c6          	setne  %sil
    23e6:	31 c9                	xor    %ecx,%ecx
    23e8:	48 85 f6             	test   %rsi,%rsi
    23eb:	4c 0f 44 c1          	cmove  %rcx,%r8
    23ef:	31 c9                	xor    %ecx,%ecx
    23f1:	48 39 ce             	cmp    %rcx,%rsi
    23f4:	be 00 00 00 00       	mov    $0x0,%esi
    23f9:	40 0f 94 c6          	sete   %sil
    23fd:	4d 89 41 10          	mov    %r8,0x10(%r9)
    2401:	b9 01 00 00 00       	mov    $0x1,%ecx
    2406:	48 31 ce             	xor    %rcx,%rsi
    2409:	49 89 71 18          	mov    %rsi,0x18(%r9)
    240d:	b9 01 00 00 00       	mov    $0x1,%ecx
    2412:	49 83 fb 00          	cmp    $0x0,%r11
    2416:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    241c:	41 0f 95 c3          	setne  %r11b
    2420:	49 31 cb             	xor    %rcx,%r11
    2423:	48 83 fe 00          	cmp    $0x0,%rsi
    2427:	be 00 00 00 00       	mov    $0x0,%esi
    242c:	40 0f 95 c6          	setne  %sil
    2430:	48 31 ce             	xor    %rcx,%rsi
    2433:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    2437:	4c 8b 49 10          	mov    0x10(%rcx),%r9
    243b:	48 89 95 d8 fe ff ff 	mov    %rdx,-0x128(%rbp)
    2442:	48 8b 11             	mov    (%rcx),%rdx
    2445:	48 89 95 d0 fe ff ff 	mov    %rdx,-0x130(%rbp)
    244c:	48 8b 51 08          	mov    0x8(%rcx),%rdx
    2450:	48 89 95 c8 fe ff ff 	mov    %rdx,-0x138(%rbp)
    2457:	ba 03 00 00 00       	mov    $0x3,%edx
    245c:	48 89 b5 c0 fe ff ff 	mov    %rsi,-0x140(%rbp)
    2463:	4c 89 ce             	mov    %r9,%rsi
    2466:	48 0f af f2          	imul   %rdx,%rsi
    246a:	48 8b 95 d0 fe ff ff 	mov    -0x130(%rbp),%rdx
    2471:	48 89 bd b8 fe ff ff 	mov    %rdi,-0x148(%rbp)
    2478:	48 8d 3c f2          	lea    (%rdx,%rsi,8),%rdi
    247c:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
    2483:	4c 89 85 d0 fe ff ff 	mov    %r8,-0x130(%rbp)
    248a:	4c 8d 04 32          	lea    (%rdx,%rsi,1),%r8
    248e:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
    2495:	48 89 17             	mov    %rdx,(%rdi)
    2498:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
    249f:	41 88 10             	mov    %dl,(%r8)
    24a2:	4c 89 57 08          	mov    %r10,0x8(%rdi)
    24a6:	45 88 58 01          	mov    %r11b,0x1(%r8)
    24aa:	48 8b 95 d0 fe ff ff 	mov    -0x130(%rbp),%rdx
    24b1:	48 89 57 10          	mov    %rdx,0x10(%rdi)
    24b5:	48 8b 95 c0 fe ff ff 	mov    -0x140(%rbp),%rdx
    24bc:	41 88 50 02          	mov    %dl,0x2(%r8)
    24c0:	49 83 c1 01          	add    $0x1,%r9
    24c4:	4c 89 49 10          	mov    %r9,0x10(%rcx)
    24c8:	48 8b 55 d0          	mov    -0x30(%rbp),%rdx
    24cc:	48 89 d6             	mov    %rdx,%rsi
    24cf:	48 83 c6 01          	add    $0x1,%rsi
    24d3:	48 8b 79 18          	mov    0x18(%rcx),%rdi
    24d7:	49 39 f9             	cmp    %rdi,%r9
    24da:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
    24e1:	48 89 b5 d0 fe ff ff 	mov    %rsi,-0x130(%rbp)
    24e8:	0f 8c 18 00 00 00    	jl     0x2506
    24ee:	48 89 df             	mov    %rbx,%rdi
    24f1:	e8 da db ff ff       	call   0xd0
    24f6:	48 85 c0             	test   %rax,%rax
    24f9:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
    2500:	0f 85 64 00 00 00    	jne    0x256a
    2506:	4c 89 f8             	mov    %r15,%rax
    2509:	48 83 c0 01          	add    $0x1,%rax
    250d:	49 89 c7             	mov    %rax,%r15
    2510:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
    2517:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
    251b:	e9 59 fe ff ff       	jmp    0x2379
    2520:	4d 89 6c 24 28       	mov    %r13,0x28(%r12)
    2525:	e9 fb fd ff ff       	jmp    0x2325
    252a:	48 89 df             	mov    %rbx,%rdi
    252d:	e8 2e db ff ff       	call   0x60
    2532:	48 85 c0             	test   %rax,%rax
    2535:	0f 84 03 fe ff ff    	je     0x233e
    253b:	49 c7 c6 fe ff ff ff 	mov    $0xfffffffffffffffe,%r14
    2542:	e9 53 00 00 00       	jmp    0x259a
    2547:	31 c0                	xor    %eax,%eax
    2549:	48 85 c0             	test   %rax,%rax
    254c:	0f 84 08 00 00 00    	je     0x255a
    2552:	49 89 c6             	mov    %rax,%r14
    2555:	e9 40 00 00 00       	jmp    0x259a
    255a:	48 89 df             	mov    %rbx,%rdi
    255d:	e8 1e db ff ff       	call   0x80
    2562:	49 89 c6             	mov    %rax,%r14
    2565:	e9 30 00 00 00       	jmp    0x259a
    256a:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
    2571:	49 89 44 24 28       	mov    %rax,0x28(%r12)
    2576:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
    257d:	48 83 f8 00          	cmp    $0x0,%rax
    2581:	0f 8d 08 00 00 00    	jge    0x258f
    2587:	49 89 c6             	mov    %rax,%r14
    258a:	e9 0b 00 00 00       	jmp    0x259a
    258f:	48 89 df             	mov    %rbx,%rdi
    2592:	e8 49 db ff ff       	call   0xe0
    2597:	49 89 c6             	mov    %rax,%r14
    259a:	4c 89 f0             	mov    %r14,%rax
    259d:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    25a4:	41 5f                	pop    %r15
    25a6:	41 5e                	pop    %r14
    25a8:	41 5d                	pop    %r13
    25aa:	41 5c                	pop    %r12
    25ac:	5b                   	pop    %rbx
    25ad:	5d                   	pop    %rbp
    25ae:	c3                   	ret
	...
    2fff:	00 14 00             	add    %dl,(%rax,%rax,1)
    3002:	00 00                	add    %al,(%rax)
    3004:	00 00                	add    %al,(%rax)
    3006:	00 00                	add    %al,(%rax)
    3008:	01 7a 52             	add    %edi,0x52(%rdx)
    300b:	00 01                	add    %al,(%rcx)
    300d:	78 10                	js     0x301f
    300f:	01 1b                	add    %ebx,(%rbx)
    3011:	0c 07                	or     $0x7,%al
    3013:	08 90 01 00 00 28    	or     %dl,0x28000001(%rax)
    3019:	00 00                	add    %al,(%rax)
    301b:	00 1c 00             	add    %bl,(%rax,%rax,1)
    301e:	00 00                	add    %al,(%rax)
    3020:	60                   	(bad)
    3021:	d1 ff                	sar    $1,%edi
    3023:	ff 89 1c 00 00 00    	decl   0x1c(%rcx)
    3029:	0a 41 0e             	or     0xe(%rcx),%al
    302c:	10 86 02 43 0d 06    	adc    %al,0x60d4302(%rsi)
    3032:	50                   	push   %rax
    3033:	83 03 8c             	addl   $0xffffff8c,(%rbx)
    3036:	04 8d                	add    $0x8d,%al
    3038:	05 8e 06 8f 07       	add    $0x78f068e,%eax
    303d:	03 74 1c 0b          	add    0xb(%rsp,%rbx,1),%esi
    3041:	00 00                	add    %al,(%rax)
    3043:	00 28                	add    %ch,(%rax)
    3045:	00 00                	add    %al,(%rax)
    3047:	00 48 00             	add    %cl,0x0(%rax)
    304a:	00 00                	add    %al,(%rax)
    304c:	f4                   	hlt
    304d:	ed                   	in     (%dx),%eax
    304e:	ff                   	(bad)
    304f:	ff 98 03 00 00 00    	lcall  *0x3(%rax)
    3055:	0a 41 0e             	or     0xe(%rcx),%al
    3058:	10 86 02 43 0d 06    	adc    %al,0x60d4302(%rsi)
    305e:	50                   	push   %rax
    305f:	83 03 8c             	addl   $0xffffff8c,(%rbx)
    3062:	04 8d                	add    $0x8d,%al
    3064:	05 8e 06 8f 07       	add    $0x78f068e,%eax
    3069:	03 83 03 0b 00 00    	add    0xb03(%rbx),%eax
    306f:	00 2c 00             	add    %ch,(%rax,%rax,1)
    3072:	00 00                	add    %al,(%rax)
    3074:	74 00                	je     0x3076
    3076:	00 00                	add    %al,(%rax)
    3078:	88 f1                	mov    %dh,%cl
    307a:	ff                   	(bad)
    307b:	ff af 03 00 00 00    	ljmp   *0x3(%rdi)
    3081:	0a 41 0e             	or     0xe(%rcx),%al
    3084:	10 86 02 43 0d 06    	adc    %al,0x60d4302(%rsi)
    308a:	50                   	push   %rax
    308b:	83 03 8c             	addl   $0xffffff8c,(%rbx)
    308e:	04 8d                	add    $0x8d,%al
    3090:	05 8e 06 8f 07       	add    $0x78f068e,%eax
    3095:	03 9a 03 0b 00 00    	add    0xb03(%rdx),%ebx
	...
