import hashlib,json,resource,sys,time
from pathlib import Path
sys.path.insert(0,'/home/rustsql/pgrust/scripts/validation')
import psycopg
from cluster import Cluster
import fixed_workload
from resource_scope import DelegatedScope,Sampler,snapshot

output=Path(sys.argv[1]);binary=Path(sys.argv[2]);(output/'jit').mkdir()
resource.setrlimit(resource.RLIMIT_STACK,(65520*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
scope=DelegatedScope([0,2,4,6],[8,10]);group,launcher=scope.server(4096)

def wait_file(name):
 deadline=time.monotonic()+45
 while not (output/name).exists():
  if time.monotonic()>deadline:raise TimeoutError(name)
  time.sleep(0.02)

class ProfileSampler(Sampler):
 def start(self):
  (output/'request.json').write_text(json.dumps({'group':str(group),'pids':(group/'cgroup.procs').read_text().split()}))
  wait_file('perf-ready')
  super().start()
 def stop(self):
  result=super().stop()
  (output/'work-complete').touch()
  wait_file('perf-stopped')
  return result

fixed_workload.Sampler=ProfileSampler
report={'passed':False,'diagnostic_profile_only':True,'binary':str(binary),'binary_sha256':hashlib.sha256((binary/'postgres').read_bytes()).hexdigest()}
try:
 with Cluster(binary,'/home/rustsql/conformance',launcher=launcher,settings=['autovacuum=off','max_active_queries=4','work_mem=16MB','pgrust.gravity_jit_perfmap=tags',f'pgrust.gravity_dump_dir={output / "jit"}']) as cluster:
  report['cluster']=str(cluster.root)
  with psycopg.connect(cluster.dsn,autocommit=True) as connection:
   fixed_workload.setup(connection,1000000,6)
   report['settings']=connection.execute("SELECT name,setting FROM pg_settings WHERE name IN ('fsync','synchronous_commit','max_active_queries','pgrust.gravity_jit_perfmap') ORDER BY name").fetchall()
  report['measurement']=fixed_workload.exercise(cluster.dsn,group,1000000,6,400,50)
  with psycopg.connect(cluster.dsn,autocommit=True) as connection:
   report['state']=fixed_workload.verify_state(connection,6,450)
 report['resources_after_shutdown']=snapshot(group)
 report['passed']=True
except Exception as error:
 report['error']=repr(error)
 raise
finally:
 (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 if not (group/'cgroup.procs').read_text().strip():group.rmdir()
