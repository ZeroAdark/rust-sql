import hashlib,json,os,pwd,select,signal,subprocess,sys,time
from pathlib import Path
label=sys.argv[1]
if label not in ('candidate','baseline'):raise ValueError('unknown label')
binary='/home/rustsql/validity-local/bin' if label=='candidate' else '/home/rustsql/window-fixed/bin'
output=Path('/home/rustsql/profile-'+label+'-20261030e');output.mkdir(mode=0o700)
user=pwd.getpwnam('rustsql');os.chown(output,user.pw_uid,user.pw_gid)
os.sched_setaffinity(0,{8,10})
unit='rustsql-qualification-profile-'+label+'-20261030e'
service_command=['systemd-run','--unit='+unit,'--uid=rustsql','--gid=rustsql','--property=Delegate=cpu memory pids','--property=MemoryMax=8G','--property=MemorySwapMax=0','--property=CPUQuota=600%','--property=LimitSTACK=67108864','--property=RuntimeMaxSec=300','--property=StandardOutput=append:'+str(output/'service.log'),'--property=StandardError=append:'+str(output/'service.log'),'--collect','--wait','/usr/bin/python3','-u','/home/rustsql/profile_fixed_driver.py',str(output),binary]
service=subprocess.Popen(service_command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
perf=None;control=ack=None;result={'passed':False,'diagnostic_profile_only':True,'service_command':service_command}

def until_file(name,seconds=120):
 deadline=time.monotonic()+seconds
 while not (output/name).exists():
  if service.poll() is not None:raise RuntimeError('service exited before '+name)
  if perf is not None and perf.poll() is not None:raise RuntimeError('perf exited before '+name)
  if time.monotonic()>deadline:raise TimeoutError(name)
  time.sleep(0.02)

def command(text):
 os.write(control,(text+'\n').encode())
 if not select.select([ack],[],[],10)[0]:raise TimeoutError('perf acknowledgement')
 observed=os.read(ack,4096)
 if observed!=b'ack\n\x00':raise RuntimeError('unexpected acknowledgement: '+repr(observed))

try:
 until_file('request.json')
 request=json.loads((output/'request.json').read_text());group=Path(request['group']).resolve()
 if group!=Path('/sys/fs/cgroup/system.slice')/(unit+'.service')/'server-0001':raise ValueError('unexpected cgroup')
 if group.stat().st_uid!=user.pw_uid:raise ValueError('unexpected cgroup owner')
 for name in ('control','ack'):os.mkfifo(output/name,0o600)
 control=os.open(output/'control',os.O_RDWR|os.O_NONBLOCK);ack=os.open(output/'ack',os.O_RDWR|os.O_NONBLOCK)
 perf_command=['/usr/lib/linux-tools/6.8.0-147-generic/perf','record','-a','-C','0,2,4,6','-e','cpu-clock:u','-G',str(group.relative_to('/sys/fs/cgroup')),'-F','199','--strict-freq','--call-graph','dwarf,8192','--delay=-1','--control=fifo:'+str(output/'control')+','+str(output/'ack'),'--max-size','128M','-o',str(output/'perf.data')]
 result['perf_command']=perf_command
 with (output/'perf-record.log').open('w') as log:
  perf=subprocess.Popen(perf_command,stdout=log,stderr=subprocess.STDOUT)
  command('enable');(output/'perf-ready').touch()
  until_file('work-complete')
  command('disable');perf.send_signal(signal.SIGINT);perf.wait(timeout=30)
  result['perf_returncode']=perf.returncode
  if perf.returncode not in (0,130,-2):raise RuntimeError('perf failed')
  pids=set(request['pids'])|set((group/'cgroup.procs').read_text().split())
  maps={}
  for pid in sorted(pids):
   if not pid.isdecimal():raise ValueError('invalid process identity')
   for suffix in ('map','gravity'):
    source=Path('/tmp')/f'perf-{pid}.{suffix}'
    if source.exists():
     data=source.read_bytes();(output/source.name).write_bytes(data);maps[source.name]=hashlib.sha256(data).hexdigest()
  result['jit_maps']=maps
  (output/'perf-stopped').touch()
 text=service.communicate(timeout=60)[0];(output/'service-completion.log').write_text(text)
 result['service_returncode']=service.returncode
 report=json.loads((output/'report.json').read_text())
 if service.returncode!=0 or report['passed'] is not True:raise RuntimeError('profile workload failed')
 if not any(name.endswith('.map') for name in maps):raise RuntimeError('missing JIT symbols')
 result['passed']=True
except Exception as error:
 result['error']=repr(error)
 raise
finally:
 if perf is not None and perf.poll() is None:
  perf.send_signal(signal.SIGINT)
  try:perf.wait(timeout=10)
  except subprocess.TimeoutExpired:perf.kill();perf.wait()
 if service.poll() is None:
  subprocess.run(['systemctl','stop',unit+'.service'],capture_output=True)
  try:service.communicate(timeout=30)
  except subprocess.TimeoutExpired:service.kill();service.wait()
 for descriptor in (control,ack):
  if descriptor is not None:os.close(descriptor)
 (output/'controller.json').write_text(json.dumps(result,indent=2)+'\n')
 for path in output.iterdir():os.chown(path,user.pw_uid,user.pw_gid)
print(json.dumps(result),flush=True)
