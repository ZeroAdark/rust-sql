from pathlib import Path
import subprocess,os,resource
b=Path('/home/rustsql');resource.setrlimit(resource.RLIMIT_STACK,(65520*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
cmd=['python3',str(b/'pgrust/scripts/validation/bind_lifecycle_probe.py'),'--candidate',str(b/'dist-profile-candidate/bin'),'--reference',str(b/'postgres18/bin'),'--work-dir',str(b/'conformance'),'--output',str(b/'dist-profile-candidate-correctness.json')]
with (b/'dist-profile-candidate-correctness.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=300)
print(r.returncode);print((b/'dist-profile-candidate-correctness.log').read_text()[-3000:]);r.check_returncode()
