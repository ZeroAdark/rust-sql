from pathlib import Path
import subprocess,hashlib,json,shutil
base=Path('/home/rustsql');repo=base/'pgrust';build=base/'dist-profile-build-20261030';meta=json.loads((build/'metadata.json').read_text());assert meta['exit']==0
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head==meta['source_head']
subprocess.run(['git','diff','--exit-code','--','crates','Cargo.toml','Cargo.lock','.cargo','rust-toolchain.toml'],cwd=repo,check=True)
source_diff=subprocess.check_output(['git','diff','db6830c..'+head,'--','crates','Cargo.toml','Cargo.lock','.cargo','rust-toolchain.toml'],cwd=repo)
changed=subprocess.check_output(['git','diff','--name-only','db6830c..'+head,'--','crates','Cargo.toml','Cargo.lock','.cargo','rust-toolchain.toml'],cwd=repo,text=True).splitlines()
name='crates/gravity/lowerv4/src/ops/hashjoin/strategies/rowfilter.rs';assert changed==[name]
old=subprocess.check_output(['git','show','db6830c:'+name],cwd=repo).replace(b'\r\n',b'\n');new=(repo/name).read_bytes().replace(b'\r\n',b'\n');marker=b'#[cfg(test)]\nmod tests {'
assert old.split(marker)[0]==new.split(marker)[0] and old.count(marker)==new.count(marker)==1
retained=json.loads((base/'pool-config-fixed-candidate/manifest.json').read_text())
for name,sha in retained['runtime_source_sha256'].items():assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==sha
root=base/'dist-profile-candidate';assert not root.exists();(root/'bin').mkdir(parents=True)
for name in ['postgres','initdb']:
 shutil.copyfile(repo/'target/dist'/name,root/'bin'/name);(root/'bin'/name).chmod(0o755)
shutil.copytree(base/'pool-config-fixed-candidate/bin/share',root/'bin/share')
(root/'retained-source-difference.patch').write_bytes(source_diff)
for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:
 if (repo/name).exists():shutil.copyfile(repo/name,root/name)
for p in (repo/'.cargo').glob('*'):
 if p.is_file():q=root/'cargo-config'/p.name;q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q)
for p in build.iterdir():
 if p.is_file():shutil.copyfile(p,root/p.name)
manifest={'source_head':head,'profile':'dist','runtime_defaults_changed':False,'retained_sha256':retained['binaries']['postgres'],'retained_runtime_equivalence':'Only a cfg(test) Bloom-filter test differs since the constructor-fix commit; runtime prefix and original startup-fix source hashes verified.','binaries':{n:hashlib.sha256((root/'bin'/n).read_bytes()).hexdigest() for n in ['postgres','initdb']},'binary_size_bytes':{n:(root/'bin'/n).stat().st_size for n in ['postgres','initdb']},'source_difference_sha256':hashlib.sha256(source_diff).hexdigest(),'qualified':False}
assert manifest['binaries']['postgres']!=manifest['retained_sha256'];(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest),flush=True)
