from pathlib import Path
import subprocess,json,sys,shutil
base=Path('/home/rustsql');label=sys.argv[1];phase=sys.argv[2];bundles=sys.argv[3];repeats=sys.argv[4];warmup=sys.argv[5];rate=None if len(sys.argv)<7 or sys.argv[6]=='none' else sys.argv[6];binary=Path(sys.argv[7]);policy=sys.argv[8] if len(sys.argv)>8 else ''
source=base/(label+'-source');source.mkdir(exist_ok=False)
for n in ['postgres_comparison.py','fixed_workload.py','cluster.py','connection_churn_probe.py','connection_queue_probe.py','resource_scope.py']:shutil.copyfile(base/'pgrust/scripts/validation'/n,source/n)
probe=source/'postgres_comparison.py'
s=probe.read_text()
s=s.replace("binaries = args.reference if reference else args.candidate", "binaries = args.reference if reference else args.baseline if label == 'rustsql-baseline' else args.candidate")
s=s.replace("('candidate','reference','work-dir','output-dir')", "('candidate','baseline','reference','work-dir','output-dir')")
s=s.replace("[('postgresql',args.reference),('rustsql',args.candidate)]", "[('postgresql',args.reference),('rustsql-baseline',args.baseline),('rustsql',args.candidate)]")
s=s.replace("(('postgresql','rustsql') if repetition%2 else ('rustsql','postgresql'))", "(('postgresql','rustsql-baseline','rustsql') if repetition%2 else ('rustsql','rustsql-baseline','postgresql'))")
s=s.replace("if not reference and args.candidate_policy:", "if label == 'rustsql' and args.candidate_policy:")
s=s.replace("report['version'] = cluster.version", "report['version'] = cluster.version\n            report['requested_policy'] = args.candidate_policy if label == 'rustsql' else ''\n            report['live_policy_env'] = [item.decode() for item in Path('/proc',str(cluster.process.pid),'environ').read_bytes().split(b'\\0') if item.startswith(b'PGRUST_MEMPOLICY=')]\n            assert report['live_policy_env'] == (['PGRUST_MEMPOLICY='+report['requested_policy']] if report['requested_policy'] else [])\n            report['resources_before_setup'] = snapshot(group)")
s=s.replace("report['measurement']=exercise(", "report['resources_before_workload']=snapshot(group)\n            report['measurement']=exercise(")
s=s.replace("with psycopg.connect(cluster.dsn,autocommit=True) as connection:\n                report['state_before_restart']", "report['resources_after_workload']=snapshot(group)\n            with psycopg.connect(cluster.dsn,autocommit=True) as connection:\n                report['state_before_restart']")
assert "label == 'rustsql' and args.candidate_policy:" in s
probe.write_text(s)
cmd=['systemd-run','--unit=rustsql-qualification-'+label,'--uid=rustsql','--gid=rustsql','--wait','--collect','--property=Delegate=cpu memory pids','--property=MemoryMax=8G','--property=MemorySwapMax=0','--property=CPUQuota=600%','--property=LimitSTACK=67108864','--property=RuntimeMaxSec=2400','--property=StandardOutput=append:'+str(base/(label+'.log')),'--property=StandardError=append:'+str(base/(label+'.log')),'/usr/bin/python3','-u',str(source/'postgres_comparison.py'),'--candidate',str(binary),'--reference',str(base/'postgres18/bin'),'--work-dir',str(base/'conformance'),'--output-dir',str(base/label),'--phase',phase,'--bundles',bundles,'--repeats',repeats,'--warmup',warmup]
cmd+=['--baseline','/home/rustsql/pool-config-fixed-candidate/bin']
if rate:cmd+=['--bundle-rate',rate]
if policy:cmd+=['--candidate-policy',policy]
r=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=2430)
(base/(label+'-command.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode,'output':r.stdout},indent=2)+'\n');(base/(label+'-journal.log')).write_bytes(subprocess.check_output(['journalctl','-u','rustsql-qualification-'+label+'.service','--no-pager','-o','short-iso']))
print(label,r.returncode,flush=True);print((base/(label+'.log')).read_text()[-3000:],flush=True);r.check_returncode()
