from pathlib import Path
import subprocess,os,json
base=Path('/home/rustsql');root=base/'dist-profile-build-20261030';root.mkdir(exist_ok=False);os.chown(root,1000,1000)
unit='rustsql-dist-profile-build-20261030'
cmd=['systemd-run','--unit='+unit,'--uid=rustsql','--gid=rustsql','--wait','--collect','--property=MemoryMax=20G','--property=MemorySwapMax=0','--property=CPUQuota=600%','--property=LimitSTACK=67108864','--property=RuntimeMaxSec=3600','--property=StandardOutput=append:'+str(root/'runner.log'),'--property=StandardError=append:'+str(root/'runner.log'),'/usr/bin/python3','-u',str(base/'build_dist_profile_inner.py')]
r=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=3630)
(root/'command.json').write_text(json.dumps({'command':cmd,'exit':r.returncode,'output':r.stdout},indent=2)+'\n')
(root/'journal.log').write_bytes(subprocess.check_output(['journalctl','-u',unit+'.service','--no-pager','-o','short-iso']))
print(r.returncode,flush=True);print((root/'runner.log').read_text()[-2000:],flush=True);r.check_returncode()
