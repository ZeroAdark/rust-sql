from pathlib import Path
import subprocess,os,json,resource,time
base=Path('/home/rustsql');repo=base/'pgrust';out=base/'dist-profile-build-20261030'
resource.setrlimit(resource.RLIMIT_STACK,(65520*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
env=os.environ.copy();env['PATH']=str(base/'.cargo/bin')+':'+env['PATH']
cmd=['cargo','build','--locked','--profile','dist','-j','2','-p','main_main','-p','initdb']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
subprocess.run(['git','diff','--exit-code','--','crates','Cargo.toml','Cargo.lock'],cwd=repo,check=True)
meta={'source_head':head,'command':cmd,'rustc':subprocess.check_output(['rustc','--version'],env=env,text=True).strip(),'qualified':False}
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
start=time.monotonic()
with (out/'build.log').open('wb') as log:r=subprocess.run(['/usr/bin/time','-v',*cmd],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
meta.update(exit=r.returncode,elapsed_seconds=time.monotonic()-start)
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta),flush=True);r.check_returncode()
