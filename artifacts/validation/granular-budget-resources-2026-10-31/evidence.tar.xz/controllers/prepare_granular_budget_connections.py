"""Predeclare a five-pair 2 GiB startup comparison before running it."""
from pathlib import Path
import json

root = Path(__file__).resolve().parent
candidate = '635ec740b3cd85c4318eadc87843705032494a49d92d1deeb79b09a8c5ab9e57'
baseline = '0be60915b40c9f70f39dcb3a0fd1f8918608a20095f767ec081a5b5320caa277'
old = '57baa2ef25bdfebccd3bf851fb84692828a72e2b8541faddfe1ace0a281cabe6'
runner = (root / 'run_guc_registry_connections.template.py').read_text()
runner = runner.replace('guc-registry-reserve-connections-20261031', 'granular-budget-connections-2g-20261031')
runner = runner.replace('guc-registry-connections-', 'granular-budget-connections-2g-')
runner = runner.replace("base/'guc_queue_probe.py'", "base/'guc-registry-reserve-connections-20261031/source/guc_queue_probe.py'")
runner = runner.replace("base/'guc-registry-reserve-medium-20261031-cpuset-preflight.json'", "base/'granular-budget-medium-20261031-cpuset-preflight.json'")
runner = runner.replace("'baseline': base/'guc-name-index-candidate/bin', 'candidate': base/'guc-registry-reserve-candidate/bin'",
                        "'baseline': base/'guc-registry-reserve-candidate/bin', 'candidate': base/'granular-budget-candidate/bin'")
runner = runner.replace(old, baseline).replace('__NEW_SHA__', candidate).replace('4096', '2048')
marker = "root = base/'granular-budget-connections-2g-20261031'"
gate = """review = json.loads((base/'granular-budget-performance-review-20261031.json').read_text())
assert review['complete'] and review['preservation_passed'] and set(review['phases']) == {'medium-1g', 'medium', 'capacity'}
"""
assert marker in runner
runner = runner.replace(marker, gate + marker)
analyzer = (root / 'compare_guc_registry_connections.template.py').read_text()
analyzer = analyzer.replace(old, baseline).replace('__NEW_SHA__', candidate).replace('4096', '2048').replace('4 GiB', '2 GiB')
for filename, code in [('run_granular_budget_connections.py', runner), ('compare_granular_budget_connections.py', analyzer)]:
    target = root / filename
    assert not target.exists()
    compile(code, filename, 'exec')
    target.write_text(code)
design = {'candidate_sha256': candidate, 'baseline_sha256': baseline, 'repeats': 5, 'memory_mib': 2048,
          'waves': 2, 'accepted_per_wave': 800, 'accepted_startups': 16000, 'overflow_rejections': 20,
          'server_cpus': [0, 2, 4, 6], 'client_cpus': [8, 10], 'swap': False, 'cfs_quota': False,
          'cpu_median_max_increase_percent': 5, 'cpu_including_shutdown_median_max_increase_percent': 5,
          'performance_timing_scope': 'CPU per accepted startup. Wave durations include orchestration/diagnostics and are descriptive only.',
          'reason': 'The new reclaim policy can engage under 2 GiB connection bursts; preserve prior startup CPU gains as well as mixed-query performance.',
          'no_retry_on_failed_trial': True, 'promoted': False}
(root / 'granular_budget_connections_design.json').write_text(json.dumps(design, indent=2) + '\n')
print('Prepared five interleaved 2 GiB startup pairs with unchanged 5% CPU guards; not started.')
