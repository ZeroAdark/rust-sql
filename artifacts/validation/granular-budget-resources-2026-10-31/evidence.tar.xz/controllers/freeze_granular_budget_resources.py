"""Freeze the complete connection and positive-budget resource checks."""
from pathlib import Path
import hashlib
import io
import json
import shutil
import tarfile
from replay_granular_budget_resources import review, tamper_controls

base = Path('/home/rustsql')
workspace = Path(__file__).resolve().parent
target = workspace / 'pgrust/artifacts/validation/granular-budget-resources-2026-10-31'
assert not target.exists()
files = {}


def add(name, path):
    assert name not in files
    files[name] = path.read_bytes()


def tree(prefix, folder):
    for path in sorted(folder.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            add(prefix + '/' + path.relative_to(folder).as_posix(), path)


tree('connections', base / 'granular-budget-connections-2g-20261031')
add('connection-design.json', workspace / 'granular_budget_connections_design.json')
add('connection-review.json', base / 'granular-budget-connections-2g-review-20261031.json')
for path in sorted(base.glob('granular-budget-limits-20261031*')):
    if path.is_dir():
        tree('limits/' + path.name, path)
    else:
        add('limits/' + path.name, path)
for number in range(1, 4):
    for suffix in ('.json', '.log'):
        name = f'granular-budget-2g-pilot-{number}-20261031' + suffix
        add('pilots/' + name, base / name)
for name in ('prepare_granular_budget_connections.py', 'run_granular_budget_connections.py',
             'compare_granular_budget_connections.py', 'run_granular_budget_runtime_checks.py',
             'run_granular_budget_limits.py', 'run_granular_budget_qualification.py',
             'freeze_granular_budget_resources.py', 'replay_granular_budget_resources.py'):
    add('controllers/' + name, workspace / name)
reports = [('connections/' + f'{label}-{number}.json') for number in range(1, 6) for label in ('baseline', 'candidate')]
reports += [('pilots/' + f'granular-budget-2g-pilot-{number}-20261031.json') for number in range(1, 4)]
reports += ['limits/' + item['name'] + '.json' for item in json.loads(files['limits/granular-budget-limits-20261031-summary.json'])['trials']]
for name in reports:
    report = json.loads(files[name])
    for log in ('initdb.log', 'server.log'):
        add(name.removesuffix('.json') + '-cluster/' + log, Path(report['cluster']) / log)
result = review(files)
rejected = tamper_controls(files)
target.mkdir()
archive = target / 'evidence.tar.xz'
with tarfile.open(archive, 'w:xz') as handle:
    for name, content in sorted(files.items()):
        member = tarfile.TarInfo(name)
        member.size, member.mode, member.mtime = len(content), 0o644, 0
        handle.addfile(member, io.BytesIO(content))
(target / 'manifest.json').write_text(json.dumps({'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'members': {name: hashlib.sha256(content).hexdigest() for name, content in files.items()}}, indent=2) + '\n')
(target / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
shutil.copyfile(workspace / 'replay_granular_budget_resources.py', target / 'replay.py')
shutil.copyfile(workspace / 'compare_granular_budget_connections.py', target / 'compare_granular_budget_connections.py')
print(json.dumps({'archive_bytes': archive.stat().st_size, 'members': len(files), 'result': result, 'tamper_controls_rejected': rejected}))
