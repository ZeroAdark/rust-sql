"""Run the remaining functional gates serially after the preserved-performance checks."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

if not __debug__:
    raise RuntimeError('Assertions must remain enabled')
base = Path('/home/rustsql')
workspace = Path(__file__).resolve().parent
output = base / 'granular-budget-runtime-checks-20261031.json'
assert not output.exists()
design = json.loads((workspace / 'granular_budget_connections_design.json').read_text())
connections = json.loads((base / 'granular-budget-connections-2g-review-20261031.json').read_text())
assert connections['evidence_valid'] and connections['accepted_startups'] == design['accepted_startups']
assert connections['cpu_us_per_accepted_startup']['median_change_pct'] <= design['cpu_median_max_increase_percent']
assert connections['cpu_us_per_accepted_startup_including_shutdown']['median_change_pct'] <= design['cpu_including_shutdown_median_max_increase_percent']
assert {k: v['sha256'] for k, v in connections['metadata']['binaries'].items()} == {
    'baseline': design['baseline_sha256'], 'candidate': design['candidate_sha256']}
performance = json.loads((base / 'granular-budget-performance-review-20261031.json').read_text())
assert performance['complete'] and performance['preservation_passed']
scripts = ['run_granular_budget_limits.py', 'run_granular_budget_qualification.py']
sources = {name: hashlib.sha256((workspace / name).read_bytes()).hexdigest() for name in scripts}
result = {'complete': False, 'passed': False, 'promoted': False, 'candidate_sha256': design['candidate_sha256'],
          'connection_cpu_preservation_passed': True, 'source_sha256': sources, 'stages': []}
output.write_text(json.dumps(result, indent=2) + '\n')
for name in scripts:
    assert hashlib.sha256((workspace / name).read_bytes()).hexdigest() == sources[name]
    print(json.dumps({'starting': name}), flush=True)
    started = time.monotonic()
    command = ['/usr/bin/python3', '-u', str(workspace / name)]
    completed = subprocess.run(command)
    result['stages'].append({'script': name, 'command': command, 'exit': completed.returncode,
                             'seconds': time.monotonic() - started})
    output.write_text(json.dumps(result, indent=2) + '\n')
    if completed.returncode:
        result['complete'] = True
        result['failed_at'] = name
        output.write_text(json.dumps(result, indent=2) + '\n')
        raise SystemExit(completed.returncode)
result['complete'] = result['passed'] = True
output.write_text(json.dumps(result, indent=2) + '\n')
