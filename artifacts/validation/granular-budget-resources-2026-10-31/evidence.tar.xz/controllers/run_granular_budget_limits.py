"""Functional sort/restart checks at positive memory budgets; no performance qualification."""
from pathlib import Path
import hashlib
import json
import subprocess

if not __debug__:
    raise RuntimeError('Assertions must remain enabled')
base = Path('/home/rustsql')
repo = Path('/mnt/c/Users/DarkMoon/Desktop/Rust SQL/pgrust')
campaign = 'granular-budget-limits-20261031'
out = base / (campaign + '-summary.json')
assert not out.exists()
review = json.loads((base / 'granular-budget-performance-review-20261031.json').read_text())
assert review['evidence_valid'] and review['preservation_passed']
assert set(review['phases']) == {'medium', 'capacity', 'medium-1g'}
assert not subprocess.check_output(['systemctl', 'list-units', 'rustsql-qualification-*', '--state=running', '--plain', '--no-legend'], text=True).strip()
engines = {
    'postgresql': ('postgres18', '07b16e1aa4f0e2206c37b339b6e4cc813aa8ab9e3c5516334f753b3d90d0c536'),
    'rustsql': ('granular-budget-candidate', json.loads((base / 'granular-budget-build-20261031/report.json').read_text())['binaries']['postgres']['sha256']),
}
source = base / (campaign + '-source')
source.mkdir(exist_ok=False)
for filename in ('sustained_sort_probe.py', 'spill_probe.py', 'cluster.py', 'connection_churn_probe.py', 'connection_queue_probe.py', 'resource_scope.py'):
    (source / filename).write_bytes((repo / 'scripts/validation' / filename).read_bytes().replace(b'\r\n', b'\n'))
(source / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
design = {'memory_mib': [2048, 4096, 8192], 'sessions': ['fresh', 'loader'], 'engines': list(engines),
          'repeats': 1, 'cycles_per_trial': 12, 'expected_trials': 12, 'performance_qualified': False,
          'outer_memory_mib': 12288, 'swap_mib': 0, 'promoted': False}
(source / 'design.json').write_text(json.dumps(design, indent=2) + '\n')
records = []
digest = '1617e17e9ee2e6e0a614c994459558f80ed98ada447da0a83dd521398abd057f'
for index, memory in enumerate(design['memory_mib']):
    for session in design['sessions']:
        for engine in (list(engines) if index % 2 == 0 else list(reversed(engines))):
            name = f'{campaign}-{memory}-{session}-{engine}'
            binary_name, sha = engines[engine]
            binary = base / binary_name / 'bin'
            assert hashlib.sha256((binary / 'postgres').read_bytes()).hexdigest() == sha
            report_path = base / (name + '.json')
            log = base / (name + '.log')
            assert not report_path.exists() and not log.exists()
            command = ['systemd-run', '--unit=rustsql-qualification-' + name,
                       '--uid=rustsql', '--gid=rustsql', '--wait', '--collect',
                       '--property=Delegate=cpu memory pids cpuset', '--property=AllowedCPUs=0,2,4,6,8,10',
                       '--property=MemoryMax=12G', '--property=MemorySwapMax=0', '--property=LimitSTACK=67108864',
                       '--property=RuntimeMaxSec=600', '--property=LimitNOFILE=65536',
                       '--property=StandardOutput=append:' + str(log), '--property=StandardError=append:' + str(log),
                       '/usr/bin/python3', '-u', str(source / 'sustained_sort_probe.py'),
                       '--engine', engine, '--bin-dir', str(binary), '--work-dir', str(base / 'conformance/sort-limits'),
                       '--memory-mib', str(memory), '--output', str(report_path)]
            if session == 'loader':
                command += ['--reuse-loader-session']
            print(json.dumps({'starting': name}), flush=True)
            result = subprocess.run(command, capture_output=True, text=True, timeout=630)
            (base / (name + '-command.json')).write_text(json.dumps({'command': command, 'exit': result.returncode,
                'stdout': result.stdout, 'stderr': result.stderr}, indent=2) + '\n')
            journal = subprocess.run(['journalctl', '-u', 'rustsql-qualification-' + name + '.service', '--no-pager', '-o', 'short-iso'], capture_output=True)
            (base / (name + '-journal.log')).write_bytes(journal.stdout + journal.stderr)
            d = json.loads(report_path.read_text()) if report_path.exists() else {}
            record = {'name': name, 'memory_mib': memory, 'session': session, 'engine': engine,
                      'exit': result.returncode, 'passed': d.get('passed', False), 'error': d.get('error')}
            records.append(record)
            out.write_text(json.dumps({'complete': False, 'trials': records, 'design': design}, indent=2) + '\n')
            print(json.dumps(record), flush=True)
            result.check_returncode()
            assert d['passed'] and d['binary_sha256'] == sha
            assert d['durability'] == ['on', 'on'] and d['memory_mib'] == memory
            assert d['reuse_loader_session'] == (session == 'loader') and not d['allocator_sql_observer']
            assert not d.get('monitor_error') and not d.get('error')
            assert d['cpu_escape_proof'] == {'allowed': [0, 2, 4, 6], 'escape_rejected': True}
            assert d['limits']['memory.max'] == str(memory * 2**20) and d['limits']['memory.swap.max'] == '0'
            assert d['parent_memory_max'] == str(12 * 2**30)
            assert d['shutdown_exit_codes'] == [0, 0] and not d['remaining_server_pids']
            assert all(d['resources_after_shutdown']['events'][event] == 0 for event in ('max', 'oom', 'oom_kill', 'oom_group_kill'))
            assert d['connection_recovery'] == 1 and d['transaction_status'] == 'IDLE'
            assert d['restart_count'] == 1_000_000
            assert (d['restart_full_sort']['rows'], d['restart_full_sort']['sha256']) == (1_000_000, digest)
            assert len(d['queries']) == 12
            for q in d['queries']:
                assert q['passed'] and not q['remaining_temp_files']
                assert (q['result']['rows'], q['result']['sha256']) == (1_000_000, digest)
                assert q['cpu_delta']['nr_throttled'] == q['cpu_delta']['throttled_usec'] == 0
                if q['work_mem'] == '64kB':
                    assert sum(f['bytes'] for f in q['spill_files']) > 0
            for filename, sha_source in d['source_lf_sha256'].items():
                assert hashlib.sha256((source / filename).read_bytes().replace(b'\r\n', b'\n')).hexdigest() == sha_source
            assert hashlib.sha256((binary / 'postgres').read_bytes()).hexdigest() == sha
assert len(records) == design['expected_trials']
out.write_text(json.dumps({'complete': True, 'passed': True, 'trials': records, 'design': design}, indent=2) + '\n')
