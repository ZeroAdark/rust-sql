"""Connection calibration with immutable binaries and private kernel CPU sets."""
import hashlib
from pathlib import Path
import connection_queue_probe as probe
import resource_scope as resources

if not __debug__:
    raise RuntimeError('Assertions must remain enabled')

witnesses, exits, scopes, bindings, environments = [], [], [], [], []

class WitnessCluster(probe.Cluster):
    def __init__(self, *args, **kwargs):
        kwargs['allocator'] = 'hearth'
        super().__init__(*args, **kwargs)
        for key in list(self.env):
            if key.startswith('MIMALLOC_'):
                del self.env[key]

    def start(self):
        super().start()
        environment = sorted(x.decode() for x in Path('/proc', str(self.process.pid), 'environ').read_bytes().split(b'\0') if x.startswith((b'PGRUST_', b'MIMALLOC_')))
        assert environment == ['PGRUST_ALLOCATOR=hearth']
        environments.append(environment)
        with probe.psycopg.connect(self.dsn, autocommit=True) as connection:
            value = connection.execute('SHOW pgrust.allocator').fetchone()[0]
        assert value == 'hearth'
        witnesses.append(value)

    def stop(self, crash=False):
        process = self.process
        try:
            super().stop(crash=crash)
        finally:
            if process is not None:
                exits.append(process.returncode)
        if process is not None and not crash:
            assert process.returncode == 0

class WitnessScope(resources.DelegatedScope):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        scopes.append({'root': self.root, 'driver': self.driver,
                       'parent_before': resources.snapshot(self.root)['cpu'],
                       'driver_before': resources.snapshot(self.driver)['cpu']})

    def server(self, memory_mib):
        group, launcher = super().server(memory_mib)
        bindings.append({name: (group/name).read_text().strip() for name in ('cpuset.cpus', 'cpuset.cpus.effective', 'cpu.max')})
        return group, launcher

probe.Cluster = WitnessCluster
resources.DelegatedScope = WitnessScope
original = probe.run_burst

def run_burst(args, report):
    try:
        original(args, report)
    finally:
        report['allocator'] = {'requested': 'hearth', 'live_witnesses': witnesses}
        report['live_environments'] = environments
        report['shutdown_exit_codes'] = exits
        report['cpu_binding'] = bindings
        report['parent_cpu_delta'] = [resources.delta(s['parent_before'], resources.snapshot(s['root'])['cpu']) for s in scopes]
        report['driver_cpu_delta'] = [resources.delta(s['driver_before'], resources.snapshot(s['driver'])['cpu']) for s in scopes]
        report['wrapper_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()

probe.run_burst = run_burst
probe.main()
