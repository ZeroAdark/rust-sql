from pathlib import Path
import json,statistics,sys
p=Path(sys.argv[1]);phase=sys.argv[2];ds=[json.loads(f.read_text()) for f in p.glob(phase+'-*.json')]
assert len(ds)==15 and all(d['passed'] for d in ds)
getters={'cpu_ms_per_bundle':lambda m:m['server_cpu_us_per_bundle']/1000,'sql_per_second':lambda m:m['bundles_per_second']*19,'charged_peak_mib':lambda m:m['sampled_resources']['sampled_memory_current_peak_bytes']/2**20,'pss_peak_mib':lambda m:m['sampled_resources']['sampled_summed_pss_peak_bytes']/2**20}
for k in ('read','update','aggregate','range','join','bundle'):getters[k+'_p99_ms']=lambda m,k=k:m['latency'][k]['p99_ms']
result={'phase':phase,'trials':len(ds),'engines':{}}
for engine in ('postgresql','rustsql-baseline','rustsql'):
 a=sorted([d for d in ds if d['engine']==engine],key=lambda d:d['repetition']);assert len(a)==5
 result['engines'][engine]={name:statistics.median(fn(d['measurement']) for d in a) for name,fn in getters.items()}
result['candidate_change_percent']={k:100*(result['engines']['rustsql'][k]/v-1) for k,v in result['engines']['rustsql-baseline'].items()}
result['preservation_failures']=[k for k,v in result['candidate_change_percent'].items() if (k=='sql_per_second' and phase=='capacity' and v < -5) or ((k=='cpu_ms_per_bundle' or k.endswith('_p99_ms')) and v>5)]
for d in ds:
 assert d['state_before_restart']==d['state_after_restart'] and d['shutdown_exit_codes']==[0,0] and not d['remaining_server_pids']
 assert not any(d['measurement']['memory_event_delta'].values())
 assert d['measurement']['cpu_delta']['nr_throttled']==0
(p/'three-engine-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
