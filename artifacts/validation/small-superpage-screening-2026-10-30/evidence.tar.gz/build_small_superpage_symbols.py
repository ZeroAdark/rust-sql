from pathlib import Path
import subprocess,os,resource
p=Path('/home/rustsql');env=os.environ.copy();env['PATH']=str(p/'.cargo/bin')+':'+env['PATH'];resource.setrlimit(resource.RLIMIT_STACK,(65520*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
cmd=['cargo','rustc','--locked','--release','-j','2','-p','main_main','--bin','postgres','--','-C','strip=none','-C','link-arg=-Wl,-Map=/home/rustsql/small-superpage-profile-link.map']
with (p/'small-superpage-profile-symbol-build.log').open('w') as log:r=subprocess.run(cmd,cwd=p/'pgrust',env=env,stdout=log,stderr=subprocess.STDOUT)
print('profile-symbol build',r.returncode,flush=True);r.check_returncode()
