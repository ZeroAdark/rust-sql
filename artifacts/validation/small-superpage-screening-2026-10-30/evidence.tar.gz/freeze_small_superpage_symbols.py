from pathlib import Path
import subprocess,hashlib,shutil,json,struct
base=Path('/home/rustsql');repo=base/'pgrust';root=base/'small-superpage-profile-symbols-candidate';assert not root.exists();(root/'bin').mkdir(parents=True)
frozen=json.loads((base/'small-superpage-candidate/manifest.json').read_text())
assert all(hashlib.sha256((repo/n).read_bytes()).hexdigest()==sha for n,sha in frozen['runtime_source_sha256'].items())
shutil.copyfile(repo/'target/release/postgres',root/'bin/postgres');(root/'bin/postgres').chmod(0o755)
shutil.copyfile(base/'small-superpage-candidate/bin/initdb',root/'bin/initdb');(root/'bin/initdb').chmod(0o755);shutil.copytree(base/'small-superpage-candidate/bin/share',root/'bin/share')
for n in ['small-superpage-profile-symbol-build.log','small-superpage-profile-link.map','build_small_superpage_symbols.py']:shutil.copyfile(base/n,root/n)
def sections(p):
 with p.open('rb') as f:
  h=f.read(64);assert h[:6]==b'\x7fELF\x02\x01';off=struct.unpack_from('<Q',h,40)[0];sz,num,names=struct.unpack_from('<HHH',h,58);f.seek(off);rows=[struct.unpack('<IIQQQQIIQQ',f.read(sz)) for _ in range(num)];r=rows[names];f.seek(r[4]);strings=f.read(r[5]);out={}
  for r in rows:
   name=strings[r[0]:].split(b'\0',1)[0].decode()
   if name in ['.text','.rodata','.data','.symtab']:
    f.seek(r[4]);out[name]={'address':r[3],'offset':r[4],'bytes':r[5],'sha256':hashlib.sha256(f.read(r[5])).hexdigest()}
  return out
old=base/'small-superpage-candidate/bin/postgres';new=root/'bin/postgres';before=sections(old);after=sections(new);assert '.symtab' in after
manifest={'purpose':'rejected small-superpage candidate with symbols for CPU diagnosis; not performance evidence','source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'binary_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'reference_binary_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'before_sections':before,'after_sections':after,'same_text':before['.text']==after['.text'],'same_rodata':before['.rodata']==after['.rodata']}
for name,path in [('before_build_id',old),('after_build_id',new)]:manifest[name]=subprocess.check_output(['readelf','-n',str(path)],text=True).split('Build ID: ')[1].splitlines()[0].strip()
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest))
