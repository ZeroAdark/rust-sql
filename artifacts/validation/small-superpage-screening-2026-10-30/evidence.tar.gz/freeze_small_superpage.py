from pathlib import Path
import subprocess,hashlib,json,shutil
base=Path('/home/rustsql');repo=base/'pgrust';root=base/'small-superpage-candidate';assert not root.exists();(root/'bin').mkdir(parents=True)
files=subprocess.check_output(['git','diff','--name-only','--','crates','Cargo.toml','Cargo.lock'],cwd=repo,text=True).splitlines();assert len(files)==7,files
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
patch=subprocess.check_output(['git','diff','--binary','HEAD','--',*files],cwd=repo);(root/'candidate.patch').write_bytes(patch)
for name in ['postgres','initdb']:
 shutil.copyfile(repo/'target/release'/name,root/'bin'/name);(root/'bin'/name).chmod(0o755)
shutil.copytree(base/'pool-config-fixed-candidate/bin/share',root/'bin/share')
for name in files:
 p=root/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,p)
for name in ['small-superpage-unit.log','small-superpage-tests.log','small-superpage-build.log']:shutil.copyfile(base/name,root/name)
manifest={'source_head':head,'runtime_patch_sha256':hashlib.sha256(patch).hexdigest(),'runtime_source_sha256':{n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in files},'binaries':{n:hashlib.sha256((root/'bin'/n).read_bytes()).hexdigest() for n in ['postgres','initdb']},'qualified':False};(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest))
