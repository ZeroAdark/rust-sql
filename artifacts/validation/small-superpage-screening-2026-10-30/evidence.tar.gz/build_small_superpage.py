from pathlib import Path
import subprocess,os,resource
base=Path('/home/rustsql');env=os.environ.copy();env['PATH']=str(base/'.cargo/bin')+':'+env['PATH'];resource.setrlimit(resource.RLIMIT_STACK,(65520*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
commands=[('unit',['cargo','test','--locked','--release','-j','2','-p','pagepool','--features','global','--lib','--','--test-threads=1']),('tests',['cargo','test','--locked','--release','-j','2','-p','pagepool','--features','global','--','--test-threads=1']),('build',['cargo','build','--locked','--release','-j','2','-p','main_main','-p','initdb'])]
for label,cmd in commands:
 with (base/('small-superpage-'+label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=base/'pgrust',env=env,stdout=log,stderr=subprocess.STDOUT)
 print(label,r.returncode,flush=True)
 if r.returncode: print((base/('small-superpage-'+label+'.log')).read_text()[-7000:],flush=True)
 r.check_returncode()
