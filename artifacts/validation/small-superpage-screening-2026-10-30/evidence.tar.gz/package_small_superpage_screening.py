from pathlib import Path
import hashlib,json,statistics,tarfile,io,shutil
base=Path('/home/rustsql');repo=base/'pgrust';destination=repo/'artifacts/validation/small-superpage-screening-2026-10-30'
phases=['capacity','medium'];rollup={};members={}
for phase in phases:
 root=base/f'small-superpage-{phase}-20261030';source=base/(root.name+'-source')
 summary=json.loads((root/'summary.json').read_text());assert summary['complete'] and summary['passed'] and len(summary['trials'])==15
 meta=json.loads((root/'metadata.json').read_text());assert meta['binary_sha256']['rustsql']=='c01c29f2f75102699fda0d9799b4fc68c3bcad480a90ecadc1d641f32c43ec28'
 assert meta['binary_sha256']['postgresql']=='07b16e1aa4f0e2206c37b339b6e4cc813aa8ab9e3c5516334f753b3d90d0c536'
 for name,sha in meta['source_lf_sha256'].items():assert hashlib.sha256((source/name).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==sha
 for p in [*root.glob('*.json'),*source.glob('*.py'),base/(root.name+'.log'),base/(root.name+'-command.json'),base/(root.name+'-journal.log')]:members[str(p.relative_to(base))]=p.read_bytes()
 rollup[phase]={}
 for engine in ['postgresql','rustsql-baseline','rustsql']:
  reports=[json.loads((root/f'{phase}-{engine}-{i}.json').read_text()) for i in range(1,6)];assert len(reports)==5
  for d in reports:
   m=d['measurement'];assert d['passed'] and m['passed'] and d['shutdown_exit_codes']==[0,0] and not d['remaining_server_pids']
   assert d['state_after_restart']==d['state_before_restart']
   settings={n:s for n,s,_ in d['settings']};assert settings['fsync']=='on' and settings['synchronous_commit']=='on'
   assert d['limits']['cpu.max']=='400000 100000' and d['limits']['memory.max']==str(2048*2**20) and d['limits']['memory.swap.max']=='0'
   assert not any(d['resources_after_shutdown']['events'][n] for n in ['oom','oom_kill','oom_group_kill','max'])
   assert m['cpu_delta']['nr_throttled']==0 and m['client_cpu_delta']['nr_throttled']==0 and not d['resources_after_shutdown']['memory_swap_current']
   assert d['state_after_restart']['committed_updates']==meta['clients']*(meta['bundles']+meta['warmup'])*4
   for kind,n in (meta['statements_per_bundle']|{'bundle':1}).items():
    l=m['latency'][kind];assert l['count']==meta['clients']*meta['bundles']*n and 0<=l['p50_ms']<=l['p95_ms']<=l['p99_ms']<=l['max_ms']
   assert abs(m['server_cpu_us_per_bundle']-m['cpu_delta']['usage_usec']/(meta['clients']*meta['bundles']))<1e-6
   assert abs(m['bundles_per_second']-meta['clients']*meta['bundles']/m['elapsed_seconds'])<1e-6
   if phase=='medium':
    assert m['offered_bundles_per_second']==9.4 and m['schedule_lag']['count']==meta['clients']*meta['bundles']
    assert m['schedule_lag']['max_ms'] < 1000*meta['clients']/9.4
   cluster=Path(d['cluster'])
   for name in ['server.log','initdb.log','data/postgresql.conf','data/pg_hba.conf']:
    path=cluster/name;members[f'clusters/{phase}-{engine}-{d["repetition"]}/{name}']=path.read_bytes()
  ms=[d['measurement'] for d in reports]
  metrics={'cpu_ms_per_bundle':lambda m:m['server_cpu_us_per_bundle']/1000,'statements_per_second':lambda m:m['bundles_per_second']*19,
   'server_cpu_percent_of_four_cores':lambda m:m['server_cpu_seconds']/m['elapsed_seconds']/4*100,
   'client_cpu_percent_of_two_cores':lambda m:m['client_cpu_delta']['usage_usec']/1e6/m['elapsed_seconds']/2*100,
   'peak_cgroup_mib':lambda m:m['sampled_resources']['sampled_memory_current_peak_bytes']/2**20,
   'peak_process_pss_mib':lambda m:m['sampled_resources']['sampled_summed_pss_peak_bytes']/2**20}
  if phase=='medium':metrics['schedule_lag_p99_ms']=lambda m:m['schedule_lag']['p99_ms']
  for kind in ['read','update','aggregate','range','join','bundle']:
   for pct in ['p50','p95','p99']:metrics[kind+'_'+pct+'_ms']=lambda m,k=kind,p=pct:m['latency'][k][p+'_ms']
  rollup[phase][engine]={k:{'median':statistics.median(f(m) for m in ms),'minimum':min(f(m) for m in ms),'maximum':max(f(m) for m in ms)} for k,f in metrics.items()}

for name in ['run_bounded_small_comparison.py','review_three_engine.py','compare_small_pages_connections.py','run_small_superpage_connections.py','small_pages_queue_probe.py','small-superpage-connection-comparison.json','small-superpage-candidate-correctness.json','small-superpage-candidate-correctness.log','build_small_superpage.py','freeze_small_superpage.py','run_small_superpage_candidate.py','package_small_superpage_screening.py']:
 members[name]=(base/name).read_bytes()
for p in (base/'small-superpage-candidate').rglob('*'):
 if p.is_file() and 'bin' not in p.relative_to(base/'small-superpage-candidate').parts:members[str(p.relative_to(base))]=p.read_bytes()
root=base/'small-superpage-connection-calibration-20261030'
for p in root.rglob('*'):
 if p.is_file():members[str(p.relative_to(base))]=p.read_bytes()
for label in ['baseline','candidate']:
 for i in range(1,6):
  d=json.loads((root/f'{label}-{i}.json').read_text())
  for n in ['server.log','initdb.log','data/postgresql.conf','data/pg_hba.conf']:members[f'clusters/connection-{label}-{i}/'+n]=(Path(d['cluster'])/n).read_bytes()
d=json.loads((base/'small-superpage-candidate-correctness.json').read_text())
assert d['passed'] and d['engines']['postgresql']['result']==d['engines']['rustsql']['result']
for engine,v in d['engines'].items():
 for n in ['server.log','initdb.log']:members['clusters/bind-correctness/'+engine+'/'+n]=(Path(v['cluster'])/n).read_bytes()
members['validation/bind_lifecycle_probe.py']=(repo/'scripts/validation/bind_lifecycle_probe.py').read_bytes()
for label in ['small-superpage-connection-profile-20261030','small-superpage-connection-profile-v2-20261030','retained-connection-profile-20261030']:
 for p in (base/label).iterdir():
  if p.is_file() and p.suffix in ('.txt','.json','.log'):members[str(p.relative_to(base))]=p.read_bytes()
 for suffix in ['.json','.log','-command.json','-journal.log']:members[label+suffix]=(base/(label+suffix)).read_bytes()
for name in ['profile_small_superpage_connections.py','run_small_superpage_profile.py','build_small_superpage_symbols.py','freeze_small_superpage_symbols.py','profile_small_superpage_connections_v2.py','run_small_superpage_profile_v2.py','profile_retained_connections.py','run_retained_connection_profile.py','small-superpage-profile-analysis.json']:
 members[name]=(base/name).read_bytes()
for name in ['manifest.json','small-superpage-profile-symbol-build.log']:
 members['small-superpage-profile-symbols-candidate/'+name]=(base/'small-superpage-profile-symbols-candidate'/name).read_bytes()
members['point-profile-symbols-candidate/manifest.json']=(base/'point-profile-symbols-candidate/manifest.json').read_bytes()
destination.mkdir(parents=True,exist_ok=False)
with tarfile.open(destination/'evidence.tar.gz','w:gz') as archive:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(data))
manifest={'members':{n:hashlib.sha256(b).hexdigest() for n,b in sorted(members.items())},'archive_sha256':hashlib.sha256((destination/'evidence.tar.gz').read_bytes()).hexdigest()}
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(destination/'results.json').write_text(json.dumps(rollup,indent=2)+'\n')
shutil.copyfile(base/'small-superpage-connection-comparison.json',destination/'connection-results.json')
print(json.dumps({'destination':str(destination),'members':len(members),'archive_bytes':(destination/'evidence.tar.gz').stat().st_size}))
