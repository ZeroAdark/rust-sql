from pathlib import Path
import subprocess,json
b=Path('/home/rustsql');label='retained-connection-profile-20261030'
cmd=['systemd-run','--unit=rustsql-qualification-'+label,'--uid=rustsql','--gid=rustsql','--collect','--wait','--property=Delegate=cpu memory pids','--property=MemoryMax=8G','--property=MemorySwapMax=0','--property=CPUQuota=600%','--property=LimitSTACK=67108864','--property=RuntimeMaxSec=180','--property=StandardOutput=append:'+str(b/(label+'.log')),'--property=StandardError=append:'+str(b/(label+'.log')),'/usr/bin/python3','-u',str(b/'profile_retained_connections.py'),'--candidate',str(b/'point-profile-symbols-candidate/bin'),'--work-dir',str(b/'conformance'),'--output',str(b/(label+'.json')),'--burst','--memory-mib','4096']
r=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=210)
(b/(label+'-command.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode,'output':r.stdout},indent=2)+'\n')
(b/(label+'-journal.log')).write_bytes(subprocess.check_output(['journalctl','-u','rustsql-qualification-'+label+'.service','--no-pager','-o','short-iso']))
print(label,r.returncode,flush=True);print((b/(label+'.log')).read_text()[-2000:],flush=True);r.check_returncode()
