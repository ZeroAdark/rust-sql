import sys, hashlib
from pathlib import Path
sys.path.insert(0, '/home/rustsql/pgrust/scripts/validation')
import connection_queue_probe as probe
witnesses=[]
class HearthCluster(probe.Cluster):
    def __init__(self,*a,**kw):
        kw['allocator']='hearth'
        super().__init__(*a,**kw)
    def start(self):
        super().start()
        with probe.psycopg.connect(self.dsn,autocommit=True) as conn:
            actual=conn.execute('SHOW pgrust.allocator').fetchone()[0]
        assert actual=='hearth'
        witnesses.append(actual)
probe.Cluster=HearthCluster
original=probe.run_burst
def run_burst(args,report):
    try:
        original(args,report)
    finally:
        report['allocator']={'requested':'hearth','live_witnesses':witnesses}
        report['wrapper_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
probe.run_burst=run_burst
probe.main()
