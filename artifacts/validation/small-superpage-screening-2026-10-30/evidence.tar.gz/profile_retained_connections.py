import sys,hashlib,subprocess,signal,time,json
from pathlib import Path
sys.path.insert(0,'/home/rustsql/pgrust/scripts/validation')
import connection_queue_probe as probe
root=Path('/home/rustsql/retained-connection-profile-20261030');root.mkdir(exist_ok=False)
witnesses=[];profiles=[]
class ProfileCluster(probe.Cluster):
 def __init__(self,*a,**kw):
  kw['allocator']='hearth';super().__init__(*a,**kw);self.perf=None
 def start(self):
  super().start()
  with probe.psycopg.connect(self.dsn,autocommit=True) as c:actual=c.execute('SHOW pgrust.allocator').fetchone()[0]
  assert actual=='hearth';witnesses.append(actual)
  self.perf_log=(root/'perf-record.log').open('w')
  pids=Path(self.launcher[2],'cgroup.procs').read_text().split();assert str(self.process.pid) in pids
  cmd=['/usr/lib/linux-tools-6.8.0-147/perf','record','-e','cpu-clock:u','-F','199','--call-graph','dwarf,8192','-p',','.join(pids),'-o',str(root/'perf.data')]
  self.perf=subprocess.Popen(cmd,stdout=self.perf_log,stderr=subprocess.STDOUT)
  profiles.append({'command':cmd,'server_pids':pids})
  time.sleep(.2);assert self.perf.poll() is None
 def stop(self,crash=False):
  if self.perf is not None:
   self.perf.send_signal(signal.SIGINT);rc=self.perf.wait(timeout=30);self.perf_log.close();self.perf=None;profiles[-1]['exit']=rc
   assert rc in (0,-2,130),rc
  super().stop(crash=crash)
probe.Cluster=ProfileCluster
original=probe.run_burst
def run_burst(args,report):
 try:original(args,report)
 finally:
  report['purpose']='diagnostic CPU sample; timings and resource costs are not performance evidence'
  report['allocator']={'requested':'hearth','live_witnesses':witnesses}
  report['wrapper_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
  report['profiles']=profiles
probe.run_burst=run_burst
probe.main()
