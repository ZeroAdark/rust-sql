from pathlib import Path
import json,statistics,hashlib,sys
root=Path(sys.argv[1]);phase=sys.argv[2];meta=json.loads((root/'metadata.json').read_text());summary=json.loads((root/'summary.json').read_text())
assert summary['complete'] and summary['passed'] and len(summary['trials'])==20
engines=('postgresql','rustsql-baseline','rustsql-prior-policy','rustsql')
assert set(meta['binary_sha256'])==set(engines)
assert meta['binary_sha256']['rustsql-baseline']==meta['binary_sha256']['rustsql-prior-policy']=='8e5bfc2b093055a5d2257dc817037a2b2f2906faf7c1b83e431f472a2f0513f0'
assert meta['binary_sha256']['rustsql']!=meta['binary_sha256']['rustsql-baseline']
assert meta['candidate_policy']=='pool_warm_zero_max=16777216,pool_decay_ms=200'
for name,sha in meta['source_lf_sha256'].items():assert hashlib.sha256((root.with_name(root.name+'-source')/name).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==sha
trials=[]
for engine in engines:
 for i in range(1,6):
  d=json.loads((root/f'{phase}-{engine}-{i}.json').read_text());m=d['measurement'];trials.append(d)
  assert d['engine']==engine and d['repetition']==i and d['phase']==phase
  assert d['passed'] and m['passed'] and d['state_before_restart']==d['state_after_restart'] and d['shutdown_exit_codes']==[0,0] and not d['remaining_server_pids']
  policy=meta['candidate_policy'] if engine in ('rustsql','rustsql-prior-policy') else ''
  assert d['requested_policy']==policy and d['live_policy_env']==(['PGRUST_MEMPOLICY='+policy] if policy else [])
  assert not any(m['memory_event_delta'].values())
  for key in ['cpu_delta','client_cpu_delta']:assert m[key]['nr_throttled']==0 and m[key]['throttled_usec']==0,(engine,i,key,'throttled')
  assert not d['resources_after_shutdown']['memory_swap_current']
  assert not any(d['resources_after_shutdown']['events'][key] for key in ['max','oom','oom_kill','oom_group_kill'])
  settings={n:v for n,v,_ in d['settings']};assert settings['fsync']==settings['synchronous_commit']=='on' and settings['max_parallel_workers_per_gather']=='2'
  assert d['state_after_restart']['committed_updates']==meta['clients']*(meta['bundles']+meta['warmup'])*4
  for kind,n in (meta['statements_per_bundle']|{'bundle':1}).items():assert m['latency'][kind]['count']==meta['clients']*meta['bundles']*n
getters={'cpu_ms_per_bundle':lambda m:m['server_cpu_us_per_bundle']/1000,'sql_per_second':lambda m:m['bundles_per_second']*19,'charged_peak_mib':lambda m:m['sampled_resources']['sampled_memory_current_peak_bytes']/2**20,'pss_peak_mib':lambda m:m['sampled_resources']['sampled_summed_pss_peak_bytes']/2**20}
for kind in ('read','update','aggregate','range','join','bundle'):getters[kind+'_p99_ms']=lambda m,k=kind:m['latency'][k]['p99_ms']
result={'phase':phase,'trials':len(trials),'engines':{}}
for engine in engines:
 arm=[d for d in trials if d['engine']==engine]
 result['engines'][engine]={name:statistics.median(fn(d['measurement']) for d in arm) for name,fn in getters.items()}
for label,control in [('candidate_change_percent','rustsql-baseline'),('prior_policy_change_percent','rustsql-prior-policy')]:
 result[label]={k:100*(result['engines']['rustsql'][k]/v-1) for k,v in result['engines'][control].items()}
result['preservation_failures']=[k for k,v in result['candidate_change_percent'].items() if (k=='sql_per_second' and phase=='capacity' and v < -5) or ((k=='cpu_ms_per_bundle' or k.endswith('_p99_ms')) and v>5)]
(root/'four-engine-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
