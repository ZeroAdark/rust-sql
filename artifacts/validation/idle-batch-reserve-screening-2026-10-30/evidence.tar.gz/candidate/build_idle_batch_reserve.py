from pathlib import Path
import subprocess,os,resource
base=Path('/home/rustsql');env=os.environ.copy();env['PATH']=str(base/'.cargo/bin')+':'+env['PATH'];resource.setrlimit(resource.RLIMIT_STACK,(65520*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
with (base/'idle-batch-reserve-build.log').open('w') as log:r=subprocess.run(['cargo','build','--locked','--release','-j','2','-p','main_main','-p','initdb'],cwd=base/'pgrust',env=env,stdout=log,stderr=subprocess.STDOUT)
print('build',r.returncode,flush=True)
if r.returncode:print((base/'idle-batch-reserve-build.log').read_text()[-7000:])
r.check_returncode()
