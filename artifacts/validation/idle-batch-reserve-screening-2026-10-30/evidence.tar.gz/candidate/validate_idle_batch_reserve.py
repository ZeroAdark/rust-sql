from pathlib import Path
import subprocess,os,hashlib,json,re
repo=Path('/home/rustsql/pgrust');base=Path('/home/rustsql');source=repo/'crates/_support/pagepool/src/central.rs'
env=os.environ.copy();env['PATH']='/home/rustsql/.cargo/bin:'+env['PATH'];env['RUST_MIN_STACK']='33554432'
positive=source.read_bytes();needle=b'pub(crate) fn take_excess(k: Key, f: impl FnMut(Batch)) {\n    drain(k, true, f);\n}'
assert positive.count(needle)==1
negative=positive.replace(needle,needle.replace(b'true',b'false'))
expected='a recently used key keeps exactly one ready batch'
try:
 source.write_bytes(negative)
 with (base/'idle-batch-reserve-negative-control.log').open('wb') as log:
  r=subprocess.run(['cargo','test','--locked','--release','-j','2','-p','pagepool','--features','global','--lib','tests::pool_kernels'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 assert r.returncode==101 and expected in (base/'idle-batch-reserve-negative-control.log').read_text()
finally:
 source.write_bytes(positive)
control={'passed':True,'exit':r.returncode,'expected_failure':expected,'positive_source_sha256':hashlib.sha256(positive).hexdigest(),'negative_source_sha256':hashlib.sha256(negative).hexdigest(),'positive_restored':source.read_bytes()==positive}
(base/'idle-batch-reserve-negative-control.json').write_text(json.dumps(control,indent=2)+'\n');print('negative control verified and source restored',flush=True)
with (base/'idle-batch-reserve-tests.log').open('wb') as log:
 r=subprocess.run(['cargo','test','--locked','--release','-j','2','-p','pagepool','--features','global'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
r.check_returncode()
counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (base/'idle-batch-reserve-tests.log').read_text())
result={'passed':True,'summaries':len(counts),'passed_tests':sum(int(x[0]) for x in counts),'failed_tests':sum(int(x[1]) for x in counts),'ignored_tests':sum(int(x[2]) for x in counts)}
assert result['summaries']==85 and result['passed_tests']==117 and result['failed_tests']==0 and result['ignored_tests']==1
(base/'idle-batch-reserve-tests.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
