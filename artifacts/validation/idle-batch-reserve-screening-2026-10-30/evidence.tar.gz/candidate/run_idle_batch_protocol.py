from pathlib import Path
from types import SimpleNamespace
import sys,resource,hashlib,json
base=Path('/home/rustsql');sys.path.insert(0,str(base/'pgrust/scripts/validation'))
import bind_lifecycle_probe as probe
resource.setrlimit(resource.RLIMIT_STACK,(65520*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
Original=probe.CheckedCluster
policy='';witnesses=[]
class PolicyCluster(Original):
 def __init__(self,*a,**kw):
  super().__init__(*a,**kw)
  if not self.reference and policy:self.env['PGRUST_MEMPOLICY']=policy
 def start(self):
  super().start()
  live=[v.decode() for v in Path('/proc',str(self.process.pid),'environ').read_bytes().split(b'\0') if v.startswith(b'PGRUST_MEMPOLICY=')]
  assert live==(['PGRUST_MEMPOLICY='+policy] if not self.reference and policy else [])
  witnesses.append({'reference':self.reference,'live_policy_env':live})
probe.CheckedCluster=PolicyCluster
out={'passed':False,'cases':{},'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path(probe.__file__)]}}
for name,policy in [('default',''),('fast','pool_warm_zero_max=16777216,pool_decay_ms=200')]:
 witnesses=[]
 report=probe.run(SimpleNamespace(candidate=base/'idle-batch-reserve-candidate/bin',reference=base/'postgres18/bin',work_dir=base/'conformance'))
 out['cases'][name]={'policy':policy,'witnesses':witnesses,'report':report}
 (base/'idle-batch-reserve-protocol.json').write_text(json.dumps(out,indent=2)+'\n')
 assert report['passed'],report
 assert len(witnesses)==2
out['passed']=True;(base/'idle-batch-reserve-protocol.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'passed':True,'cases':len(out['cases']),'checks_per_case':8,'committed_updates_per_engine_per_case':192}))
