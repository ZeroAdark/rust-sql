from pathlib import Path
import gzip,tarfile,io,json,hashlib,subprocess,re,shutil,sys,copy
base=Path('/home/rustsql');repo=base/'pgrust';out=repo/'artifacts/validation/allocator-small-pages-2026-10-30';out.mkdir(parents=True,exist_ok=False)
files={}
def add(name,path):
    assert name not in files and not name.startswith('/') and '..' not in Path(name).parts
    files[name]=Path(path).read_bytes()
def tree(prefix,path):
    for p in sorted(Path(path).rglob('*')):
        if p.is_file():add(prefix+'/'+p.relative_to(path).as_posix(),p)
def unit(name):
    text=(base/name).read_text();m=[tuple(map(int,x)) for x in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)]
    return {'executables':len(m),'passed':sum(x[0] for x in m),'failed':sum(x[1] for x in m),'ignored':sum(x[2] for x in m)}
retained=unit('small-pages-retained-pool-tests-20261030.log');assert retained=={'executables':82,'passed':112,'failed':0,'ignored':1},retained
candidate=unit('small-pages-pool-tests-final-20261030.log');assert candidate=={'executables':83,'passed':113,'failed':0,'ignored':1}
for name in ['small-pages-frame-ci-command-20261030.log','small-pages-negative-unit-20261030.log','small-pages-positive-unit-20261030.log','small-pages-pool-tests-20261030.log','small-pages-pool-tests-complete-20261030.log','small-pages-focused-final-20261030.log','small-pages-pool-tests-final-20261030.log','small-pages-retained-pool-tests-20261030.log','small-pages-build-20261030.log']:add('logs/'+name,base/name)
tree('controls',base/'small-pages-controls-20261030')
for p in ['candidate.patch','manifest.json']:add('candidate/'+p,base/'small-pages-candidate'/p)
tree('candidate/source',base/'small-pages-candidate/source')
add('baseline/manifest.json',base/'connection-queue-fixed/manifest.json')
for name in ['build_small_pages.py','small_pages_queue_probe.py','run_small_pages_connection_comparison.py','compare_small_pages_connections.py','package_small_pages_evidence.py']:add('source/'+name,base/name)
sourceeq={}
for p in ['crates/_support/pagepool/src/os.rs','crates/_support/pagepool/src/run.rs','crates/_support/pagepool/src/small.rs']:
    sourceeq[p]=(repo/p).read_bytes()==subprocess.check_output(['git','show','HEAD:'+p],cwd=repo)
assert all(sourceeq.values())
files['retained.patch']=subprocess.check_output(['git','diff','--','.github/workflows/validation.yml','crates/_support/pagepool/tests/frames.rs'],cwd=repo)
def cluster(prefix,report):
    root=Path(report['cluster'])
    for name in ['server.log','initdb.log']:add(prefix+'/'+name,root/name)
for path in sorted((base/'small-pages-calibration-20261030').glob('*.json')):
    add('mixed/'+path.name,path)
    if path.name.startswith(('baseline-','candidate-')):cluster('mixed/clusters/'+path.stem,json.loads(path.read_text()))
tree('mixed/source',base/'small-pages-calibration-source-20261030')
add('mixed/comparison.json',base/'small-pages-calibration-comparison-20261030.json')
for name in ['small-pages-calibration-20261030.log','small-pages-calibration-journal-20261030.log']:add('mixed/'+name,base/name)
tree('connection',base/'small-pages-connection-calibration-20261030')
for path in sorted((base/'small-pages-connection-calibration-20261030').glob('*.json')):
    if path.stem.startswith(('baseline-','candidate-')):cluster('connection/clusters/'+path.stem,json.loads(path.read_text()))
add('connection/comparison.json',base/'small-pages-connection-comparison-20261030.json')
pressure=[]
for name in ['small-pages-2g-20261030','small-pages-baseline-2g-20261030','small-pages-repeat2-2g-20261030','small-pages-repeat3-2g-20261030']:
    for ext in ['json','log']:add('pressure/'+name+'.'+ext,base/(name+'.'+ext))
    d=json.loads((base/(name+'.json')).read_text());cluster('pressure/clusters/'+name,d)
    assert not d['remaining_server_pids']
    pressure.append({'name':name,'passed':d['passed'],'waves':len(d.get('waves',[])),'peak_mib':d['resources_after_shutdown']['memory_peak']/1048576,'events':d['resources_after_shutdown']['events']})
for path in [base/'small-pages-2g-journal-20261030.log',*base.glob('small-pages-*-2g-20261030-journal.log'),base/'small-pages-pressure-commands-20261030.json']:add('pressure/'+path.name,path)
assert [p['passed'] for p in pressure]==[True,False,True,True]
sys.path.insert(0,str(base));import compare_small_pages_connections as cc
conn=cc.analyze(base/'small-pages-connection-calibration-20261030')
assert conn==json.loads((base/'small-pages-connection-comparison-20261030.json').read_text())
m=json.loads((base/'small-pages-connection-calibration-20261030/metadata.json').read_text());good=json.loads((base/'small-pages-connection-calibration-20261030/baseline-1.json').read_text())
tamper={}
for name,mutate in [('wrong_binary',lambda r:r.update(binary_sha256='0'*64)),('wrong_limit',lambda r:r['limits'].update({'memory.max':'2147483648'})),('missing_startup',lambda r:r['waves'][0].update(accepted=799))]:
    r=copy.deepcopy(good);mutate(r)
    try:cc.validate(r,m,'baseline')
    except ValueError:tamper[name]=True
    else:raise AssertionError('accepted '+name)
mixed=json.loads((base/'small-pages-calibration-comparison-20261030.json').read_text())
checks={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'candidate_accepted':False,'production_qualified':False,'retained_allocator_tests':retained,'experimental_allocator_tests':candidate,'runtime_sources_restored_to_parent':sourceeq,'connection_source_and_report_validation':True,'connection_validation_rejects_tampering':tamper,'connection_all_pairs_more_cpu':conn['all_pairs_more_cpu'],'mixed_evidence_valid':mixed['evidence_valid'],'mixed_measured_statements':mixed['measured_statements'],'pressure':pressure,'scope':'Rejected runtime experiment; only frame test/CI/docs retained. Runtime remains the previously qualified-scope connection-queue binary.'}
(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');(out/'mixed-comparison.json').write_bytes((base/'small-pages-calibration-comparison-20261030.json').read_bytes());(out/'connection-comparison.json').write_bytes((base/'small-pages-connection-comparison-20261030.json').read_bytes())
archive=out/'evidence.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as tar:
            for name,data in sorted(files.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
manifest={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files),'uncompressed_bytes':sum(map(len,files.values())),'files':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())}}
with tarfile.open(archive,'r:gz') as tar:
    assert len(tar.getmembers())==len(files)
    for member in tar:
        assert member.isfile() and member.name in files and tar.extractfile(member).read()==files[member.name]
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
win=Path('/mnt/c/Users/DarkMoon/Desktop/Rust SQL/pgrust')/out.relative_to(repo);win.mkdir(parents=True,exist_ok=False)
for p in out.iterdir():shutil.copyfile(p,win/p.name)
print(json.dumps({k:v for k,v in manifest.items() if k!='files'}),flush=True)
