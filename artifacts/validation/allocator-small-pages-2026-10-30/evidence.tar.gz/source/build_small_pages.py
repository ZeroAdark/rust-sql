from pathlib import Path
import subprocess,resource,os,hashlib,json,shutil
resource.setrlimit(resource.RLIMIT_STACK,(67108864,resource.getrlimit(resource.RLIMIT_STACK)[1]))
repo=Path('/home/rustsql/pgrust');out=Path('/home/rustsql/small-pages-candidate/bin');out.mkdir(parents=True,exist_ok=False)
paths=['crates/_support/pagepool/'+p for p in ['src/os.rs','src/run.rs','src/small.rs','tests/sparse_small_pages.rs','tests/frames.rs']]
source_hashes={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
for p in paths:
 target=out.parent/'source'/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/p,target)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
with open('/home/rustsql/small-pages-build-20261030.log','w') as log:
 r=subprocess.run(['/home/rustsql/.cargo/bin/cargo','+1.96.0','build','--locked','--release','-j2','-p','main_main','-p','initdb'],cwd=repo,env=dict(os.environ,RUST_MIN_STACK='33554432'),stdout=log,stderr=subprocess.STDOUT)
print('build_exit',r.returncode,flush=True);r.check_returncode()
assert source_hashes=={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
assert head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
for name in ('postgres','initdb'):shutil.copyfile(repo/'target/release'/name,out/name);(out/name).chmod(0o755)
shutil.copytree('/home/rustsql/connection-queue-fixed/bin/share',out/'share')
manifest={'source_head':head,'binaries':{n:hashlib.sha256((out/n).read_bytes()).hexdigest() for n in ('postgres','initdb')},'source_lf_sha256':source_hashes}
(out.parent/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest),flush=True)
