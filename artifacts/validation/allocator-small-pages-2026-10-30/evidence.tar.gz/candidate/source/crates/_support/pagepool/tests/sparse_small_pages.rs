//! Small runs use base-page advice; cold runs avoid huge-page faults. Returned runs restore the pool policy.
#![cfg(all(feature = "global", target_os = "linux", not(miri)))]

mod common;
use std::alloc::{GlobalAlloc, Layout};
use pagepool::PoolAlloc;

fn flags(address: usize) -> String {
    let mut inside = false;
    for line in std::fs::read_to_string("/proc/self/smaps").unwrap().lines() {
        if let Some((lo, hi)) = line.split_whitespace().next().unwrap_or("").split_once('-')
            .and_then(|(a, b)| Some((usize::from_str_radix(a, 16).ok()?, usize::from_str_radix(b, 16).ok()?))) {
            inside = lo <= address && address < hi;
        } else if inside && line.starts_with("VmFlags:") {
            return line.to_string();
        }
    }
    panic!("missing pool mapping for {address:x}");
}

#[test]
fn sparse_runs_fault_base_pages_and_restore_advice_after_thread_exit() {
    common::setup();
    if pagepool::hooks::thp_never() {
        return; // No huge-page policy to distinguish on this host.
    }
    for _ in 0..2 {
        let addresses = std::thread::spawn(|| {
            let mut held = Vec::new();
            for size in [8, 64, 256, 1024] {
                let layout = Layout::from_size_align(size, 8).unwrap();
                // SAFETY: a valid nonzero layout; the block is released below.
                let p = unsafe { PoolAlloc.alloc(layout) };
                assert!(!p.is_null() && pagepool::owns(p));
                let vm = flags(p as usize);
                assert!(vm.split_whitespace().any(|v| v == "nh"), "small run still permits huge pages: {vm}");
                assert!(!vm.split_whitespace().any(|v| v == "hg"));
                // SAFETY: the allocator owns this writable block of `size` bytes.
                unsafe { p.write_bytes(0x5a, size) };
                held.push((p as usize, layout));
            }
            let superpage = held[0].0 & !(common::SUPER - 1);
            assert!(common::resident(superpage, common::SUPER) < common::SUPER / 2,
                    "sparse runs faulted a whole huge page before their first use");
            for &(address, layout) in &held {
                // SAFETY: our still-live allocation; check all bytes before returning it once.
                unsafe {
                    assert!(std::slice::from_raw_parts(address as *const u8, layout.size()).iter().all(|&b| b == 0x5a));
                    PoolAlloc.dealloc(address as *mut u8, layout);
                }
            }
            held.into_iter().map(|(address, _)| address).collect::<Vec<_>>()
        }).join().unwrap();
        for address in addresses {
            let vm = flags(address);
            assert!(vm.split_whitespace().any(|v| v == "hg"), "returned run lost the pool's huge-page policy: {vm}");
            assert!(!vm.split_whitespace().any(|v| v == "nh"));
        }
    }
}
